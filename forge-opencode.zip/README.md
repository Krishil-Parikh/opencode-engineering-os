# FORGE — three platform packages

Framework for Optimized and Reliable Generation Engineering. One portable core, three entry points.

| Package | Install into | Entry point | Agents |
|---|---|---|---|
| `forge-claude-code/` | `.claude/skills/forge/` + `.claude/agents/` | `/forge`, or auto-triggered | 11 subagents via the Task tool |
| `forge-opencode/` | `.opencode/skills/forge/` + `.opencode/agents/` + `.opencode/commands/` | `/forge`, `skill({id:"forge"})`, `@forge`, or the `forge` primary agent | 1 primary + 11 subagents via the `task` tool |
| `forge-github-copilot/` | `.github/skills/forge/` + `.github/agents/` + `.github/prompts/` | the `forge` agent in the picker, `/agent forge`, or `/forge` in VS Code | 1 user-invocable + 11 subagent-only custom agents |

Each package is self-contained: it carries its own copy of the twelve protocol documents, the thirteen
agent briefs, the eleven scripts, the five schemas, the report template and the runnable example. Read
the package's own `README.md` for install and platform notes.

The differences between the three are the frontmatter, the dispatch mechanism and the degraded-mode
notes. `SKILL.md`'s substance, and everything under `skills/forge/`, is identical.

A repository can hold more than one: OpenCode and Copilot both also discover skills from
`.claude/skills/`, so the Claude Code package's skill directory serves all three, and only the agent
definitions need copying per platform.

## Pairs with TRACE

FORGE makes sure the software being written is as simple and effective as possible; TRACE investigates
why software failed. They share an evidence discipline, a workspace convention and the right to refuse
an answer. Either works alone. See `skills/forge/core/integration_with_trace.md`.
