# FORGE report template

`scripts/report_generator.py` produces `final_report.md` from the task's records, so in normal operation you do not write this file by hand. This document exists for three reasons: to show what the generator produces and why, to give you the structure when the scripts are unavailable, and to say what belongs in `notes.md`, the one section the generator cannot write.

## Rules for the whole report

1. **The wording never exceeds the verdict.** `TIE_NEEDS_PRIORITIES` means there is a question, not a winner with an asterisk.
2. **Every number carries its spread, its size and its host.** A figure without them is not a measurement.
3. **Correctness is reported as a gate, never as a score.**
4. **Size is reported and never presented as a reason.**
5. **The losing candidates stay in the report**, with their measurements and the reasons they lost. Nothing is deleted to make the competition look tidier.
6. **No agent count, no process narrative.** The reader wants the decision, the evidence and what it cost.
7. **Unmeasured claims are labelled unmeasured.** Including in the notes.

## The structure

### Header

Verdict, selected candidate if there is one, candidate count and eligible count, the ranked axes, the ranking size, the noise floor, the spec hash. The verdict belongs at the top because it changes how every other line should be read.

### 1. Outcome

The verdict's meaning in one sentence, then the reasons from `decisions.json`, then either the selected implementation (path, strategy, author, rationale, declared trade-offs, dependencies) or, for `TIE_NEEDS_PRIORITIES`, **the question for the requester** in their terms.

For `NO_CANDIDATE_PASSES`, this section says what each candidate got wrong. That is a finding about the spec or the problem, and it is not softened.

### 2. What was asked for

The statement, the interface, the numbered contract clauses, the acceptance criteria with how each is decided, the constraints and non-goals, and the **baseline finding**: whether this already existed, what was searched, and why the existing thing was or was not sufficient.

A reader should be able to tell from this section alone whether the competition was asking the right question.

### 3. The candidates

One row each: strategy, what it is, dependencies, status. Retired candidates appear with their retirement reason, and derived candidates name their parent.

### 4. Mandatory gates

The candidate-by-gate matrix with an eligibility column, then one line describing each gate. Followed by the differential testing summary if there were disagreements, with the shrunk counterexample and which candidates returned what.

The shrunk case is worth printing in full. It is the most concrete thing in the report: a three-record input on which two implementations of one spec disagreed.

### 5. Measurements

Medians with interquartile spread, per size, per candidate. Then peak memory growth with the `tracemalloc` caveat. Then the measured scaling fits with their R² and a reading. Then the **noise calibration**: what identical code measured twice actually differed by. Then the host.

The calibration line is what entitles the rest of the section to be believed, so it is not optional.

### 6. Static analysis

sloc, cyclomatic total and worst, nesting, function count, dependencies, and the count of overengineering signals, per candidate; then the signals themselves. Followed by the sentence stating that size is reported and not ranked.

### 7. Adversarial review

Every challenge with its target, kind, severity, status and claim. Then each upheld, fixed or accepted-trade-off challenge in full, with its basis and its resolution evidence. Then the unresolved ones, which are reportable findings: a competition that ended with open questions.

### 8. Simplification pass

What was removed, the verification verdict, the regressions or improvements with figures, and the static change. Followed by the sentence stating that acceptance was mechanical.

If nothing could be removed, that is recorded too, with the questions answered.

### 9. Selection

The axis table with the front marked, the excluded candidates with the limits they broke, the unmeasured ones, the priorities and their source, and **the trade-off stated plainly** — including, where two candidates are equivalent on every ranked axis, a statement that they are equivalent and that something unmeasured should separate them.

### 10. What was not chosen, and why

Every candidate except the selected one, with its reasons: retired, failed a gate, upheld challenge, dominated, or on the front but not selected. Ending with the reminder that an approach that lost here lost against *this* spec, at *these* sizes, on *this* host.

### 11. Notes

Yours. See below.

## Writing `notes.md`

This is the only section the generator cannot produce, and it is where the report earns its keep. It is for the judgement the records imply but do not state.

What belongs here:

- **What the competition actually turned on.** Often not the thing the request was about. ("The cheapest step was the baseline question: the standard library already solved this, so the real question was whether anything could beat it.")
- **What surprised you, and why it was not predictable.** A measurement that contradicted the obvious reading of the code is the most valuable sentence in a FORGE report.
- **What the candidates got wrong in common.** When two independent implementations misread the same clause in the same direction, that is worth saying out loud: it is a fact about generated code, and it is why the differential oracle exists.
- **What the test suite missed, and how it was found.** Reading the design rather than the tests. This is the lesson that transfers.
- **Why a simplification was accepted or rejected**, where the figures alone do not make it obvious — for instance when the accepted simplification was *longer*.
- **What is still open**, and what would settle it.

What does not belong here:

- A recap of the tables.
- Any number that is not in the records.
- Praise for a candidate the measurements did not favour.
- A winner the verdict did not select.

**The notes must not contradict the data.** Check them against the tables before generating. A note saying "nothing beat the baseline" above a table showing something beating the baseline is the worst defect a FORGE report can have, because every other number becomes suspect.

## Writing the whole thing by hand

Keep the eleven sections and their order. Keep the verdict in the header and in section 1. Keep the spreads, the sizes and the host on every number. Keep the status column in section 4 and the reasons in section 10. Those are the parts that let someone who was not there check the decision, which is the only property that matters once you have gone.

The report ends with the guiding line, which is the standard it had to meet:

> Never accept the first working implementation. Generate alternatives, challenge them, measure them, simplify them and verify the winner.
