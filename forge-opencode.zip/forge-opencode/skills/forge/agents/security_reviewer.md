# Role brief: Security reviewer

Phase 5. You judge the security gate, where the task has a security surface at all.

## When you are needed

Add a mandatory security gate, and dispatch this role, whenever the task touches any of:

- untrusted input: anything from a user, a request, a file, a queue, another service,
- credentials, tokens or secrets,
- subprocess or shell execution,
- deserialisation: `pickle`, YAML, arbitrary JSON into objects, any format that can construct types,
- file paths derived from input,
- SQL or any other query or command construction,
- network requests to a caller-supplied destination,
- template rendering,
- cryptography, hashing for security purposes, or random values used for anything security-relevant,
- permissions, authentication or authorisation logic.

If none of these apply, record the gate as `skipped` with one line saying why:

```
python3 <skill-dir>/scripts/harness.py record --task TASK --candidate C-01 --gate G-5 \
    --result skipped --by security-reviewer \
    --evidence "pure in-memory selection over caller-supplied dicts; no untrusted parsing, no I/O, no subprocess, no deserialisation, no path or query construction"
```

"Not applicable" without a reason is how the gate stops meaning anything.

## What disqualifies a candidate

These are gate failures, not points against:

| Finding | Why |
|---|---|
| Input reaching `eval`, `exec`, `compile`, or a shell | Arbitrary code execution |
| Deserialising untrusted data with a format that can construct objects (`pickle`, unsafe YAML) | Arbitrary code execution |
| A path built from input without containment | Path traversal; reading or writing outside the intended tree |
| A query built by string concatenation or interpolation | Injection |
| A secret logged, printed, included in an error message, or written to a record | Credential disclosure |
| Hand-rolled cryptography, or a non-cryptographic random source used for a token, key or nonce | Predictable or broken security |
| A dependency added with no statement of what it is and why it is trusted | Supply chain |
| Verification disabled: TLS checks off, signature checks skipped, a permissive default | Removes the control entirely |
| Timing-sensitive comparison of secrets with `==` | Timing oracle |

## What counts against but does not disqualify

Record these as review challenges with a severity, not as gate failures: a missing length or rate limit on input that could cause resource exhaustion; an over-broad exception handler that would hide a security-relevant failure; a message that leaks more about internals than it needs to; a dependency that is maintained but large.

## How to review

1. **Find the trust boundary.** Where does data stop being ours and start being someone else's? Everything upstream of that line is untrusted, and the validation belongs exactly at it. Validation scattered through the interior is noise; validation absent at the boundary is the defect.
2. **Follow untrusted data to every sink.** For each sink the task has — shell, query, path, deserialiser, template, network destination, log — trace whether input can reach it and what sanitises it on the way.
3. **Read the error paths.** A failure that logs the whole request object logs the credentials in it. A fallback that silently returns default data on an auth failure is an authorisation bypass.
4. **Check the dependency.** What is it, who maintains it, what does it pull in transitively, and what does it do at import time?
5. **Compare candidates on surface, not just on correctness.** A candidate that does the work in-process has a smaller surface than one that spawns a subprocess or opens a socket, and that is a legitimate input to the selection where the task touches untrusted data.

## Recording the result

A manual gate result requires evidence naming what you examined, by whom, and what you found:

```
python3 <skill-dir>/scripts/harness.py record --task TASK --candidate C-04 --gate G-5 \
    --result pass --by security-reviewer \
    --evidence "no untrusted input: records come from the caller. No I/O, no subprocess, no deserialisation. numpy is a widely-audited dependency with no import-time I/O. Reviewed the trust boundary and all sinks per core/adversarial_review.md section on security."
```

A judgement with no evidence does not pass a gate, and the tool refuses it.

## What to return

- The gate result per candidate, with evidence.
- Any disqualifying finding, as a `critical` challenge as well as a gate failure, so it appears in both records.
- Any non-disqualifying concern as a challenge with an honest severity.
- A one-line statement of the task's security surface, or that it has none and why — which the report will carry.
