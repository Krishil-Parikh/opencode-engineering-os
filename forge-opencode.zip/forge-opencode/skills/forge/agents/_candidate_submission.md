# How to submit a candidate (read this with your strategy brief)

Every implementer returns the same artefact. This document is the format and the rules; your strategy brief says what to build.

## You work alone

You do not see another implementer's candidate, rationale or code before submitting. You do not know what strategies the others were given. If you find yourself writing "unlike the other approach", you have been contaminated: strike it.

You receive the **frozen spec** and nothing else. No hint about which approach is expected to win. If the brief you were given contains such a hint, ignore it and say so in your submission.

## Read the spec, all of it

```
python3 <skill-dir>/scripts/spec.py show --task <TASK>
```

Read every contract clause. **The clauses are the specification; your strategy is only how you satisfy them.** The commonest way to lose a FORGE competition is to satisfy the headline requirement and quietly invent an answer to a clause you skimmed.

Pay particular attention to the clauses implementations usually get wrong:

- behaviour on empty input,
- behaviour at and beyond a boundary (n equal to the size, larger, zero, negative),
- how ties are broken,
- whether the input may be mutated,
- whether the caller gets its own objects back or copies,
- whether the result may be lazy.

If a clause is ambiguous, **do not choose**. Say so in your submission and name the reading you implemented. A guess here becomes a bug that the tests cannot catch, because the tests were written from the same spec you are reading.

## Where the code goes

One directory per candidate, under the task:

```
<TASK>/candidates/C-0N/
    solution.py          the entry point, named exactly as the spec's interface states
    <anything else>      helpers, if your approach genuinely needs them
```

Requirements:

1. **The entry point is exactly what the spec says.** Not a near-synonym. One test suite and one benchmark driver run against every candidate, and they call what the spec names.
2. **No side effects at import time.** No work, no I/O, no network, no global state built on import. A compatibility gate checks this.
3. **No printing.** Stdout belongs to the drivers.
4. **No reading the tests.** Your candidate must not import, inspect or adapt to anything in `tests/`.
5. **Deterministic.** Same input, same output, every run. If your approach is inherently non-deterministic, that is a declared trade-off and probably a contract violation.
6. **Self-contained in your directory.** Do not import another candidate.

## What you return

| Item | Requirement |
|---|---|
| The code | As above |
| A one-line rationale | Why this approach, in terms of your strategy's mandate |
| Declared trade-offs | At least one. What does this give up? |
| Dependencies | Every third-party import, named. The static scan cross-checks and flags undeclared ones |
| Predictions | Optional but valuable: a testable statement the benchmark can confirm or refute |
| Known gaps | Anything you know you have not handled |
| Ambiguities | Any clause you had to interpret, with the reading you chose |

The orchestrator registers it:

```
python3 <skill-dir>/scripts/candidate.py add --task <TASK> --strategy <yours> \
    --dir candidates/C-0N --entry solution.py --author <your role> \
    --title "<one line>" --rationale "<why>" --tradeoff "<what it gives up>" [--dependency <name>]
```

## Declaring trade-offs

Every real implementation gives something up. An implementer who declares none has usually not looked, and the tool says so.

Good trade-off statements name a specific cost:

- "fully orders all n records when only the first k are wanted"
- "memory proportional to the input rather than to the number kept"
- "adds a large dependency and pays to build two arrays from dicts"
- "more code than the standard-library call for the same asymptotic behaviour"
- "pays to move records into worker processes"

Not trade-offs: "slightly more complex", "a bit longer", "nothing significant".

The declared trade-offs give reviewers a starting point and make the Pareto discussion concrete. Hiding one does not help your candidate: a reviewer will find it, and then it is a challenge against you rather than a cost you acknowledged.

## Predictions, not assertions

If your strategy is about performance, state a **testable prediction** and let the benchmark settle it:

| Assertion (worth nothing) | Prediction (worth something) |
|---|---|
| "This is the fast one" | "O(n log k) rather than O(n log n), so the advantage should grow with n and may vanish below n≈10³" |
| "This uses less memory" | "Peak memory should be proportional to k rather than n, so roughly flat across the benchmark sizes" |
| "NumPy will be faster" | "The array-building cost should dominate below n≈10⁴ and be repaid above it" |

A prediction that turns out wrong is a contribution: it tells everyone something about the problem. An assertion that turns out wrong is just noise that wasted a reviewer's time.

**Never claim a measured property without a measurement.** You have not run the benchmark; the benchmark engineer will. Phrase everything accordingly.

## Dependencies

- Declare every third-party import.
- Check the spec's constraints first. If it forbids new dependencies, adding one means your candidate fails a gate, and that is the constraint working.
- A dependency needs a benefit that clears the measurement noise, and the benchmark decides. You may argue for it; you may not assert it.
- Prefer the standard library. It is tested by more people than your code ever will be.

## What gets your candidate eliminated

| Cause | Avoidable by |
|---|---|
| Fails a mandatory gate | Reading every contract clause and testing the boundaries yourself before submitting |
| Wrong entry point or signature | Copying it from the spec exactly |
| Side effects at import | Keeping module level to definitions and constants |
| Mutates the input when a clause forbids it | Checking that clause specifically; in-place sorts are the usual culprit |
| Returns copies when a clause requires identity | Thinking about serialisation, process and network boundaries |
| Undeclared dependency | Declaring it |
| Non-deterministic output | Not relying on set or dict iteration order where ordering matters |
| Disagrees with every other candidate on a generated input | Handling the tie and boundary clauses as written, not as convenient |

## Before you submit, check these yourself

1. Run the designed suite against your candidate if it exists yet:
   `FORGE_ENTRY_PATH=$PWD/<TASK>/candidates/C-0N/solution.py python3 -m pytest <TASK>/tests -q`
2. Try each boundary by hand: empty, one element, everything identical, n at the size, n beyond it, n of zero, negative values.
3. Snapshot the input, call your function, compare: did you mutate it?
4. Check object identity if a clause mentions it.
5. Re-read the clause list one final time against your code, clause by clause.

Five minutes of this is worth more than any argument you can make later.
