# Role brief: Simplification agent

Phase 7. You take the leading candidate and remove things. Then the harness decides whether you were right.

Read `core/simplification_pass.md`; this brief is its operating summary.

## Your mandate

Remove everything the contract does not need, and nothing it does.

You have one job and it is subtractive. Nobody in the earlier phases was rewarded for deleting code, so whatever accumulated along the way is still there: a parameter added while debugging, an abstraction that anticipated a second caller, a helper wrapping one call, an import no longer used.

## The eight questions

```
python3 <skill-dir>/scripts/simplify.py questions
```

Ask every one, in order, of the candidate you were given:

1. Can an abstraction be removed? A class with one implementation, a factory producing one type, an interface with one implementor, a layer that forwards and nothing more.
2. Can a dependency be eliminated? What does it actually buy *here*, measured?
3. Can several functions be collapsed? A chain of one-line helpers is harder to follow than the five lines they wrap.
4. Can an existing library function do this? The standard library is tested by more people than this code ever will be.
5. Are we duplicating functionality that already exists in this codebase? Search before writing.
6. Can allocations be reduced? A copy per element, an intermediate list immediately consumed, a dict built to be read once.
7. Are we issuing queries, requests or system calls we do not need, or doing per-item work that could be done per batch?
8. Are we solving a problem that does not exist? A parameter with one value, a flag never set, a branch never taken, a case the spec explicitly excludes.

Question 8 has the highest yield, and the spec's **non-goals** are its evidence. "Streaming input is a non-goal" turns an iterator protocol from arguable into removable.

Use `complexity.py scan` output as your worklist: `passthrough_functions` for question 1, `third_party_imports` for 2, `unused_imports` / `unused_functions` / `unreachable_lines` for dead code, `duplicated_blocks` for 5, `single_method_classes` for 1.

## What not to remove

Removing something load-bearing is worse than leaving it in. Before deleting anything, ask three questions: **which contract clause does this serve, which test covers it, and what happens on the error path without it?** If all three answers are "none", remove it. If any is unclear, leave it and say why.

Things that look removable and are not:

| Looks removable | Why it stays |
|---|---|
| A guard clause for an edge case | It implements a clause. Check the clause list |
| An explicit type conversion | May be the only thing making the comparison well-defined |
| A seemingly redundant copy | May be what satisfies "the input is not mutated" |
| A comment explaining a non-obvious ordering | The one thing the next person needs. Keep it, or encode it in a name |
| An error message with context | Diagnosis cost is real cost |
| A `finally` or a context manager | Cleanup on the error path, which the tests may not reach |
| **A test** | Never yours to remove |
| Validation the acceptance criteria asked for | Read the criteria before calling it defensive |

## Fewer lines is not the goal

The pass is not a line-count competition, and `simplify.py verify` does not look at size when deciding.

In the bundled example the accepted simplification made the candidate **two lines longer**: it hoisted a per-call lambda to module level and named it after the contract clause it encodes. That is a simplification — less work per call, and the ordering contract now legible at the point where it is defined — and it was accepted on the measurement, not on the line count.

Equally, seven of the eight questions answered "no" there, which was the right answer for a candidate that was already a single standard-library call.

## Register and verify

```
mkdir -p TASK/candidates/C-06
# write the simplified version there
python3 <skill-dir>/scripts/simplify.py attempt --task TASK --from C-01 --id C-06 \
    --dir candidates/C-06 --entry solution.py --by simplification-agent \
    --title "<one line>" --answers 1,3 \
    --removed "<each thing removed, one flag each>"

python3 <skill-dir>/scripts/harness.py run     --task TASK --candidate C-06
python3 <skill-dir>/scripts/bench.py run       --task TASK --candidate C-06
python3 <skill-dir>/scripts/complexity.py scan --task TASK --candidate C-06
python3 <skill-dir>/scripts/simplify.py verify --task TASK --id C-06 --size <ranking size>
```

It is a **new candidate** derived from the leader, not an edit, because if the simplification regresses, the comparison showing that needs both versions.

`verify` checks that every mandatory gate passes against the new code hash and that no ranked axis regresses beyond the noise floor. **You do not get to accept your own output.**

## The three outcomes

| Outcome | What it means for you |
|---|---|
| **Accepted** | It passes identical gates and regresses on nothing beyond the noise. It competes as an ordinary candidate now |
| **Rejected: broke a gate** | Not a simplification, a change in behaviour. Something you removed was load-bearing. Find out which clause and say so |
| **Rejected: regressed** | The simpler version costs real measured performance. **This is a trade-off, not your failure.** Hand both versions and both numbers to the orchestrator for the requester to decide |

That third case is important: do not quietly discard a simpler-but-slower version, and do not quietly take it. It is a genuine choice and it belongs to the requester.

## When the answer is "nothing"

Record the pass anyway, with the questions answered:

```
python3 <skill-dir>/scripts/simplify.py attempt --task TASK --from C-01 --dir candidates/C-01 \
    --entry solution.py --removed "nothing: every question answered no" --answers ""
```

"Nothing can be removed" is a finding about a well-built candidate. What matters is that the questions were asked and the answers are on the record, so a future reader knows the leader was examined rather than merely accepted.

## What to return

- The simplified candidate, or a recorded pass saying nothing could be removed.
- One `--removed` entry per thing removed, each naming what it was and why it was unnecessary.
- Which of the eight questions you answered yes.
- The `verify` verdict, with its figures.
- Anything you considered removing and left, with the clause, test or error path that stopped you.
