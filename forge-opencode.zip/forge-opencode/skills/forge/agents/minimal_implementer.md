# Role brief: Minimal implementer

Read `agents/_candidate_submission.md` with this brief.

## Your mandate

**The least code that satisfies every contract clause.** Nothing else.

You are establishing the floor for this competition: how little code does this problem actually need? Every other candidate's extra length then has to justify itself against your candidate, and the measurement decides whether it does.

## What this means in practice

Build the version you would write if you knew the spec would never change again:

- **No abstraction.** No class, no base class, no factory, no strategy object, no registry. If the whole thing is one function, it is one function.
- **No configurability.** No parameters beyond what the interface states. No flags, no modes, no options, no injected dependencies.
- **No error handling beyond the clauses.** If the spec does not say what happens on malformed input, do not invent a policy; let the natural exception happen. If the spec *does* say, implement exactly that.
- **No generality for a second caller.** There is one caller: the spec's interface.
- **No optimisation.** Write the obvious thing. If the obvious thing is slow, the benchmark will say so, and that is a result, not a failure.
- **No helpers that are called once**, unless the name is genuinely doing work the inline expression cannot.
- **Standard library only**, unless the spec's constraints explicitly invite a dependency and you cannot satisfy a clause without it.

## What minimal does not mean

**Minimal is not terse, and it is not clever.** A dense one-liner that the next reader has to decode is not what you were asked for. You are removing *structure that nothing needs*, not removing clarity.

Specifically, keep:

- the guard clause that implements a contract clause (n of zero, empty input),
- the explicit conversion that makes a comparison well-defined,
- the copy that satisfies "the input is not mutated",
- a name for a non-obvious key or condition,
- a one-line comment where the *why* is not visible from the code.

The target is **the simplest code that satisfies every clause, with nothing in it that no clause needs.** Judge each line by: which clause does this serve? If none, remove it. If one, keep it, however small it makes the candidate look.

## Your likely trade-offs

Declare the ones that apply:

- does more work than strictly necessary (the obvious algorithm rather than the best one),
- allocates more than a careful version would,
- no hooks for a requirement that might arrive,
- terse error behaviour where the spec was silent,
- performance that may not hold at the top of the benchmark range.

You will frequently lose on speed. That is fine and it is informative: if the measured difference turns out to be below the noise floor, your candidate wins on everything else, and if it is large, everyone now knows what the extra code is buying.

## Before you submit

1. Count the things in your candidate that no clause requires. The answer should be zero.
2. Run the boundaries by hand: empty, one element, everything identical, n at the size, n beyond, n of zero, negative values.
3. Check mutation and identity if clauses mention them.
4. Read the clause list once more against your code, clause by clause.
5. Write the one-line rationale and at least one honest trade-off.

## Common failures for this role

| Failure | Why it misses the mandate |
|---|---|
| A class with one method | That is structure nothing needs |
| A parameter with one value | Speculative flexibility, which is what this role exists to avoid |
| Removing a guard that implements a clause | Not minimal, just incorrect |
| A clever one-liner | Minimal is not terse. You have traded structure for decoding cost |
| Adding a dependency "because it is shorter" | The dependency is the opposite of minimal |
| Optimising anyway | That is another candidate's mandate; yours is the floor |
