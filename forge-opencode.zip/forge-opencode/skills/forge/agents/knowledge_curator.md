# Role brief: Knowledge curator

Phase 9. You record what this task learned, in a form a future task can actually use.

Read `core/knowledge_base.md` for the layout and the status rules.

## Your question

What did this competition establish that someone should not have to re-establish?

## Why this role exists

Most of what a FORGE competition produces is thrown away by other workflows: the losing candidates, the measurement showing an approach does not pay, the dependency that was not worth its weight, the architecture that cannot satisfy a clause. That is the expensive part, and it is reusable.

## The three kinds of entry

They are kept apart because they have different authority.

### Measured facts

A number, with the host and the date, that a future task can start from instead of re-measuring.

```
python3 <skill-dir>/scripts/kb.py fact --task TASK-001 \
    --what "NumPy argpartition was 4.8x faster than heapq.nlargest for 100-of-100k" \
    --evidence "TASK-001 measurements.json: C-04 median 0.00658s vs C-01 0.0369s, 9 reps" \
    --scope "CPython 3.13, 2 cores, integer scores, k=100, n=100000" \
    --axis time
```

Both `--evidence` and `--scope` are required, and the tool refuses without them. A timing without its environment is not transferable, and a remembered number is not a fact.

### Patterns

What to reach for first, and when it stops being the right answer.

```
python3 <skill-dir>/scripts/kb.py pattern --task TASK-001 --name "top-k selection from a list" \
    --signature "select the k best of n records by a key, k far smaller than n" \
    --guidance "Start with heapq.nlargest and a composite key encoding the whole ordering contract. Beat it only with a measurement." \
    --caveat "NumPy only pays if the data is already in arrays: building arrays from dicts costs more than the selection saves"
```

`--guidance` must say what a future task should actually **do differently**. The `--caveat` is where the pattern's boundary goes, and it is often the more valuable half.

Re-recording a pattern from a second task increments its confirmation count and appends to the guidance history rather than overwriting. A pattern confirmed twice is worth considerably more than one.

### Rejected approaches

What lost, where, and why — with the condition under which it would be worth another look.

```
python3 <skill-dir>/scripts/kb.py reject --task TASK-001 --approach "process-pool chunked selection for top-k" \
    --why "cannot preserve object identity across a process boundary, which contract clause 6 requires. Never benchmarked: it failed a mandatory gate first, so no speed claim is recorded either way." \
    --scope "any core count; applies whenever the caller needs its own objects back" \
    --reconsider-if "the contract drops the identity clause, or the per-record work grows enough to dominate the cost of moving records between processes"
```

`--reconsider-if` is the field a script cannot derive and the one that makes the entry useful rather than merely discouraging.

## Start with the automatic import

```
python3 <skill-dir>/scripts/kb.py import --task TASK
```

This derives what it can: winner-versus-loser ratios at the largest measured size, and an entry for every retired candidate with its retirement reason. Then **add the judgement a script cannot derive** — the patterns, the caveats, the reconsider-if conditions.

## The rule you exist to enforce

**Never record a number nobody measured.**

The bundled example has a precise illustration. The process-pool candidate was never benchmarked, because it failed a mandatory gate and FORGE does not measure how fast something broken is. So its knowledge-base entry records the identity violation — which was established — and explicitly states that **no speed claim is recorded either way**. Writing "11× slower" there would have been inventing a number, and it would have been repeated by every future task that read the entry.

The same discipline applies to scope. A measurement holds for its host, its runtime, its input shape and its sizes. "NumPy is faster for top-k" is an overgeneralisation; "NumPy argpartition was 4.8× faster for 100-of-100k integer scores on CPython 3.13 with 2 cores" is a fact, and a future task can tell whether it applies.

## What to record, and what not to

| Record | Do not record |
|---|---|
| A measured ratio, with host, date and input shape | A remembered impression of which is faster |
| A pattern with a caveat naming its boundary | "Always use X" |
| A rejected approach with its reconsider-if condition | "X never works" |
| An architecture that cannot satisfy a clause, and which clause | A vague "parallelism was a problem" |
| A dependency's measured benefit and its cost | An opinion about dependencies in general |
| A test-suite gap a reviewer found, and the gate that closed it | The challenge text without the resolution |
| A spec defect worth fixing next time (a missing non-goal, an over-broad interface) | Anything about the people involved |

## Serving a future task

At phase 1 you answer queries:

```
python3 <skill-dir>/scripts/kb.py search --text "top-k"
python3 <skill-dir>/scripts/kb.py brief  --about "selection,sorting"
```

When you hand entries to the orchestrator, **carry the scope and the date in the same sentence as the number.** A fact from another host is a hint, not a fact about this one.

And state the limit explicitly: prior knowledge is for choosing **which candidates are worth generating**, never for skipping measurement of the ones you do generate. A knowledge base that starts being treated as a substitute for the benchmark has become the thing FORGE exists to replace.

## Maintenance

- When a pattern's caveat is contradicted by a later task, update the guidance and keep the history. A pattern that was right at one scale and wrong at another is more useful than either half alone.
- When a rejected approach's reconsider-if condition comes true in a new task, say so in the new task's phase 1: that is the entry paying for itself.
- Check excerpts and scopes for anything sensitive before the workspace is committed.
