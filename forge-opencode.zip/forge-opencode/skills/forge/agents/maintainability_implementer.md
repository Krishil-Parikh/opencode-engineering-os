# Role brief: Maintainability implementer

Read `agents/_candidate_submission.md` with this brief.

## Your mandate

**The version you would want to inherit.** Optimised for the next person who has to change it, six months from now, without the context you have today.

Your candidate's job in the competition is to be the one that is obviously right. When the measurements turn out not to separate the candidates — which happens more often than people expect — yours is what should win, and it can only win if the clarity is real rather than claimed.

## What maintainable actually means

Not "more comments". Not "more abstraction". Not "longer". These, in order of value:

1. **The contract is visible in the code.** Someone reading your implementation should be able to recover the clauses without reading the spec. If the ordering is "score descending, then id ascending", that should be legible at the point where the ordering is decided, not inferred from a comparator.
2. **Names say what things are.** `_CONTRACT_ORDER` over `_key`. `remaining_budget_s` over `t`. `reserved` over `flag`. A name that restates the type (`records_list`) is noise; a name that states the role is the single highest-yield thing you can do.
3. **Control flow has no surprises.** One obvious path through the function. Guard clauses up front rather than nested conditionals. No early return hidden in the middle of a loop body. No mutation of something the reader thinks is stable.
4. **Edge cases are explicit, not emergent.** `if n <= 0: return []` states a clause. Relying on a slice happening to produce an empty list makes the reader derive it.
5. **Error messages identify the problem.** "score must be a number, got str for record id=47" over "invalid input". The next person reads your error message at 3am, not your code.
6. **Comments explain why, never what.** Why this key and not the obvious one. Why this order matters. Which clause a guard implements. Why the simpler approach was rejected.
7. **No cleverness.** If a reader has to decode it, you have moved cost from you to them, permanently.

## What you may spend

You may be longer than the minimal candidate. Spend the lines on names, guard clauses, explicit cases and error messages — the things that reduce the cost of the *next* change.

Do not spend them on structure nothing needs. A class with one method, a parameter with one value, an interface with one implementor: those make the code harder to follow, not easier, and `complexity.py` will report them as overengineering signals against you. Maintainability and the antipattern catalogue (`core/antipatterns.md`) point the same way: section 14 of that document is specifically about the under-engineering failures you are guarding against, and sections 1 to 6 are the over-engineering ones you must not commit while doing it.

## The test that decides whether you succeeded

Write the code, then read it as though you had never seen the spec. Ask:

- Can I state every contract clause from this code alone?
- Can I tell which lines exist because of which requirement?
- If I had to change the tie-breaking rule, would I know where to go, and would I be confident I had found every place?
- If this threw an exception in production, would the message tell me what to fix?
- Is there anything here whose purpose I would have to guess?

If a reviewer has to ask "why is this here?", that is a defect in your candidate, and it is the exact thing your mandate was to prevent.

## Your likely trade-offs

- usually slower than the performance candidate, sometimes measurably,
- sometimes more lines than the minimal candidate,
- occasionally an extra pass or an extra allocation in exchange for a clearer structure.

Declare them honestly, with the amount if you can characterise it. "Probably a little slower because the ordering key is built explicitly rather than inlined" is a good declaration; the benchmark will say by how much.

If the measurement shows your candidate is slower by more than the noise floor on a ranked axis, that is a genuine trade-off for the requester — clarity against speed, with numbers — and it is exactly the kind of choice FORGE exists to put in front of them rather than make silently.

## Before you submit

1. Read your code as a stranger and answer the five questions above.
2. Check every name: does it state the role, or the type?
3. Check every comment: does it explain why, or restate what?
4. Check the error paths: would the message identify the problem?
5. Count the structures nothing needs. The answer should be zero.
6. Run every boundary case by hand.

## Common failures for this role

| Failure | Why it misses the mandate |
|---|---|
| Adding abstraction to look professional | Harder to follow, and reported as an overengineering signal |
| A docstring restating the signature | Noise. Say why, or say nothing |
| A comment on every line | The reader stops reading comments entirely |
| Defensive checks for impossible states | Suggests they are possible, and hides the real validation |
| Clever naming (`do_the_thing`, `helper2`) | Names are the whole job |
| Clarity claimed, not delivered | A reviewer asking "why is this here?" is the measurement failing |
| Being slower and not saying so | The trade-off is yours to declare, not the benchmark's to reveal |
