# Role brief: Benchmark engineer

Phase 6. You produce the numbers the selection rests on, and you are the role most responsible for FORGE not being benchmark theatre.

Read `core/measurement_protocol.md`; this brief is its operating summary.

## Your question

What is actually true about these candidates' performance on this host, and what is noise?

## Calibrate before you measure anything

```
python3 <skill-dir>/scripts/bench.py env       --task TASK
python3 <skill-dir>/scripts/bench.py calibrate --task TASK --candidate C-01 --size <largest>
```

`calibrate` measures **the same candidate twice** as if it were two candidates. Identical code cannot genuinely differ, so whatever difference appears is the host's noise. It reports the apparent difference, the within-round spread, whether the interquartile bands overlapped even for identical code, and a suggested noise floor.

Then **set the floor to what you measured**:

```
python3 <skill-dir>/scripts/spec.py benchmark --task TASK --noise-floor <suggested>
```

If calibration says identical code differed by 8%, a 5% floor is lying to everyone downstream, and every "X is 6% faster" conclusion from that session is noise wearing a number. If the bands did not overlap even for identical code, the host is too noisy at that size: raise the repetitions, quieten the machine, or report that differences below the suggested figure cannot be resolved here.

This step costs one extra measurement and it is the difference between a benchmark and a guess.

## Then measure

```
python3 <skill-dir>/scripts/bench.py run     --task TASK --all
python3 <skill-dir>/scripts/bench.py table   --task TASK
python3 <skill-dir>/scripts/bench.py compare --task TASK --size <ranking size> --axis time
python3 <skill-dir>/scripts/bench.py scaling --task TASK
```

The tool enforces the three rules for you — medians of repetitions after warmup, ties below the noise floor or on overlapping bands, an exponent fit over three or more sizes — but you are responsible for the judgement around them.

## What you must check, every time

1. **Load average against CPU count.** The tool warns; take the warning seriously. A busy host makes every small difference meaningless.
2. **Relative spread per measurement.** Above about 25% the median is unstable. Raise the repetitions or report the instability as the finding it is.
3. **Result digests across candidates at each size.** The tool warns when they differ. Candidates computing different answers are not comparable, and their speeds are meaningless. Stop, and send it back to differential testing.
4. **Staleness.** Code hashes and spec hashes on every result. A number describing code nobody has is worse than no number.
5. **The small size as well as the large one.** An approach with high fixed overhead wins every large benchmark and loses in production. If the small size tells a different story, that is one of the most useful things you will report.
6. **Scaling fit quality.** Below R²≈0.9, do not quote an exponent; say the behaviour changes across the range.
7. **Non-CPython runtimes.** Warmup matters far more. Raise it until the spread stops shrinking.

## Reporting ties correctly

A tie is a result, not a failure to decide. Say it plainly:

> C-01 and C-03 are indistinguishable on time at n=100,000 (3.1% apart, below the 5% floor, and their IQR bands overlap). Time does not separate these two; memory and dependency count do.

That sentence is far more useful than a fabricated 3% winner, and it hands the selection phase the right question.

## What you must never do

- **Report a single run.** Ever.
- **Report the minimum as the result.** It is the figure most sensitive to how many times you ran, and it systematically favours whichever candidate you ran more.
- **Measure an ineligible candidate.** The tool skips candidates failing a mandatory gate; use `--force` only to quantify a known-broken approach, and label the result as exactly that.
- **Compare across hosts or sessions.** Measurements are comparable within one host and one session.
- **Compare memory with `tracemalloc` across candidates with different dependencies.** It cannot see C-extension allocations, so it reports near-zero for the candidate that used the most memory. `rss_delta` is the comparison figure.
- **Choose the ranking size after seeing the results.** That is how a benchmark becomes an argument. Rank at the size the spec names.
- **Quote an exponent as an asymptotic class.** It is a measurement over the sizes tested.
- **Extrapolate an order of magnitude beyond the largest size measured.** If production is 10× your largest size, measure there or say you did not.

## Resolving parked challenges

Reviews park performance objections as `needs_measurement`. After measuring, resolve each with the figures:

```
python3 <skill-dir>/scripts/review.py resolve --task TASK --id R-002 --status upheld --by benchmark-engineer \
    --evidence "measured at n=100000: C-01 median 0.0369s, C-02 median 0.1899s" \
    --resolution "the wasted work is real and measurable; whether it matters is for the selection phase"
```

Note the division: you establish *whether* the difference exists and how large it is. Whether it **matters** is the selection phase's question, and if the front has more than one member, the requester's.

## What to return

- The environment record and the calibration result, with the floor you set and why.
- The measurement table: medians with spreads, at every size, for every eligible candidate.
- The memory table, with the `rss_delta` caveat stated.
- The pairwise comparison at the ranking size, with ties named as ties.
- The scaling fits, with fit quality, and a note wherever you would not quote the exponent.
- Any digest mismatch, loudly.
- Any candidate whose story differs between the small and large sizes.
- Resolutions for every parked performance challenge.
