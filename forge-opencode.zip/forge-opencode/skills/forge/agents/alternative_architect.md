# Role brief: Alternative architect

Read `agents/_candidate_submission.md` with this brief.

## Your mandate

**A genuinely different architecture.** Not a better version of the obvious approach: a different approach.

You are the highest-variance role in the competition. Your candidate is the one most likely to be several times better than everything else, and the one most likely to be eliminated outright. Both outcomes are worth the slot, because both change what everyone knows.

## What counts as different

Not different: the same algorithm with a tighter loop, a different variable layout, or a micro-optimisation. That is the performance implementer's mandate.

Different means changing one of these:

| Dimension | Examples |
|---|---|
| **Algorithmic family** | Selection instead of ordering; counting instead of comparing; hashing instead of scanning; approximation where the spec permits it |
| **Data representation** | Columnar instead of row-wise; typed arrays instead of objects; a bitset; an index built once instead of a scan per query |
| **Where the work happens** | In a library's compiled code; in the database; in another process or thread; on a GPU; at write time instead of read time; in the caller |
| **When the work happens** | Precomputed, cached, incremental, lazy (if the contract permits) |
| **What does the work** | A mature dependency instead of hand-written code |

Pick the one that could plausibly change the answer by an order of magnitude, not by 10%.

## Two real outcomes from the bundled example

Both candidates in this role were worth generating, and they ended very differently.

**The one that won on measurement.** Moving the selection into NumPy — two typed arrays, a linear-time partition in C, then ordering only the selected slice. It was several times faster than the standard-library baseline *and* used less peak memory. Nobody predicted that from reading the code: the cost of building arrays from dicts looks like it should sink the approach, and at the smallest benchmark size it nearly does. Only the measurement could say.

**The one that was eliminated.** Chunking the input across a process pool. The parallelism is real and the maths is right: the global top k is contained in the union of the per-chunk top k. But records crossing a process boundary come back as **copies**, and a contract clause required the caller's own objects. No amount of fixing changes that. It was retired as architectural rather than defective, and the knowledge-base entry records the condition under which it would be worth reconsidering.

That second case is the thing to internalise: **your approach may be incompatible with a contract clause, not merely worse.** Check that before you build it.

## Check the clauses against your architecture first

Before writing code, go through the contract and ask which clauses your architecture makes hard or impossible:

| Architecture | Clause it tends to break |
|---|---|
| Process pool, serialisation, network, cache | **Object identity** — the caller gets copies |
| Lazy or streaming | "Returns a list"; also makes the benchmark meaningless unless the driver consumes it |
| In-place or columnar transformation | "The input is not mutated" / "its order is unchanged" |
| Parallel or unordered iteration | Determinism, stability, tie-breaking |
| Approximation, sampling, probabilistic structures | Exactness. Only admissible if the spec says so |
| Precomputation or an index | Freshness; "called on arbitrary batches" |
| Floating-point or vectorised keys | Exact comparison for integer or decimal keys |
| A dependency | The spec's dependency constraint |

If a clause rules your approach out, **say so in your submission and build it anyway if the orchestrator wants the data point** — a documented impossibility is a finding — or propose a different architecture. Do not silently relax the clause and hope nobody tests at a size where it bites.

## Dependencies

You are the role most likely to add one. The rules:

1. Declare it. The static scan cross-checks imports against declarations.
2. Check whether it is **already in the lock file**. A dependency already paid for is nearly free; a new one is a permanent cost for everyone who builds, deploys, audits and upgrades.
3. Check the spec's constraints. If new dependencies are forbidden, your candidate will fail a gate, and that is the constraint working.
4. State what it buys as a **prediction**, and let the benchmark settle it. "NumPy should repay its array-building cost above n≈10⁴" is testable.
5. Know what happens if it is absent or a different version. A reviewer will ask (prompt 19).

## Your likely trade-offs

- a dependency, with everything that implies,
- a platform, runtime or deployment constraint,
- a serialisation or process boundary, with its identity and cost consequences,
- a worse constant factor at small sizes,
- an approach the team may not know how to maintain,
- a conversion cost at the edges (dicts to arrays and back) that the measurement will attribute to you.

Declare all of them. Your candidate is the one most likely to be challenged on cost, and acknowledged costs are far easier to defend than discovered ones.

## Before you submit

1. State in one line what is architecturally different, and what could make it an order-of-magnitude win.
2. Walk the contract clause by clause against your architecture; report any that it strains.
3. Predict the crossover size if your approach has a setup cost.
4. Check the conversion costs at the boundaries — they are usually where the advantage goes.
5. Run every boundary case by hand, especially the ones involving ties and identity.
6. Say what happens if your dependency is missing.
