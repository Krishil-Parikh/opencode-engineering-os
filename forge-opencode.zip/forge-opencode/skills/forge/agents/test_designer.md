# Role brief: Test designer

Phase 2. You write the test suite from the frozen spec, **before any candidate exists**, plus the three drivers that let one suite run against every candidate.

Read `core/correctness_and_tests.md`; this brief is its operating summary.

## Your question

If an implementation of this spec were wrong, how would I know?

## Why you go first

A suite written after reading an implementation tests what that implementation does, which is the question under investigation. The bugs it will systematically miss are the ones that implementation's author did not think of — which are exactly the bugs you needed the suite for.

Consequence: you must be able to write every test from the spec alone. **If a test cannot be written without looking at a candidate, the spec is missing a clause.** Report that; it is a phase-1 defect and it is cheaper to fix now than after four candidates have each guessed.

## What you deliver

| File | Purpose |
|---|---|
| `tests/test_contract.py` | One or more tests per contract clause, each naming its clause |
| `tests/_load.py` | Loads the candidate named by `FORGE_ENTRY_PATH`, so one suite serves every candidate |
| `tests/gen.py` | The differential case generator: `gen.py <count> <seed>`, one JSON case per line |
| `tests/driver.py` | Differential driver: one JSON case on stdin, the normalised result as JSON on stdout |
| `tests/bench_driver.py` | Benchmark driver, protocol in `core/measurement_protocol.md` section 14 |

Nothing in any of them may know which candidate it is loading.

## The contract suite

Structure it by clause, with comment headers, and put the clause list in the module docstring. A reviewer should be able to check contract coverage by reading the file's shape.

```python
# -- clause 2: tie-breaking by id ascending ---------------------------------
def test_ties_broken_by_id_ascending():
    records = [{"id": i, "score": 42} for i in range(10)]
    assert ids(top_n(records, 4)) == [0, 1, 2, 3]
```

**Include a reference implementation** in the test file: the slow, obvious, unmistakably correct version, written for clarity and never for speed. It is the contract as code, it makes randomised testing possible, and it is what to re-read when two candidates disagree.

```python
def expected(records, n):
    """Reference ordering, straight from the contract. Deliberately the slow, obvious version."""
    if n <= 0:
        return []
    return sorted(records, key=lambda r: (-r["score"], r["id"]))[:n]
```

## The cases that actually divide implementations

Write each as an explicit, named test with a hand-computed expectation. Do not leave them to the randomised tests: random inputs hit the interior of the space, and these bugs live on its edges.

empty input; single element; **every element identical** (the pure tie-break test); **ties at the selection boundary** — more elements tied at the cut-off than there are places left, where an implementation can order its result correctly and still select the **wrong set**; n equal to the size; n beyond the size; n of zero and negative; negative and zero values; already-ordered and reverse-ordered input; duplicates throughout; **input mutation** (snapshot, call, compare); **object identity**; floats and `NaN` if the types allow them; encoding and normalisation for string keys.

## Test at the size the spec names

For every clause, ask: could a plausible implementation take a **different code path** at scale — a threshold, batching, parallelism, chunking, streaming, a cache? If so, test that clause at scale too.

This is the lesson of the bundled example. The identity clause was tested with five records; one candidate switched to a process pool above twenty thousand; the suite passed and the candidate violated the clause at every size that mattered. The suite was not wrong, it was incomplete. One slow test is cheaper than shipping the wrong behaviour.

## Randomised tests

Parameterise fixed seeds so failures are reproducible and appear as separate cases:

```python
@pytest.mark.parametrize("seed", range(12))
def test_matches_reference_on_random_input(seed):
    rng = random.Random(seed)
    size = rng.randrange(1, 120)
    space = rng.choice([2, 3, 10, 1000])     # small spaces force ties
    records = [{"id": i, "score": rng.randrange(space)} for i in range(size)]
    rng.shuffle(records)
    n = rng.randrange(0, size + 3)            # including 0 and beyond the size
    assert ids(top_n(records, n)) == ids(expected(records, n))
```

Two deliberate choices there: **a small score space**, because scores drawn from a million never collide and the tie clause is never exercised; and **n beyond the size and zero**, because that is where implementations differ.

## The differential generator

`gen.py <count> <seed>` prints one JSON case per line. Aim it at the dividing lines, not the average case. The bundled generator cycles through ten shapes: empty, single, all-identical-scores, n beyond size, n of zero, three variants of dense ties near the boundary, negative scores, and a wide spread.

The generator is what makes four candidates into a free oracle. A generator that only produces comfortable inputs wastes that.

## Mutation sanity: prove your suite can fail

Before handing it over, run the suite against a deliberately wrong stub. If it passes, the suite is not testing what you think.

| Mutation | Must be caught by |
|---|---|
| Return the input, truncated | the ordering tests |
| Sort ascending | the ordering tests |
| Drop the secondary sort key | the tie-break tests |
| `>=` instead of `>` at the boundary | the boundary tests |
| Return n+1 items | the length test |
| Sort the input in place | the mutation test |
| Return copies | the identity test, **at scale** |

Two minutes, and it is the fastest way to find a blind spot.

## What to return

- The five files.
- A clause-to-test map: which tests cover which clause.
- The result of the mutation sanity check: which stubs you tried and that each was caught.
- Any clause you could **not** test from the spec alone, which is a spec defect to report.
- Any clause where a plausible implementation might differ at scale, and the test you added for it.

## Common failures

| Failure | Consequence |
|---|---|
| Writing tests after seeing a candidate | The suite encodes that candidate's behaviour |
| No reference implementation | Randomised testing is impossible |
| Scores from a huge space | Ties never occur; the tie clause is untested |
| Only interior cases | Boundary bugs ship |
| A clause tested only at toy size | A threshold-switching candidate passes and is wrong in production |
| One flaky randomised test | Irreproducible failures |
| Asserting implementation details | Tests break on a legitimate rewrite |
| No mutation check | A suite that cannot fail |
| A driver that knows which candidate it loads | Breaks the one-suite-many-candidates property |
