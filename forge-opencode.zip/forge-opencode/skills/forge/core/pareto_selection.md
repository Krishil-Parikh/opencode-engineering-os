# Pareto selection

Phase 8. How FORGE picks a winner, and why it often refuses to.

## Contents

1. Why not a weighted score
2. Dominance, with ties
3. Computing the front
4. Hard limits versus ranked axes
5. The five verdicts
6. Articulating the trade-off
7. Priorities: asking rather than inferring
8. Equivalent candidates
9. Choosing the ranking size
10. How many axes
11. Common selection mistakes

---

## 1. Why not a weighted score

The tempting design is: score each candidate on correctness, speed, memory, complexity and size; multiply by weights; rank. It is tempting because it always produces an answer.

That is the problem. The weights are invented, so the answer is invented. Change `time: 0.4, deps: 0.2` to `time: 0.3, deps: 0.3` and the winner changes, and nobody can say which weighting was right because the question "how many milliseconds is a dependency worth?" has no general answer. It has a *local* answer that belongs to the person who will maintain the code, and a scoring system that invents weights is quietly answering it on their behalf while presenting the result as a measurement.

`autoresearch` can rank on one number because it genuinely has one objective: validation bits per byte, lower is better. General-purpose software does not. Speed, memory, dependency count and maintainability are incommensurable, and pretending otherwise is the central dishonesty FORGE is built to avoid.

So FORGE computes the **Pareto front**: the set of candidates that nothing else beats on every axis at once. Then it either finds one member (a selection), or it names the trade-off and asks (`TIE_NEEDS_PRIORITIES`).

## 2. Dominance, with ties

Candidate A **dominates** B when A is better-or-tied on every ranked axis, and genuinely better on at least one.

"Genuinely better" means the difference clears the measurement noise (`core/measurement_protocol.md`, section 7): the medians differ by at least the noise floor **and**, for timings, the interquartile bands do not overlap. Without that condition, benchmark noise would decide dominance, and the front would change from run to run.

Consequences worth understanding:

- A candidate that is 2% faster and otherwise identical does **not** dominate: it ties, and both stay on the front.
- A candidate that is 5× faster but adds a dependency does **not** dominate, if `dependencies` is a ranked axis. It wins one axis and loses another.
- A candidate dominated by anything is out of the running, and the tool names what dominated it.

## 3. Computing the front

```
python3 <skill-dir>/scripts/pareto.py eligible  --task TASK
python3 <skill-dir>/scripts/pareto.py front     --task TASK --size 100000
python3 <skill-dir>/scripts/pareto.py tradeoffs --task TASK --size 100000
python3 <skill-dir>/scripts/pareto.py select    --task TASK --size 100000
```

Order matters and the tool enforces it:

1. **Eligibility first.** Only candidates passing every mandatory gate, with non-stale results, enter the ranking.
2. **Hard limits next.** A candidate exceeding a limit on any axis is excluded, with the figure recorded.
3. **Then the front**, on the axes marked `--pareto`.
4. **Then the verdict.**

Axis values come from the records, never from an argument: `time`, `memory` and `throughput` from `measurements.json`; `complexity`, `dependencies` and `size` from `complexity.json` and the candidate register. A candidate missing a value on a ranked axis is reported as unmeasured and is not ranked, rather than being given a default.

## 4. Hard limits versus ranked axes

| | Hard limit (`--limit`) | Ranked axis (`--pareto`) |
|---|---|---|
| Means | "This cannot be used" | "Less of this is better" |
| Effect of exceeding | Excluded from the competition | Counts against it |
| Use for | A real ceiling: the memory the process has, a deadline the caller enforces | A preference between usable options |

Expressing a preference as a limit is a mistake that silently removes candidates the requester might have chosen. If the honest statement is "we would rather it used less memory", that is an axis. If it is "it will be OOM-killed above 512 MiB", that is a limit.

## 5. The five verdicts

| Verdict | Condition | What to do |
|---|---|---|
| `SELECTED` | Exactly one candidate on the front | Ship it. Report what the others cost |
| `SELECTED_WITH_TRADEOFF` | Several on the front, and the requester stated a priority order that picks one | Ship it, and **state in the report what it gives up** |
| `TIE_NEEDS_PRIORITIES` | Several on the front, no stated priorities | Put the question to the requester with the numbers. Record the answer with `spec.py priorities` and select again |
| `NO_CANDIDATE_PASSES` | Nothing passes every mandatory gate | Report what each got wrong. Do not lower a gate |
| `INSUFFICIENT_MEASUREMENT` | Eligible candidates exist but the measurements cannot support a comparison | Say what is missing and measure it, or report without a performance ranking |

Three of the five are not a winner, and that is deliberate. A system that always produces a winner is not measuring anything; it is generating confidence.

**`NO_CANDIDATE_PASSES` is a finding, not a failure.** It usually means the spec is harder than it looked, or a contract clause is impossible as stated. Both are worth knowing before more code is written, and neither is a reason to relax a gate so that something can win.

## 6. Articulating the trade-off

When the front has more than one member, `pareto.py tradeoffs` prints the comparison axis by axis and, for each pair, the sentence to put to the requester:

```
C-01 is better on dependencies; C-04 is better on time and memory. Which matters more here?
```

That is the output of the bundled example: the NumPy candidate was several times faster **and** used less peak memory, and still did not win, because it costs a dependency the baseline does not and nobody had said whether that mattered.

A good trade-off statement has four parts:

1. **Each candidate named with what it is**, not just an id.
2. **The axes each wins, with the actual figures and units.**
3. **The size the comparison was made at**, because the answer can reverse at another size.
4. **The question, in the requester's terms**: not "which has higher utility" but "is NumPy already in your lock file, and do you want it here?"

## 7. Priorities: asking rather than inferring

`spec.py priorities` accepts `user` or `unset` and **rejects `inferred`**. If the requester has not stated an order, FORGE does not choose for them.

When priorities are recorded, selection applies them **lexicographically**: the first named axis decides, and later axes only break exact ties on the earlier ones. Lexicographic order is used rather than weights because it is the thing a requester can actually state and verify. "Speed first, then dependencies" is a sentence someone can agree with; "speed 0.45, dependencies 0.3, memory 0.25" is not.

The report then records both the order and the requester's own words, so a future reader can see why the winner won and re-decide if their priorities differ.

If the stated priorities mention no ranked axis, the verdict stays `TIE_NEEDS_PRIORITIES`: priorities over axes nobody measured cannot break a tie.

## 8. Equivalent candidates

Two candidates can tie on every ranked axis. Both stay on the front, and the tool says so explicitly:

> C-01 and C-06 are equivalent on every ranked axis (time, memory, dependencies), so both stay on the front. Separate them on something the ranking does not measure, such as which one the next person will find easier to read.

This is the right moment for the unmeasurable criteria to decide, **after** the measurements have shown they cannot. Readability, the clarity of the error messages, whether the ordering contract is visible in the code: these are legitimate tie-breakers, they should be argued rather than scored, and the argument belongs in the report.

What is not legitimate is reaching for them *before* the measurement, to justify a candidate that is measurably worse.

## 9. Choosing the ranking size

The front is computed at one input size, and the choice can change the answer. Rules:

- **Rank at the size the spec names.** If the request says "about 100,000 records", rank at 100,000.
- **Look at the other sizes before accepting the verdict.** If the front at 1,000 has a different member than at 100,000, that is a finding for the report: the answer depends on the input size, and the requester may have both regimes.
- **Never rank at the size that flatters a candidate.** Choosing the benchmark size after seeing the results is how a benchmark becomes an argument.
- If the production distribution is genuinely wide, say so and give the front at both ends rather than picking one.

## 10. How many axes

Every axis added makes the front larger, because more candidates become non-dominated. With six axes almost everything is on the front and the ranking says nothing.

Practical guidance: **two to three ranked axes.** Typically `time` plus one of `memory` or `dependencies`. Everything else is reported and used in the review and the tie-break discussion.

In particular, do not rank on both `time` and `throughput`: they are the same measurement in different units, and ranking on both double-counts it.

## 11. Common selection mistakes

| Mistake | Why it is wrong | Guard |
|---|---|---|
| Inventing weights to get one winner | The answer comes from the weights, not the data | `TIE_NEEDS_PRIORITIES` is first-class |
| Ranking a candidate that fails a gate | Ranks something that does not work | Eligibility first |
| Letting a 3% difference decide | Noise decides the winner | Noise floor plus band overlap |
| Ranking on size | Rewards terseness over clarity and speed | `size` is not a Pareto axis by default |
| Ranking at a cherry-picked size | The benchmark becomes an argument | Rank at the spec's size; report the others |
| Six ranked axes | Everything is on the front | Two or three |
| Hiding the trade-off behind the winner | The requester cannot re-decide later | `SELECTED_WITH_TRADEOFF` must state what was given up |
| Breaking a tie on readability without measuring first | Unmeasurable criteria used to override measurable ones | Measure, then use readability only for genuine ties |
| Relaxing a gate so something can win | Converts a finding into a false success | `NO_CANDIDATE_PASSES` is a legitimate verdict |
| Treating a dominated candidate as worthless | It may have found something, or win at another size | It stays in the record with its measurements |
