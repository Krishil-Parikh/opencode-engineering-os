# Integration with TRACE

FORGE and TRACE are a pair: one makes sure the software being written is as simple and effective as possible, the other investigates why software failed. They share a philosophy, a workspace convention and a knowledge-base discipline, and either works alone.

## Contents

1. The shared philosophy
2. The division of labour
3. Handing a finding from FORGE to TRACE
4. Handing a finding from TRACE to FORGE
5. Shared evidence discipline
6. Shared workspace conventions
7. Using both in one session
8. If only one is installed

---

## 1. The shared philosophy

Both skills exist because an agent's confidence in its own output is not evidence, and both replace it with the same two moves: an explicit record of what is actually known, and a mechanism that refuses to conclude more than the record supports.

| | TRACE | FORGE |
|---|---|---|
| Question | Why did this fail? | Which implementation should we ship? |
| Record | Evidence ledger: FACT / INFERENCE / ASSUMPTION | Measurements, gate results, challenges |
| Mechanism that prevents overreach | Scores capped by what the ledger contains | Pareto front with a measured noise floor |
| Right to refuse an answer | `INSUFFICIENT_EVIDENCE` | `TIE_NEEDS_PRIORITIES`, `NO_CANDIDATE_PASSES`, `INSUFFICIENT_MEASUREMENT` |
| Adversarial step | Hypothesis duels | Candidate review and differential testing |
| What survives the task | Findings with honest verification status | Measured facts with their scope and date |

The shared rule, in both: **a claim with no citable basis does not enter the record**, and a conclusion the record does not support does not get reported.

## 2. The division of labour

| Situation | Skill |
|---|---|
| Something is broken and nobody knows why | TRACE |
| An exception, a hang, a leak, an intermittent failure | TRACE |
| A choice between implementations | FORGE |
| "Make this faster" with no failure | FORGE |
| "Is this the simplest way to do it?" | FORGE |
| A failure whose cause is known, and the fix has several plausible shapes | TRACE to establish the cause, then FORGE for the fix |
| A performance regression | TRACE to find what changed, then FORGE to choose the replacement |
| A fix that is one obvious line | Neither. Just write it |

The boundary: TRACE ends at a root cause and a recommended fix. FORGE begins when the fix is a real implementation choice rather than a single line. A TRACE investigation that concludes "the request budget is shorter than the retry policy" has several possible remedies — raise the budget, shorten the retries, pass a deadline down — and that is a FORGE task with a frozen spec and measurements, not an argument.

## 3. Handing a finding from FORGE to TRACE

FORGE's static scan and reviews surface things that are defects in **existing** code rather than properties of a candidate. The most common:

- `except Exception: pass` and other swallowing handlers (`complexity.py` reports `passthrough_functions`, and review prompt 21 covers error handling)
- cleanup only on the success path, or in a handler that does not run on cancellation
- an unbounded retry or a missing timeout noticed while reading the surrounding code
- a race or shared-state hazard spotted in code the candidate calls

These are not FORGE's to fix: they are outside the task's scope, and fixing them would violate the surgical-changes principle. Record them as a knowledge-base entry and, if TRACE is installed, open an investigation:

```
python3 <forge-skill-dir>/scripts/kb.py reject --approach "<not applicable>" ...   # not this
python3 <trace-skill-dir>/scripts/workspace.py new --title "Swallowed exception in orders.send_confirmation" \
    --error "none observed yet: defect found by static review during FORGE TASK-004" --mode A
```

Then record the FORGE finding as the first evidence item in the TRACE ledger, `class=source`, grade FACT, with the file and line range. The two records cross-reference: the TRACE investigation names the FORGE task that found it, and the FORGE report's notes name the investigation.

## 4. Handing a finding from TRACE to FORGE

TRACE investigations end with a recommended fix, and its section 7 ordering is: the Layer 3 fix, the trigger mitigation, the failure-mode fix, the observability fix. Where any of those is a genuine implementation choice, it becomes a FORGE task:

```
python3 <forge-skill-dir>/scripts/workspace.py new --language python \
    --title "Deadline propagation for the payment client" \
    --statement "From TRACE BUG-001: the request budget (1.0s) is shorter than the payment client's retry worst case (2.4s), so the caller cancels mid-retry. Several remedies are possible."
```

The TRACE report supplies most of phase 1 for free:

| TRACE artefact | FORGE use |
|---|---|
| The root cause (Layer 3) | The problem statement |
| The failing execution path | The contract clauses that must not break |
| The verified findings | Constraints and non-goals |
| The reproduction or counterfactual experiment | A mandatory regression gate: the fix must make it pass |
| The measured timings in the investigation | Benchmark sizes and the axes that matter |

That last row is worth emphasising. A TRACE investigation that produced a counterfactual experiment has already written FORGE's hardest gate: the candidate must make the failing scenario stop failing, and that is a command with an exit status.

## 5. Shared evidence discipline

Both skills refuse claims without a basis, and the grading vocabulary transfers:

| TRACE grade | FORGE equivalent |
|---|---|
| FACT: directly observed, re-checkable, with a locator and a verbatim excerpt | A measurement with its command, host and date; a gate result with its exit status; a `file:line` citation |
| INFERENCE: derived from other items by a stated step | A prediction from a complexity argument; a scaling extrapolation within the measured range |
| ASSUMPTION: believed, not checked | A declared implementer assumption; an unmeasured performance claim |

The rules that carry over unchanged:

- An excerpt is read from the file, never paraphrased. TRACE's ledger tool enforces it; in FORGE, `complexity.py` and the gate harness read the code themselves.
- Absence needs a scope. "There is no existing helper for this" requires saying what was searched, exactly as TRACE's absence evidence requires a search scope.
- A number without its environment is not a measurement. TRACE records the host for runtime evidence; FORGE records it for every benchmark.
- Staleness is tracked, not assumed away: TRACE re-checks evidence excerpts, FORGE hashes candidate code and the spec.

## 6. Shared workspace conventions

Both create a top-level directory at the repository root, with the same shape:

```
debugging/                  forge/
  investigations/BUG-001/     tasks/TASK-001/
  knowledge_base/             knowledge_base/
  index.md                    index.md
  trace_config.json           forge_config.json
```

Both: one directory per unit of work, JSON records written only by their tools, a rendered markdown knowledge base, a status-carrying state file, and an index. Both commit cleanly, and both carry the same caution about committing raw logs or excerpts containing secrets or personal data.

Keeping them separate is deliberate. A failure investigation and an implementation competition have different records, and merging them would mean one tool's schema constraining the other's.

## 7. Using both in one session

A realistic sequence:

1. **TRACE** investigates a production failure and reaches a verified root cause: a timeout hierarchy inversion.
2. Its report recommends making the budgets consistent, and notes three ways to do it.
3. **FORGE** takes that as a task. The TRACE reproduction becomes a mandatory regression gate. The three remedies become candidates, plus a baseline (does the HTTP client already support deadline propagation?).
4. Measurement shows which remedy costs what, at the request rates that occur.
5. The Pareto front has two members: raising the budget is one line and makes failures slower; passing a deadline down is thirty lines and makes them correct. No priority order is recorded, so the verdict is `TIE_NEEDS_PRIORITIES` and the question goes to the team with both numbers.
6. **TRACE's** knowledge base gains a confirmed pattern (timeout hierarchy inversions in this codebase). **FORGE's** gains a measured fact (the cost of each remedy) and a rejected approach with its reconsider-if condition.

Each skill does the part it is built for, and neither pretends to the other's authority: TRACE does not choose the implementation, and FORGE does not diagnose.

## 8. If only one is installed

Both are self-contained. Nothing in FORGE requires TRACE, and nothing in TRACE requires FORGE.

With FORGE alone: when a review or a static scan finds a defect in existing code, record it in FORGE's knowledge base with the file, the line and what was observed, and say in the report that it is outside this task's scope and was not investigated. Do not expand the task to chase it — that is the unrelated-changes antipattern — and do not diagnose it from a static read, which is exactly the overreach TRACE exists to prevent.

With TRACE alone: when an investigation's fix has several plausible shapes, say so, list them with their trade-offs as arguments rather than measurements, and mark the performance claims unmeasured. That is the honest version of the answer FORGE would have measured.
