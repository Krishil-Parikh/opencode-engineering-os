# The overengineering catalogue

What generated code gets wrong, how to detect each one mechanically where possible, and what to do about it.

This exists because the failure modes are specific and repeatable rather than random. Karpathy's public criticisms of LLM-written code name them directly: overengineering simple requirements, creating unnecessary abstractions, adding speculative flexibility, leaving dead code behind, making unrelated changes, and producing a thousand lines where a hundred would do. A systematic bias needs a checklist, not an exhortation.

`complexity.py` detects many of these. Where it can, the detector is named. Where it cannot, the review prompt is named instead.

## Contents

1. Unnecessary abstraction
2. Speculative flexibility
3. Dead code
4. Indirection without purpose
5. Defensive noise
6. Configuration that configures nothing
7. Premature optimisation
8. Dependency reflex
9. Reinvention
10. Unrelated changes
11. Comment inflation and comment absence
12. Error handling that hides errors
13. Volume
14. The other direction: under-engineering
15. Using this catalogue

---

## 1. Unnecessary abstraction

**What it looks like.** A class with one implementation. A factory that produces one type. An abstract base or `Protocol` with one implementor. A strategy pattern with one strategy. A `Manager`, `Handler`, `Processor` or `Service` wrapping a single function.

**Detector.** `single_method_classes`, `abstract_bases`, `class_count` against `function_count`.

**Why it happens.** Abstraction is what experienced code looks like, so generated code imitates the shape without the condition that justifies it: a second implementation that actually exists.

**What to do.** Inline it. The rule: an abstraction needs **two** current implementations, not one and an imagined future. If the second arrives, introducing the abstraction then is a small, mechanical change with tests already in place.

## 2. Speculative flexibility

**What it looks like.** Parameters nobody passes. A `**kwargs` forwarded somewhere. Hooks, callbacks and event points with no subscribers. Support for input shapes the spec excludes. A `mode` argument with one caller and one value.

**Detector.** `unused_parameters`, `kwargs_passthrough`. Review prompts 13 and 16.

**Why it happens.** It is cheap to add and feels prudent, and nothing punishes it at the moment of writing.

**What to do.** Delete it, citing the spec's **non-goals**. This is what non-goals are for: "streaming input is a non-goal" converts an argument into a deletion. Every speculative parameter is a permanent cost — it must be documented, tested, kept working — paid against a benefit that may never arrive.

## 3. Dead code

**What it looks like.** Unused imports. Private helpers nothing calls. Statements after a `return`. A branch whose condition cannot hold. A commented-out earlier attempt. `TODO` markers from the agent's own drafting.

**Detector.** `unused_imports`, `unused_functions`, `unreachable_lines`, `todo_comments`.

**Why it happens.** The code was refactored and the remnant was not removed, because nothing failed.

**What to do.** Remove it. Dead code is not neutral: it is read by everyone who maintains the file, it appears in searches, it gets updated by refactors, and it suggests a purpose that no longer exists.

## 4. Indirection without purpose

**What it looks like.** A function whose entire body returns one call. A chain of one-line helpers. A module that re-exports another module. Four hops from the entry point to the work.

**Detector.** `passthrough_functions`. Review prompt 14.

**Why it happens.** Decomposition is good, so more decomposition seems better. But a helper earns its place by being called twice, or by giving a non-obvious operation a name. One caller and a name that restates the call is pure cost.

**What to do.** Inline. Keep a single-caller helper only when its **name** is doing real work: `_resolve_contract_order()` can be worth keeping where `_get_key()` is not.

## 5. Defensive noise

**What it looks like.** Type checks the type system already guarantees. `if x is not None` where `x` cannot be `None`. Try/except around code that cannot raise. Re-validating what the caller validated. Asserting invariants the function itself just established.

**Detector.** None reliable. Review prompts 1 and 12.

**Why it happens.** Each check is individually defensible, which is why they accumulate.

**What to do.** Keep validation at the **boundary** — where untrusted input enters — and remove it in the interior. The distinction to apply: does this check protect against something a caller can actually do, or against something this code just ruled out?

## 6. Configuration that configures nothing

**What it looks like.** A constants module read in one place. An environment variable with a default nobody overrides. A config object threaded through five functions to reach one. A feature flag permanently on.

**Detector.** Partially: `unused_parameters`. Review prompt 13.

**What to do.** Inline the constant at its single use site, with a name. Configuration is justified by something actually varying — between environments, between callers, at runtime. A value that varies only in principle is a constant with extra steps.

## 7. Premature optimisation

**What it looks like.** A cache in front of a cheap pure function. A manual loop replacing a clear comprehension "for speed". `__slots__`, interning, or micro-tuning on a path called once per request. An index for a lookup over ten items. Complexity accepted for a performance claim nobody measured.

**Detector.** None. This is what phase 6 is for.

**Why it happens.** The optimisation is real in the abstract and irrelevant in context.

**What to do.** Measure. FORGE's advantage here is that the measurement is already in the workflow: if the optimisation does not clear the noise floor at the sizes the spec names, it is complexity bought with nothing. Note that this cuts both ways — in the bundled example an "obviously too heavy" NumPy approach turned out to be several times faster, which is also something only the measurement could say.

## 8. Dependency reflex

**What it looks like.** A package added for one function. A date library for one format call. A framework for one feature. A dependency whose capability the standard library covers.

**Detector.** `third_party_imports`, `undeclared_dependencies`, plus the `dependencies` axis.

**What to do.** Ask question 2 of the simplification pass and review prompts 17 to 19: what does it buy *here*, measured; is it already in the lock file; what happens if it is absent or a different version. A dependency is a permanent cost paid by everyone who builds, deploys, audits and upgrades the project. It is often worth it — FORGE's example found a dependency that was genuinely several times faster — but it must be an exchange, not a reflex.

## 9. Reinvention

**What it looks like.** A hand-written selection where `heapq.nlargest` exists. A manual date parse. A custom LRU where `functools.lru_cache` exists. A second helper in the codebase doing what the first already does.

**Detector.** None mechanical. This is the **baseline question** in phase 1, and simplification questions 4 and 5.

**Why it matters most.** It is the most expensive antipattern, because the duplicate must be maintained, tested and kept consistent with the original forever. It is also the cheapest to prevent: one search, before writing.

**What to do.** Search first, always. Register what you find as the baseline and make everything else beat it.

## 10. Unrelated changes

**What it looks like.** A fix that also reformats the file. A feature that renames variables elsewhere. An "improvement" to adjacent code nobody asked about. A dependency bumped in passing.

**Detector.** `git diff --stat` against the spec's stated scope.

**Why it matters.** It makes the change impossible to review, impossible to revert cleanly, and it mixes a tested change with an untested one. Surgical changes are not a style preference: they are what makes a change reviewable and reversible.

**What to do.** Keep the diff to the spec's scope. Record the unrelated improvement as a separate suggestion. If the spec names code the change may not touch, a reviewer can challenge on that basis directly.

## 11. Comment inflation and comment absence

**Inflation.** A docstring restating the signature. A comment on every line. A comment describing what the next line obviously does.

**Absence.** No note on the non-obvious thing: why the key is `(score, -id)` rather than `(-score, id)`, why this must run before that, which contract clause a guard implements, why the obvious approach was rejected.

**Detector.** `comment_ratio` in both directions, weakly. Review prompt 22.

**What to do.** Comment the **why**, never the what. The best outcome is usually a name instead of a comment: `_CONTRACT_ORDER` beats a comment explaining the tuple. In the bundled example this was exactly what the simplification pass produced, and it added two lines.

## 12. Error handling that hides errors

**What it looks like.** `except Exception: pass`. A broad catch that logs at debug and continues. A fallback returning stale or default data as if fresh. An exception translated without chaining the cause. A bare `except` catching cancellation and interruption.

**Detector.** Not in `complexity.py`. Review prompt 21.

**What to do.** Catch the narrowest exception that can actually occur; re-raise or handle, never swallow; chain causes (`raise X from e`); and make a fallback distinguishable from a real answer by the caller. If the sibling TRACE skill is available, this is the single most productive category of finding to hand it: see `core/integration_with_trace.md`.

## 13. Volume

**What it looks like.** A thousand lines where a hundred would do: all the above at once, plus repetition instead of a loop, plus a scaffold the task did not need.

**Detector.** `sloc`, `duplicated_blocks`, `function_count`, `smell_count`, and most of all the comparison with the `minimal` candidate.

**Why the minimal candidate exists.** It establishes the floor. When the performance candidate is six times longer, the question is not "is this too long" but "what are the extra five-sixths buying, and did the benchmark confirm it?" That is answerable; "does this feel too long" is not.

## 14. The other direction: under-engineering

A catalogue of overengineering invites the opposite error, so for completeness. These are also defects, and the `maintainability` candidate exists partly to catch them:

| Under-engineering | Consequence |
|---|---|
| One function doing five things | Untestable, unreadable, hard to change safely |
| No names for the concepts | Every reader re-derives the logic |
| Duplicated logic instead of a shared helper called twice | Two places to fix |
| Clever one-liners | Write-only code |
| No error handling where errors occur | Failures become mysteries |
| No validation at the trust boundary | A security surface |
| Silent fallbacks | Wrong answers presented as right ones |

The target is not minimal code. It is **the simplest code that satisfies every clause, with nothing in it that no clause needs**. Those are different, and the difference is why size is reported rather than ranked.

## 15. Using this catalogue

**As an implementer.** Read sections 1 to 12 before submitting, and declare anything you knowingly kept and why.

**As a reviewer.** Run `complexity.py scan`, cite its detectors in challenges, and use the sections it cannot detect as review prompts. A citation to `complexity.json` is a basis; "this feels overengineered" is not.

**As the simplification agent.** The eight questions in `core/simplification_pass.md` map onto these sections. Removing something is only accepted if `simplify.py verify` passes.

**As the orchestrator.** When every candidate shows the same antipattern, that is a signal about the spec, not about the implementers: an over-broad requirement, a missing non-goal, or an interface that invites generality. Fix the spec for next time, and record it in the knowledge base.
