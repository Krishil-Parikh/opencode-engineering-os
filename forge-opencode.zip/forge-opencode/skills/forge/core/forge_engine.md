# FORGE engine

The mandatory nine-phase sequence, with the entry gate, the work, the artefacts and the exit gate for every phase. The orchestrator owns this document. The other roles own their briefs in `agents/`.

`<skill-dir>` means the directory that contains this skill's `SKILL.md`. Run every command from the repository root so that paths in the records stay stable.

## Contents

1. The principle the engine enforces
2. Where the idea comes from
3. Roles
4. Scaling: how much machinery a task deserves
5. The nine phases
6. The state file and resuming
7. Budgets and stop conditions
8. Degraded operation
9. Failure modes of the engine itself

---

## 1. The principle the engine enforces

> Never accept the first working implementation. Generate alternatives, challenge them, measure them, simplify them and verify the winner.

A normal coding agent optimises for getting the task done. FORGE optimises for getting the task done with the simplest, cleanest, most maintainable implementation that meets the measured constraints. Those are different objectives and they need different machinery.

The distinction that makes FORGE more than a style guide: it never asks an agent *"is this implementation optimised?"*. It asks *"can you demonstrate that this implementation is better under predefined engineering constraints?"* Every design choice below exists to keep those two apart.

- Nothing is concluded from a claim that has no measurement or no citable location behind it.
- Correctness is a gate, not a score. A candidate that fails one mandatory gate is out, whatever its numbers.
- A difference smaller than the measurement noise is not a difference.
- Several candidates can be on the Pareto front at once. When they are, FORGE names the trade-off and asks the requester rather than inventing weights.
- Fewer lines are not automatically better. Size is reported, never ranked on alone.
- The simplification pass is verified by re-running the same gates and benchmarks, not by anyone's judgement that the result reads better.

## 2. Where the idea comes from

FORGE combines ideas that already work in separate places. Attribution matters here, so each is described as what it actually is.

| Source | What FORGE borrows | What it is, precisely |
|---|---|---|
| Engineering guidelines inspired by Karpathy's observations | Think before coding, simplicity first, surgical changes, goal-driven execution | These four principles circulate as a **community-authored** skill (`andrej-karpathy-skills`, originally published by Forrest Chang, later hosted under Multica AI), built from Karpathy's public criticisms of LLM-written code. It is not an official release by Karpathy. It teaches an agent how to *behave* while coding; it does not generate or benchmark alternatives. FORGE treats it as the behavioural floor and adds the experiment. See `core/engineering_guidelines.md`. |
| Karpathy's `autoresearch` | Experiment, measure, keep or discard | A real repository: an agent edits `train.py`, trains for a **fixed five-minute budget**, and the change is kept or reverted according to **validation bits per byte** (lower is better), measured rather than judged. The fixed budget is what makes runs comparable. FORGE's measurement protocol is this discipline applied to general software, with one difference it must respect: autoresearch optimises a single number, and general-purpose software has several objectives, some of which cannot be reduced to one. That is why FORGE ranks on a Pareto front instead of a score. |
| AgentCoder | Separate the coding, testing and execution roles | A multi-agent code-generation paper: a programmer agent, a test designer and a test executor, iterating on test feedback. The borrowed rule: **never let the coding agent be the only judge of its own code.** |
| SWE-Debate | Adversarial multi-agent reasoning | A real method: multiple fault-propagation traces built by traversing a code dependency graph, specialised agents each taking one trace's perspective, **three rounds** of competitive debate, a consolidated fix plan, then an MCTS-based modification agent. The borrowed rule: agents should **challenge each other's assumptions**, not vote on which code looks nicer. |
| RankAgent | Generate several candidates and rank them systematically | A code-ranking framework that generates multiple implementations and ranks them through systematically generated tests, rather than asking a model which looks best. |
| Surveys of LLM-agent code generation | What actually goes wrong | Coordination overhead, verification, context limits and reliability remain the hard problems in multi-agent coding. This is why FORGE caps the agent count and spends its budget on measurement instead of on more opinions. |

The one thing FORGE does not borrow from anywhere: a single weighted score. Collapsing correctness, speed, memory, complexity and dependency cost into one number is how a system pretends to have answered a question it has only hidden.

## 3. Roles

| Role | Does | Never does |
|---|---|---|
| Orchestrator (the main agent) | Runs the nine phases, owns the spec and the records, dispatches and briefs every other role, writes the report, talks to the requester | Writes a candidate and then judges it. Picks a winner the measurements do not support. Breaks a tie the requester should break |
| Requirement analyst | Turns the request into a frozen contract: interface, clauses, acceptance criteria, gates, axes, constraints. Searches for an existing solution and registers it as the baseline | Starts implementing. Answers an unknown contract question by choosing |
| Test designer | Writes the test suite from the frozen spec **before** candidates exist, plus the differential generator and the drivers | Reads a candidate and then writes tests that fit it |
| Implementers (up to four, one strategy each) | Each produces one candidate under one strategy: baseline, minimal, performance, maintainability, alternative architecture | Sees another implementer's candidate before submitting. Claims a performance property without a measurement |
| Benchmark engineer | Calibrates the host, runs the measurements, computes scaling, reports spreads and ties | Reports a single run as a result. Compares across hosts or sessions |
| Adversarial reviewers (one or two) | Attack candidates they did not write, each challenge citing a location, a measurement, a failing input or a contract clause | Raises a challenge from taste. Reviews their own candidate as their only review |
| Security reviewer | Judges the security gate where the task touches untrusted input, secrets, subprocesses, deserialisation, file paths or network | Waves the gate through as "not applicable" without saying why |
| Simplification agent | Takes the leader and removes things, then has the result verified against identical gates and benchmarks | Accepts its own output. Removes something load-bearing and calls it simpler |
| Knowledge curator | Records measured facts with their scope and date, patterns, and rejected approaches with their reconsider-if conditions | Records a number nobody measured. Writes "always do X" from one task |

Independence is structural, not a matter of asking agents to be fair. Implementers are briefed separately from the same frozen spec and do not see each other's work. Reviewers do not review their own candidates. The simplification agent's output is verified by the harness, not by itself.

On hosts without subagents the orchestrator plays the roles one at a time, writing each role's output to disk before starting the next (see section 8).

## 4. Scaling: how much machinery a task deserves

Do not spawn fifty agents for every coding request. A small number of genuinely independent candidates, evaluated rigorously, beats a large group generating near-identical solutions. Fifty agents producing variations of the same approach is not a competition; it is the same opinion fifty times, with the costs of coordination and none of the benefits of diversity.

| Tier | When | What runs |
|---|---|---|
| **T0: no competition** | The answer is one obvious line, a config change, or a mechanical edit; or an existing function already does it | Phase 1 only. Register the baseline, confirm it passes, ship it, and say that no competition was warranted. **This is a legitimate and common outcome.** |
| **T1: baseline plus one** | Small, self-contained, one plausible approach beyond the existing one | Baseline plus one candidate, gates, a measurement if any axis matters, simplification pass, select |
| **T2: focused competition** (the default) | A real implementation choice exists: several plausible algorithms or architectures, or performance matters, or the code will be maintained by others | Baseline plus 2 to 3 candidates, full gates, differential testing, measurement with calibration, one or two reviewers, simplification, Pareto selection |
| **T3: full competition** | High-stakes, hot-path, or load-bearing; a genuine architectural fork; or T2 ended with an unresolved tie | Baseline plus 4 candidates across distinct strategies, two reviewers, security review, full measurement across sizes with scaling, simplification of the top two, Pareto selection with the requester consulted |
| **Expansion** | A specific open question remains that a new strategy could answer | Add one implementer with one written question. Record in the spec why it was added |

**The recommended default shape at T3:** four independent implementation agents, two adversarial reviewers, one benchmark engineer, one simplification agent. Scale dynamically when the task warrants it, and only then.

**Choosing the strategies.** The four lenses are chosen to produce genuinely different code, not four flavours of the same idea:

| Strategy | Mandate |
|---|---|
| `baseline` | What already exists: a standard-library call, an existing codebase function, something already in the lock file. **Always generated when one exists.** |
| `minimal` | The least code that satisfies every clause. No abstraction, no configurability, no speculative generality |
| `performance` | The approach with the best expected asymptotic or constant-factor behaviour, accepting more code to get it |
| `maintainability` | The version optimised for the next person: clearest naming, most obvious control flow, best error messages |
| `alternative` | A genuinely different architecture: a different data structure, a library, a different place to do the work, a different algorithmic family |

If two strategies would produce the same code, merge them and generate something else instead. Four candidates that differ only in variable names waste the whole budget.

## 5. The nine phases

Each phase has an **exit gate**. Do not start the next phase until it holds. If a gate cannot be met, record why in the spec's open questions and carry the gap forward explicitly: it will cap the confidence of the final verdict.

### Phase 1. Requirements

*Understand what is being asked, and write it down so that candidates are comparable.*

```
python3 <skill-dir>/scripts/workspace.py new --title "<short title>" --language <lang> --tier T2 \
    --statement "<the request, in the requester's words>"
```

Prints the task directory; call it `TASK`. Then, following `core/requirements_protocol.md`:

1. Fill `TASK/requirements.md`. Every `unknown` is a question for the requester, not a decision for an implementer.
2. Record the interface and the **contract clauses**. The usual omissions are empty input, tie-breaking, what happens at and beyond a boundary, whether the input is mutated, and whether the caller gets its own objects back. An unstated clause becomes four different behaviours in four candidates.
3. Record **measurable** acceptance criteria. "Fast" is not a criterion; "median under 50 ms at n=100,000 on the benchmark host" is.
4. **Ask the baseline question.** Does this already exist, in the standard library, in this codebase, or in a dependency already in the lock file? Search before writing. Register what you find with `spec.py baseline`. This is the cheapest step in FORGE and the one most often skipped.
5. Define the gates (`spec.py gate`) and the axes (`spec.py axis`), marking which axes participate in ranking.
6. Record the requester's priority order if they have stated one, and leave it `unset` if they have not. Priorities are never inferred.
7. Choose the tier and write down why.

```
python3 <skill-dir>/scripts/spec.py check --task TASK
python3 <skill-dir>/scripts/spec.py freeze --task TASK
```

**Exit gate.** `spec.py check` passes and the spec is frozen with a hash. Candidates may now be generated.

### Phase 2. Test design

*Write the tests from the spec, before any candidate exists.*

The test designer writes `TASK/tests/`: the contract suite (one test per clause, named after the clause), the differential case generator, the differential driver and the benchmark driver. Full guidance in `core/correctness_and_tests.md`.

Writing the tests before the implementations is not a preference. A suite written after reading a candidate tests what that candidate does, which is exactly the thing in question.

**Exit gate.** Every contract clause has at least one test naming it. The drivers run. A deliberately wrong stub implementation fails the suite (if it passes, the suite is not testing anything).

### Phase 3. Candidate generation

*Produce genuinely independent implementations of the frozen spec.*

Dispatch the implementers the tier calls for, in parallel where the host allows. Each gets: its strategy brief from `agents/`, `agents/_candidate_submission.md`, the frozen spec, and nothing else. No implementer sees another's output. Then register each:

```
python3 <skill-dir>/scripts/candidate.py add --task TASK --strategy performance \
    --dir candidates/C-03 --entry solution.py --author performance-implementer \
    --title "<one line>" --rationale "<why this approach>" \
    --tradeoff "<what it gives up>" [--dependency <name>]
```

**Exit gate.** Every candidate is registered with a code hash, a rationale and at least one declared trade-off. The baseline is among them if one exists.

### Phase 4. Gates

*Correctness before anything else.*

```
python3 <skill-dir>/scripts/harness.py run --task TASK --all
python3 <skill-dir>/scripts/harness.py report --task TASK
python3 <skill-dir>/scripts/harness.py differential --task TASK --cases 200 --seed 7 --shrink
```

Differential testing is where independent candidates pay for themselves: four implementations of one spec are a free oracle, and any disagreement is a bug in at least one of them, found without writing the expected answer down. Resolve **every** disagreement before ranking anything. If the contract does not settle it, that is a gap in the spec and the requester decides.

A candidate that fails a mandatory gate is fixed and re-run (`candidate.py rehash` first, which marks its old results stale) or retired with a recorded reason.

**Exit gate.** Every active candidate passes every mandatory gate against its current code hash, and the differential run is clean.

### Phase 5. Adversarial review

*Attack what the tests did not.*

Reviewers work through `core/adversarial_review.md` and `review.py prompts` against candidates they did not write. Every challenge cites a location, a measurement, a failing input or a contract clause.

```
python3 <skill-dir>/scripts/review.py challenge --task TASK --against C-05 --by reviewer-1 \
    --kind correctness --claim "<what is wrong>" --basis "<where to look>" --proposed-test "<how to settle it>"
python3 <skill-dir>/scripts/review.py resolve --task TASK --id R-001 --status upheld --evidence "<...>"
```

A challenge that reveals a gap in the test suite becomes a **new gate**, which means unfreezing the spec, adding it, re-freezing and re-running everything. That is deliberately expensive, and it is why the spec is frozen in the first place.

**Exit gate.** No challenge is left `open` or `needs_measurement`. No candidate carries an unfixed upheld correctness challenge.

### Phase 6. Measurement

*Measure, do not argue.*

```
python3 <skill-dir>/scripts/bench.py env       --task TASK
python3 <skill-dir>/scripts/bench.py calibrate --task TASK --candidate C-01 --size <largest>
python3 <skill-dir>/scripts/bench.py run       --task TASK --all
python3 <skill-dir>/scripts/bench.py table     --task TASK
python3 <skill-dir>/scripts/bench.py compare   --task TASK --size <largest> --axis time
python3 <skill-dir>/scripts/bench.py scaling   --task TASK
python3 <skill-dir>/scripts/complexity.py scan --task TASK --all
```

Calibrate first. Measuring the same candidate twice tells you what the host's noise actually is, and a noise floor that was guessed rather than measured is how benchmark theatre happens. Full methodology in `core/measurement_protocol.md`.

**Exit gate.** Every eligible candidate is measured on every ranked axis at the sizes the spec names, the host and calibration are recorded, and no comparison rests on a difference below the noise floor.

### Phase 7. Simplification

*Remove things, then prove nothing broke.*

```
python3 <skill-dir>/scripts/simplify.py questions
python3 <skill-dir>/scripts/simplify.py attempt --task TASK --from C-01 --dir candidates/C-06 \
    --entry solution.py --removed "<each thing removed>" --answers 1,3
python3 <skill-dir>/scripts/harness.py run  --task TASK --candidate C-06
python3 <skill-dir>/scripts/bench.py run    --task TASK --candidate C-06
python3 <skill-dir>/scripts/simplify.py verify --task TASK --id C-06
```

The pass is mandatory even when the answer is "nothing can be removed" — record that, with the questions answered. Full guidance in `core/simplification_pass.md`.

**Exit gate.** A simplification attempt exists and is verified: accepted (passes identical gates, no regression beyond the noise floor) or rejected with the measurement that rejected it.

### Phase 8. Selection

*Gate, then front, then verdict.*

```
python3 <skill-dir>/scripts/pareto.py eligible  --task TASK
python3 <skill-dir>/scripts/pareto.py front     --task TASK --size <largest>
python3 <skill-dir>/scripts/pareto.py tradeoffs --task TASK --size <largest>
python3 <skill-dir>/scripts/pareto.py select    --task TASK --size <largest>
```

Five verdicts are possible, and three of them are not a winner:

| Verdict | Meaning |
|---|---|
| `SELECTED` | One candidate alone on the front |
| `SELECTED_WITH_TRADEOFF` | Several on the front; the requester's stated priority order picked one, and what it gives up is recorded |
| `TIE_NEEDS_PRIORITIES` | Several on the front and no stated priorities. The question goes back to the requester |
| `NO_CANDIDATE_PASSES` | Nothing passes every mandatory gate |
| `INSUFFICIENT_MEASUREMENT` | The measurements cannot support a comparison |

**Exit gate.** `decisions.json` holds a verdict with its reasons.

### Phase 9. Report and learn

```
python3 <skill-dir>/scripts/report_generator.py --task TASK --notes TASK/notes.md
python3 <skill-dir>/scripts/kb.py import --task TASK
python3 <skill-dir>/scripts/kb.py pattern --name "<...>" --guidance "<...>" --task <TASK-ID>
python3 <skill-dir>/scripts/kb.py reject --approach "<...>" --why "<measured reason>" --reconsider-if "<...>"
```

Read the generated report once as the person who has to act on it. If a sentence in your summary to the requester is stronger than the report's verdict, weaken the sentence.

**Exit gate.** The report exists, the knowledge base has the facts with their scope and date, and the summary you give the requester states the verdict in its first two sentences.

## 6. The state file and resuming

`TASK/spec.json` carries `phase`, `status`, `tier`, `frozen_at` and `spec_hash`. Update `phase` as you pass each gate (`workspace.py set --task TASK phase=6-measure`). An interrupted task is resumed with `workspace.py status --task TASK`: the records are the task, the conversation is not. Everything a fresh agent needs is on disk by design.

## 7. Budgets and stop conditions

Stop and report the current verdict when:

- The verdict is `SELECTED` or `SELECTED_WITH_TRADEOFF` and the simplification pass is done.
- Two further candidates have failed to reach the front. The approach space is explored; more candidates will not help.
- The front has settled and the only open question is a priority the requester must set. Ask, and stop.
- The remaining differences are all below the noise floor. The task is finished and the answer is "any of these; here is the one with fewest dependencies".
- The budget is reached. Report what was measured, what was not, and which candidate is currently leading on what.

Never keep generating candidates because none feels right. If the measurements cannot separate them, say so.

## 8. Degraded operation

**No subagents.** Play each role in sequence. Before each role, re-read only that role's brief and the files it would be given. Write its output to disk before starting the next. For the implementers, write each candidate to its own directory before thinking about the next strategy, and do not revise an earlier one in light of a later idea — if a later idea improves an earlier candidate, that is a new candidate with its own id. For review, attack each candidate as if you had not written it, using the prompt list literally. State in the report that roles were not independently executed.

**No shell.** The scripts cannot run, so the measurements do not exist. Say so plainly: without measurement FORGE cannot rank on time or memory, and the honest verdict is based on gates, contract reasoning and static reading only. Keep the same records by hand in the same formats, mark every performance statement as unmeasured, and do not report a performance winner.

**No test runner.** Write the tests anyway and run the contract cases by hand through the smallest possible driver. A gate that was not run is `not-run`, never `pass`.

**One candidate only** (budget, or the task is genuinely T0 or T1). Say that no competition was run. Still do the baseline question, the gates and the simplification pass: those are most of the value and they are cheap.

## 9. Failure modes of the engine itself

| Failure mode | What it looks like | Guard |
|---|---|---|
| Benchmark theatre | Confident numbers from one run on a noisy host | Calibration, medians, spreads, the noise floor |
| Fake winner | Several candidates on the front collapsed into one by invented weights | `TIE_NEEDS_PRIORITIES` is a first-class verdict |
| Measuring the broken | Benchmarking a candidate that fails a gate | The harness blocks it; `bench.py` skips it unless forced |
| Comparing different problems | Two candidates fast at computing different answers | Result digests per size, plus differential testing |
| Line-count worship | The 12-line version wins because it is 12 lines | Size is reported, never a default ranking axis |
| Self-judging | The implementer reviews, benchmarks or simplifies its own candidate | Separate roles; the harness decides gates |
| Spec drift | The target moves while candidates are measured against it | Freeze and hash; unfreezing invalidates everything loudly |
| Review by taste | "This feels overengineered" | Every challenge needs a basis |
| Simplification by assertion | The simpler version is accepted because it reads better | `simplify.py verify` re-runs the identical gates and benchmarks |
| Candidate monoculture | Four candidates, one idea | Distinct strategy mandates; merge duplicates and generate something else |
| Reinventing the baseline | Four hand-written candidates and nobody checked the standard library | The baseline question is a phase-1 exit gate |
| Stale comparison | Numbers from code that has since changed | Code and spec hashes on every result, reported as stale |
