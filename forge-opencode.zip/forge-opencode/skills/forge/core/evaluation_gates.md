# Evaluation gates

Phase 4. Constraint-first evaluation: what must be true before a candidate is allowed to compete at all.

## Contents

1. Constraint-first, not points
2. Mandatory versus advisory
3. The gate kinds
4. How gates run
5. Manual gates
6. What a gate result records
7. Failing a gate: fix, or retire
8. Staleness
9. The security gate
10. Resource gates and hard limits
11. Common gate mistakes

---

## 1. Constraint-first, not points

Evaluation is not a weighted sum. It is a sequence of filters followed by a ranking:

```
all candidates
    │
    ├── fail a mandatory gate ──────────▶ out of the competition, recorded with the reason
    │
    ├── exceed a hard limit on an axis ─▶ excluded, recorded with the figure
    │
    ▼
eligible candidates ──▶ Pareto front on the ranked axes ──▶ verdict
```

The reason correctness cannot be a score is that a weighted sum lets a fast candidate buy its way past a broken one. **Speed is not a defence against being wrong.** A candidate that fails a correctness gate is not a slightly worse candidate; it is not a candidate.

So the evaluation table in the spec looks like this:

| Property | Treatment |
|---|---|
| Functional correctness | **Mandatory gate** |
| Regression (existing tests still pass) | **Mandatory gate** |
| Security, where relevant | **Mandatory gate** |
| Runtime performance | Benchmark, ranked |
| Memory | Benchmark, ranked, sometimes with a hard limit |
| Code complexity | Static analysis and review; reported, rarely ranked |
| Maintainability | Independent review; argued, never scored |
| Code size | **Secondary metric. Reported, not ranked** |

## 2. Mandatory versus advisory

A **mandatory** gate decides eligibility. Failing one removes the candidate from ranking entirely, and `bench.py` will refuse to measure it without `--force`, because measuring how fast something broken is tells you nothing you can use.

An **advisory** gate is recorded and reported but does not exclude. Use it for things that are informative rather than disqualifying: a strict linter the project has not adopted, a type-check with known gaps, a style preference.

Guidance: if you would not ship a candidate that fails it, it is mandatory. If you would ship it with a note, it is advisory. A "mandatory" gate that the team routinely overrides is not a gate; it is a comment.

Every task needs at least one mandatory correctness gate. `spec.py check` refuses to pass without one, because without it every candidate "passes" and the ranking is meaningless.

## 3. The gate kinds

| Kind | Checks | Typical command |
|---|---|---|
| `correctness` | The contract holds, clause by clause | the designed test suite |
| `regression` | Existing behaviour is unchanged | the project's existing suite |
| `security` | No new exposure where the task touches untrusted input, secrets, subprocesses, deserialisation, paths or the network | reviewer judgement, plus a scanner if the project has one |
| `resource` | A hard ceiling is respected | a run with a memory or descriptor limit |
| `compatibility` | Runtime version floor, platform, import-time behaviour, the exact entry point | an import-and-call smoke check |
| `style` | Lint, format, type-check | the project's tools |
| `custom` | Anything else decidable by a command | — |

The compatibility gate is worth more than it looks. A one-line check that the entry point imports, is callable, and does nothing at import time catches a whole class of candidate that would otherwise fail confusingly inside the benchmark driver:

```
python3 -c "import sys; sys.path.insert(0,'tests'); from _load import load_entry; f=load_entry(); assert callable(f)"
```

## 4. How gates run

```
python3 <skill-dir>/scripts/harness.py run    --task TASK --all
python3 <skill-dir>/scripts/harness.py run    --task TASK --candidate C-03 --gate G-1
python3 <skill-dir>/scripts/harness.py report --task TASK
```

Each gate command runs with the task directory as the working directory and these variables set, so one command serves every candidate:

| Variable | Value |
|---|---|
| `FORGE_CANDIDATE` | the candidate id |
| `FORGE_CANDIDATE_DIR` | absolute path to its directory |
| `FORGE_ENTRY` | its entry file name |
| `FORGE_ENTRY_PATH` | absolute path to the entry file |
| `PYTHONPATH` | the candidate directory, prepended |

A gate passes on exit status zero and fails otherwise. A gate that exceeds its timeout **fails**: a gate timeout is a failure, not a slow pass, because an implementation that cannot finish the check cannot be shipped on the strength of it.

`harness.py report` prints the candidate-by-gate matrix with an eligibility verdict per candidate, which is the one table to look at before any measurement.

## 5. Manual gates

Some gates cannot be a command: a security judgement, an API-design review, a check that the code matches a house convention no linter encodes. Declare them `--manual` and record the result with evidence:

```
python3 <skill-dir>/scripts/harness.py record --task TASK --candidate C-02 --gate G-5 \
    --result pass --by security-reviewer \
    --evidence "no user input reaches a subprocess or eval; the only file path is constructed from an allow-listed basename at solution.py:31-38; reviewed against core/adversarial_review.md section 5"
```

Two rules the tool enforces:

- A gate **with** a command cannot be recorded by hand. It is decided by running it. This stops "I read it and it looks right" from substituting for the suite.
- A manual `pass` or `fail` **requires** `--evidence` naming what was examined, by whom, and what was found. A judgement with no evidence does not pass a gate.

## 6. What a gate result records

Every result carries the candidate's **code hash** and the **spec hash**, plus the exit status, the output tail, and the timestamp. That is what makes the record trustworthy later: a result is evidence about one specific version of one specific candidate judged against one specific contract, and the tooling can tell when any of those three has moved.

## 7. Failing a gate: fix, or retire

Two legitimate responses, and they are different:

**Fix** when the failure is a defect: a misread clause, a boundary case, a bug. Edit the candidate, then:

```
python3 <skill-dir>/scripts/candidate.py rehash --task TASK      # marks old results stale
python3 <skill-dir>/scripts/harness.py run --task TASK --candidate C-03
```

**Retire** when the failure is a property of the approach, not a defect in this attempt:

```
python3 <skill-dir>/scripts/candidate.py retire --task TASK --id C-05 \
    --reason "cannot satisfy contract clause 6 (identity) at the specified sizes: records returned from worker processes are copies. Architectural, not a fixable defect."
```

The distinction matters because a retirement is a **finding about an approach** and belongs in the knowledge base with the condition under which it would be worth reconsidering. In the bundled example the process-pool candidate was not badly written: no amount of fixing would let it return the caller's own objects across a process boundary. That is knowledge, and it was recorded as knowledge rather than as a mistake.

A retired candidate keeps its measurements and the challenges against it. It appears in the report under "what was not chosen, and why". Nothing is deleted to make the competition look tidier.

## 8. Staleness

A gate result goes stale when the candidate's code changes or the spec changes. `harness.py report` shows `stale` rather than a pass, and `pareto.py eligible` refuses to call such a candidate eligible.

This is the mechanism that stops the most insidious failure in a competitive workflow: a candidate that passed, was then "improved", and is now ranked on the strength of a result that describes code nobody has.

## 9. The security gate

Add a mandatory security gate whenever the task touches any of: untrusted input, credentials or secrets, subprocess execution, deserialisation (`pickle`, YAML, arbitrary JSON into objects), file paths derived from input, SQL or other query construction, network requests to a caller-supplied destination, template rendering, or cryptography.

The reviewer judges against the attack surface the task actually creates, and records evidence. Specific things that disqualify a candidate rather than merely counting against it:

- user input reaching `eval`, `exec`, a shell, or a deserialiser that can construct objects,
- a path built from input without containment,
- a query built by string concatenation,
- a secret logged, printed, or included in an error message,
- a dependency added without stating what it is and why it is trusted,
- cryptography implemented by hand.

If the task genuinely has no security surface, record the gate as `skipped` with one line saying why. "Not applicable" without a reason is how the gate stops meaning anything.

## 10. Resource gates and hard limits

A **hard limit** on an axis (`spec.py axis --limit`) excludes rather than demotes. Use it for real ceilings: a memory budget the process actually has, a descriptor limit, a wall-clock deadline the caller enforces.

The difference from ranking: exceeding a limit means "this cannot be used", while being worse on a ranked axis means "this is worse". Expressing a *preference* as a limit is a mistake, because it silently removes candidates the requester might have preferred on another axis.

Resource gates can also be enforced as commands, which is stronger than measuring afterwards:

```
python3 <skill-dir>/scripts/spec.py gate --task TASK --kind resource --mandatory \
    --description "completes at n=1e6 inside 512 MiB" \
    --command "python3 -c \"import resource,subprocess,sys; resource.setrlimit(resource.RLIMIT_AS,(512*1024*1024,)*2); sys.exit(subprocess.run([sys.executable,'tests/bench_driver.py'],input='{\\\"size\\\":1000000,\\\"reps\\\":1,\\\"warmup\\\":0}',text=True,capture_output=True).returncode)\""
```

## 11. Common gate mistakes

| Mistake | Why it matters | Fix |
|---|---|---|
| No mandatory correctness gate | Every candidate "passes"; ranking is meaningless | `spec.py check` refuses to pass |
| Gates written after reading the candidates | They test what the candidates do | Tests come from the spec, in phase 2 |
| Correctness as a score | A fast wrong candidate outranks a slow right one | Correctness is a filter |
| Treating a timeout as a slow pass | Ships something that cannot finish the check | Timeout is a failure |
| Recording a manual pass with no evidence | An opinion wearing a gate's clothes | `--evidence` required |
| Overriding a mandatory gate to keep a favourite | The whole mechanism stops working | Fix it, retire it, or change the spec deliberately and re-run everything |
| Lowering a gate because nothing passes | Converts a finding into a false success | `NO_CANDIDATE_PASSES` is a legitimate verdict |
| Benchmarking an ineligible candidate | Measures the speed of something broken | The harness blocks it; `bench.py` skips it |
| Letting the test suite be the only check | Suites are incomplete by construction | Differential testing, plus adversarial review |
