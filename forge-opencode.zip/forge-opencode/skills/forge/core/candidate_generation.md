# Candidate generation

Phase 3. How to produce implementations that are genuinely different, and how to keep them independent enough for the comparison to mean anything.

## Contents

1. Why independence matters more than count
2. The five strategies
3. Independence rules
4. What each implementer receives
5. What each implementer returns
6. Registering a candidate
7. Avoiding candidate monoculture
8. Declaring trade-offs
9. Dependencies
10. Common failures in generation

---

## 1. Why independence matters more than count

A small number of genuinely independent candidates, evaluated rigorously, will outperform a large group of agents generating nearly identical solutions.

The reason is mechanical. Four candidates give you three things: a choice, a free correctness oracle (differential testing), and a set of trade-offs to show the requester. All three depend on the candidates **differing**. Four variations on one approach give you one choice, no oracle (they agree because they are the same code), and nothing to show. You have paid four times for one candidate.

So the budget goes on *distinctness*, not on quantity. Two sharply different candidates are worth more than six near-duplicates, and the point of assigning each implementer a strategy is to force the difference.

Independence also buys the oracle. In the bundled example, two candidates misread the same contract clause and the divergence appeared the instant two implementations were asked the same question — localised to a three-record input by `harness.py differential`. Neither bug was visible from reading the code.

## 2. The five strategies

Each implementer gets exactly one mandate. The mandates are chosen to produce different code, not different styling.

### `baseline` — what already exists

The standard-library call, the existing codebase function, or the thing already in the lock file that does this. **Always generated when one exists**, registered first, as C-01.

This is not a courtesy entrant. It has the lowest cost of ownership of any candidate — no new code to maintain, no new tests to keep, no new dependency — so anything else has to beat it on a *measurement*, which is a far higher bar than beating it on an opinion. In the bundled example the baseline was one standard-library call and it reached the Pareto front; the only candidate that beat it on speed did so by adding a dependency.

### `minimal` — the least code that satisfies every clause

The fewest moving parts. No abstraction, no configurability, no error handling the spec does not ask for, no generality for a second caller that does not exist.

Its job in the competition is to establish the floor: how little code does this actually need? Everything above that floor has to justify itself. It is often slower, sometimes acceptably so, and the measurement decides.

### `performance` — the best expected behaviour, accepting more code

The approach with the best asymptotics or constant factors: a better data structure, one pass instead of three, avoiding allocation, a bounded working set.

Its claims must be stated as **predictions, not facts**: "O(n log k) rather than O(n log n), so the advantage should grow with n". The benchmark then confirms or refutes it. An implementer asserting that its candidate is faster, with no measurement, has contributed nothing the other candidates did not.

### `maintainability` — optimised for the next person

The clearest version. Names that say what things are, control flow with no cleverness, error messages that identify the problem, the ordering contract visible in the code rather than implied by a comparator.

Its job is to be the version you would want to inherit. It frequently loses on speed and frequently wins the argument, because the measured difference turns out to be below the noise floor and then readability is the only thing left that distinguishes the candidates.

### `alternative` — a genuinely different architecture

A different algorithmic family, a different data structure, a library doing the work, the work done in a different place (in the database, in C, in another process, at write time instead of read time).

This is the strategy that produces surprises in both directions. In the bundled example it produced the fastest candidate (NumPy, several times faster than the baseline) *and* the one eliminated outright (a process pool, which cannot return the caller's own objects across a process boundary). Both were worth generating: one changed the answer, the other closed off an approach with evidence and became a knowledge-base entry.

## 3. Independence rules

1. **Each implementer works alone.** It does not see another implementer's candidate, rationale or code before submitting.
2. **Each gets the frozen spec and nothing else.** Not the orchestrator's hunch about which approach will win. Not "the performance one is probably going to be fastest, confirm that".
3. **No implementer is told what the others were assigned.** Knowing that someone else has `performance` changes what `minimal` writes.
4. **Revision after submission creates a new candidate.** If a later idea improves an earlier candidate, register it as a new id with `--derived-from`. Editing a submitted candidate invalidates its gate results and measurements (`candidate.py rehash` says so loudly).
5. **The orchestrator does not write a candidate and then judge the competition.** If it has an approach in mind, it goes to an implementer as a mandate, and the orchestrator records that it was its idea.

On a host without subagents, play each implementer in turn and write each candidate to disk before thinking about the next strategy. Do not go back and improve C-02 after writing C-03: that is contamination, and it is exactly what the independence rules exist to prevent. State in the report that the candidates were generated sequentially by one agent.

## 4. What each implementer receives

```
You are acting as the <strategy> implementer. Read and follow <skill-dir>/agents/<strategy>_implementer.md
and <skill-dir>/agents/_candidate_submission.md.

Task: <TASK path>
The frozen spec: run `python3 <skill-dir>/scripts/spec.py show --task <TASK>`
Write your implementation to: <TASK>/candidates/C-0N/
Entry point: exactly as the spec's interface states.

Return: the code, a one-line rationale, and the trade-offs your approach accepts.
```

Nothing else. No hints about what is expected, no summary of what other candidates look like, no suggestion of which approach the orchestrator favours.

## 5. What each implementer returns

| Item | Requirement |
|---|---|
| The code | In its own directory, exposing exactly the spec's entry point, with no side effects at import time |
| A one-line rationale | Why this approach, in terms of the strategy it was given |
| Declared trade-offs | What this approach gives up. At least one |
| Dependencies | Every third-party import, declared. The static scan cross-checks and flags undeclared ones |
| Predictions, if any | "I expect this to win above n≈10⁴ and lose below it." Testable, and the benchmark will settle it |
| Known gaps | Anything the implementer knows it has not handled, stated rather than hidden |

Full details in `agents/_candidate_submission.md`.

## 6. Registering a candidate

```
python3 <skill-dir>/scripts/candidate.py add --task TASK --strategy performance \
    --dir candidates/C-03 --entry solution.py --author performance-implementer \
    --title "bounded min-heap over the stream" \
    --rationale "Memory proportional to the number kept rather than the input." \
    --tradeoff "more code than the stdlib call for the same asymptotic behaviour" \
    [--dependency numpy] [--derived-from C-01]
```

The register records a **code hash** of the candidate's directory. Every gate result and measurement carries it, and anything whose hash no longer matches the files is reported as stale rather than silently compared. After editing a candidate, run `candidate.py rehash`, which says exactly what must be re-run.

Registration is refused before the spec is frozen, and a second `baseline` is refused: there is one existing thing to beat, not several.

## 7. Avoiding candidate monoculture

Before dispatching, write down in one line what each candidate will do differently. If two lines say the same thing, you have one candidate and a wasted slot.

Checks that catch monoculture early:

- **Different data structure or different algorithmic family?** If all four sort, you have one candidate.
- **Different place for the work?** In-process, in a library, in the database, at write time.
- **Different dependency posture?** At least one standard-library-only candidate, at least one that may use a library if that is admissible.
- **Different code-size regime?** The minimal one should be substantially shorter than the performance one. If they come out the same length, one of the mandates was not followed.

If a strategy genuinely has nothing distinct to offer for this task, **do not generate it**. Report that the approach space for this problem has two serious entries, not four, and run a smaller competition. A fabricated third candidate dilutes the differential oracle and adds a row to every table for no information.

## 8. Declaring trade-offs

Every real implementation gives something up. An implementer who declares none has usually not looked, and `candidate.py` says so.

| Strategy | Trade-offs it usually has |
|---|---|
| baseline | Little control if the contract later changes; behaviour tied to a runtime version |
| minimal | Does more work than necessary; no hooks for a future requirement; terse error behaviour |
| performance | More code; more invariants to maintain; often a worse small-input constant |
| maintainability | Usually slower; sometimes more lines |
| alternative | A dependency, a deployment constraint, a serialisation boundary, a platform assumption |

Declared trade-offs serve three purposes: they give reviewers a starting point, they make the Pareto discussion concrete, and they are the honest basis for the report's "what was not chosen and why".

## 9. Dependencies

A new dependency is a permanent cost paid by everyone who builds, deploys, audits and upgrades the project, in exchange for a benefit that must be **measured**.

Rules:

1. Declare every third-party import with `--dependency`. The static scan flags undeclared ones.
2. Respect the spec's constraint. If it says no new dependencies, a candidate that adds one will fail the dependency gate, and that is the constraint working, not a bug.
3. The benefit must clear the noise floor. "NumPy might be faster" is not a reason; "NumPy is 4.8× faster at the size the spec names, measured" is.
4. The cost does not disappear when the benefit is real. In the bundled example the NumPy candidate *won* on both time and memory and still did not win the task, because the dependency axis is ranked too and nobody had said which mattered. That is the correct outcome: the trade-off went back to the requester with the numbers attached.
5. Check whether it is already in the lock file. A dependency you already pay for is nearly free; a new one is not.

## 10. Common failures in generation

| Failure | What it looks like | Fix |
|---|---|---|
| Monoculture | Four candidates, one idea, differing in names | Write the distinctness line per candidate before dispatching |
| No baseline | Four hand-written candidates, and the standard library did it in one line | The baseline question is a phase-1 exit gate |
| Contaminated candidates | Candidate 3 is candidate 2 with the reviewer's comments applied | Isolation; a revision is a new id |
| Unfollowed mandate | The `minimal` candidate has a plugin registry | The mandate is the brief; a reviewer can challenge on this basis |
| Asserted performance | "This is the fast one" with no measurement | Predictions go in the submission and the benchmark settles them |
| Hidden dependency | An import nobody declared | The static scan cross-checks declared against imported |
| Different entry point | A candidate exposing `select_top` when the spec says `top_n` | The compatibility gate catches it; the spec states it exactly |
| Import-time side effects | Work, I/O, or a global built at import | Gate G-2 in the example checks precisely this |
| Lazy work | Returns a generator, so the benchmark measures nothing | The contract must state whether the result is lazy; the driver consumes it |
| Edited after measuring | Numbers describing code that no longer exists | Code hashes, `rehash`, and stale reporting |
