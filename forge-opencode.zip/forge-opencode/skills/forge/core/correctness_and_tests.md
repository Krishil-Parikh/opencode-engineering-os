# Correctness and tests

Phase 2, and the machinery that keeps phase 4 honest. How to design a test suite from a spec before any implementation exists, and how to use several independent implementations as an oracle.

The rule borrowed from AgentCoder's separation of programmer, test designer and test executor: **never let the coding agent be the only judge of its own code.**

## Contents

1. Tests before candidates
2. One test per contract clause
3. The edge cases that actually divide implementations
4. Testing at the size the spec names
5. The reference implementation
6. Property-based and randomised testing
7. Differential testing: the free oracle
8. Shrinking
9. What differential agreement does and does not prove
10. The drivers
11. Mutation sanity: does the suite test anything?
12. Common test-design failures

---

## 1. Tests before candidates

The suite is written in phase 2, from the frozen spec, before any candidate exists. This is not a preference about process. A suite written after reading an implementation tests what that implementation does, which is precisely the question under investigation. The bugs it will systematically miss are the ones the author of that implementation did not think of, which are the ones you needed the suite for.

Practical consequence: the test designer must be able to write every test from the spec alone. If a test cannot be written without looking at a candidate, the spec is missing a clause, and that is a phase-1 defect to fix before generating candidates.

## 2. One test per contract clause

Each contract clause gets at least one test, and the test names the clause. When a candidate fails, the output should say which promise was broken, not merely that something is wrong.

```python
# -- clause 2: tie-breaking by id ascending ---------------------------------
def test_ties_broken_by_id_ascending():
    records = [{"id": i, "score": 42} for i in range(10)]
    assert ids(top_n(records, 4)) == [0, 1, 2, 3]
```

Group the tests by clause with comment headers, and keep the docstring at the top of the file listing the clauses under test. A reviewer should be able to check coverage of the contract by reading the file's structure, without running anything.

## 3. The edge cases that actually divide implementations

From experience of what four independent implementations disagree about:

| Case | Why implementations diverge |
|---|---|
| **Empty input** | Early return, exception, or falling through to a code path that assumes non-empty |
| **Single element** | Loops that assume a comparison, heaps that assume a sibling |
| **Every element identical** | The pure tie-break test. Reveals any implementation that resolves ties by data-structure accident |
| **Ties at the selection boundary** | The hard one: more elements tied at the cut-off than there are places left. An implementation can order ties correctly *within* its result and still select the **wrong set**. The bundled example's two bugs were both exactly this |
| **n equal to the input size** | Off-by-one, and the partition/selection fast path that assumes `k < n` |
| **n greater than the input size** | Clamping, or an index error |
| **n of zero, and negative n** | Empty result, exception, or a slice that silently returns everything |
| **Negative and zero values** | Sign assumptions, `max`-with-zero initialisation |
| **Already-ordered and reverse-ordered input** | Best and worst case for comparison-based approaches |
| **Duplicates throughout** | Interacts with stability |
| **Input mutation** | Snapshot before, compare after. An in-place sort is faster and may be forbidden |
| **Object identity** | Does the caller get its own objects back? Decides whether serialisation or process boundaries are admissible at all |
| **Unicode, encoding, normalisation** | For anything string-keyed |
| **Floats** | `NaN` breaks every comparison-based ordering; `-0.0 == 0.0`; precision in composite keys |

Write the boundary cases as explicit, named tests with hand-computed expectations. Do not rely on the randomised tests to cover them: random inputs hit the interior of the space, and the bugs live on its edges.

## 4. Testing at the size the spec names

A contract clause must be tested at the volumes the contract is about.

This is the single most instructive failure in the bundled example. The identity clause was tested with five records. One candidate switched from a serial path to a process pool above twenty thousand records, so the test exercised the serial path, passed, and the candidate violated the clause at every size that mattered. The suite was not wrong; it was incomplete, and no amount of re-reading the implementation would have found it. A reviewer reading the *design* found it in one pass, and the fix was a new gate rather than a patch.

So: for every clause, ask whether any plausible implementation might behave differently at scale — thresholds, batching, parallelism, chunking, streaming, caching, a different code path for large inputs — and if so, test it at scale too. Expensive tests are acceptable: one 100,000-record test that takes a second is cheaper than shipping the wrong behaviour.

## 5. The reference implementation

Put the slow, obvious, unmistakably correct version in the test file:

```python
def expected(records, n):
    """Reference ordering, straight from the contract. Deliberately the slow, obvious version."""
    if n <= 0:
        return []
    return sorted(records, key=lambda r: (-r["score"], r["id"]))[:n]
```

It is the contract expressed as code, and it earns its place three times over: it makes randomised testing possible, it makes the expected value of a boundary case obvious, and it is the thing to re-read when two candidates disagree and nobody is sure which is right.

Write it for clarity, never for speed. If the reference is also the fastest candidate, that is a result: the task is over and the answer is the obvious version.

## 6. Property-based and randomised testing

Randomised tests over a parameterised seed catch what hand-written cases miss, as long as the generator is aimed at the right distribution.

```python
@pytest.mark.parametrize("seed", range(12))
def test_matches_reference_on_random_input(seed):
    rng = random.Random(seed)
    size = rng.randrange(1, 120)
    space = rng.choice([2, 3, 10, 1000])          # small spaces force ties
    records = [{"id": i, "score": rng.randrange(space)} for i in range(size)]
    rng.shuffle(records)
    n = rng.randrange(0, size + 3)                 # including 0 and beyond the size
    assert ids(top_n(records, n)) == ids(expected(records, n))
```

Two deliberate choices in that generator:

- **A small score space.** With scores drawn from a million, ties essentially never happen and the tie-break clause is never exercised. Draw from 2 or 3 as often as from 1000.
- **`n` beyond the size, and zero.** The boundary is where implementations differ.

Use fixed seeds, parameterised, so failures are reproducible and appear as separate test cases rather than one flaky test.

Properties worth asserting directly when there is no reference: output length, that the result is a subset of the input, that scores are non-increasing, that the input is unchanged, that running twice gives the same answer, and that the result equals the reference's.

## 7. Differential testing: the free oracle

Once there are two or more independent implementations of one spec, they can be tested against each other without anybody writing down the expected answer. Any disagreement means at least one is wrong.

```
python3 <skill-dir>/scripts/harness.py differential --task TASK --cases 200 --seed 7 --shrink
```

Every candidate is given the same generated case, and the outputs are grouped into equivalence classes. The output names which candidates returned what:

```
case 3 (shrunk):
  input: {"records": [{"id": 2, "score": 42}, {"id": 3, "score": 42}, {"id": 1, "score": 42}], "n": 1}
  C-01,C-02,C-05   -> [[0, 42]]
  C-03,C-04        -> [[2, 42]]
```

That is the bundled example's real output. Two candidates had misread the tie-breaking clause in the same direction, and the disagreement localised it to a three-record input.

What differential testing buys over the pass/fail suite:

- **It localises.** A failing test says "this assertion failed". A disagreement hands you the minimal input and both answers.
- **It needs no oracle.** You do not have to know the right answer to know that someone is wrong.
- **It finds what the suite did not think of**, because the generator explores and the candidates disagree wherever the spec was ambiguous.
- **It catches divergence at benchmark sizes**, where the hand-written suite usually does not reach.

The generator should attack the dividing lines, not the average case. The bundled generator cycles through ten shapes: empty, single, all-identical-scores, n beyond size, n of zero, three variants of dense ties near the boundary, negative scores, and a wide spread.

**Every disagreement must be resolved before anything is ranked.** Decide which behaviour the contract requires. If the contract does not say, that is a gap in the spec, and the requester decides — not the implementer who happened to guess.

## 8. Shrinking

`--shrink` halves the longest list in a disagreeing case while the disagreement survives, then reports the smallest input it could still reproduce it on. A three-record counterexample is a bug report; a two-hundred-record one is a puzzle.

Shrinking is a convenience, not a proof: a shrunk case is still only one case. When a shrunk case looks like it reveals a general rule ("ties at the boundary"), write that rule as a named test in the suite so it is checked for every future candidate.

## 9. What differential agreement does and does not prove

When every candidate agrees on every case, the tool says:

> All candidates agreed on every case. That is evidence of consistency, not of correctness: they can agree and all be wrong.

This matters. Agreement is a weak signal, and it is weakest in exactly the case where the candidates were generated by the same model from the same prompt — the shared misreading is the likeliest bug, and it is invisible to a method that compares candidates against each other.

The division of labour:

| Method | Answers |
|---|---|
| The designed suite, with its reference | Do they implement **the contract**? |
| Differential testing | Do they implement **the same thing**? |
| Adversarial review | What did the suite **not think of**? |

All three are needed. Differential testing without a contract suite tells you the candidates match; it does not tell you they match the requirement.

## 10. The drivers

The task supplies two drivers, shared by every candidate, in `TASK/tests/`:

**`driver.py`** (differential): reads one JSON case on stdin, calls the entry point, prints the result as JSON on stdout. It should normalise the output to the thing the contract is about — in the example, a list of `[id, score]` pairs, so the comparison is about which records in which order and not about dict key ordering. It should also snapshot the input and fail loudly if the candidate mutated it.

**`bench_driver.py`** (measurement): protocol in `core/measurement_protocol.md`, section 14.

**`_load.py`** (shared loader): loads the candidate named by `FORGE_ENTRY_PATH` so that one suite runs against every candidate unchanged. It must register the module in `sys.modules` before executing it, or a candidate using multiprocessing cannot pickle its own module-level helpers.

Nothing in the drivers may know which candidate it is loading.

## 11. Mutation sanity: does the suite test anything?

Before trusting the suite, check that it can fail. Write a deliberately wrong stub — return the input unchanged, return the *lowest* scores, ignore the tie-break — and run the suite against it. If the suite passes, it is not testing the thing you think.

Cheap mutations worth trying on any ordering or selection task:

| Mutation | Should be caught by |
|---|---|
| Return the input, truncated | the ordering tests |
| Sort ascending instead of descending | the ordering tests |
| Drop the secondary sort key | the tie-break tests |
| Use `>=` instead of `>` at a boundary | the boundary tests |
| Return `n+1` or `n-1` items | the length test |
| Sort the input in place | the mutation test |
| Return copies of the records | the identity test, **at scale** |

This is the fastest way to find out that a suite has a blind spot, and it takes two minutes.

## 12. Common test-design failures

| Failure | Consequence | Fix |
|---|---|---|
| Tests written after the candidates | They encode one implementation's behaviour | Phase 2 comes before phase 3 |
| No reference implementation | Randomised testing is impossible | Write the slow obvious version |
| Random scores from a huge space | Ties never occur; the tie clause is untested | Mix in tiny score spaces |
| Only interior cases | Boundary bugs ship | Explicit named boundary tests |
| Clause tested only at toy size | A threshold-switching candidate passes and is wrong in production | Test at the size the spec names |
| One flaky randomised test | Failures are irreproducible | Parameterise fixed seeds |
| Asserting implementation details | Tests break on a legitimate rewrite | Assert the contract, not the mechanism |
| No mutation sanity check | A suite that cannot fail | Run it against a deliberately wrong stub |
| Differential testing treated as proof | "They all agree, so it is correct" | Agreement is consistency, not correctness |
| Disagreement left unresolved | Ranking candidates that compute different things | Resolve every disagreement before phase 6 |
