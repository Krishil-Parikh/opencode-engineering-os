# Requirements protocol

Phase 1. How to turn a request into a frozen contract that several independent implementations can be measured against.

This phase decides whether the rest of FORGE is worth running. Candidates built against a vague spec cannot be compared, because they are not solving the same problem; and a competition that nobody needed is pure cost.

## Contents

1. Why the spec is frozen
2. The contract, and the clauses everyone forgets
3. Measurable acceptance criteria
4. The baseline question
5. Gates
6. Axes
7. The benchmark plan
8. Priorities, and why they are never inferred
9. Constraints and non-goals
10. Choosing the tier
11. Freezing, and what unfreezing costs
12. When to stop and ask

---

## 1. Why the spec is frozen

Four implementations are only comparable if they were aiming at the same target. If the contract changes while they are being written, or worse while they are being measured, the comparison is between candidates that answered different questions.

So: the spec is written first, checked for completeness, then **frozen and hashed**. Every gate result and every measurement carries that hash. Changing the spec afterwards is possible and sometimes necessary, but it is deliberately loud: `spec.py freeze --unfreeze` requires a reason, and every existing result becomes stale and must be re-run.

```
python3 <skill-dir>/scripts/spec.py check  --task TASK
python3 <skill-dir>/scripts/spec.py freeze --task TASK
```

`check` refuses to pass while the spec has no entry point, no contract clauses, an acceptance criterion with no way to decide it, no mandatory correctness gate, no ranked axis, or an unanswered baseline question.

## 2. The contract, and the clauses everyone forgets

The contract is the list of promises the implementation makes. Each clause is one sentence that can be tested. Record them with:

```
python3 <skill-dir>/scripts/spec.py interface --task TASK --language python \
    --entry "top_n(records, n)" \
    --signature "def top_n(records: list[dict], n: int) -> list[dict]" \
    --contract "returns the n highest-scoring records, ordered by score descending" \
    --contract "ties on score are broken by id ascending"
```

**An unstated clause becomes four different behaviours in four candidates.** That is not a hypothetical: in the bundled example, two of five candidates resolved ties by whatever their data structure made convenient, and both were wrong in the same direction. The clause was stated, which is the only reason it was caught.

Work through this list for every task. Each row is a question that has a right answer the requester knows and the implementer does not.

| Question | Why it matters |
|---|---|
| What is the entry point, exactly? | Four candidates must expose the same thing to be measured by one driver |
| What happens on empty input? | Empty list, empty string, zero rows, `None` |
| What happens at the boundary, and beyond it? | `n` equal to the size, larger than the size, zero, negative |
| How are ties broken? | The commonest silent divergence. "Any order" is a valid answer, but it must be *said*, because then the tests must not assume one |
| Is ordering of the output guaranteed? | Stable? Deterministic across runs? Across versions? |
| Is the input mutated? | A candidate that sorts in place is faster and may be unacceptable |
| Does the caller get its own objects back, or copies? | Decides whether a process-boundary or serialisation approach is even admissible. In the bundled example this single clause eliminated a whole architecture |
| What types are accepted? | Ints only? Floats? Mixed? `Decimal`? Missing keys? |
| What happens on malformed input? | Raise, skip, default, or undefined |
| Is it called once, or in a hot loop? | Decides whether fixed overhead or asymptotics matter |
| Single-threaded or concurrent callers? | Decides whether shared state is admissible |
| What is the realistic input size, and the worst case? | Decides the benchmark sizes, which decide the winner |
| Is the result consumed lazily? | A generator moves the work elsewhere and makes timing meaningless unless specified |
| What may the implementation depend on? | Standard library only, lock file only, anything |

Answer every row, or mark it `unknown` and ask. A row answered by an implementer's guess is a bug with a 1-in-N chance of being noticed.

## 3. Measurable acceptance criteria

```
python3 <skill-dir>/scripts/spec.py criterion --task TASK --mandatory --kind correctness \
    --statement "every contract clause holds" \
    --measured-by "the designed test suite in tests/test_contract.py passes"
```

`--measured-by` is required, and the tool rejects a criterion without it. The test: could a script decide this, or could a named person decide it by running something?

| Not a criterion | A criterion |
|---|---|
| "fast" | "median under 50 ms at n=100,000 on the benchmark host" |
| "memory-efficient" | "peak RSS growth under 64 MiB at n=1,000,000" |
| "clean code" | "no function above cyclomatic 10; no duplicated 4-line block" (and even then, reported, not ranked) |
| "scales well" | "measured growth exponent below 1.2 over n=10³ to 10⁶" |
| "production-ready" | decompose it: the gates it must pass, the limits it must respect |
| "handles errors properly" | "raises ValueError on a missing score key; the suite covers it" |

If you cannot write `--measured-by`, you have a wish rather than a criterion, and no competition can settle it. Either make it measurable or move it to a review question, where it will be argued and recorded as an argument.

## 4. The baseline question

```
python3 <skill-dir>/scripts/spec.py baseline --task TASK --exists yes --what "heapq.nlargest" \
    --searched "stdlib heapq, sorted, bisect; grep for existing helpers in src/" \
    --why-not-enough "none: it is sufficient, so it competes as the baseline"
```

Ask, before any code is written:

1. **Does the standard library do this?** Reach for the language's own documentation, not memory.
2. **Does this codebase already do this?** Search for it. Duplicated functionality is the most expensive kind of new code, because now there are two behaviours to keep in step.
3. **Does something already in the lock file do this?** A dependency you already pay for is free; a new one is not.
4. **If something exists, why is it not enough?** Write the answer down. "It does not handle our tie-breaking" is a reason. "I would rather write it" is not.

If something exists, **register it as candidate C-01 with strategy `baseline`**. It then has to be beaten by a measurement, which is a much higher bar than being beaten by an opinion. In the bundled example, the baseline was a one-line standard-library call; it survived to the Pareto front and the only thing that beat it on speed cost a dependency.

If nothing exists, `--exists no` requires `--searched` describing what you actually looked at. "No" without a search is an assertion.

**The honest outcome of this question is sometimes that the task is over.** If the standard library does exactly this and nothing in the spec says otherwise, the answer is one line, tier T0, and no competition. That is a success.

## 5. Gates

A gate is a pass-or-fail condition. Mandatory gates decide eligibility: a candidate that fails one is out of the competition regardless of its numbers, because speed is not a defence against being wrong.

```
python3 <skill-dir>/scripts/spec.py gate --task TASK --id G-1 --kind correctness --mandatory \
    --description "the designed test suite passes" \
    --command "python3 -m pytest tests/test_contract.py -q"
```

| Kind | What it checks | Mandatory? |
|---|---|---|
| `correctness` | The contract holds. At least one is always mandatory | Yes |
| `regression` | Existing tests still pass. Mandatory whenever the change touches existing code | Usually |
| `security` | Judged by a reviewer where the task touches untrusted input, secrets, subprocesses, deserialisation, file paths or the network | Where relevant |
| `resource` | A hard ceiling: memory, file descriptors, time | Where the spec sets one |
| `compatibility` | Runtime version floor, platform, import-time behaviour | Usually |
| `style` | Lint, format, type-check | Project's choice |
| `custom` | Anything else with a command | As needed |

Gate commands run with the task directory as the working directory and the candidate identified by environment variables (`FORGE_CANDIDATE_DIR`, `FORGE_ENTRY_PATH`, and `PYTHONPATH` prepended), so one command serves every candidate.

A gate with no command must be `--manual`, and a manual result requires `--evidence` naming what was examined, by whom, and what was found. A judgement with no evidence does not pass a gate.

## 6. Axes

An axis is something measured and possibly ranked on.

```
python3 <skill-dir>/scripts/spec.py axis --task TASK --id time   --direction min --unit s   --pareto
python3 <skill-dir>/scripts/spec.py axis --task TASK --id memory --direction min --unit KiB --pareto --limit 262144
python3 <skill-dir>/scripts/spec.py axis --task TASK --id size   --direction min --unit lines
```

| Axis | Source | Ranked by default |
|---|---|---|
| `time` | Measured median at the ranking size | Usually yes |
| `memory` | Measured peak RSS growth | Often |
| `throughput` | Derived from time and size | Alternative framing of time; do not rank on both |
| `complexity` | Total cyclomatic complexity (`complexity.py`) | Rarely; prefer review |
| `dependencies` | Declared plus imported third-party packages | Often, and cheap to rank on |
| `size` | Source lines | **No.** Reported only |

**`--limit` is a hard ceiling, not a ranking input.** A candidate that exceeds it is excluded, not demoted. Use it for real constraints ("must fit in 256 MiB"), never as a way of expressing a preference.

**Why `size` is not ranked by default.** Fewer lines are not automatically better: a 12-line implementation that is slower, harder to understand, or wrong should lose to a 25-line one. Size is reported because the requester may care and because a sudden jump in it is worth explaining. Mark it `--pareto` only if the requester explicitly asked to minimise code size, and the tool prints a warning when you do.

Do not rank on more than three or four axes. Every added axis makes the Pareto front larger (more candidates become non-dominated), until everything is on the front and the ranking says nothing.

## 7. The benchmark plan

```
python3 <skill-dir>/scripts/spec.py benchmark --task TASK --sizes 1000,10000,100000 \
    --reps 9 --warmup 2 --noise-floor 5
```

- **Sizes.** At least two; three or more spanning two decades is better. Include the size the spec actually names, and include a small one, because an approach with high fixed overhead can win every large benchmark and lose in production where the real inputs are tiny.
- **Reps.** 9 by default, odd so the median is a real observation. The tool warns below 5.
- **Warmup.** 2 for CPython; much more for any JIT.
- **Noise floor.** Start at 5%, then **calibrate** and set what the host actually shows (`core/measurement_protocol.md`, section 6). A floor that was guessed rather than measured is how benchmark theatre happens.

## 8. Priorities, and why they are never inferred

```
python3 <skill-dir>/scripts/spec.py priorities --task TASK --source user \
    --order time,dependencies,memory --quote "<the requester's own words>"
```

`--source` accepts `user` or `unset`. It deliberately **rejects** `inferred`: if the requester has not stated a preference order, FORGE leaves it unset, and the selection phase presents the trade-off and asks. Choosing for them and calling it an inference is how a measurement system quietly becomes an opinion generator.

Leaving priorities unset is the normal state at the start. Most requesters have not thought about whether they would trade a dependency for a 5× speed-up, and the honest moment to ask is when the measurements show that the trade actually exists, with the numbers attached.

Record their answer in their words (`--quote`), so the report can show why the winner won.

## 9. Constraints and non-goals

```
python3 <skill-dir>/scripts/spec.py constraint --task TASK --text "no new third-party dependencies"
python3 <skill-dir>/scripts/spec.py constraint --task TASK --non-goal --text "streaming input"
```

Constraints that matter in practice: dependencies allowed, runtime version floor, memory ceiling, platforms, code the change may not touch, and the effort ceiling.

**Non-goals are as valuable as goals**, because they are what stops speculative flexibility. "Streaming input is a non-goal: the caller always has a list in memory" pre-empts an implementer building an iterator protocol nobody asked for, and gives a reviewer a citable basis for challenging it if they do.

## 10. Choosing the tier

| Tier | Signals | Candidates |
|---|---|---|
| T0 | One obvious line; a config change; an existing function already does it | None: register the baseline and ship |
| T1 | Small and self-contained; one plausible approach beyond the existing one | Baseline + 1 |
| T2 | A real implementation choice; performance matters; others will maintain it | Baseline + 2 to 3 |
| T3 | Hot path, load-bearing, or a genuine architectural fork; or T2 tied | Baseline + 4, two reviewers |

Write the choice and the reason into the spec. The commonest mistake is running T2 on a T0 task, which burns the budget on a competition whose answer was in the standard library.

## 11. Freezing, and what unfreezing costs

After `freeze`, `spec.py` refuses changes to the interface, criteria, gates, axes, benchmark plan, constraints and non-goals. Priorities and the baseline record can still be set, because neither changes what is being measured.

When a review challenge reveals a genuine gap — most often a contract clause nobody tested — the spec must change:

```
python3 <skill-dir>/scripts/spec.py freeze --task TASK --unfreeze --reason "R-001 upheld: clause 6 untested at scale"
python3 <skill-dir>/scripts/spec.py gate --task TASK --id G-4 --kind correctness --mandatory \
    --description "clause 6 holds at the size the spec names" --command "python3 -m pytest tests/test_identity_at_scale.py -q"
python3 <skill-dir>/scripts/spec.py freeze --task TASK
python3 <skill-dir>/scripts/harness.py run --task TASK --all      # everything re-runs
```

This is expensive on purpose. Every existing result now carries the old hash and is reported as stale until re-run. The cost is the point: it is what stops the target drifting quietly while candidates are being judged.

## 12. When to stop and ask

Stop phase 1 and put a question to the requester when:

- A contract row is `unknown` and the answer changes what gets built. Guessing produces a candidate that is wrong in a way no test will catch, because the test was written from the same guess.
- The acceptance criteria cannot be made measurable. Either you do not yet know what "good" means, or the real criterion is a judgement that should be a review question.
- The baseline exists and looks sufficient. Confirm that before spending four implementers on it.
- The constraints are contradictory: "no new dependencies" plus "must be as fast as NumPy" may simply be unsatisfiable, and that is worth saying before four candidates discover it.
- The realistic input size is unknown. It decides the winner more often than the algorithm does.

Ask narrowly, with the options and their consequences, and record the answer in the spec. One question answered now is cheaper than four candidates built against a guess.
