# Engineering guidelines

The behavioural floor. How an agent should conduct itself while writing code, independent of the competition machinery around it.

## Attribution, stated plainly

Four principles circulate as a community-authored agent skill — `andrej-karpathy-skills`, originally published by Forrest Chang and later hosted under Multica AI — assembled from Andrej Karpathy's **public criticisms** of LLM-written code. It is a community interpretation, **not an official skill released by Karpathy**, and it should not be described as one.

What it covers and what it does not:

| | |
|---|---|
| It teaches an agent how to **behave** while coding | Think before coding, simplicity first, surgical changes, goal-driven execution |
| It does **not** create a competitive optimisation process | It generates no alternatives and benchmarks nothing |

That gap is the whole reason FORGE exists. These guidelines are the floor; the phases in `core/forge_engine.md` are the experiment built on top of them. The text below is FORGE's own expression of the four principles, not a reproduction of that skill.

Separately, Karpathy's `autoresearch` repository supplies the measurement discipline: an agent edits `train.py`, trains under a **fixed five-minute budget**, and the change is kept or reverted according to **validation bits per byte**. The agent's belief about whether the change helped is not an input. `core/measurement_protocol.md` is that idea applied to general software.

## 1. Think before coding

Understand the requirement before implementing it.

- Restate the request in your own words and check the restatement against what was asked. If the restatement is longer than the request, you are probably inventing requirements; if it is shorter, you are probably dropping some.
- List the inputs, the outputs, and the behaviour at every boundary **before** writing a line. In FORGE this is phase 1, and it is written down as contract clauses so that four implementations cannot each invent their own answer.
- Find the questions you cannot answer and **ask them**. A question answered by a guess becomes a bug that no test catches, because the test was written from the same guess.
- Search for what already exists. This is the single highest-yield minute in the whole process.
- Decide what "done" means, concretely enough to check.

The anti-pattern: starting to type as soon as the request is understood well enough to begin, and discovering the requirement by writing code against it.

## 2. Simplicity first

Write the minimum code necessary.

- The target is **the simplest code that satisfies every clause, with nothing in it that no clause needs.** Not the shortest: a terse one-liner that the next reader has to decode is not simple.
- An abstraction needs two current implementations, not one and an imagined future.
- A parameter needs a caller that passes something other than the default.
- A dependency needs a measured benefit.
- Delete what you stop using, in the same change in which you stop using it.
- Prefer the standard library. It is tested by more people than your code ever will be.

The failure modes this principle is aimed at are catalogued in `core/antipatterns.md`, with mechanical detectors where they exist. The reason FORGE does not stop at the principle: an agent asked whether its own code is simple will say yes. So the principle is enforced by a separate pass with a single mandate (`core/simplification_pass.md`) and a verification step that re-runs the same gates and benchmarks.

**Simplicity is not the same as fewer lines, and FORGE is built to keep them apart.** Size is reported, never ranked on by default. In the bundled example the accepted simplification made the leading candidate two lines *longer*: it named the ordering key after the contract clause it encodes and stopped rebuilding it on every call.

## 3. Surgical changes

Avoid unrelated modifications.

- Change what the task requires, and nothing adjacent.
- No drive-by reformatting, renaming, reordering or dependency bumps.
- If you notice an unrelated improvement, record it as a suggestion rather than making it. In FORGE, that is a review challenge or a knowledge-base entry.
- Keep the diff reviewable. A reviewer who cannot see the change among the noise cannot review it, and a change that cannot be reviewed cannot be trusted or cleanly reverted.
- Respect the code the spec says not to touch.

This matters more for agents than for people, because an agent can produce a large diff quickly and has no instinct for the cost of reviewing it.

## 4. Goal-driven execution

Define measurable success criteria, then show you met them.

- Every criterion needs a way to decide it. "Fast" is a wish; "median under 50 ms at n=100,000 on the benchmark host" is a criterion. `spec.py criterion` refuses one without a `--measured-by`.
- State predictions as predictions. "This should win above n≈10⁴ and lose below it" is a contribution, because it can be checked. "This is the fast one" is not.
- Verify against the criteria, not against your own impression. Run the suite; do not read the code and conclude it passes.
- Report what you did not check, and what you assumed. A declared assumption is a work item; a hidden one is a defect waiting for someone else to find.

This is where the guidelines stop being enough on their own and the measurement protocol takes over. The question an agent should be asked is never *"is this implementation optimised?"* but *"can you demonstrate that this implementation is better under predefined engineering constraints?"*

## How these interact with the phases

| Principle | Where FORGE enforces it |
|---|---|
| Think before coding | Phase 1: the contract, the acceptance criteria, the baseline question, and a frozen spec before any candidate exists |
| Simplicity first | Phase 7's dedicated pass with mechanical verification; `size` deliberately excluded from ranking; the `minimal` candidate as a floor |
| Surgical changes | The spec's scope and non-goals; review challenges citing them; the static scan's diff signals |
| Goal-driven execution | `--measured-by` on every criterion; gates; the measurement protocol; verdicts that can refuse to pick a winner |

## When to apply the guidelines without the machinery

FORGE's phases cost real time and tokens. The guidelines do not. For a one-line change, a config edit, or a task where the answer is already in the standard library, apply all four principles and skip everything else — that is tier **T0** in `core/forge_engine.md`, and recognising it is a skill in itself.

Run the competition when there is a genuine implementation choice, when performance matters, or when the code will be maintained by people who were not there. Run the guidelines always.
