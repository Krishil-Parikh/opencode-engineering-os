# The simplification pass

Phase 7. The leading candidate is handed to an agent whose only job is to remove things, and whose output must survive the identical gates and benchmarks.

This is the phase that most changes what gets shipped, and it is a controlled version of the simplicity-first principle: the simplified version is not accepted because it looks cleaner, it is accepted because it **passed the same tests and did not regress beyond the noise floor**.

## Contents

1. Why this needs its own phase
2. The eight questions
3. Producing the candidate
4. Verification, which is the whole point
5. The three outcomes
6. When the answer is "nothing"
7. What not to remove
8. Simplifying more than one candidate
9. Common failures

---

## 1. Why this needs its own phase

An implementer optimises for making its approach work. Nobody in phases 3 to 6 is rewarded for deleting code. So the code that arrives at selection carries whatever accumulated along the way: a parameter added while debugging, an abstraction that anticipated a second caller, a helper that wraps one call, an import that is no longer used.

The characteristic failure of generated code is specific and repeatable: overengineering simple requirements, unnecessary abstractions, speculative flexibility, dead code left behind, unrelated changes, and a thousand lines where a hundred would do. Those are not random mistakes; they are a systematic bias, and a systematic bias needs a dedicated counter-pressure rather than a general instruction to be tidy.

Hence a separate agent with a single mandate — remove things — and a mechanical check that it did not break anything in the process.

## 2. The eight questions

```
python3 <skill-dir>/scripts/simplify.py questions
```

Ask every one of the leading candidate, in order.

1. **Can an abstraction be removed?** A class with one implementation, a factory producing one type, an interface with one implementor, a layer that forwards and nothing more.
2. **Can a dependency be eliminated?** What does it actually buy over the standard library *here*, measured?
3. **Can several functions be collapsed?** A chain of one-line helpers is harder to follow than the five lines they wrap.
4. **Can an existing library function do this?** The standard library is tested by more people than this code ever will be.
5. **Are we duplicating functionality that already exists in this codebase?** Search before writing.
6. **Can allocations be reduced?** A copy per element, an intermediate list immediately consumed, a dict built to be read once.
7. **Are we issuing queries, requests or system calls we do not need**, or doing per-item work that could be done per batch?
8. **Are we solving a problem that does not exist?** A parameter with one value, a flag never set, a branch never taken, a case the spec explicitly excludes.

Question 8 is the one with the highest yield, and the spec's **non-goals** are its evidence. "Streaming input is a non-goal" makes an iterator protocol removable rather than arguable.

`complexity.py` provides mechanical evidence for several of these: `passthrough_functions` for question 1, `third_party_imports` for question 2, `unused_imports`, `unused_functions` and `unreachable_lines` for dead code, `duplicated_blocks` for question 5, `single_method_classes` for question 1.

## 3. Producing the candidate

The simplified version is a **new candidate**, derived from the leader:

```
mkdir -p TASK/candidates/C-06
# write the simplified implementation there
python3 <skill-dir>/scripts/simplify.py attempt --task TASK --from C-01 --id C-06 \
    --dir candidates/C-06 --entry solution.py --by simplification-agent \
    --title "C-01 with the key hoisted and named" --answers 1 \
    --removed "the per-call lambda construction: hoisted to module level and named after the contract clause it encodes" \
    --removed "nothing else: questions 2 to 8 all answered no"
```

`--removed` is required, once per thing removed, and `--answers` records which of the eight questions were answered yes. It is registered with `strategy: simplified` and `derived_from`, so it competes as an ordinary candidate once verified.

It is a new candidate rather than an edit because the original must remain measurable. If the simplification regresses, the comparison that shows it regressed needs both versions.

## 4. Verification, which is the whole point

```
python3 <skill-dir>/scripts/harness.py run    --task TASK --candidate C-06
python3 <skill-dir>/scripts/bench.py run      --task TASK --candidate C-06
python3 <skill-dir>/scripts/complexity.py scan --task TASK --candidate C-06
python3 <skill-dir>/scripts/simplify.py verify --task TASK --id C-06 --size 100000
```

`verify` checks three things against the parent, and refuses to accept on anybody's judgement:

1. **Every mandatory gate passes**, against this candidate's current code hash. A gate that was not run for this candidate is a problem, not a pass.
2. **No ranked axis regresses beyond the noise floor.** Within the floor, or with overlapping bands, counts as unchanged.
3. **The static change is recorded**: lines, complexity, nesting, function count, dependencies, smell count — reported, not judged.

The output is a verdict with the figures:

```
C-06 (simplification of C-01): ACCEPTED
  time: unchanged within noise (3.9% apart, floor 5.0%)
  memory: unchanged within noise (0.0% apart, floor 5.0%)
  static change:
    sloc  13 -> 15
```

That is the bundled example's real output, and note what it shows: the simplification made the code **two lines longer** and was still accepted. It named the ordering key after the contract clause it encodes and stopped rebuilding it on every call. The pass is not a line-count competition, and `verify` does not look at line count when deciding.

## 5. The three outcomes

| Outcome | Condition | What it means |
|---|---|---|
| **Accepted** | All mandatory gates pass; no regression beyond the noise floor | It competes as an ordinary candidate. Re-run `pareto.py select` |
| **Rejected: broke a gate** | A mandatory gate fails | This is not a simplification, it is a change in behaviour. Something removed was load-bearing |
| **Rejected: regressed** | A ranked axis is measurably worse | The simpler version costs real performance. **This is a trade-off, not a verdict** |

The third case is the interesting one. A simpler implementation that is measurably slower on an axis the spec ranks is a genuine choice, and it is the requester's, not the agent's:

> Rejected on measurement, not on taste. The simpler version costs real performance on an axis the spec ranks on. If the requester would rather have the simplicity, that is their trade-off to make: put the numbers to them and record the answer with `spec.py priorities`.

Do not quietly discard it, and do not quietly take it. Put both versions and both numbers in front of the requester.

## 6. When the answer is "nothing"

Often the leader cannot be simplified, especially when it is the baseline: a single standard-library call has nothing to remove. **Record the pass anyway**, with the questions answered:

```
python3 <skill-dir>/scripts/simplify.py attempt --task TASK --from C-01 --dir candidates/C-01 \
    --entry solution.py --removed "nothing: every question answered no" --answers ""
```

"Nothing can be removed" is a finding about a well-built candidate, not a failure of the pass. What matters is that the questions were asked and the answers are on the record, so a future reader knows the leader was examined rather than merely accepted.

## 7. What not to remove

Removing something load-bearing is worse than leaving it in. Things that look removable and are not:

| Looks removable | Why it stays |
|---|---|
| A guard clause for an edge case | It implements a contract clause. Check the clause list before deleting a condition |
| An explicit type conversion | It may be the only thing making the comparison well-defined |
| A seemingly redundant copy | It may be what satisfies "the input is not mutated" |
| A comment explaining a non-obvious ordering | The one thing the next person needs. Keep it, or encode it in a name |
| An error message with context | Diagnosis cost is real cost |
| A `finally` or a context manager | Cleanup on the error path, which the tests may not reach |
| A test | Not the simplification agent's to remove. Ever |
| Validation the spec asked for | Read the acceptance criteria before calling it defensive |

The questions to ask before removing anything: which contract clause does this serve, which test covers it, and what happens on the error path without it. If the answer to all three is "none", remove it. If any answer is unclear, leave it and say so.

## 8. Simplifying more than one candidate

At T3, or when the front has more than one member, simplify **each front member**. A simplification can change the front: a candidate that loses on dependencies may become competitive once an unnecessary import is removed, and one that wins on time may lose its advantage when a layer of indirection that was doing real work is removed.

Each simplification is its own candidate with its own id and its own verification. Do not simplify a dominated candidate: it is not going to be selected, and the budget is better spent on the ones that might be.

## 9. Common failures

| Failure | Why it matters | Guard |
|---|---|---|
| Accepted because it reads better | The whole point is that judgement is not enough | `verify` re-runs identical gates and benchmarks |
| Line count as the goal | Rewards terseness over clarity; a one-liner can be worse | `verify` ignores size when deciding |
| Removing a guard that implements a clause | Silent contract violation | Check the clause list before deleting a condition |
| Removing a test | Destroys the check that makes the pass safe | Never the agent's to touch |
| Simplifying and editing in place | Loses the comparison that shows whether it regressed | A new candidate with `derived_from` |
| Not re-running the benchmarks | "Should be the same" is not a measurement | `verify` refuses without them |
| Skipping the pass when the leader is already simple | Nobody can tell later whether it was examined | Record the pass with the answers |
| Quietly dropping a simpler-but-slower version | Hides a real choice from the requester | Rejected-on-measurement goes in the report with both figures |
| The implementer simplifying its own candidate | The author's blind spots again | A separate agent, and `verify` decides |
