# Measurement protocol

How FORGE produces numbers that mean something, and how it avoids the far more common outcome: confident numbers that mean nothing.

This is the document that makes FORGE an experiment rather than an opinion. Its discipline is borrowed from Karpathy's `autoresearch`, where an agent's change to `train.py` is kept or reverted according to a **fixed five-minute training budget** scored by **validation bits per byte**, not according to whether the agent believes it helped. The fixed budget is the load-bearing part: it makes runs comparable regardless of what the agent changed.

One difference FORGE must respect. `autoresearch` optimises a single measurable objective. General-purpose software has several, and some of them (maintainability, how surprising the code will be to the next person) cannot be reduced to a number at all. So FORGE measures each axis separately, reports them separately, and ranks on a Pareto front. It never produces a single score.

## Contents

1. The three rules
2. What to measure, and what cannot be measured
3. Isolation: one fresh process per measurement
4. Warmup and repetitions
5. Statistics: medians, spread, and the noise floor
6. Calibration: measuring your own noise first
7. Comparison: when a difference is real
8. Scaling: one size tells you nothing
9. Memory
10. Throughput, latency and the size that matters
11. Correctness cross-check during measurement
12. The environment, and what invalidates a measurement
13. Common ways benchmarks lie
14. Writing the driver

---

## 1. The three rules

Enforced mechanically by `scripts/bench.py`:

1. **One run is not a measurement.** Every figure is the median of several repetitions after warmup, reported with its spread.
2. **A difference smaller than the noise is not a difference.** Two candidates tie on an axis unless their medians differ by more than the noise floor **and** their interquartile ranges do not overlap.
3. **One input size cannot show how code scales.** With three or more sizes the tool fits a measured growth exponent, which is what separates a full sort from a bounded heap.

A violation of any of these produces a result that looks like evidence and is not. That is worse than no measurement, because people act on it.

## 2. What to measure, and what cannot be measured

| Measurable, and FORGE measures it | How |
|---|---|
| Wall-clock time per call | Median of repetitions inside the process, excluding fixture construction |
| Peak memory growth during the call | Resident-set high-water mark, in a fresh process |
| Throughput | Input size divided by median time |
| Growth with input size | Log-log slope over three or more sizes |
| Cyclomatic complexity, nesting, size | AST analysis (`complexity.py`) |
| Dependency count | Declared plus actually imported |
| Correctness against the contract | Gates; pass or fail, never a score |
| Agreement between candidates | Differential testing |

| Not measurable, and FORGE does not pretend | What it does instead |
|---|---|
| Maintainability | Reports complexity, nesting, duplication, smells, and the reviewers' challenges. A human or a reviewer judges, and the judgement is recorded as a judgement |
| Readability | Same. If two candidates are equivalent on every measured axis, this is exactly what should separate them, and it should be said out loud rather than dressed up as a metric |
| Future extensibility | Asked as a review question ("if the requirement changes in the most likely direction, which candidate absorbs it better?") and answered as an argument, not a number |
| Security | A gate, judged by a reviewer with named evidence. Not a score |
| "Elegance" | Nothing. It is not an axis |

Reporting an unmeasurable property as a number is the single most common way these systems mislead. If you cannot say what command produced a figure, it is not a measurement.

## 3. Isolation: one fresh process per measurement

Each (candidate, size) pair runs in its own subprocess. This matters for three reasons:

- **Peak memory becomes attributable.** A high-water mark is monotonic within a process, so measuring two candidates in one process gives the second one the first one's peak.
- **No cache carry-over.** One candidate's warm caches, interned objects, imported modules and allocator state cannot flatter the next.
- **A crash or hang is contained**, and reported as a failure at that size rather than taking the session down.

The cost is interpreter startup and imports, which is exactly why the driver times the call **inside** the process and reports the timings, rather than letting the harness time the subprocess. Timing the subprocess would measure Python starting up, which is identical for every candidate and swamps the thing being compared.

## 4. Warmup and repetitions

**Warmup** exists because the first call is not representative: imports resolve lazily, caches are cold, the allocator has not reached a steady state, and on a JIT runtime nothing has been compiled yet. FORGE's driver calls the entry point `warmup` times before timing anything, and those calls are discarded.

- CPython, pure Python code: 2 warmup calls is usually enough.
- Anything touching a JIT (PyPy, GraalPy, Node, the JVM): raise it substantially, often 10 or more, and check that the within-run spread has stopped shrinking before trusting the median. `bench.py` warns when the implementation is not CPython.
- Code that builds a cache on first use: warmup hides the cold cost, which may be the cost you care about. Measure both, with two labels (`bench.py run --label cold`).

**Repetitions** default to 9, an odd number so the median is an actual observation rather than an average of two. Raise it when the spread is high; `bench.py` warns above 25% relative spread. If a candidate's spread stays high at 25 repetitions, something about it is genuinely variable (allocation, GC, I/O, an adaptive data structure) and that variability is itself a finding worth reporting.

**What is excluded from the timed region.** Fixture construction. If the driver builds 100,000 records and then times the selection, the record-building is not in the measurement. This is not a convenience: if setup were timed, every candidate would carry an identical large constant and all the differences would shrink toward zero.

**What must be included.** Everything the candidate does as part of the call, including any lazy work it defers. A candidate that returns a generator and does the work when consumed has not done the work: the driver must consume the result, or the measurement is of constructing a generator.

## 5. Statistics: medians, spread, and the noise floor

FORGE reports:

| Figure | Why |
|---|---|
| **median** | The headline. Robust to the occasional scheduling spike, which a mean is not |
| **p25 and p75** (the interquartile range) | The band the middle half of runs fell in. Two candidates whose bands overlap have not been shown to differ |
| **IQR as a percentage of the median** (`rel_spread_pct`) | A single number for "how stable was this". Above ~25% the median is not trustworthy |
| **min** | The best case, useful for spotting a bimodal distribution, never the headline |
| **max** | The worst case, which for latency-sensitive code is sometimes the only figure that matters |
| **MAD and stdev** | Recorded for anyone who wants them |

**Never report the minimum as the result.** It is tempting, because the minimum is the least noisy figure and the closest to "what the code can do on an idle machine". It is also the figure most sensitive to how many times you ran, and it systematically favours whichever candidate you happened to run more. The median answers "what will happen", which is the question.

**The noise floor** (`noise_floor_pct`, default 5%) is the minimum relative difference in medians that FORGE will call a difference. It belongs to the host, not to the code, and it should be *measured* (section 6) rather than assumed. On a shared container under load, 10% or more is realistic.

## 6. Calibration: measuring your own noise first

```
python3 <skill-dir>/scripts/bench.py calibrate --task TASK --candidate C-01 --size <largest>
```

This measures **the same candidate twice** as if it were two candidates, and reports the difference. Identical code cannot genuinely differ, so whatever difference appears is the host's noise. The output gives:

- the apparent difference between two rounds of identical code,
- the within-round spread,
- whether the interquartile bands overlapped even for identical code,
- a suggested `noise_floor_pct` for this host, right now.

If calibration says identical code differed by 8%, then a 5% noise floor is lying to you, and every "X is 6% faster" conclusion from that session is noise. If the bands did not overlap even for identical code, the host is too noisy for a reliable comparison at that size: raise the repetitions, quieten the machine, or treat everything below the suggested floor as a tie regardless.

Calibrate once per session, at the largest size you will use, before any comparison. It costs one extra measurement and it is the difference between a benchmark and a guess.

## 7. Comparison: when a difference is real

`bench.py compare` applies both tests and reports `TIE` unless both pass:

1. The medians differ by at least the noise floor, relative to the smaller.
2. The interquartile ranges do not overlap.

The second test catches the case the first misses: two candidates whose medians are 7% apart but whose runs swing by 20% have not been separated, and reporting a winner there is fabrication.

**Ties are results, not failures to decide.** A tie on time means time does not distinguish these candidates, so something else must: memory, dependencies, complexity, or the requester's priorities. Say so plainly. "C-01 and C-03 are indistinguishable on time at this size; C-01 has less code and the same dependencies" is a far more useful sentence than a fake 3% winner.

**Ratios.** Report both the relative difference and the ratio, because at large differences the percentage becomes unreadable: "27.6x slower" is clearer than "2661% slower". FORGE prints both.

## 8. Scaling: one size tells you nothing

Two candidates can be identical at n=100 and differ by orders of magnitude at n=10,000,000. A full sort and a bounded heap look the same until they do not. FORGE therefore requires at least two sizes, recommends three or more spanning at least two decades, and fits a growth exponent:

```
python3 <skill-dir>/scripts/bench.py scaling --task TASK
```

The exponent is the least-squares slope of log(time) against log(n), with an R² for how well the points actually lie on that line.

| Exponent | Reading |
|---|---|
| < 0.3 | Flat: fixed overhead dominates at these sizes. The real work has not started yet |
| 0.3 to 0.85 | Sub-linear: overhead still significant, or the work is not proportional to n |
| 0.85 to 1.25 | About linear; consistent with O(n) or O(n log n) over this range |
| 1.25 to 1.75 | Between linear and quadratic: an O(n log n) with a large constant, or a hidden O(n^1.5) |
| > 1.75 | Super-linear: suspect O(n²) or worse |

Three honest limits, which FORGE prints with every fit:

- **An exponent is a measurement, not a proof of asymptotic class.** It describes the sizes measured. A candidate that is O(n²) with a tiny constant can measure as linear across two decades.
- **A poor fit (R² below about 0.9) means do not quote the exponent.** Either the timings are noisy or the behaviour changes across the range, and the single number hides that.
- **Extrapolating an order of magnitude beyond the largest size measured is a guess.** If the production size is 10× your largest benchmark size, measure there or say you did not.

Watch for the regime change. A candidate that wins at every size you measured and loses above them is a real and common outcome: caches stop fitting, allocation patterns change, an O(n) memory cost starts to swap. If the production size is near the top of your range, add a larger size.

## 9. Memory

FORGE reports three figures and uses one for comparison:

| Figure | What it is | Use |
|---|---|---|
| `rss_peak_kib` | Peak resident set of the whole process, including the interpreter and every import | Context. Not comparable between candidates with different imports |
| `rss_delta_kib` | Peak minus the resident set immediately before the first timed call | **The comparison figure.** Growth attributable to the work |
| `tracemalloc_peak_bytes` | Peak of Python-level allocations during the calls | Diagnostic for pure-Python code |

**The trap that matters: `tracemalloc` cannot see C extensions.** A NumPy candidate allocates its arrays outside the Python allocator, so `tracemalloc` reports a tiny figure for the candidate that actually used the most memory. Comparing memory with `tracemalloc` across candidates with different dependencies produces an exactly backwards answer. This is why `rss_delta` is the comparison figure, and why FORGE prints the caveat in every table.

Three further cautions:

- **RSS is coarse.** It moves in pages, the high-water mark never falls, and the allocator may hold freed memory. Small differences (a few hundred KiB) are not meaningful; order-of-magnitude differences are.
- **Importing a dependency costs memory before any work happens.** That cost appears in `rss_peak` but not in `rss_delta`, which is correct for comparing the work and wrong for judging total footprint. If footprint matters, report both and say which you mean.
- **Peak is not average.** A candidate that briefly doubles the input and then frees it has a high peak and a low steady state. For a batch job the peak decides whether it runs at all; for a long-lived service the steady state matters more. The spec should say which.

## 10. Throughput, latency and the size that matters

- **Throughput** (items per second) is derived, not measured: size divided by median time. It is the right framing for batch work and the wrong framing for a per-request path.
- **Latency** is the median at the size that actually occurs. A candidate that wins at n=1,000,000 and loses at n=100 is the wrong choice for a service whose requests carry 50 items.
- **Measure the size that occurs, not the size that flatters.** This is the most common honest mistake in these competitions: an approach with high fixed overhead and excellent asymptotics wins every benchmark and loses in production, because production calls it with twelve records. If the spec says "about 100,000 records", measure 100,000; measure 1,000 as well, so the small-input cost is visible.
- **Report the worst case when it is load-bearing.** For anything user-facing, `max` and `p75` matter. A candidate with a better median and a much worse tail is usually the wrong answer.

## 11. Correctness cross-check during measurement

The benchmark driver returns a `result_digest`: a stable hash of the result it computed. `bench.py` compares digests across candidates at each size and warns loudly when they differ:

> candidates produced DIFFERENT results at n=100000

Two candidates that disagree are not solving the same problem, so their speeds are not comparable and ranking them is meaningless. This catches the case where a candidate passes the test suite (whose cases are small) and diverges at benchmark sizes — a real failure mode, and one the gates alone will miss.

## 12. The environment, and what invalidates a measurement

`bench.py env` records the runtime, implementation, platform, machine, CPU count and load average, and stores it with the measurements. A number without its machine is not a measurement.

`bench.py` warns when:

- the load average exceeds half the CPU count (the host is busy; small differences will not be real),
- the implementation is not CPython (JIT: warmup matters far more).

A measurement becomes **stale**, and FORGE reports it as such rather than comparing it, when:

- the candidate's **code hash** changes (`candidate.py rehash` after an edit),
- the **spec hash** changes (`spec.py freeze --unfreeze` after a requirement change).

Both are enforced by the tools, which refuse to quietly compare across them. Measurements are also only comparable **within one host and one session**: do not compare today's numbers on this machine with last week's on another, and do not merge two sessions' runs into one table.

## 13. Common ways benchmarks lie

| Lie | How it happens | Guard |
|---|---|---|
| Single-run winner | One run each, 4% apart | Medians, repetitions, noise floor |
| Minimum-of-N winner | Reporting the best run | Median is the headline |
| Setup in the timed region | Fixture construction inside the loop | Driver builds the fixture outside |
| Lazy work never done | Candidate returns a generator; nothing consumes it | Driver consumes the result and digests it |
| Warm cache favouring one candidate | All candidates in one process | Fresh process per pair |
| Measuring the broken | Benchmarking something that fails a gate | Harness blocks; bench skips unless forced |
| Measuring different problems | Candidates disagree at benchmark size | Result digests compared per size |
| One size | n=1000 only, shipping for n=10,000,000 | At least two sizes, exponent fit |
| Wrong size | Benchmarking the size that flatters the approach | Measure the size the spec names, and a small one |
| `tracemalloc` for a C-extension candidate | Reports near-zero for the heaviest candidate | `rss_delta` is the comparison figure |
| Noisy host | Shared container under load | Calibrate; check load average |
| Stale numbers | Code edited after measuring | Code and spec hashes on every result |
| Cross-host comparison | Numbers from two machines in one table | Environment recorded and printed |
| Cherry-picked axis | Reporting only the axis your candidate wins | Every ranked axis in the table, every time |

## 14. Writing the driver

The task supplies `tests/bench_driver.py`, shared by every candidate so that they are measured identically. Protocol:

**stdin** — one JSON object:

```json
{"size": 100000, "reps": 9, "warmup": 2, "seed": 7}
```

**stdout** — one JSON object:

```json
{"times_s": [...], "setup_s": 0.31, "rss_before_kib": 20480, "rss_peak_kib": 53248,
 "tracemalloc_peak_bytes": 14680064, "result_digest": "a1b2c3..."}
```

Requirements for a correct driver:

1. **Build the fixture once, outside the timed region**, deterministically from `seed`, so every candidate gets byte-identical input.
2. **Call the entry point `warmup` times and discard those timings.**
3. **Time each of `reps` calls individually** with a monotonic clock (`time.perf_counter`), and return all of them. Returning the list rather than a summary lets the analysis change without re-running.
4. **Consume the result** so that lazy work is actually done, and hash it into `result_digest`.
5. **Read the resident set immediately before the first timed call** and again after the last, so the delta is attributable to the work.
6. **Exercise the interesting shape of the input.** The example's fixture gives about a third of the records colliding scores, so tie-handling is under measurement and not just under test.
7. **Do not print anything else to stdout.** Diagnostics go to stderr.

For a language other than Python, write the equivalent driver in that language and have the gate command invoke it; `bench.py` only requires the JSON contract on stdin and stdout.
