# Adversarial review

Phase 5. Agents attack each other's implementations and identify weaknesses, with a basis for every claim.

The rule borrowed from SWE-Debate, which runs three rounds of competitive debate among agents each taking a distinct perspective along a fault-propagation trace: **agents should challenge each other's assumptions, not vote on which code looks better.** A vote aggregates taste. A challenge has to be answered.

## Contents

1. What review is for
2. Every challenge needs a basis
3. Who reviews what
4. The attack catalogue
5. Challenge kinds and severity
6. Resolving a challenge
7. When a challenge changes the spec
8. Rounds, and when to stop
9. What review is not for
10. Common review failures

---

## 1. What review is for

The gates check what somebody thought to test. Review finds what nobody thought of. Those are different activities, and the second cannot be automated, which is why it gets its own phase and its own ledger.

The most valuable thing review produces is not a list of complaints. It is a **test that did not exist**. In the bundled example, a reviewer read the design of the process-pool candidate and observed that records crossing a process boundary come back as copies, so the contract's identity clause could not hold at the sizes the spec names — and that the suite's identity test used five records, below the candidate's parallel threshold, so the suite passed while the contract was violated. That challenge became a new mandatory gate, the candidate failed it, and the approach was retired with evidence. No amount of re-reading the implementation would have produced that.

## 2. Every challenge needs a basis

`review.py challenge` requires `--basis`, and rejects a challenge without one:

> a challenge needs --basis: a file:line, a measurement, a failing input, or the contract clause it violates. Without one it is a matter of taste, and taste does not eliminate candidates in FORGE.

| Not a challenge | A challenge |
|---|---|
| "This feels overengineered" | "`build_pipeline` at solution.py:41 forwards one call to one other call and is referenced once (complexity.json: passthrough_functions)" |
| "This is probably slow" | "This allocates a list per record at solution.py:28; measure at n=1e5 before accepting it" (raised with `--requires-measurement`) |
| "I would have written it differently" | "Clause 4 says n of zero returns empty; solution.py:9 returns the whole list for n=0" |
| "Too many dependencies" | "Adds numpy; the spec's baseline names heapq.nlargest as sufficient. Is numpy already in the lock file, and does it clear the noise floor?" |
| "The naming is bad" | "`process` at solution.py:12 does three unrelated things; the maintainability axis is not ranked, so this is a tie-break argument rather than a defect" |

Writing the basis is most of the work, and it is what turns a review into something another agent can check.

## 3. Who reviews what

- **A reviewer does not review its own candidate** as its only review. Self-review is recorded and permitted, and the tool notes it, but it does not substitute for a reviewer with no stake.
- At T2, one reviewer attacks all candidates. At T3, two reviewers work independently, which matters because two reviewers given the same brief find substantially different things.
- The reviewer reads the **design and the contract**, not only the code. The identity bug in the example was invisible in the code and obvious in the design.
- Reviewers receive the frozen spec, the candidates, the gate results and the measurements if they exist. They do not receive the orchestrator's opinion of which candidate should win.

## 4. The attack catalogue

`review.py prompts` prints this list. Work through it against a candidate and raise a challenge wherever you can point at something checkable.

**Correctness and contract**

1. Which contract clause is least obviously satisfied? Construct the input that would break it.
2. What happens at every boundary: empty, one element, n equal to the size, n beyond the size, n of zero, duplicates throughout, every element identical, negative and zero values?
3. Does the candidate mutate or alias its input? Does it return the caller's objects or copies?
4. Are ties, ordering and stability handled the way the contract says, or the way this implementation made easy?
5. Where does this silently produce a plausible wrong answer rather than failing?
6. **Is any clause tested only at a size where this candidate takes a different code path?** (Thresholds, batching, parallelism, caching.)

**Measurement and claims**

7. Which performance claim in the rationale has no measurement behind it?
8. At which input size does the approach stop winning? Has anyone measured there?
9. What does it cost at the small sizes that are actually common in production?
10. Does the measured growth exponent match the complexity the author claims?
11. Does it allocate proportionally to the input where a streaming version would not?

**Complexity and overengineering**

12. Which abstraction could be removed without changing behaviour?
13. Which parameter, flag or hook has exactly one caller and one value?
14. What is the indirection for: how many hops from entry point to the work?
15. Is there dead code, an unused import, a pass-through function, duplicated blocks? (`complexity.py` lists these; cite it.)
16. Is this solving a problem the spec does not pose? Cite the non-goal.

**Dependencies and risk**

17. What does the new dependency cost: install size, build requirements, platform support, security surface, upgrade cadence, transitive tree?
18. Does the standard library, or something already in the lock file, do this?
19. What happens when the dependency is absent, a different version, or fails to import?

**Operational**

20. How does this behave under concurrency, if callers are concurrent?
21. How does it fail: an exception the caller can handle, or a hang, a crash, a silent default?
22. What does the next person need to know that only the author knows?
23. If the requirement changes in the most likely direction, which candidate absorbs it better?

**Security**, where the task touches untrusted input, secrets, subprocesses, deserialisation, paths, queries, or the network: does input reach `eval`, `exec`, a shell, or an object-constructing deserialiser? Is a path built from input without containment? Is a query built by concatenation? Is a secret logged or included in an error? Is cryptography hand-rolled?

## 5. Challenge kinds and severity

Kinds: `correctness`, `edge_case`, `performance`, `memory`, `complexity`, `maintainability`, `security`, `dependency`, `concurrency`, `api_design`, `overengineering`, `other`.

| Severity | Meaning |
|---|---|
| `critical` | The candidate is unusable: a security hole, data loss, a contract clause broken in normal use |
| `high` | A contract clause broken in a reachable case, or a cost that changes the selection |
| `medium` | A real defect or cost that does not by itself decide the competition |
| `low` | Worth recording; an argument for the tie-break, not a disqualification |

A `critical` or `high` correctness challenge, once upheld, means the candidate must not be selected until it is fixed or retired.

## 6. Resolving a challenge

Every resolution needs evidence. The tool enforces it.

| Status | Means | Requires |
|---|---|---|
| `upheld` | The claim is right | The failing test, the measurement, or the cited clause |
| `rejected` | The claim is wrong | Evidence that it is wrong, not merely a counter-assertion |
| `fixed` | It was right and has been addressed | The change, plus re-run gates and measurements (the code hash moved) |
| `accepted_tradeoff` | It is right, and the cost is worth paying | `--accepted-by`: **who** decided. A trade-off nobody accepted is unresolved |
| `needs_measurement` | Cannot be settled by argument | The measurement to run. Resolve it after phase 6 |

`needs_measurement` is the most useful status in the ledger. "This is probably slower" is unanswerable as an argument and trivial as a measurement, so it is parked, measured, and then resolved with the number. In the bundled example, the challenge that fully sorting 100,000 records to return 100 is wasted work was parked, measured at 4.8× slower, and upheld with the figures.

A challenge that cannot be settled stays `open`, and an open challenge is a reportable finding: it means the competition ended with a question nobody answered.

## 7. When a challenge changes the spec

Some upheld challenges reveal that the **spec** was wrong or incomplete, not the candidate. The usual case is a contract clause that was never tested, or tested only at a size where it does not bite.

The response is to change the spec, which is deliberately expensive:

```
python3 <skill-dir>/scripts/spec.py freeze --task TASK --unfreeze --reason "R-001 upheld: clause 6 untested at scale"
# add the test file, add the gate
python3 <skill-dir>/scripts/spec.py freeze --task TASK
python3 <skill-dir>/scripts/harness.py run --task TASK --all
```

Every existing gate result and measurement is now stale and must be re-run. That cost is the point: it is what stops the target drifting quietly while candidates are judged, and it means a mid-competition spec change is a decision rather than a slip.

## 8. Rounds, and when to stop

SWE-Debate uses three rounds. FORGE uses one round by default and a second only when the first introduced evidence the other side has not had a chance to answer. There is no third round: if two exchanges have not settled it, more words will not. A measurement might, and that is what `needs_measurement` is for.

Stop reviewing when:

- Every challenge is resolved or parked for measurement.
- The remaining objections are all `low` and all about taste. Record them as tie-break arguments and move on.
- New challenges have stopped changing the eligibility or the front.

Do not keep reviewing to find a reason to prefer a particular candidate. That is advocacy with a review ledger's name on it.

## 9. What review is not for

- **Not for deciding the winner.** The front and the verdict come from gates and measurements. Review changes eligibility (by finding defects) and informs the tie-break; it does not outrank a measurement.
- **Not for style preferences the project has not adopted.** If the project has no convention about it, a challenge about it is `low` at most.
- **Not for rewriting someone else's candidate.** A reviewer who has a better idea should say so; the orchestrator may register it as a new candidate with its own id. Editing another agent's candidate destroys the independence the comparison depends on.
- **Not for re-litigating the spec**, unless the spec is genuinely wrong, in which case see section 7.

## 10. Common review failures

| Failure | Why it matters | Guard |
|---|---|---|
| Taste as a challenge | Eliminates candidates for no checkable reason | `--basis` required |
| Reviewing only the code | Misses design-level impossibilities | Review the design against the contract |
| Self-review as the only review | The author's blind spots survive | A reviewer with no stake |
| Unanswerable performance objections | Argument where a measurement belongs | `--requires-measurement`, then resolve with the number |
| Resolution by assertion | The last word wins | `--evidence` required |
| An accepted trade-off with nobody accepting it | An unresolved cost presented as settled | `--accepted-by` required |
| Challenges left open | The competition ends with open questions | Report them; they cap confidence |
| Review used to justify a favourite | Advocacy disguised as process | Reviewers do not pick winners |
| Three rounds of argument | Burns budget on words | One round, then measure |
