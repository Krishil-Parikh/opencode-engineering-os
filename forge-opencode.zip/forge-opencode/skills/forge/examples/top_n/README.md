# Worked example: top 100 records by score from 100,000

A complete FORGE competition, runnable, with five candidates that genuinely differ and two real bugs that the machinery actually catches.

```bash
python3 -m pytest --version      # the gates use pytest
bash walkthrough.sh              # about a minute
cat forge/tasks/TASK-001/final_report.md
```

`walkthrough.sh` rebuilds `./forge` from scratch each time. Read it top to bottom: the comments say which phase each block belongs to and which agent would normally do that work.

## The task

> Build a Python function that processes 100,000 records and returns the top 100 records based on score.

Six contract clauses were written in phase 1, and two of them decide the competition:

1. returns the n highest-scoring records, ordered by score descending
2. **ties on score are broken by id ascending**
3. n greater than or equal to the input size returns every record, ordered
4. n of zero or less returns an empty list
5. the input list is not mutated, and its order is unchanged
6. **the returned objects are the input objects, not copies**

## The candidates

| | Strategy | Approach | Outcome |
|---|---|---|---|
| C-01 | baseline | `heapq.nlargest` with a composite key | On the Pareto front |
| C-02 | minimal | full sort, take the front | Dominated: 4.8× slower, 30× more peak memory |
| C-03 | performance | bounded min-heap over the stream | **Failed the tie clause.** Fixed, then dominated |
| C-04 | alternative | NumPy `argpartition` + `lexsort` | **Fastest and lowest memory.** On the front, costs a dependency |
| C-05 | alternative | chunked selection across a process pool | **Retired:** cannot satisfy clause 6 at all |
| C-06 | simplified | C-01 with the ordering key hoisted and named | Accepted; equivalent to C-01 |

## What the machinery actually catches

**Two candidates misread the same clause, in the same direction.** C-03 ordered its heap by score alone and C-04 partitioned on score alone, so both selected an arbitrary subset of the records tied at the selection boundary. Neither bug is visible from reading the code. The designed suite caught both; `harness.py differential --shrink` then localised it to a three-record input:

```
case 3 (shrunk):
  input: {"records": [{"id": 2, "score": 42}, {"id": 3, "score": 42}, {"id": 1, "score": 42}], "n": 1}
  C-01,C-02,C-05   -> [[0, 42]]
  C-03,C-04        -> [[2, 42]]
```

**One candidate passed the entire suite while violating a clause at the sizes that matter.** C-05 switches from a serial path to a process pool above 20,000 records. The suite's identity test used five records, so it exercised the serial path and passed — and at n=100,000 none of the returned records is one of the caller's objects. A reviewer reading the *design* against the contract found it in one pass; the fix was a new mandatory gate, not a patch. Adding that gate meant unfreezing the spec and re-running everything, which is what freezing is for.

**The measurement contradicted the obvious reading of the code.** NumPy has to build two arrays from a list of dicts before it can do anything, which looks like it should sink the approach — and at n=1,000 it nearly does. At n=100,000 it is several times faster than the standard-library baseline *and* uses less peak memory. Only the benchmark could say that.

**The verdict is a question, not a winner.** C-04 is better on time and memory; C-01 and C-06 are better on dependencies. Nobody stated a priority order, so FORGE reports `TIE_NEEDS_PRIORITIES`, states the trade-off with the figures, and hands it back:

> C-01 is better on dependencies; C-04 is better on time and memory. Which matters more here?

**The accepted simplification made the code longer.** C-06 hoisted a per-call lambda to module level and named it after the contract clause it encodes: two more lines, one less allocation per call, and the ordering contract now legible where it is defined. `simplify.py verify` accepted it on the measurement, not on the line count. Seven of the eight simplification questions answered "no", which is the right answer for a candidate that was already a single standard-library call.

## Representative numbers

On a 2-core CPython 3.13 container, median of 9 repetitions after 2 warmup calls, k=100:

| n | C-01 stdlib | C-02 full sort | C-03 heap | C-04 NumPy |
|---|---|---|---|---|
| 1,000 | 0.00075 s | 0.00052 s | 0.00060 s | 0.00027 s |
| 10,000 | 0.0043 s | 0.0115 s | 0.0044 s | 0.00090 s |
| 100,000 | 0.0369 s | 0.1899 s | 0.0394 s | 0.0066 s |

Peak RSS growth at n=100,000: C-01 988 KiB, C-02 27,868 KiB, C-03 988 KiB, C-04 800 KiB.

Measured growth exponents: C-01 n^0.85, C-02 n^1.28, C-03 n^0.91, C-04 n^0.69.

Your numbers will differ. That is the point of recording the host, and of `bench.py calibrate`, which on this host showed identical code differing by about 0.3% between rounds.

## Files

```
candidates/C-01..C-05/solution.py   the five candidates, as generated (C-03 and C-04 still buggy)
tests/_load.py                      loads the candidate under test from FORGE_ENTRY_PATH
tests/test_contract.py              37 tests, grouped by contract clause, with a reference implementation
tests/gen.py                        differential generator: ten input shapes aimed at the dividing lines
tests/driver.py                     differential driver, and it fails loudly if a candidate mutates its input
tests/bench_driver.py               benchmark driver: fixture outside the timed region, RSS and digest
walkthrough.sh                      the whole competition, phase by phase
```

The candidates here are the **initial generated set**. `walkthrough.sh` copies them into the task workspace and applies the fixes there, so re-running it always starts from the same buggy state.

## Trying things yourself

```bash
# run the suite against one candidate
FORGE_ENTRY_PATH=$PWD/candidates/C-03/solution.py python3 -m pytest tests/test_contract.py -q

# see how noisy your host is
python3 ../../scripts/bench.py calibrate --task forge/tasks/TASK-001 --candidate C-01 --size 100000

# re-rank at a different size, where the answer may change
python3 ../../scripts/pareto.py front --task forge/tasks/TASK-001 --size 1000

# record a priority order and watch the verdict change
python3 ../../scripts/spec.py priorities --task forge/tasks/TASK-001 --source user \
    --order dependencies,time --quote "we are not adding NumPy for this"
python3 ../../scripts/pareto.py select --task forge/tasks/TASK-001 --size 100000
```

That last pair is the most instructive thing in the example: the same measurements, a stated priority, and a definite answer.
