"""Benchmark driver.

stdin:  {"size": N, "reps": R, "warmup": W, "seed": S}
stdout: {"times_s": [...], "setup_s": f, "rss_before_kib": k, "rss_peak_kib": k,
         "tracemalloc_peak_bytes": b, "result_digest": "..."}

Input construction is outside the timed region, so the measurement is of the
selection and not of building the fixture. One fresh process per (candidate,
size) pair, so the peak RSS is attributable.

tracemalloc counts Python-level allocations only: a candidate that allocates
inside a C extension such as NumPy is invisible to it, which is why rss_delta is
the figure used to compare memory across candidates.
"""
import hashlib
import json
import os
import resource
import sys
import time
import tracemalloc

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _load import load_entry, make_records  # noqa: E402

TOP_K = 100


def rss_kib():
    usage = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    return usage if sys.platform != "darwin" else usage // 1024


def main():
    cfg = json.loads(sys.stdin.read())
    size = int(cfg["size"])
    reps = int(cfg.get("reps", 9))
    warmup = int(cfg.get("warmup", 2))
    seed = int(cfg.get("seed", 7))

    top_n = load_entry()
    t0 = time.perf_counter()
    records = make_records(size, seed=seed)
    setup_s = time.perf_counter() - t0

    k = min(TOP_K, max(1, size)) if size else TOP_K
    for _ in range(warmup):
        top_n(records, k)

    before = rss_kib()
    tracemalloc.start()
    times = []
    for _ in range(reps):
        start = time.perf_counter()
        result = top_n(records, k)
        times.append(time.perf_counter() - start)
    tm_peak = tracemalloc.get_traced_memory()[1]
    tracemalloc.stop()
    peak = rss_kib()

    digest = hashlib.sha256(
        json.dumps([[r["id"], r["score"]] for r in result], sort_keys=True).encode()).hexdigest()
    print(json.dumps({"times_s": times, "setup_s": setup_s, "rss_before_kib": before,
                      "rss_peak_kib": peak, "tracemalloc_peak_bytes": tm_peak,
                      "result_digest": digest, "top_k": k}))


if __name__ == "__main__":
    main()
