"""Load the candidate under test. Shared by every test and driver.

FORGE sets FORGE_ENTRY_PATH to the candidate's entry file, so the same test
suite runs unchanged against every candidate. Nothing here knows which
candidate it is loading, which is the point: the tests were written against the
spec before any candidate existed.
"""
import importlib.util
import os
import sys


def load_entry(symbol="top_n"):
    path = os.environ.get("FORGE_ENTRY_PATH")
    if not path:
        raise SystemExit("FORGE_ENTRY_PATH is not set. Run this through harness.py or bench.py, "
                         "which set it for the candidate under test.")
    spec = importlib.util.spec_from_file_location("forge_candidate", path)
    module = importlib.util.module_from_spec(spec)
    # Registered in sys.modules before execution so that a candidate using
    # multiprocessing can pickle its own module-level helpers by reference.
    sys.modules["forge_candidate"] = module
    spec.loader.exec_module(module)
    if not hasattr(module, symbol):
        raise SystemExit("%s does not define %s(), which the frozen spec requires" % (path, symbol))
    return getattr(module, symbol)


def make_records(size, seed=7, duplicate_rate=0.3, score_space=None):
    """Deterministic record set. A third of the scores collide by default, so ties are exercised."""
    import random
    rng = random.Random(seed)
    space = score_space or max(10, int(size * (1 - duplicate_rate)))
    return [{"id": i, "score": rng.randrange(space)} for i in range(size)]
