"""Differential driver: one JSON case on stdin, the candidate's result as JSON on stdout.

The same driver runs for every candidate; FORGE points FORGE_ENTRY_PATH at whichever
one is under test. Output is normalised to a list of [id, score] pairs so that the
comparison is about the contract (which records, in which order) and not about dict
key ordering or object identity.
"""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _load import load_entry  # noqa: E402


def main():
    case = json.loads(sys.stdin.read())
    top_n = load_entry()
    records = case["records"]
    snapshot = json.dumps(records, sort_keys=True)
    result = top_n(records, case["n"])
    out = [[r["id"], r["score"]] for r in result]
    if json.dumps(records, sort_keys=True) != snapshot:
        print(json.dumps({"error": "the candidate mutated its input, which the contract forbids"}))
        raise SystemExit(3)
    print(json.dumps(out))


if __name__ == "__main__":
    main()
