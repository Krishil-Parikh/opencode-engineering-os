"""Differential case generator.

Usage: gen.py <count> <seed>   ->  one JSON case per line on stdout

Each case is {"records": [...], "n": k}. The distribution is chosen to attack
the places where implementations of this spec are most likely to disagree:
duplicate scores (tie-breaking), n at and beyond the input size, empty input,
n of zero, negative scores, and single-element inputs. Roughly half of all
cases use a tiny score space so that ties are the norm rather than the
exception.
"""
import json
import random
import sys


def main():
    count = int(sys.argv[1]) if len(sys.argv) > 1 else 100
    seed = int(sys.argv[2]) if len(sys.argv) > 2 else 1
    rng = random.Random(seed)
    for i in range(count):
        shape = i % 10
        if shape == 0:
            records, n = [], rng.choice([0, 1, 5])
        elif shape == 1:
            records, n = [{"id": 0, "score": rng.randrange(-5, 5)}], rng.choice([0, 1, 3])
        elif shape == 2:                      # every score identical: pure tie-break test
            size = rng.randrange(2, 40)
            records = [{"id": j, "score": 42} for j in range(size)]
            n = rng.randrange(1, size + 2)
        elif shape == 3:                      # n larger than the input
            size = rng.randrange(1, 12)
            records = [{"id": j, "score": rng.randrange(0, 5)} for j in range(size)]
            n = size + rng.randrange(1, 5)
        elif shape == 4:                      # n of exactly zero
            size = rng.randrange(1, 20)
            records = [{"id": j, "score": rng.randrange(0, 100)} for j in range(size)]
            n = 0
        elif shape in (5, 6, 7):              # dense ties around the selection boundary
            size = rng.randrange(5, 60)
            space = rng.randrange(2, 6)
            records = [{"id": j, "score": rng.randrange(space)} for j in range(size)]
            n = rng.randrange(1, max(2, size // 2 + 2))
        elif shape == 8:                      # negative and zero scores
            size = rng.randrange(3, 30)
            records = [{"id": j, "score": rng.randrange(-50, 1)} for j in range(size)]
            n = rng.randrange(1, size + 1)
        else:                                 # wide spread, few ties
            size = rng.randrange(10, 80)
            records = [{"id": j, "score": rng.randrange(10 ** 6)} for j in range(size)]
            n = rng.randrange(1, size + 1)
        rng.shuffle(records)
        print(json.dumps({"records": records, "n": n}))


if __name__ == "__main__":
    main()
