"""The designed test suite for TASK-001.

Written by the test designer against the frozen spec, before any candidate
existed, and run unchanged against every candidate. Each test names the contract
clause or acceptance criterion it enforces, so a failure says which promise was
broken rather than merely that something is wrong.

Contract under test:
  1. returns the n highest-scoring records, ordered by score descending
  2. ties on score are broken by id ascending
  3. n greater than or equal to the input size returns every record, ordered
  4. n of zero or less returns an empty list
  5. the input list is not mutated
  6. the returned objects are the input objects, not copies
"""
import os
import random
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _load import load_entry  # noqa: E402

top_n = load_entry()


def expected(records, n):
    """Reference ordering, straight from the contract. Deliberately the slow, obvious version."""
    if n <= 0:
        return []
    return sorted(records, key=lambda r: (-r["score"], r["id"]))[:n]


def ids(result):
    return [r["id"] for r in result]


# -- clause 1: ordering by score descending ---------------------------------
def test_returns_n_highest_in_descending_order():
    records = [{"id": i, "score": s} for i, s in enumerate([5, 1, 9, 3, 7])]
    assert ids(top_n(records, 3)) == [2, 4, 0]


def test_result_length_is_n():
    records = [{"id": i, "score": i} for i in range(50)]
    assert len(top_n(records, 10)) == 10


def test_scores_are_non_increasing():
    rng = random.Random(11)
    records = [{"id": i, "score": rng.randrange(100)} for i in range(200)]
    scores = [r["score"] for r in top_n(records, 25)]
    assert scores == sorted(scores, reverse=True)


# -- clause 2: tie-breaking by id ascending ---------------------------------
def test_ties_broken_by_id_ascending():
    records = [{"id": i, "score": 42} for i in range(10)]
    assert ids(top_n(records, 4)) == [0, 1, 2, 3]


def test_ties_broken_by_id_when_input_is_shuffled():
    records = [{"id": i, "score": 42} for i in range(10)]
    random.Random(3).shuffle(records)
    assert ids(top_n(records, 4)) == [0, 1, 2, 3]


def test_tie_at_the_selection_boundary_keeps_lowest_ids():
    """The hard case: more records tied at the cut-off than there are places left."""
    records = ([{"id": 0, "score": 100}] +
               [{"id": i, "score": 50} for i in range(1, 8)])
    assert ids(top_n(records, 3)) == [0, 1, 2]


def test_mixed_ties_and_distinct_scores():
    records = [{"id": 0, "score": 5}, {"id": 1, "score": 9}, {"id": 2, "score": 5},
               {"id": 3, "score": 9}, {"id": 4, "score": 7}]
    assert ids(top_n(records, 5)) == [1, 3, 4, 0, 2]


# -- clause 3: n at or beyond the input size --------------------------------
def test_n_equal_to_input_size_returns_everything():
    records = [{"id": i, "score": 10 - i} for i in range(6)]
    assert len(top_n(records, 6)) == 6


def test_n_greater_than_input_size_returns_everything_ordered():
    records = [{"id": i, "score": i} for i in range(4)]
    assert ids(top_n(records, 99)) == [3, 2, 1, 0]


def test_empty_input_returns_empty():
    assert top_n([], 5) == []


def test_single_record():
    assert ids(top_n([{"id": 7, "score": 1}], 3)) == [7]


# -- clause 4: non-positive n ------------------------------------------------
@pytest.mark.parametrize("n", [0, -1, -100])
def test_non_positive_n_returns_empty(n):
    records = [{"id": i, "score": i} for i in range(5)]
    assert top_n(records, n) == []


# -- clause 5: the input is not mutated -------------------------------------
def test_input_is_not_mutated():
    records = [{"id": i, "score": (i * 37) % 11} for i in range(40)]
    before = [dict(r) for r in records]
    top_n(records, 5)
    assert records == before


def test_input_order_is_not_changed():
    records = [{"id": i, "score": (i * 13) % 7} for i in range(30)]
    order_before = [r["id"] for r in records]
    top_n(records, 5)
    assert [r["id"] for r in records] == order_before


# -- clause 6: identity, not copies -----------------------------------------
def test_returns_the_input_objects():
    records = [{"id": i, "score": i} for i in range(5)]
    result = top_n(records, 2)
    assert all(any(r is original for original in records) for r in result)


# -- negative scores and zero ----------------------------------------------
def test_negative_scores():
    records = [{"id": i, "score": s} for i, s in enumerate([-5, -1, -9, 0])]
    assert ids(top_n(records, 2)) == [3, 1]


# -- agreement with the reference over random inputs ------------------------
@pytest.mark.parametrize("seed", range(12))
def test_matches_reference_on_random_input(seed):
    rng = random.Random(seed)
    size = rng.randrange(1, 120)
    space = rng.choice([2, 3, 10, 1000])
    records = [{"id": i, "score": rng.randrange(space)} for i in range(size)]
    rng.shuffle(records)
    n = rng.randrange(0, size + 3)
    assert ids(top_n(records, n)) == ids(expected(records, n))


@pytest.mark.parametrize("seed", range(6))
def test_matches_reference_when_every_score_collides(seed):
    rng = random.Random(100 + seed)
    size = rng.randrange(2, 60)
    records = [{"id": i, "score": 1} for i in range(size)]
    rng.shuffle(records)
    n = rng.randrange(1, size + 1)
    assert ids(top_n(records, n)) == list(range(n))


# -- the volume the spec actually asks about --------------------------------
def test_handles_one_hundred_thousand_records():
    rng = random.Random(5)
    records = [{"id": i, "score": rng.randrange(70000)} for i in range(100000)]
    result = top_n(records, 100)
    assert len(result) == 100
    assert ids(result) == ids(expected(records, 100))
