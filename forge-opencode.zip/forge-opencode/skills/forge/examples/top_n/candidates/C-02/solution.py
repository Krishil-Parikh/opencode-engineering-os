"""Candidate C-02, strategy: minimal.

Sort everything, take the front. One expression, no imports, and the sort key
states the ordering contract directly: score descending, then id ascending.

It does strictly more work than it has to, because it fully orders all n records
when only the first 100 are wanted. Whether that matters is a question for the
benchmark, not for an argument.
"""


def top_n(records, n):
    if n <= 0:
        return []
    return sorted(records, key=lambda r: (-r["score"], r["id"]))[:n]
