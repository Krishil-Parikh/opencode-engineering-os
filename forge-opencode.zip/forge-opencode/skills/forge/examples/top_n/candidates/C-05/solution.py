"""Candidate C-05, strategy: alternative architecture (parallel).

Split the input into one chunk per worker process, have each worker select its
own local top n, then merge the per-chunk results. The selection is embarrassingly
parallel: the global top n is always contained in the union of the per-chunk top n.

Whether the parallelism pays for itself depends on how much it costs to move the
records into the workers, which is a measurement, not an opinion.
"""
import heapq
import multiprocessing
import os

_KEY = lambda r: (r["score"], -r["id"])          # noqa: E731


def _local_top(args):
    chunk, n = args
    return heapq.nlargest(n, chunk, key=_KEY)


def top_n(records, n):
    if n <= 0:
        return []
    count = len(records)
    workers = min(os.cpu_count() or 1, 4)
    if count < 20000 or workers < 2:
        return heapq.nlargest(n, records, key=_KEY)

    size = (count + workers - 1) // workers
    chunks = [(records[i:i + size], n) for i in range(0, count, size)]
    try:
        ctx = multiprocessing.get_context("fork")
    except ValueError:
        return heapq.nlargest(n, records, key=_KEY)
    with ctx.Pool(processes=workers) as pool:
        partials = pool.map(_local_top, chunks)
    merged = [record for part in partials for record in part]
    return heapq.nlargest(n, merged, key=_KEY)
