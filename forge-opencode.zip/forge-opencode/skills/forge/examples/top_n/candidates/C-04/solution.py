"""Candidate C-04, strategy: alternative architecture.

Move the selection into NumPy. Build two parallel arrays, use argpartition to
find the n best positions in a single linear pass without ordering the rest,
then order just those n.

The composite ordering is expressed by sorting the selected slice with
numpy.lexsort, whose last key is the primary one: id ascending within score
descending.
"""
import numpy as np


def top_n(records, n):
    if n <= 0:
        return []
    count = len(records)
    if count == 0:
        return []
    n = min(n, count)
    scores = np.fromiter((r["score"] for r in records), dtype=np.int64, count=count)
    ids = np.fromiter((r["id"] for r in records), dtype=np.int64, count=count)
    if n < count:
        positions = np.argpartition(-scores, n - 1)[:n]
    else:
        positions = np.arange(count)
    order = np.lexsort((ids[positions], -scores[positions]))
    return [records[int(positions[i])] for i in order]
