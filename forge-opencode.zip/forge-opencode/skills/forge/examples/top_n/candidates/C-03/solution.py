"""Candidate C-03, strategy: performance.

Keep a min-heap of exactly the n best seen so far and push-pop through the
stream, so memory is proportional to the number kept rather than to the size of
the input, and the comparison count is bounded by the kept size.
"""
import heapq


def top_n(records, n):
    if n <= 0:
        return []
    heap = []
    for record in records:
        key = record["score"]
        if len(heap) < n:
            heapq.heappush(heap, (key, record["id"], record))
        elif key > heap[0][0]:
            heapq.heapreplace(heap, (key, record["id"], record))
    heap.sort(key=lambda item: -item[0])
    return [record for _key, _id, record in heap]
