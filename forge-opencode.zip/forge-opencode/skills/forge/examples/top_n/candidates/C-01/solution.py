"""Candidate C-01, strategy: baseline.

The standard library already solves this. `heapq.nlargest` keeps a heap of the n
best as it streams the input, which is the textbook O(n log n_kept) selection,
written and tested by people who do this for a living.

Tie-breaking: nlargest returns the largest keys, so the key (score, -id) gives
the highest score first and, among equal scores, the smallest id first, which is
what the contract asks for.
"""
import heapq


def top_n(records, n):
    if n <= 0:
        return []
    return heapq.nlargest(n, records, key=lambda r: (r["score"], -r["id"]))
