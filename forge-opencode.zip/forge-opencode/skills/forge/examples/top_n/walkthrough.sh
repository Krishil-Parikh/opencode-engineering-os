#!/usr/bin/env bash
# FORGE worked example: a complete competitive implementation, driven only by the
# bundled scripts. Run it from this directory:
#
#     bash walkthrough.sh
#
# It rebuilds ./forge from scratch and takes about a minute. Read it top to bottom
# as a reference for the order of operations: the comments say which phase each
# block belongs to and which agent would normally do that work.
#
# The task: "Build a Python function that processes 100,000 records and returns the
# top 100 records based on score." Five candidates compete. Along the way the
# harness catches a tie-handling bug in two of them, differential testing localises
# it, an adversarial reviewer finds a gap in the test suite that lets a fifth
# candidate pass while violating the contract at scale, and the measurements
# decide the rest.
set -euo pipefail
cd "$(dirname "$0")"
F="${FORGE_SCRIPTS:-$(cd ../../scripts && pwd)}"
rm -rf forge
line() { printf '\n\033[1m== %s\033[0m\n' "$*"; }

# =========================================================== PHASE 1: REQUIREMENTS
line "PHASE 1  Requirements: write the contract, then freeze it"
python3 "$F/workspace.py" init --root forge >/dev/null
TASK=$(python3 "$F/workspace.py" new --root forge --language python --tier T2 \
  --title "Top 100 records by score from 100,000" \
  --statement "Given a list of records, each with an integer id and an integer score, return the 100 highest-scoring records. Called on batches of about 100,000 records.")
echo "task: $TASK"

# requirement-analyst: the contract. Every clause here is a question that would
# otherwise be answered four different ways by four implementers.
python3 "$F/spec.py" interface --task "$TASK" --language python \
  --entry "top_n(records, n)" \
  --signature "def top_n(records: list[dict], n: int) -> list[dict]" \
  --contract "returns the n highest-scoring records, ordered by score descending" \
  --contract "ties on score are broken by id ascending" \
  --contract "n greater than or equal to the input size returns every record, ordered" \
  --contract "n of zero or less returns an empty list" \
  --contract "the input list is not mutated, and its order is unchanged" \
  --contract "the returned objects are the input objects, not copies" >/dev/null

python3 "$F/spec.py" criterion --task "$TASK" --mandatory --kind correctness \
  --statement "every contract clause holds" \
  --measured-by "the designed test suite in tests/test_contract.py passes" >/dev/null
python3 "$F/spec.py" criterion --task "$TASK" --mandatory --kind resource \
  --statement "handles 100,000 records within the benchmark timeout" \
  --measured-by "bench.py completes at n=100000 inside the 60s timeout" >/dev/null
python3 "$F/spec.py" criterion --task "$TASK" --kind performance \
  --statement "fast enough to run per request" \
  --measured-by "median wall time at n=100000, compared across candidates above the noise floor" >/dev/null

# The baseline question, asked before any code is written. This is the single
# cheapest step in FORGE and the one most often skipped.
python3 "$F/spec.py" baseline --task "$TASK" --exists yes --what "heapq.nlargest" \
  --searched "stdlib: heapq, sorted, statistics, bisect. No existing helper in this example codebase." \
  --why-not-enough "it is sufficient on its own, so it enters the competition as the baseline and anything else has to beat it on a measurement"

python3 "$F/spec.py" gate --task "$TASK" --id G-1 --kind correctness --mandatory \
  --description "the designed test suite passes" \
  --command "python3 -m pytest tests/test_contract.py -q" >/dev/null
python3 "$F/spec.py" gate --task "$TASK" --id G-2 --kind compatibility --mandatory \
  --description "the entry point imports and is callable with no side effects at import time" \
  --command "python3 -c \"import os,sys; sys.path.insert(0,'tests'); from _load import load_entry; f=load_entry(); assert callable(f)\"" >/dev/null
python3 "$F/spec.py" gate --task "$TASK" --id G-3 --kind style --mandatory \
  --description "no syntax errors and no obvious dead code: the static scan parses every file" \
  --command "python3 $F/complexity.py file \$FORGE_ENTRY_PATH >/dev/null" >/dev/null

python3 "$F/spec.py" axis --task "$TASK" --id time   --direction min --unit s    --pareto >/dev/null
python3 "$F/spec.py" axis --task "$TASK" --id memory --direction min --unit KiB  --pareto >/dev/null
python3 "$F/spec.py" axis --task "$TASK" --id dependencies --direction min --pareto >/dev/null
# size is recorded but deliberately NOT a pareto axis: fewer lines are not better.
python3 "$F/spec.py" axis --task "$TASK" --id size --direction min --unit lines >/dev/null
python3 "$F/spec.py" benchmark --task "$TASK" --sizes 1000,10000,100000 --reps 9 --warmup 2 --noise-floor 5
python3 "$F/spec.py" constraint --task "$TASK" --text "python 3.9 or later" >/dev/null
python3 "$F/spec.py" constraint --task "$TASK" --non-goal --text "streaming input: the caller always has a list in memory" >/dev/null
# Priorities are left unset on purpose. If the front ends up with more than one
# member, FORGE asks rather than inventing weights.

line "PHASE 1  spec check and freeze"
python3 "$F/spec.py" check --task "$TASK"
python3 "$F/spec.py" freeze --task "$TASK"

# =========================================================== PHASE 2: CANDIDATES
python3 "$F/workspace.py" set --task "$TASK" phase=2-candidates >/dev/null
line "PHASE 2  Candidates: five independent implementations of the frozen spec"
cp -r candidates/C-0{1,2,3,4,5} "$TASK/candidates/"
cp tests/_load.py tests/gen.py tests/driver.py tests/bench_driver.py tests/test_contract.py "$TASK/tests/"

add() { python3 "$F/candidate.py" add --task "$TASK" "$@" >/dev/null; }
add --id C-01 --strategy baseline --dir candidates/C-01 --entry solution.py --author requirement-analyst \
  --title "stdlib heapq.nlargest" \
  --rationale "The standard library already solves this, tested by more people than this code ever will be." \
  --tradeoff "no control over the internals if the contract later changes"
add --id C-02 --strategy minimal --dir candidates/C-02 --entry solution.py --author minimal-implementer \
  --title "full sort, take the front" \
  --rationale "One expression, no imports; the sort key states the ordering contract directly." \
  --tradeoff "fully orders all n records when only the first 100 are wanted"
add --id C-03 --strategy performance --dir candidates/C-03 --entry solution.py --author performance-implementer \
  --title "bounded min-heap over the stream" \
  --rationale "Memory proportional to the number kept rather than the input; comparisons bounded by the kept size." \
  --tradeoff "more code than the stdlib call for the same asymptotic behaviour"
add --id C-04 --strategy alternative --dir candidates/C-04 --entry solution.py --author alternative-architect \
  --title "NumPy argpartition and lexsort" --dependency numpy \
  --rationale "Linear-time partition in C, with the ordering expressed as a lexsort." \
  --tradeoff "adds a large dependency and pays to build two arrays from dicts"
add --id C-05 --strategy alternative --dir candidates/C-05 --entry solution.py --author alternative-architect \
  --title "chunked selection across a process pool" \
  --rationale "The global top n is contained in the union of the per-chunk top n, so the work parallelises." \
  --tradeoff "pays to move records into worker processes"
python3 "$F/candidate.py" list --task "$TASK"

# =========================================================== PHASE 3: GATES
python3 "$F/workspace.py" set --task "$TASK" phase=3-gates >/dev/null
line "PHASE 3  Mandatory gates: correctness before anything else"
python3 "$F/harness.py" run --task "$TASK" --all || true
python3 "$F/harness.py" report --task "$TASK"

line "PHASE 3  Differential testing: make them disagree and find out who is wrong"
# Four implementations of one spec are a free oracle. This localises the failure
# to a specific input, which a pass/fail suite does not.
python3 "$F/harness.py" differential --task "$TASK" --cases 120 --seed 7 --shrink --max-report 2 || true

line "PHASE 3  Fixing the two candidates that misread the tie-breaking clause"
# C-03 ordered its heap by score alone, so at the selection boundary it kept an
# arbitrary subset of the tied records and returned ties in heap order.
cat > "$TASK/candidates/C-03/solution.py" <<'PY'
"""Candidate C-03, strategy: performance.

Keep a min-heap of exactly the n best seen so far and push-pop through the
stream, so memory is proportional to the number kept rather than to the size of
the input, and the comparison count is bounded by the kept size.

The heap is ordered by the full contract key, not by score alone. Entries are
(score, -id) so that the smallest element of the heap is the worst record under
the contract: lowest score, and among equal scores the highest id. That is the
one to evict, and getting this wrong silently returns the wrong set of records
whenever more records tie at the boundary than there are places left.
"""
import heapq


def top_n(records, n):
    if n <= 0:
        return []
    heap = []
    for record in records:
        key = (record["score"], -record["id"])
        if len(heap) < n:
            heapq.heappush(heap, (key, record))
        elif key > heap[0][0]:
            heapq.heapreplace(heap, (key, record))
    heap.sort(key=lambda item: (-item[0][0], -item[0][1]))
    return [record for _key, record in heap]
PY
# C-04 partitioned on score alone, which picks an arbitrary n of the top scores
# and so breaks ties by position in the array rather than by id.
cat > "$TASK/candidates/C-04/solution.py" <<'PY'
"""Candidate C-04, strategy: alternative architecture.

Move the selection into NumPy. Build two parallel arrays, use argpartition to
find the n best positions in a single linear pass without ordering the rest,
then order just those.

argpartition only knows about score, so it cannot resolve ties by id on its own:
it returns *some* n of the highest scores. To honour the contract, the candidate
widens the pool to every record whose score reaches the boundary score, then
lexsorts that pool by (-score, id) and takes the first n. When many records tie
at the boundary the pool grows and this degrades towards a full sort, which is
the honest cost of the approach.
"""
import numpy as np


def top_n(records, n):
    if n <= 0:
        return []
    count = len(records)
    if count == 0:
        return []
    n = min(n, count)
    scores = np.fromiter((r["score"] for r in records), dtype=np.int64, count=count)
    ids = np.fromiter((r["id"] for r in records), dtype=np.int64, count=count)
    if n < count:
        top = np.argpartition(-scores, n - 1)[:n]
        boundary = scores[top].min()
        pool = np.flatnonzero(scores >= boundary)
    else:
        pool = np.arange(count)
    order = np.lexsort((ids[pool], -scores[pool]))[:n]
    return [records[int(pool[i])] for i in order]
PY
python3 "$F/candidate.py" rehash --task "$TASK"
python3 "$F/harness.py" run --task "$TASK" --all
python3 "$F/harness.py" differential --task "$TASK" --cases 120 --seed 7

# =========================================================== PHASE 4: REVIEW
python3 "$F/workspace.py" set --task "$TASK" phase=4-review >/dev/null
line "PHASE 4  Adversarial review: attack what the tests did not"
R1=$(python3 "$F/review.py" challenge --task "$TASK" --against C-05 --by reviewer-1 --kind correctness --severity high \
  --claim "Clause 6 (the returned objects are the input objects) cannot hold for this design at the sizes the spec names" \
  --basis "candidates/C-05/solution.py:30 sends records through a multiprocessing pool, so workers return unpickled copies; the identity test in the suite uses 5 records, which takes the serial fallback below the 20000-record threshold, so the suite passes while the contract is violated at n=100000" \
  --proposed-test "assert object identity at a size above the parallel threshold")
echo "raised $R1 against C-05"
python3 "$F/review.py" challenge --task "$TASK" --against C-02 --by reviewer-2 --kind performance --severity low \
  --claim "Fully ordering 100,000 records to return 100 is wasted work" \
  --basis "candidates/C-02/solution.py:11 sorts the whole list; only the first n are returned" \
  --requires-measurement --proposed-test "compare median time against C-01 at n=100000" >/dev/null
python3 "$F/review.py" challenge --task "$TASK" --against C-04 --by reviewer-1 --kind dependency --severity medium \
  --claim "NumPy is a large dependency for a selection that the standard library already does" \
  --basis "candidate declares dependency numpy; spec baseline names heapq.nlargest as sufficient" \
  --proposed-test "is NumPy faster here by more than the noise floor, and is it already in the lock file?" >/dev/null

# The reviewer's challenge is upheld, so the spec gains a gate. Unfreezing is
# deliberately noisy: it invalidates every gate result and measurement, which is
# exactly why the spec is frozen in the first place.
line "PHASE 4  The upheld challenge changes the spec, so everything is re-run"
cat > "$TASK/tests/test_identity_at_scale.py" <<'PY'
"""Clause 6 at the volume the spec actually names.

Added after reviewer-1 pointed out that the identity test in the main suite uses
five records, which is below the threshold at which a chunked implementation
switches to its parallel path. A contract clause has to be tested at the sizes
the contract is about.
"""
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _load import load_entry  # noqa: E402

top_n = load_entry()


def test_returns_input_objects_at_one_hundred_thousand():
    rng = random.Random(4)
    records = [{"id": i, "score": rng.randrange(70000)} for i in range(100000)]
    result = top_n(records, 100)
    by_id = {id(r) for r in records}
    assert len(result) == 100
    assert all(id(r) in by_id for r in result), (
        "returned records are copies, not the caller's objects: clause 6 is violated")
PY
python3 "$F/spec.py" freeze --task "$TASK" --unfreeze --reason "review challenge $R1 upheld: clause 6 was untested at scale"
python3 "$F/spec.py" gate --task "$TASK" --id G-4 --kind correctness --mandatory \
  --description "clause 6 (identity, not copies) holds at the size the spec names" \
  --command "python3 -m pytest tests/test_identity_at_scale.py -q" >/dev/null
python3 "$F/spec.py" freeze --task "$TASK"
python3 "$F/harness.py" run --task "$TASK" --all || true
python3 "$F/review.py" resolve --task "$TASK" --id "$R1" --status upheld --by test-designer \
  --evidence "new mandatory gate G-4 fails for C-05: none of the 100 returned records is an input object at n=100000" \
  --resolution "the parallel design cannot satisfy clause 6; it is not a bug to fix but a consequence of crossing a process boundary"
python3 "$F/candidate.py" retire --task "$TASK" --id C-05 \
  --reason "cannot satisfy contract clause 6 (identity) at the specified sizes: records returned from worker processes are copies. Architectural, not a fixable defect."

# =========================================================== PHASE 5: MEASUREMENT
python3 "$F/workspace.py" set --task "$TASK" phase=5-measure >/dev/null
line "PHASE 5  Measurement: calibrate the host before trusting any comparison"
python3 "$F/bench.py" env --task "$TASK"
# Measuring the same candidate twice tells you what the host's noise actually is.
# A noise floor guessed rather than calibrated is how benchmark theatre happens.
python3 "$F/bench.py" calibrate --task "$TASK" --candidate C-01 --size 100000

line "PHASE 5  Measuring every eligible candidate at three sizes"
python3 "$F/bench.py" run --task "$TASK" --all
line "PHASE 5  Results"
python3 "$F/bench.py" table --task "$TASK"
line "PHASE 5  Pairwise comparison at the size the spec is about"
python3 "$F/bench.py" compare --task "$TASK" --size 100000 --axis time
line "PHASE 5  Measured scaling"
python3 "$F/bench.py" scaling --task "$TASK"

line "PHASE 5  Static analysis"
python3 "$F/complexity.py" scan --task "$TASK" --all >/dev/null
python3 "$F/complexity.py" compare --task "$TASK"

# Now the measurement-dependent challenges can be resolved, with numbers.
C1=$(python3 - "$TASK" <<'PY'
import json, sys
runs = json.load(open(sys.argv[1] + "/measurements.json"))["runs"]
at = {r["candidate"]: r for r in runs if r.get("ok") and r["size"] == 100000}
print("%.6g %.6g" % (at["C-01"]["median_s"], at["C-02"]["median_s"]))
PY
)
set -- $C1
python3 "$F/review.py" resolve --task "$TASK" --id R-002 --status upheld --by benchmark-engineer \
  --evidence "measured at n=100000: C-01 median ${1}s, C-02 median ${2}s" \
  --resolution "the wasted work is real and measurable; whether it matters is for the selection phase"

# R-003 claimed NumPy was a large dependency for no gain. The measurement says
# otherwise, so the claim as stated is rejected. The dependency cost itself does
# not go away: it becomes the trade-off the selection phase hands back.
R3=$(python3 - "$TASK" <<'PY'
import json, sys
runs = json.load(open(sys.argv[1] + "/measurements.json"))["runs"]
at = {r["candidate"]: r for r in runs if r.get("ok") and r["size"] == 100000}
print("%.2f" % (at["C-01"]["median_s"] / at["C-04"]["median_s"]))
PY
)
python3 "$F/review.py" resolve --task "$TASK" --id R-003 --status rejected --by benchmark-engineer \
  --evidence "measured at n=100000: C-04 is ${R3}x faster than the stdlib baseline C-01, far above the 5% noise floor, and uses less peak memory" \
  --resolution "the dependency does buy something real, so 'for no gain' is wrong. The cost of the dependency still stands and is carried into the selection phase as a trade-off rather than dismissed."

# =========================================================== PHASE 6: SIMPLIFICATION
python3 "$F/workspace.py" set --task "$TASK" phase=6-simplify >/dev/null
line "PHASE 6  Simplification pass on the leader"
python3 "$F/simplify.py" questions
mkdir -p "$TASK/candidates/C-06"
cat > "$TASK/candidates/C-06/solution.py" <<'PY'
"""Candidate C-06: simplification of C-01.

Question 1 of the simplification pass asked whether an abstraction could be
removed. C-01 wrapped the standard-library call in a lambda built per call and
an explicit guard. The guard is still needed, because heapq.nlargest(0, ...)
returns an empty list but a negative n would too, and the contract wants that
spelled out. The lambda is hoisted to module level so it is not rebuilt on every
call, and the key is named so that the ordering contract is readable.

Nothing else was removed: there was nothing else to remove.
"""
import heapq

# (score, -id): highest score first, and among equal scores the smallest id,
# because nlargest returns the largest keys.
_CONTRACT_ORDER = lambda record: (record["score"], -record["id"])  # noqa: E731


def top_n(records, n):
    if n <= 0:
        return []
    return heapq.nlargest(n, records, key=_CONTRACT_ORDER)
PY
python3 "$F/simplify.py" attempt --task "$TASK" --from C-01 --id C-06 \
  --dir candidates/C-06 --entry solution.py --by simplification-agent \
  --title "C-01 with the key hoisted and named" --answers 1 \
  --removed "the per-call lambda construction: hoisted to module level and named after the contract clause it encodes" \
  --removed "nothing else: questions 2 to 8 all answered no, and removing anything further would break a clause"
python3 "$F/harness.py" run --task "$TASK" --candidate C-06
python3 "$F/bench.py" run --task "$TASK" --candidate C-06
python3 "$F/complexity.py" scan --task "$TASK" --candidate C-06 >/dev/null
python3 "$F/simplify.py" verify --task "$TASK" --id C-06 --size 100000

# =========================================================== PHASE 7: SELECTION
python3 "$F/workspace.py" set --task "$TASK" phase=7-select >/dev/null
line "PHASE 7  Selection: gate, then front, then verdict"
python3 "$F/pareto.py" eligible --task "$TASK"
line "PHASE 7  Pareto front at n=100000"
python3 "$F/pareto.py" front --task "$TASK" --size 100000
line "PHASE 7  Trade-offs on the front"
python3 "$F/pareto.py" tradeoffs --task "$TASK" --size 100000
line "PHASE 7  Verdict"
python3 "$F/pareto.py" select --task "$TASK" --size 100000 \
  --note "Priorities were never stated by the requester, so a multi-member front would go back to them rather than being broken here."

# =========================================================== PHASE 8: REPORT
line "PHASE 8  Report"
cat > "$TASK/notes.md" <<'MD'
The cheapest step in this task was the baseline question in phase 1. The standard
library already solved the problem, so the competition was never "which
implementation do we write" but "can anything beat the one that already exists".

Something did. NumPy's argpartition is several times faster at the size the spec
names, and uses less peak memory, because it does the selection in C over two
typed arrays instead of over a list of dicts. That is a real result and it was not
predictable from reading the code: the array-building cost looks like it should
sink the approach, and at n=1000 it nearly does.

It is also not a winner, because it costs a dependency the standard-library
candidates do not, and nobody stated whether that matters here. So the verdict is a
trade-off handed back to the requester with the numbers attached, which is the
honest end state for this task rather than a failure to decide. The question "is
NumPy already in your lock file, and do you want it for this?" is the requester's to
answer, not the agent's to assume.

Which of the standard-library candidates holds the front varies between runs, and
the selection table shows why: C-01 and C-06 are the same algorithm, so they sit
within a few percent of each other and the noise floor decides whether that counts.
On a quiet host C-06's hoisted key is measurably ahead; on a busy one they tie and
both stay on the front. That is the floor doing its job rather than a defect, and it
is the reason the report prints the spread next to every median.

Two of the five candidates misread the same contract clause in the same direction:
both resolved ties by whatever their data structure made convenient. Neither bug
was visible from reading the implementations, and both were visible the moment two
implementations were asked the same question and gave different answers. That is
what differential testing buys over a pass/fail suite: it localised the failure to
a three-record input.

The fifth candidate passed the entire designed suite while violating a contract
clause at the sizes the spec is about, because the test for that clause used five
records and the candidate's behaviour changed above twenty thousand. The suite was
not wrong, it was incomplete, and no amount of re-reading the implementation would
have found it. A reviewer reading the design rather than the tests found it in one
pass, and the fix was a gate, not a patch.

The simplification pass made the leading candidate two lines longer. It was still
accepted, because the pass is not a line-count competition: it named the ordering
key after the contract clause it encodes and stopped building it on every call.
Seven of the eight simplification questions answered no, which is the right answer
for a candidate that was already a single standard-library call.
MD
python3 "$F/report_generator.py" --task "$TASK" --notes "$TASK/notes.md"

# =========================================================== PHASE 9: LEARN
line "PHASE 9  Knowledge base"
python3 "$F/kb.py" import --task "$TASK"
python3 "$F/kb.py" pattern --task TASK-001 --name "top-k selection from a list" \
  --signature "select the k best of n records by a key, k far smaller than n" \
  --guidance "Start with heapq.nlargest and a composite key that encodes the whole ordering contract. Beat it only with a measurement." \
  --caveat "NumPy only pays if the data is already in arrays: building arrays from dicts costs more than the selection saves." >/dev/null
# The auto-import already recorded the retired candidate and why it was retired.
# What a script cannot derive is the condition under which a rejected approach
# would be worth another look, so that is what gets added by hand. Note what is
# NOT recorded: C-05 has no speed claim either way, because it failed a mandatory
# gate and FORGE does not measure how fast something broken is.
python3 "$F/kb.py" reject --task TASK-001 --approach "full sort to take the top k" \
  --why "4.8x slower and 30x more peak memory than the stdlib heap call at n=100000, measured" \
  --scope "CPython 3.13, 2 cores, k=100 of n=100000 integer scores" \
  --reconsider-if "the whole ordering is needed anyway, or k approaches n" >/dev/null
python3 "$F/kb.py" brief --about "selection,top-k"

python3 "$F/workspace.py" set --task "$TASK" phase=9-learn status=awaiting-priorities >/dev/null

line "DONE"
python3 "$F/workspace.py" status --task "$TASK"
echo
echo "report:    $TASK/final_report.md"
echo "index:     forge/index.md"
