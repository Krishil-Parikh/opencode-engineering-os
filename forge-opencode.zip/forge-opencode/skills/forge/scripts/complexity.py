#!/usr/bin/env python3
"""FORGE static analysis: complexity, and mechanical detection of overengineering.

Measures the things an agent is worst at judging about its own code. Python is
analysed precisely with the `ast` module; other languages get a line-based
heuristic pass that reports fewer metrics and says so.

The overengineering checks exist because the failure modes of LLM-written code
are specific and repeatable: unnecessary abstractions, speculative flexibility,
dead code, indirection that forwards one call to one other call, and a thousand
lines where a hundred would do. Those are detectable, so FORGE detects them
rather than asking an agent whether it thinks its own code is simple.

**Size is reported, never ranked on by itself.** A 12-line candidate that is
slower or harder to follow should lose to a 25-line one. These numbers feed the
maintainability discussion and the simplification pass; they do not pick winners.

Usage:
    complexity.py scan --task T --candidate C-02
    complexity.py scan --task T --all
    complexity.py compare --task T
    complexity.py file path/to/solution.py
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import os
import re
import sys
from typing import Any, Dict, List

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import die, get_candidate, load_candidates, load_json, now_iso, save_json, task_path  # noqa: E402

try:
    STDLIB = set(sys.stdlib_module_names)  # Python 3.10+
except AttributeError:  # pragma: no cover
    STDLIB = set("""abc argparse array ast asyncio base64 bisect builtins bz2 calendar collections
    concurrent contextlib copy csv ctypes datetime decimal difflib dis enum errno faulthandler fcntl
    fnmatch fractions functools gc getpass gettext glob gzip hashlib heapq hmac html http imaplib
    importlib inspect io ipaddress itertools json keyword linecache locale logging lzma math mimetypes
    mmap multiprocessing numbers operator os pathlib pickle pkgutil platform plistlib pprint queue
    random re resource secrets select selectors shelve shlex shutil signal site smtplib socket
    socketserver sqlite3 ssl stat statistics string stringprep struct subprocess symtable sys
    sysconfig tarfile tempfile textwrap threading time timeit token tokenize traceback tracemalloc
    types typing unicodedata unittest urllib uuid venv warnings wave weakref webbrowser xml zipfile
    zlib zoneinfo""".split())

DECISION_NODES = (ast.If, ast.For, ast.AsyncFor, ast.While, ast.ExceptHandler, ast.Assert, ast.IfExp)
NEST_NODES = (ast.If, ast.For, ast.AsyncFor, ast.While, ast.With, ast.AsyncWith, ast.Try, ast.FunctionDef,
              ast.AsyncFunctionDef, ast.ClassDef)
TODO_RE = re.compile(r"\b(TODO|FIXME|XXX|HACK)\b")
HEURISTIC_EXT = {".js": "javascript", ".jsx": "javascript", ".mjs": "javascript", ".cjs": "javascript",
                 ".ts": "typescript", ".tsx": "typescript", ".go": "go", ".java": "java", ".kt": "kotlin",
                 ".rb": "ruby", ".rs": "rust", ".cs": "csharp", ".php": "php", ".c": "c", ".cpp": "cpp"}


def cyclomatic(node: ast.AST) -> int:
    score = 1
    for sub in ast.walk(node):
        if isinstance(sub, DECISION_NODES):
            score += 1
        elif isinstance(sub, ast.BoolOp):
            score += len(sub.values) - 1
        elif isinstance(sub, ast.comprehension):
            score += 1 + len(sub.ifs)
        elif hasattr(ast, "Match") and isinstance(sub, getattr(ast, "match_case", ())):
            score += 1
    return score


def nesting(node: ast.AST, depth: int = 0) -> int:
    best = depth
    for child in ast.iter_child_nodes(node):
        d = depth + 1 if isinstance(child, NEST_NODES) else depth
        best = max(best, nesting(child, d))
    return best


def is_passthrough(fn: ast.AST) -> bool:
    """A function whose entire body returns exactly one call: pure indirection."""
    body = [s for s in fn.body if not (isinstance(s, ast.Expr) and isinstance(getattr(s, "value", None), ast.Constant)
                                       and isinstance(s.value.value, str))]
    if len(body) != 1:
        return False
    stmt = body[0]
    return isinstance(stmt, ast.Return) and isinstance(stmt.value, (ast.Call, ast.Await))


def param_names(fn: ast.AST) -> List[str]:
    a = fn.args
    names = [p.arg for p in list(a.posonlyargs) + list(a.args) + list(a.kwonlyargs)]
    if a.vararg:
        names.append(a.vararg.arg)
    if a.kwarg:
        names.append(a.kwarg.arg)
    return names


def used_names(node: ast.AST) -> set:
    out = set()
    for sub in ast.walk(node):
        if isinstance(sub, ast.Name):
            out.add(sub.id)
        elif isinstance(sub, ast.Attribute):
            base = sub
            while isinstance(base, ast.Attribute):
                base = base.value
            if isinstance(base, ast.Name):
                out.add(base.id)
    return out


def analyse_python(path: str, rel: str) -> Dict[str, Any]:
    src = open(path, "r", encoding="utf-8", errors="replace").read()
    lines = src.splitlines()
    try:
        tree = ast.parse(src, filename=rel)
    except SyntaxError as exc:
        return {"file": rel, "language": "python", "error": "syntax error at line %s" % exc.lineno}
    blank = sum(1 for ln in lines if not ln.strip())
    comment = sum(1 for ln in lines if ln.strip().startswith("#"))
    todos = [i + 1 for i, ln in enumerate(lines) if TODO_RE.search(ln)]

    functions, classes = [], []
    imports: List[Dict[str, Any]] = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            params = param_names(node)
            body_used = used_names(node) - {node.name}
            unused_params = [p for p in params if p not in body_used and not p.startswith("_") and p not in ("self", "cls")]
            functions.append({
                "name": node.name, "line": node.lineno,
                "end_line": getattr(node, "end_lineno", node.lineno),
                "length": getattr(node, "end_lineno", node.lineno) - node.lineno + 1,
                "cyclomatic": cyclomatic(node), "max_nesting": nesting(node),
                "params": len(params), "unused_params": unused_params,
                "decorators": [ast.unparse(d) if hasattr(ast, "unparse") else "<decorator>" for d in node.decorator_list],
                "passthrough": is_passthrough(node),
                "async": isinstance(node, ast.AsyncFunctionDef),
                "has_kwargs_passthrough": bool(node.args.kwarg and node.args.kwarg.arg in body_used),
                "returns_annotated": node.returns is not None,
            })
        elif isinstance(node, ast.ClassDef):
            methods = [n.name for n in node.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
            bases = [ast.unparse(b) if hasattr(ast, "unparse") else "<base>" for b in node.bases]
            classes.append({"name": node.name, "line": node.lineno, "bases": bases,
                            "methods": methods, "method_count": len(methods),
                            "abstract": any("ABC" in b or "Protocol" in b for b in bases),
                            "dataclass": any("dataclass" in (ast.unparse(d) if hasattr(ast, "unparse") else "")
                                             for d in node.decorator_list)})
        elif isinstance(node, ast.Import):
            for a in node.names:
                root = a.name.split(".")[0]
                imports.append({"module": a.name, "root": root, "asname": a.asname,
                                "stdlib": root in STDLIB, "line": node.lineno})
        elif isinstance(node, ast.ImportFrom):
            root = (node.module or "").split(".")[0]
            for a in node.names:
                imports.append({"module": "%s.%s" % (node.module or ".", a.name), "root": root,
                                "asname": a.asname, "stdlib": root in STDLIB or node.level > 0,
                                "line": node.lineno, "relative": node.level > 0})

    all_used = used_names(tree)
    unused_imports = []
    for imp in imports:
        bound = imp["asname"] or (imp["module"].split(".")[-1] if imp.get("relative") is not None
                                  and "." in imp["module"] else imp["root"])
        bound = imp["asname"] or imp["module"].split(".")[-1] or imp["root"]
        if bound not in all_used and imp["root"] not in all_used:
            unused_imports.append(imp["module"])

    defined = {f["name"] for f in functions}
    referenced = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            fn = node.func
            if isinstance(fn, ast.Name):
                referenced.add(fn.id)
            elif isinstance(fn, ast.Attribute):
                referenced.add(fn.attr)
        elif isinstance(node, ast.Name):
            referenced.add(node.id)
    method_names = {m for c in classes for m in c["methods"]}
    # A module-level public function is the API, not dead code: only private helpers
    # that nothing in the candidate references are worth reporting.
    unused_functions = sorted(n for n in defined - referenced - method_names
                              if n.startswith("_") and not n.startswith("__"))

    unreachable = []
    for node in ast.walk(tree):
        body = getattr(node, "body", None)
        if isinstance(body, list):
            for i, stmt in enumerate(body[:-1]):
                if isinstance(stmt, (ast.Return, ast.Raise, ast.Continue, ast.Break)):
                    nxt = body[i + 1]
                    if not isinstance(nxt, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                        unreachable.append(nxt.lineno)

    # duplication: identical windows of 4 or more meaningful lines
    norm = [re.sub(r"\s+", " ", ln.strip()) for ln in lines]
    meaningful = [(i + 1, n) for i, n in enumerate(norm) if n and not n.startswith("#") and len(n) > 8]
    seen: Dict[str, List[int]] = {}
    window = 4
    for i in range(len(meaningful) - window + 1):
        chunk = "\n".join(n for _, n in meaningful[i:i + window])
        key = hashlib.sha256(chunk.encode()).hexdigest()[:16]
        seen.setdefault(key, []).append(meaningful[i][0])
    duplicated = [{"first_line": v[0], "repeats_at": v[1:], "window": window}
                  for v in seen.values() if len(v) > 1]

    third_party = sorted({i["root"] for i in imports if not i["stdlib"]})
    return {
        "file": rel, "language": "python", "precision": "ast",
        "total_lines": len(lines), "sloc": len(lines) - blank - comment,
        "blank_lines": blank, "comment_lines": comment,
        "comment_ratio": round(comment / max(1, len(lines) - blank), 3),
        "functions": functions, "classes": classes, "imports": imports,
        "function_count": len(functions), "class_count": len(classes),
        "third_party_imports": third_party,
        "max_cyclomatic": max([f["cyclomatic"] for f in functions] or [0]),
        "total_cyclomatic": sum(f["cyclomatic"] for f in functions) or cyclomatic(tree),
        "max_nesting": max([f["max_nesting"] for f in functions] or [nesting(tree)]),
        "longest_function": max([f["length"] for f in functions] or [0]),
        "max_params": max([f["params"] for f in functions] or [0]),
        "smells": {
            "unused_imports": unused_imports,
            "unused_functions": unused_functions,
            "passthrough_functions": [f["name"] for f in functions if f["passthrough"]],
            "unused_parameters": {f["name"]: f["unused_params"] for f in functions if f["unused_params"]},
            "kwargs_passthrough": [f["name"] for f in functions if f["has_kwargs_passthrough"]],
            "unreachable_lines": sorted(set(unreachable)),
            "duplicated_blocks": duplicated,
            "todo_comments": todos,
            "abstract_bases": [c["name"] for c in classes if c["abstract"]],
            "single_method_classes": [c["name"] for c in classes if c["method_count"] == 1],
            "deep_functions": [f["name"] for f in functions if f["max_nesting"] >= 4],
            "complex_functions": [f["name"] for f in functions if f["cyclomatic"] >= 11],
            "long_functions": [f["name"] for f in functions if f["length"] > 60],
        },
    }


def analyse_heuristic(path: str, rel: str, lang: str) -> Dict[str, Any]:
    lines = open(path, "r", encoding="utf-8", errors="replace").read().splitlines()
    blank = sum(1 for ln in lines if not ln.strip())
    comment = sum(1 for ln in lines if ln.strip().startswith(("//", "#", "*", "/*")))
    decisions = sum(len(re.findall(r"\b(if|for|while|case|catch|switch|elif|unless)\b", ln)) for ln in lines)
    depth = 0
    best = 0
    for ln in lines:
        depth += ln.count("{") - ln.count("}")
        best = max(best, depth)
    funcs = len(re.findall(r"\b(function|func|def|fn)\b", "\n".join(lines)))
    todos = [i + 1 for i, ln in enumerate(lines) if TODO_RE.search(ln)]
    imports = re.findall(r"^\s*(?:import|from|require|use|using|#include)\s+(.+)$", "\n".join(lines), re.M)
    return {
        "file": rel, "language": lang, "precision": "line-heuristic (approximate; no AST for this language)",
        "total_lines": len(lines), "sloc": len(lines) - blank - comment, "blank_lines": blank,
        "comment_lines": comment, "comment_ratio": round(comment / max(1, len(lines) - blank), 3),
        "function_count": funcs, "class_count": len(re.findall(r"\b(class|struct|interface|type)\b", "\n".join(lines))),
        "total_cyclomatic": decisions + 1, "max_cyclomatic": None, "max_nesting": best,
        "longest_function": None, "max_params": None, "functions": [], "classes": [],
        "imports": [{"module": i.strip().rstrip(";"), "stdlib": None} for i in imports],
        "third_party_imports": [],
        "smells": {"todo_comments": todos,
                   "note": "unused imports, dead code, pass-through indirection and duplication are "
                           "only detected for Python. Review this candidate by hand against "
                           "core/antipatterns.md and record what you find as a review challenge."},
    }


def analyse_candidate(task: str, cand: dict) -> Dict[str, Any]:
    cdir = os.path.join(task, cand["dir"])
    files = []
    for rel in cand["files"]:
        path = os.path.join(cdir, rel)
        ext = os.path.splitext(rel)[1]
        if ext == ".py":
            files.append(analyse_python(path, rel))
        elif ext in HEURISTIC_EXT:
            files.append(analyse_heuristic(path, rel, HEURISTIC_EXT[ext]))
    if not files:
        return {"candidate": cand["id"], "error": "no analysable source files"}
    agg = {
        "candidate": cand["id"], "strategy": cand["strategy"], "title": cand["title"],
        "code_hash": cand["code_hash"], "files": files, "file_count": len(files),
        "sloc": sum(f["sloc"] for f in files),
        "total_lines": sum(f["total_lines"] for f in files),
        "comment_ratio": round(sum(f["comment_lines"] for f in files) /
                               max(1, sum(f["total_lines"] - f["blank_lines"] for f in files)), 3),
        "function_count": sum(f["function_count"] for f in files),
        "class_count": sum(f["class_count"] for f in files),
        "total_cyclomatic": sum(f["total_cyclomatic"] or 0 for f in files),
        "max_cyclomatic": max([f["max_cyclomatic"] or 0 for f in files] or [0]),
        "max_nesting": max([f["max_nesting"] or 0 for f in files] or [0]),
        "longest_function": max([f["longest_function"] or 0 for f in files] or [0]),
        "third_party_imports": sorted({m for f in files for m in f.get("third_party_imports", [])}),
        "declared_dependencies": cand.get("dependencies_added", []),
        "analysed_at": now_iso(),
    }
    smells: Dict[str, Any] = {}
    for f in files:
        for key, value in (f.get("smells") or {}).items():
            if isinstance(value, list):
                smells.setdefault(key, []).extend(
                    ["%s:%s" % (f["file"], v) if not isinstance(v, dict) else dict(v, file=f["file"]) for v in value])
            elif isinstance(value, dict):
                smells.setdefault(key, {}).update({"%s:%s" % (f["file"], k): v for k, v in value.items()})
            else:
                smells.setdefault("notes", []).append("%s: %s" % (f["file"], value))
    agg["smells"] = smells
    agg["smell_count"] = sum(len(v) for v in smells.values() if isinstance(v, (list, dict)))
    undeclared = [m for m in agg["third_party_imports"] if m not in agg["declared_dependencies"]]
    if undeclared:
        agg["undeclared_dependencies"] = undeclared
    return agg


def store(task: str, entry: dict) -> None:
    path = task_path(task, "complexity.json")
    data = load_json(path, default={"task": os.path.basename(task), "candidates": []})
    data["candidates"] = [c for c in data["candidates"] if c["candidate"] != entry["candidate"]]
    data["candidates"].append(entry)
    save_json(path, data)


def print_report(a: dict) -> None:
    print("%s  %s  [%s]" % (a["candidate"], a["title"], a["strategy"]))
    print("  sloc %-5d  lines %-5d  functions %-3d  classes %-3d  comment ratio %.2f" % (
        a["sloc"], a["total_lines"], a["function_count"], a["class_count"], a["comment_ratio"]))
    print("  cyclomatic total %-4d  worst function %-4s  max nesting %-3d  longest function %s lines" % (
        a["total_cyclomatic"], a["max_cyclomatic"] or "n/a", a["max_nesting"], a["longest_function"] or "n/a"))
    print("  third-party imports: %s" % (", ".join(a["third_party_imports"]) or "none (standard library only)"))
    if a.get("undeclared_dependencies"):
        print("  UNDECLARED DEPENDENCIES: %s (the candidate imports these but did not declare them)"
              % ", ".join(a["undeclared_dependencies"]))
    s = a.get("smells") or {}
    order = ["unused_imports", "unused_functions", "unreachable_lines", "passthrough_functions",
             "kwargs_passthrough", "unused_parameters", "duplicated_blocks", "single_method_classes",
             "abstract_bases", "complex_functions", "deep_functions", "long_functions", "todo_comments"]
    shown = False
    for key in order:
        v = s.get(key)
        if not v:
            continue
        shown = True
        if key == "duplicated_blocks":
            print("  duplicated_blocks: %d block(s) of 4+ identical lines" % len(v))
        elif isinstance(v, dict):
            print("  %s: %s" % (key, json.dumps(v)[:200]))
        else:
            print("  %s: %s" % (key, ", ".join(str(x) for x in v[:8]) + (" ..." if len(v) > 8 else "")))
    for n in s.get("notes", []):
        print("  note: " + n)
    if not shown:
        print("  no overengineering signals detected")


def cmd_scan(args: argparse.Namespace) -> None:
    cands = [c for c in load_candidates(args.task)["items"] if c["status"] == "active"]
    if not args.all:
        cands = [get_candidate(args.task, args.candidate)]
    for cand in cands:
        a = analyse_candidate(args.task, cand)
        if a.get("error"):
            print("%s: %s" % (cand["id"], a["error"])); continue
        store(args.task, a)
        print_report(a)
        print()
    print("These are inputs to the maintainability discussion and to the simplification pass. Size is "
          "reported, never ranked on alone: a shorter candidate that is slower or harder to follow "
          "should lose to a longer one.")


def cmd_compare(args: argparse.Namespace) -> None:
    data = load_json(task_path(args.task, "complexity.json"), default={"candidates": []})
    rows = data["candidates"]
    if not rows:
        die("nothing scanned yet; run `complexity.py scan --task %s --all`" % args.task)
    rows.sort(key=lambda r: r["candidate"])
    cols = [("sloc", "sloc"), ("total_cyclomatic", "cyclo"), ("max_cyclomatic", "worst"),
            ("max_nesting", "nest"), ("function_count", "fns"), ("class_count", "cls"),
            ("smell_count", "smells")]
    print("%-6s " % "id" + " ".join("%-7s" % label for _, label in cols) + " deps      title")
    for r in rows:
        deps = ",".join(r["third_party_imports"]) or "stdlib"
        print("%-6s " % r["candidate"] + " ".join("%-7s" % (r.get(k) if r.get(k) is not None else "-")
                                                  for k, _ in cols) + " %-9s %s" % (deps[:9], r["title"][:40]))
    print("\nReminder: no column here decides the competition. `sloc` in particular is reported "
          "because the requester may care, and because a sudden jump in it is worth explaining.")


def cmd_file(args: argparse.Namespace) -> None:
    ext = os.path.splitext(args.path)[1]
    if ext == ".py":
        a = analyse_python(args.path, os.path.basename(args.path))
    elif ext in HEURISTIC_EXT:
        a = analyse_heuristic(args.path, os.path.basename(args.path), HEURISTIC_EXT[ext])
    else:
        die("unsupported file type: " + ext)
    print(json.dumps(a, indent=2))


def main() -> None:
    ap = argparse.ArgumentParser(description="FORGE static analysis")
    sub = ap.add_subparsers(dest="cmd")
    p = sub.add_parser("scan"); p.add_argument("--task", required=True)
    p.add_argument("--candidate"); p.add_argument("--all", action="store_true"); p.set_defaults(fn=cmd_scan)
    p = sub.add_parser("compare"); p.add_argument("--task", required=True); p.set_defaults(fn=cmd_compare)
    p = sub.add_parser("file"); p.add_argument("path"); p.set_defaults(fn=cmd_file)
    args = ap.parse_args()
    if not getattr(args, "fn", None):
        ap.print_help(); sys.exit(1)
    if args.cmd == "scan" and not args.all and not args.candidate:
        die("pass --candidate C-xx or --all")
    args.fn(args)


if __name__ == "__main__":
    main()
