#!/usr/bin/env python3
"""FORGE adversarial review ledger.

Reviewers attack candidates. The ledger exists so that an attack has to be an
argument from something checkable rather than a matter of taste, and so that a
rejected attack is recorded with the reason it failed instead of quietly
disappearing.

Two rules are enforced:

* **Every challenge needs a basis**: a `file:line`, a measurement, a failing
  input, or a named contract clause. "This feels overengineered" is not a
  challenge; "`build_pipeline` at solution.py:41 forwards one call to one other
  call and is referenced once (complexity.json: passthrough_functions)" is.
* **Every resolution needs evidence.** A challenge may be upheld only with a
  failing test, a measurement or a cited clause; rejected only with evidence
  that the claim is wrong. A challenge nobody can settle stays `open` or becomes
  `needs_measurement`, which is itself a finding.

Usage:
    review.py challenge --task T --against C-05 --by reviewer-1 --kind correctness \\
        --claim "Clause 6 (returned objects are the input objects) cannot hold for this design" \\
        --basis "solution.py:30 sends records through a process pool, so the workers return copies" \\
        --proposed-test "assert identity at a size above the 20000-record parallel threshold"

    review.py resolve --task T --id R-001 --status upheld --by test-designer \\
        --evidence "new gate G-5 (identity at scale) fails for C-05: 0 of 100 returned objects are input objects"

    review.py list   --task T [--against C-05] [--status open]
    review.py report --task T
    review.py prompts
"""
from __future__ import annotations

import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import (CHALLENGE_KINDS, CHALLENGE_STATUSES, die, get_candidate, load_candidates,  # noqa: E402
                     load_json, next_id, now_iso, save_json, task_path)

PROMPTS = """Attack prompts for an adversarial reviewer. Work through them against a candidate that is
not yours, and raise a challenge only where you can point at something checkable.

Correctness and contract
  1. Which contract clause is least obviously satisfied? Construct the input that would break it.
  2. What happens at every boundary: empty, one element, n equal to the size, n beyond the size,
     n of zero, duplicates throughout, every element identical, negative and zero values?
  3. Does the candidate mutate or alias its input? Does it return the caller's objects or copies?
  4. Are ties, ordering and stability handled the way the contract says, or the way this
     implementation happened to make easy?
  5. Where does this silently produce a plausible wrong answer rather than failing?

Measurement and claims
  6. Which performance claim in the rationale has no measurement behind it?
  7. At which input size does the approach stop winning? Has anyone measured there?
  8. What does it cost at the small sizes that are actually common in production?
  9. Does the measured growth exponent match the complexity the author claims?
 10. Does it allocate proportionally to the input where a streaming version would not?

Complexity and overengineering
 11. Which abstraction could be removed without changing behaviour?
 12. Which parameter, flag or hook has exactly one caller and one value?
 13. What is the indirection for: how many hops from entry point to the work?
 14. Is there dead code, an unused import, a pass-through function, duplicated blocks?
 15. Is this solving a problem the spec does not pose (speculative flexibility)?

Dependencies and risk
 16. What does the new dependency cost: install size, build requirements, platform support,
     security surface, upgrade cadence, transitive tree?
 17. Does the standard library, or something already in the lock file, do this?
 18. What happens when the dependency is absent, a different version, or fails to import?

Operational
 19. How does this behave under concurrency, if callers are concurrent?
 20. How does it fail: an exception the caller can handle, or a hang, a crash, a silent default?
 21. What does the next person need to know that only the author knows?
 22. If the requirement changes in the most likely direction, which candidate absorbs it better?
"""


def cmd_challenge(args: argparse.Namespace) -> None:
    get_candidate(args.task, args.against)
    if args.kind not in CHALLENGE_KINDS:
        die("--kind must be one of: " + ", ".join(CHALLENGE_KINDS))
    if not args.basis:
        die("a challenge needs --basis: a file:line, a measurement, a failing input, or the contract "
            "clause it violates. Without one it is a matter of taste, and taste does not eliminate "
            "candidates in FORGE.")
    path = task_path(args.task, "reviews.json")
    data = load_json(path)
    cid = args.id or next_id("R", [c["id"] for c in data["challenges"]])
    entry = {
        "id": cid, "against": args.against, "by": args.by or "reviewer",
        "kind": args.kind, "claim": args.claim, "basis": args.basis,
        "proposed_test": args.proposed_test or "", "severity": args.severity or "medium",
        "status": "needs_measurement" if args.requires_measurement else "open",
        "resolution": "", "resolution_evidence": "", "resolved_by": "", "resolved_at": None,
        "raised_at": now_iso(),
    }
    if args.by and args.by == get_candidate(args.task, args.against).get("author"):
        print("note: %s is the author of %s. Self-review is allowed and recorded, but it is not a "
              "substitute for a reviewer with no stake in the candidate." % (args.by, args.against),
              file=sys.stderr)
    data["challenges"].append(entry)
    save_json(path, data)
    print(cid)


def cmd_resolve(args: argparse.Namespace) -> None:
    path = task_path(args.task, "reviews.json")
    data = load_json(path)
    entry = next((c for c in data["challenges"] if c["id"] == args.id), None)
    if not entry:
        die("unknown challenge " + args.id)
    if args.status not in CHALLENGE_STATUSES:
        die("--status must be one of: " + ", ".join(CHALLENGE_STATUSES))
    if args.status in ("upheld", "rejected", "fixed", "accepted_tradeoff") and not args.evidence:
        die("resolving a challenge as '%s' needs --evidence: the failing test, the measurement, the "
            "commit, or the cited clause. A resolution without evidence is just the last word." % args.status)
    if args.status == "accepted_tradeoff" and not args.accepted_by:
        die("--accepted-tradeoff needs --accepted-by: who decided that this cost is worth paying. "
            "A trade-off nobody accepted is an unresolved challenge.")
    entry["status"] = args.status
    entry["resolution"] = args.resolution or ""
    entry["resolution_evidence"] = args.evidence or ""
    entry["resolved_by"] = args.by or "unknown"
    entry["accepted_by"] = args.accepted_by or ""
    entry["resolved_at"] = now_iso()
    save_json(path, data)
    print("%s -> %s" % (args.id, args.status))
    if args.status == "upheld":
        print("An upheld challenge is a defect in %s. Fix it and re-run its gates and measurements "
              "(the code hash changes, so the old results go stale), or retire the candidate."
              % entry["against"])


def cmd_list(args: argparse.Namespace) -> None:
    data = load_json(task_path(args.task, "reviews.json"))
    for c in data["challenges"]:
        if args.against and c["against"] != args.against:
            continue
        if args.status and c["status"] != args.status:
            continue
        print("%-7s %-6s %-18s %-10s %-8s %s" % (c["id"], c["against"], c["kind"], c["status"],
                                                 c["severity"], c["claim"][:70]))
        print("        basis: %s" % c["basis"][:110])
        if c["resolution_evidence"]:
            print("        resolved (%s): %s" % (c["resolved_by"], c["resolution_evidence"][:100]))


def cmd_report(args: argparse.Namespace) -> None:
    data = load_json(task_path(args.task, "reviews.json"))
    cands = [c["id"] for c in load_candidates(args.task)["items"]]
    rows = data["challenges"]
    print("%-6s %-5s %-7s %-9s %-6s %-9s %-16s" % ("cand", "open", "upheld", "rejected", "fixed", "tradeoff", "needs measurement"))
    for cid in cands:
        mine = [c for c in rows if c["against"] == cid]
        if not mine:
            continue
        def n(status):
            return sum(1 for c in mine if c["status"] == status)
        print("%-6s %-5d %-7d %-9d %-6d %-9d %-16d" % (
            cid, n("open"), n("upheld"), n("rejected"), n("fixed"), n("accepted_tradeoff"), n("needs_measurement")))
    unresolved = [c for c in rows if c["status"] in ("open", "needs_measurement")]
    upheld = [c for c in rows if c["status"] == "upheld"]
    print()
    if upheld:
        print("UPHELD and not yet fixed:")
        for c in upheld:
            print("  %s against %s [%s]: %s" % (c["id"], c["against"], c["severity"], c["claim"][:90]))
        print("A candidate with an upheld correctness challenge must not be selected. Fix it or retire it.")
    if unresolved:
        print("\nUnresolved (%d). Each is either a measurement nobody ran or a question nobody answered:" % len(unresolved))
        for c in unresolved:
            print("  %s against %s: %s" % (c["id"], c["against"], c["claim"][:80]))
            if c["proposed_test"]:
                print("      proposed check: " + c["proposed_test"])
    if not rows:
        print("No challenges recorded. Either nobody has reviewed these candidates, or the review was "
              "a formality. Four implementations of one spec always disagree about something: run "
              "`review.py prompts` and work through them.")


def cmd_prompts(args: argparse.Namespace) -> None:
    print(PROMPTS)


def main() -> None:
    ap = argparse.ArgumentParser(description="FORGE adversarial review ledger")
    sub = ap.add_subparsers(dest="cmd")
    p = sub.add_parser("challenge"); p.add_argument("--task", required=True); p.add_argument("--id")
    p.add_argument("--against", required=True); p.add_argument("--by"); p.add_argument("--kind", required=True)
    p.add_argument("--claim", required=True); p.add_argument("--basis"); p.add_argument("--proposed-test")
    p.add_argument("--severity", choices=["critical", "high", "medium", "low"])
    p.add_argument("--requires-measurement", action="store_true"); p.set_defaults(fn=cmd_challenge)
    p = sub.add_parser("resolve"); p.add_argument("--task", required=True); p.add_argument("--id", required=True)
    p.add_argument("--status", required=True); p.add_argument("--evidence"); p.add_argument("--resolution")
    p.add_argument("--by"); p.add_argument("--accepted-by"); p.set_defaults(fn=cmd_resolve)
    p = sub.add_parser("list"); p.add_argument("--task", required=True); p.add_argument("--against")
    p.add_argument("--status"); p.set_defaults(fn=cmd_list)
    p = sub.add_parser("report"); p.add_argument("--task", required=True); p.set_defaults(fn=cmd_report)
    p = sub.add_parser("prompts"); p.set_defaults(fn=cmd_prompts)
    args = ap.parse_args()
    if not getattr(args, "fn", None):
        ap.print_help(); sys.exit(1)
    args.fn(args)


if __name__ == "__main__":
    main()
