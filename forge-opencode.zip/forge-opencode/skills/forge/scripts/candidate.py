#!/usr/bin/env python3
"""FORGE candidate register.

Every competing implementation is registered here with its strategy, its files,
its declared trade-offs and a hash of its code. The hash is what keeps the
competition honest: `harness.py` and `bench.py` stamp it into every result, and
any result whose hash no longer matches the files on disk is reported as stale
rather than silently compared.

Usage:
    candidate.py add --task T --strategy baseline --title "stdlib heapq.nlargest" \
        --dir candidates/C-01 --entry solution.py --author requirement-analyst \
        --rationale "The standard library already does exactly this." \
        [--dependency numpy] [--tradeoff "no control over tie-breaking"]

    candidate.py list --task T
    candidate.py show --task T --id C-01
    candidate.py rehash --task T            (after an edit; marks dependent results stale)
    candidate.py retire --task T --id C-04 --reason "superseded by C-06"
"""
from __future__ import annotations

import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import (STRATEGIES, die, load_json, load_schema, next_id, now_iso, save_json,  # noqa: E402
                     sha256_file, sha256_text, task_path, validate)

SKIP = {"__pycache__", ".git", "node_modules", ".pytest_cache", "target", "dist", "build"}


def code_files(root: str) -> list:
    out = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = sorted(d for d in dirnames if d not in SKIP and not d.startswith("."))
        for fn in sorted(filenames):
            if fn.endswith((".pyc", ".pyo", ".so", ".o")):
                continue
            out.append(os.path.relpath(os.path.join(dirpath, fn), root))
    return out


def dir_hash(root: str) -> str:
    parts = []
    for rel in code_files(root):
        parts.append(rel + ":" + sha256_file(os.path.join(root, rel)))
    return sha256_text("\n".join(parts))[:16]


def cmd_add(args: argparse.Namespace) -> None:
    spec = load_json(task_path(args.task, "spec.json"))
    if not spec.get("frozen_at"):
        die("the spec is not frozen. Freeze it with `spec.py freeze --task %s` before generating "
            "candidates: implementations built against different targets are not comparable." % args.task)
    if args.strategy not in STRATEGIES:
        die("--strategy must be one of: " + ", ".join(STRATEGIES))
    cdir = args.dir if os.path.isabs(args.dir) else os.path.join(args.task, args.dir)
    if not os.path.isdir(cdir):
        die("candidate directory not found: " + cdir)
    files = code_files(cdir)
    if not files:
        die("no files in " + cdir)
    entry = args.entry
    if entry not in files:
        die("--entry %s is not in the candidate directory (found: %s)" % (entry, ", ".join(files)))
    data = load_json(task_path(args.task, "candidates.json"))
    existing = [c["id"] for c in data["items"]]
    cid = args.id or next_id("C", existing, width=2)
    if cid in existing:
        die("candidate %s already exists" % cid)
    if args.strategy == "baseline" and any(c["strategy"] == "baseline" for c in data["items"]):
        die("a baseline candidate already exists. There is one existing thing to beat, not several.")
    cand = {
        "id": cid,
        "strategy": args.strategy,
        "title": args.title,
        "dir": os.path.relpath(cdir, args.task),
        "entry": entry,
        "files": files,
        "code_hash": dir_hash(cdir),
        "spec_hash": spec.get("spec_hash"),
        "author": args.author or "unknown",
        "rationale": args.rationale or "",
        "dependencies_added": [d for d in (args.dependency or [])],
        "declared_tradeoffs": [t for t in (args.tradeoff or [])],
        "derived_from": args.derived_from or None,
        "status": "active",
        "registered_at": now_iso(),
    }
    errors = validate(cand, load_schema("candidate.schema.json"))
    if errors:
        die("candidate failed schema validation:\n  " + "\n  ".join(errors))
    data["items"].append(cand)
    save_json(task_path(args.task, "candidates.json"), data)
    print(cid)
    if cand["dependencies_added"]:
        allowed = " ".join(spec.get("constraints", [])).lower()
        if "no new" in allowed and "depend" in allowed:
            print("warning: this candidate adds %s, and the spec constrains new dependencies. The "
                  "dependency gate will fail it unless the constraint says otherwise."
                  % ", ".join(cand["dependencies_added"]), file=sys.stderr)
    if not cand["declared_tradeoffs"]:
        print("note: no declared trade-offs. Every real implementation gives something up; an "
              "implementer who claims none has usually not looked. The adversarial reviewers will.",
              file=sys.stderr)


def cmd_list(args: argparse.Namespace) -> None:
    data = load_json(task_path(args.task, "candidates.json"))
    for c in data["items"]:
        stale = ""
        cdir = os.path.join(args.task, c["dir"])
        if os.path.isdir(cdir) and dir_hash(cdir) != c["code_hash"]:
            stale = "  [EDITED SINCE REGISTRATION: run candidate.py rehash]"
        print("%-6s %-16s %-10s %-40s %s%s" % (
            c["id"], c["strategy"], c["status"], c["title"][:40],
            ",".join(c["dependencies_added"]) or "stdlib only", stale))


def cmd_show(args: argparse.Namespace) -> None:
    from _common import get_candidate
    c = get_candidate(args.task, args.id)
    print("%s  %s  [%s]" % (c["id"], c["title"], c["strategy"]))
    print("  dir: %s   entry: %s" % (c["dir"], c["entry"]))
    print("  files: %s" % ", ".join(c["files"]))
    print("  code hash: %s   spec hash: %s" % (c["code_hash"], c["spec_hash"]))
    print("  author: %s" % c["author"])
    print("  rationale: %s" % c["rationale"])
    print("  dependencies added: %s" % (", ".join(c["dependencies_added"]) or "none"))
    for t in c["declared_tradeoffs"]:
        print("  tradeoff: " + t)
    if c.get("derived_from"):
        print("  derived from: " + c["derived_from"])
    cdir = os.path.join(args.task, c["dir"])
    if os.path.isdir(cdir) and dir_hash(cdir) != c["code_hash"]:
        print("  STALE: the files have changed since registration")


def cmd_rehash(args: argparse.Namespace) -> None:
    data = load_json(task_path(args.task, "candidates.json"))
    changed = []
    for c in data["items"]:
        cdir = os.path.join(args.task, c["dir"])
        if not os.path.isdir(cdir):
            continue
        h = dir_hash(cdir)
        if h != c["code_hash"]:
            c.setdefault("hash_history", []).append({"from": c["code_hash"], "to": h, "at": now_iso()})
            c["code_hash"] = h
            c["files"] = code_files(cdir)
            changed.append(c["id"])
    save_json(task_path(args.task, "candidates.json"), data)
    if not changed:
        print("no candidate changed"); return
    print("rehashed: " + ", ".join(changed))
    print("Every gate result and measurement recorded for these candidates now carries an old code "
          "hash. Re-run `harness.py run` and `bench.py run` for each before comparing anything: a "
          "measurement of code that no longer exists is worse than no measurement.")


def cmd_retire(args: argparse.Namespace) -> None:
    from _common import get_candidate
    data = load_json(task_path(args.task, "candidates.json"))
    c = get_candidate(args.task, args.id)
    for item in data["items"]:
        if item["id"] == c["id"]:
            item["status"] = "retired"
            item["retired_reason"] = args.reason
            item["retired_at"] = now_iso()
    save_json(task_path(args.task, "candidates.json"), data)
    print("%s retired: %s" % (args.id, args.reason))
    print("Its measurements and the challenges against it stay in the record. A retired candidate is "
          "evidence about an approach, not a mistake to be hidden.")


def main() -> None:
    ap = argparse.ArgumentParser(description="FORGE candidate register")
    sub = ap.add_subparsers(dest="cmd")
    p = sub.add_parser("add")
    p.add_argument("--task", required=True); p.add_argument("--id"); p.add_argument("--strategy", required=True)
    p.add_argument("--title", required=True); p.add_argument("--dir", required=True); p.add_argument("--entry", required=True)
    p.add_argument("--author"); p.add_argument("--rationale"); p.add_argument("--dependency", action="append")
    p.add_argument("--tradeoff", action="append"); p.add_argument("--derived-from")
    p.set_defaults(fn=cmd_add)
    p = sub.add_parser("list"); p.add_argument("--task", required=True); p.set_defaults(fn=cmd_list)
    p = sub.add_parser("show"); p.add_argument("--task", required=True); p.add_argument("--id", required=True); p.set_defaults(fn=cmd_show)
    p = sub.add_parser("rehash"); p.add_argument("--task", required=True); p.set_defaults(fn=cmd_rehash)
    p = sub.add_parser("retire"); p.add_argument("--task", required=True); p.add_argument("--id", required=True)
    p.add_argument("--reason", required=True); p.set_defaults(fn=cmd_retire)
    args = ap.parse_args()
    if not getattr(args, "fn", None):
        ap.print_help(); sys.exit(1)
    args.fn(args)


if __name__ == "__main__":
    main()
