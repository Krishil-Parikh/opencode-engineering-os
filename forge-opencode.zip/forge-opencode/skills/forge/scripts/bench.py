#!/usr/bin/env python3
"""FORGE measurement engine.

This is the script that makes FORGE an experiment rather than an opinion. It
borrows its discipline from Karpathy's autoresearch, where a change is kept or
discarded by a fixed measurement (a 5-minute training budget scored by
validation bits per byte) rather than by whether the agent believes it helped.
General-purpose software needs several objectives instead of one number, so
FORGE measures each axis separately and refuses to collapse them.

Three rules are enforced mechanically:

1. **One run is not a measurement.** Every figure is the median of several
   repetitions after warmup, reported with its spread.
2. **A difference smaller than the noise is not a difference.** Two candidates
   TIE on an axis unless their medians differ by more than the noise floor AND
   their interquartile ranges do not overlap.
3. **One input size cannot show how code scales.** With three or more sizes the
   tool fits a measured growth exponent, which is what separates the 12-line
   sort from the heap.

Each (candidate, size) pair runs in a **fresh subprocess** so that peak memory
is attributable and one candidate's warm caches cannot flatter another.

Driver protocol. The task supplies `tests/bench_driver.py`, shared by every
candidate. It reads one JSON object on stdin:

    {"size": 100000, "reps": 9, "warmup": 2, "seed": 7}

builds the input once (not timed), calls the candidate's entry point `warmup`
times, then `reps` times, and prints on stdout:

    {"times_s": [...], "setup_s": 0.31, "rss_before_kib": 20480,
     "rss_peak_kib": 53248, "tracemalloc_peak_bytes": 14680064,
     "result_digest": "a1b2c3..."}

`result_digest` is a stable hash of the result, so the benchmark also notices
when two candidates are fast at computing different answers.

Usage:
    bench.py env       --task T
    bench.py calibrate --task T --candidate C-01 [--size N]
    bench.py run       --task T --all [--sizes 1000,10000,100000] [--reps 9] [--warmup 2]
    bench.py table     --task T
    bench.py compare   --task T [--size N] [--axis time]
    bench.py scaling   --task T
"""
from __future__ import annotations

import argparse
import json
import math
import os
import platform
import statistics
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import (die, get_candidate, load_candidates, load_json, load_spec, now_iso,  # noqa: E402
                     save_json, task_path)

AXIS_FIELDS = {
    "time": ("median_s", "s", "min"),
    "memory": ("rss_delta_kib", "KiB", "min"),
    "throughput": ("throughput_per_s", "1/s", "max"),
}


def capture_env() -> dict:
    load = None
    try:
        load = os.getloadavg()
    except (OSError, AttributeError):
        pass
    return {
        "python": sys.version.split()[0],
        "implementation": platform.python_implementation(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "processor": platform.processor() or "unknown",
        "cpu_count": os.cpu_count(),
        "loadavg_1m": round(load[0], 2) if load else None,
        "captured_at": now_iso(),
    }


def env_warnings(env: dict) -> list:
    out = []
    cpus = env.get("cpu_count") or 1
    la = env.get("loadavg_1m")
    if la is not None and la > cpus * 0.5:
        out.append("load average %.2f on %d CPU(s): the host is busy, so timings will be noisy and a "
                   "small difference will not be real. Re-run when it is quiet, or raise the noise "
                   "floor to what `bench.py calibrate` actually measures." % (la, cpus))
    if env.get("implementation") != "CPython":
        out.append("%s has a JIT: warmup matters far more, and a cold measurement can be an order of "
                   "magnitude slow. Raise --warmup substantially." % env["implementation"])
    return out


def run_one(task: str, cand: dict, size: int, reps: int, warmup: int, seed: int,
            driver: str, timeout: int) -> dict:
    cdir = os.path.abspath(os.path.join(task, cand["dir"]))
    env = dict(os.environ)
    env["FORGE_CANDIDATE"] = cand["id"]
    env["FORGE_CANDIDATE_DIR"] = cdir
    env["FORGE_ENTRY"] = cand["entry"]
    env["FORGE_ENTRY_PATH"] = os.path.join(cdir, cand["entry"])
    env["PYTHONPATH"] = cdir + (os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else "")
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    payload = json.dumps({"size": size, "reps": reps, "warmup": warmup, "seed": seed})
    try:
        proc = subprocess.run([sys.executable, driver], cwd=os.path.abspath(task), env=env,
                              input=payload, capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "timeout", "detail": "exceeded %ds at size %d" % (timeout, size)}
    if proc.returncode != 0:
        return {"ok": False, "error": "crash", "detail": (proc.stderr or "").strip()[-800:]}
    try:
        data = json.loads(proc.stdout.strip() or "{}")
    except ValueError:
        return {"ok": False, "error": "bad-output", "detail": proc.stdout.strip()[:400]}
    times = data.get("times_s") or []
    if not times:
        return {"ok": False, "error": "no-timings", "detail": "driver returned no times_s"}
    srt = sorted(times)
    n = len(srt)
    median = statistics.median(srt)
    p25 = srt[max(0, int(n * 0.25) - (1 if n % 4 == 0 else 0))] if n >= 4 else srt[0]
    p75 = srt[min(n - 1, int(n * 0.75))] if n >= 4 else srt[-1]
    mad = statistics.median([abs(t - median) for t in srt])
    out = {
        "ok": True, "size": size, "reps": n, "warmup": warmup, "seed": seed,
        "times_s": times, "median_s": median, "min_s": srt[0], "max_s": srt[-1],
        "p25_s": p25, "p75_s": p75, "iqr_s": p75 - p25, "mad_s": mad,
        "stdev_s": statistics.stdev(srt) if n > 1 else 0.0,
        "rel_spread_pct": (100.0 * (p75 - p25) / median) if median else 0.0,
        "throughput_per_s": (size / median) if median else None,
        "setup_s": data.get("setup_s"),
        "rss_before_kib": data.get("rss_before_kib"),
        "rss_peak_kib": data.get("rss_peak_kib"),
        "rss_delta_kib": ((data["rss_peak_kib"] - data["rss_before_kib"])
                          if data.get("rss_peak_kib") is not None and data.get("rss_before_kib") is not None else None),
        "tracemalloc_peak_bytes": data.get("tracemalloc_peak_bytes"),
        "result_digest": data.get("result_digest"),
    }
    return out


def store(task: str, entry: dict) -> None:
    path = task_path(task, "measurements.json")
    data = load_json(path)
    data["runs"] = [r for r in data["runs"]
                    if not (r["candidate"] == entry["candidate"] and r["size"] == entry["size"]
                            and r.get("label") == entry.get("label"))]
    data["runs"].append(entry)
    data["environment"] = data.get("environment") or capture_env()
    save_json(path, data)


def cmd_env(args: argparse.Namespace) -> None:
    env = capture_env()
    path = task_path(args.task, "measurements.json")
    data = load_json(path)
    data["environment"] = env
    save_json(path, data)
    print(json.dumps(env, indent=2))
    for w in env_warnings(env):
        print("warning: " + w, file=sys.stderr)
    print("\nMeasurements are only comparable within one host and one session. Record the environment "
          "in the report: a number without its machine is not a measurement.")


def cmd_calibrate(args: argparse.Namespace) -> None:
    """Measure the same candidate twice and report the apparent difference: that is the noise floor."""
    spec = load_spec(args.task)
    cand = get_candidate(args.task, args.candidate)
    b = spec["benchmark"]
    size = args.size or (b.get("sizes") or [1000])[-1]
    reps = args.reps or b.get("reps", 9)
    warmup = args.warmup if args.warmup is not None else b.get("warmup", 2)
    print("calibrating on %s at size %d, %d reps x 2 rounds" % (cand["id"], size, reps))
    rounds = []
    for i in (1, 2):
        r = run_one(args.task, cand, size, reps, warmup, args.seed, args.driver, args.timeout)
        if not r["ok"]:
            die("calibration run %d failed: %s %s" % (i, r["error"], r.get("detail", "")))
        rounds.append(r)
        print("  round %d: median %.6gs  IQR %.3g  spread %.1f%%" % (i, r["median_s"], r["iqr_s"], r["rel_spread_pct"]))
    a, c = rounds
    lo = min(a["median_s"], c["median_s"])
    apparent = 100.0 * abs(a["median_s"] - c["median_s"]) / lo if lo else 0.0
    overlap = not (a["p75_s"] < c["p25_s"] or c["p75_s"] < a["p25_s"])
    worst_spread = max(a["rel_spread_pct"], c["rel_spread_pct"])
    suggested = max(5.0, round(max(apparent, worst_spread / 2.0) * 1.5, 1))
    print("\nIdentical code measured twice differed by %.1f%% in the median." % apparent)
    print("Within-round spread (IQR/median): %.1f%%. IQR bands overlap: %s." % (worst_spread, "yes" if overlap else "NO"))
    print("\nSuggested noise_floor_pct for this host right now: %.1f" % suggested)
    if not overlap:
        print("The bands did NOT overlap even for identical code. This host is too noisy for a "
              "reliable comparison at this size: increase --reps, quieten the machine, or treat every "
              "difference below %.0f%% as a tie regardless of what the bands say." % suggested)
    print("\nSet it with:  spec.py benchmark --task %s --noise-floor %.1f" % (args.task, suggested))
    data = load_json(task_path(args.task, "measurements.json"))
    data["calibration"] = {"candidate": cand["id"], "size": size, "reps": reps,
                           "apparent_difference_pct": round(apparent, 2),
                           "worst_rel_spread_pct": round(worst_spread, 2),
                           "bands_overlapped": overlap, "suggested_noise_floor_pct": suggested,
                           "at": now_iso()}
    data["environment"] = data.get("environment") or capture_env()
    save_json(task_path(args.task, "measurements.json"), data)


def cmd_run(args: argparse.Namespace) -> None:
    spec = load_spec(args.task)
    if not spec.get("frozen_at"):
        die("the spec is not frozen; freeze it before measuring")
    b = spec["benchmark"]
    sizes = [int(s) for s in args.sizes.split(",")] if args.sizes else (b.get("sizes") or [])
    if not sizes:
        die("no benchmark sizes. Set them with `spec.py benchmark --task %s --sizes 1000,10000,100000`." % args.task)
    reps = args.reps or b.get("reps", 9)
    warmup = args.warmup if args.warmup is not None else b.get("warmup", 2)
    timeout = args.timeout or b.get("timeout_s", 60)
    if not os.path.exists(os.path.join(args.task, args.driver)):
        die("benchmark driver not found: %s" % os.path.join(args.task, args.driver))
    gates = load_json(task_path(args.task, "gates.json"))["results"]
    cands = [c for c in load_candidates(args.task)["items"] if c["status"] == "active"]
    if not args.all:
        cands = [get_candidate(args.task, args.candidate)]
    env = capture_env()
    for w in env_warnings(env):
        print("warning: " + w, file=sys.stderr)
    digests = {}
    for cand in cands:
        blocked = [r["gate"] for r in gates
                   if r["candidate"] == cand["id"] and r.get("mandatory") and r["result"] in ("fail", "error")]
        if blocked and not args.force:
            print("%s  SKIPPED: fails mandatory gate(s) %s. Measuring it would tell you how fast "
                  "something broken is. Pass --force only to quantify a known-broken approach."
                  % (cand["id"], ",".join(blocked)))
            continue
        print("%s  %s" % (cand["id"], cand["title"]))
        for size in sizes:
            r = run_one(args.task, cand, size, reps, warmup, args.seed, args.driver, timeout)
            if not r["ok"]:
                print("  n=%-9d %s: %s" % (size, r["error"], (r.get("detail") or "")[:160]))
                store(args.task, {"candidate": cand["id"], "size": size, "ok": False,
                                  "error": r["error"], "detail": r.get("detail", ""),
                                  "code_hash": cand["code_hash"], "spec_hash": spec.get("spec_hash"),
                                  "label": args.label, "measured_at": now_iso(), "environment": env})
                continue
            entry = dict(r, candidate=cand["id"], code_hash=cand["code_hash"],
                         spec_hash=spec.get("spec_hash"), label=args.label,
                         measured_at=now_iso(), environment=env)
            store(args.task, entry)
            digests.setdefault(size, {})[cand["id"]] = r.get("result_digest")
            mem = "  rss+%-7s" % (("%dKiB" % r["rss_delta_kib"]) if r["rss_delta_kib"] is not None else "?")
            print("  n=%-9d median %-10.6g IQR %-9.3g spread %5.1f%%%s  %s" % (
                size, r["median_s"], r["iqr_s"], r["rel_spread_pct"], mem,
                "digest " + (r.get("result_digest") or "-")[:8]))
            if r["rel_spread_pct"] > 25:
                print("       warning: %.0f%% spread across repetitions. The median is unstable; "
                      "raise --reps or quieten the host before trusting a comparison." % r["rel_spread_pct"])
    for size, d in sorted(digests.items()):
        vals = {v for v in d.values() if v}
        if len(vals) > 1:
            print("\nWARNING at n=%d: candidates produced DIFFERENT results: %s" % (
                size, json.dumps({k: (v or "")[:8] for k, v in d.items()})))
            print("They are not solving the same problem, so their speeds are not comparable. Run "
                  "`harness.py differential` and resolve it before ranking anything.")


def runs_for(task: str, label=None) -> list:
    data = load_json(task_path(task, "measurements.json"))
    return [r for r in data["runs"] if r.get("ok") and (label is None or r.get("label") == label)]


def stale_check(task: str, rows: list) -> list:
    spec = load_spec(task)
    cands = {c["id"]: c for c in load_candidates(task)["items"]}
    stale = []
    for r in rows:
        c = cands.get(r["candidate"])
        if not c:
            continue
        if r.get("code_hash") != c["code_hash"]:
            stale.append("%s n=%s was measured from code hash %s, now %s" % (
                r["candidate"], r["size"], (r.get("code_hash") or "?")[:8], c["code_hash"][:8]))
        if r.get("spec_hash") != spec.get("spec_hash"):
            stale.append("%s n=%s was measured against spec hash %s, now %s" % (
                r["candidate"], r["size"], (r.get("spec_hash") or "?")[:8], (spec.get("spec_hash") or "?")[:8]))
    return stale


def cmd_table(args: argparse.Namespace) -> None:
    rows = runs_for(args.task, args.label)
    if not rows:
        die("no measurements yet. Run `bench.py run --task %s --all`." % args.task)
    sizes = sorted({r["size"] for r in rows})
    cands = sorted({r["candidate"] for r in rows})
    titles = {c["id"]: c["title"] for c in load_candidates(args.task)["items"]}
    by = {(r["candidate"], r["size"]): r for r in rows}
    print("median seconds (IQR%% in brackets)\n")
    print("%-6s " % "n" + " ".join("%-22s" % c for c in cands))
    for size in sizes:
        cells = []
        for c in cands:
            r = by.get((c, size))
            cells.append("%-22s" % ("%.6g [%.0f%%]" % (r["median_s"], r["rel_spread_pct"]) if r else "-"))
        print("%-6d " % size + " ".join(cells))
    print("\npeak RSS growth during the call, KiB\n")
    print("%-6s " % "n" + " ".join("%-22s" % c for c in cands))
    for size in sizes:
        cells = []
        for c in cands:
            r = by.get((c, size))
            v = r.get("rss_delta_kib") if r else None
            cells.append("%-22s" % (str(v) if v is not None else "-"))
        print("%-6d " % size + " ".join(cells))
    print()
    for c in cands:
        print("%-6s %s" % (c, titles.get(c, "")))
    stale = stale_check(args.task, rows)
    if stale:
        print("\nSTALE MEASUREMENTS (re-run before comparing):")
        for s in stale:
            print("  " + s)
    env = load_json(task_path(args.task, "measurements.json")).get("environment") or {}
    if env:
        print("\nhost: %s, %s %s, %s CPU(s), load %s at capture" % (
            env.get("platform"), env.get("implementation"), env.get("python"),
            env.get("cpu_count"), env.get("loadavg_1m")))
    print("tracemalloc note: the tracemalloc figures count Python-level allocations only. A candidate "
          "using NumPy or another C extension allocates outside it, so compare memory with rss_delta.")


def compare_pair(a: dict, b: dict, field: str, direction: str, floor_pct: float) -> dict:
    av, bv = a.get(field), b.get(field)
    if av is None or bv is None:
        return {"outcome": "unmeasured"}
    lo = min(av, bv)
    rel = (100.0 * abs(av - bv) / lo) if lo else 0.0
    if field == "median_s":
        overlap = not (a["p75_s"] < b["p25_s"] or b["p75_s"] < a["p25_s"])
    else:
        overlap = False
    better = None
    if rel >= floor_pct and not overlap:
        if direction == "min":
            better = a["candidate"] if av < bv else b["candidate"]
        else:
            better = a["candidate"] if av > bv else b["candidate"]
    return {"outcome": "difference" if better else "tie", "better": better,
            "rel_pct": round(rel, 2), "bands_overlap": overlap,
            "a": av, "b": bv, "ratio": round(max(av, bv) / lo, 3) if lo else None}


def cmd_compare(args: argparse.Namespace) -> None:
    spec = load_spec(args.task)
    floor = args.noise_floor if args.noise_floor is not None else spec["benchmark"].get("noise_floor_pct", 5.0)
    rows = runs_for(args.task, args.label)
    if not rows:
        die("no measurements yet")
    sizes = sorted({r["size"] for r in rows})
    size = args.size or sizes[-1]
    rows = [r for r in rows if r["size"] == size]
    if len(rows) < 2:
        die("need at least two candidates measured at n=%d" % size)
    axis = args.axis or "time"
    if axis not in AXIS_FIELDS:
        die("--axis must be one of " + ", ".join(AXIS_FIELDS))
    field, unit, direction = AXIS_FIELDS[axis]
    rows.sort(key=lambda r: (r.get(field) if r.get(field) is not None else float("inf")),
              reverse=(direction == "max"))
    print("axis=%s  n=%d  noise floor %.1f%%\n" % (axis, size, floor))
    for r in rows:
        extra = ""
        if field == "median_s":
            extra = "  IQR [%.6g, %.6g]" % (r["p25_s"], r["p75_s"])
        print("  %-6s %-14s %s%s" % (r["candidate"], ("%.6g" % r[field]) if r.get(field) is not None else "-", unit, extra))
    print("\npairwise:")
    ties = []
    for i, a in enumerate(rows):
        for b in rows[i + 1:]:
            res = compare_pair(a, b, field, direction, floor)
            if res["outcome"] == "unmeasured":
                print("  %s vs %s: not measured on this axis" % (a["candidate"], b["candidate"])); continue
            if res["outcome"] == "tie":
                ties.append((a["candidate"], b["candidate"]))
                why = []
                if res["rel_pct"] < floor:
                    why.append("%.1f%% apart, below the %.1f%% noise floor" % (res["rel_pct"], floor))
                if res["bands_overlap"]:
                    why.append("IQR bands overlap")
                print("  %s vs %s: TIE (%s)" % (a["candidate"], b["candidate"], "; ".join(why)))
            else:
                print("  %s vs %s: %s is better by %.1f%% (%.2fx)" % (
                    a["candidate"], b["candidate"], res["better"], res["rel_pct"], res["ratio"]))
    if ties:
        print("\nTies are a result, not a failure to decide. Two candidates that tie on %s must be "
              "separated on another axis, or by the simplicity and dependency questions, or by the "
              "requester's stated priorities." % axis)
    stale = stale_check(args.task, rows)
    for s in stale:
        print("STALE: " + s)


def fit_exponent(points: list) -> dict:
    """Least-squares slope of log(time) against log(n)."""
    pts = [(n, t) for n, t in points if n > 0 and t > 0]
    if len(pts) < 2:
        return {"exponent": None, "note": "need at least two sizes"}
    xs = [math.log(n) for n, _ in pts]
    ys = [math.log(t) for _, t in pts]
    mx, my = sum(xs) / len(xs), sum(ys) / len(ys)
    den = sum((x - mx) ** 2 for x in xs)
    if den == 0:
        return {"exponent": None, "note": "all sizes equal"}
    slope = sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / den
    pred = [my + slope * (x - mx) for x in xs]
    ss_res = sum((y - p) ** 2 for y, p in zip(ys, pred))
    ss_tot = sum((y - my) ** 2 for y in ys)
    r2 = 1 - ss_res / ss_tot if ss_tot else 1.0
    if slope < 0.3:
        shape = "flat (dominated by fixed overhead at these sizes)"
    elif slope < 0.85:
        shape = "sub-linear (overhead still dominates, or the work is not proportional to n)"
    elif slope < 1.25:
        shape = "about linear, consistent with O(n) or O(n log n) over this range"
    elif slope < 1.75:
        shape = "between linear and quadratic: suspect an O(n log n) with a large constant, or a hidden O(n^1.5)"
    else:
        shape = "super-linear: suspect O(n^2) or worse"
    return {"exponent": round(slope, 3), "r_squared": round(r2, 4), "shape": shape,
            "sizes": [n for n, _ in pts]}


def cmd_scaling(args: argparse.Namespace) -> None:
    rows = runs_for(args.task, args.label)
    if not rows:
        die("no measurements yet")
    cands = sorted({r["candidate"] for r in rows})
    titles = {c["id"]: c["title"] for c in load_candidates(args.task)["items"]}
    out = {}
    print("measured growth of median time against input size\n")
    for c in cands:
        pts = sorted((r["size"], r["median_s"]) for r in rows if r["candidate"] == c)
        fit = fit_exponent(pts)
        out[c] = fit
        if fit["exponent"] is None:
            print("  %-6s %s" % (c, fit["note"])); continue
        print("  %-6s n^%-6.3g  R2=%.3f  over n=%s" % (c, fit["exponent"], fit["r_squared"],
                                                       "..".join(str(n) for n in (fit["sizes"][0], fit["sizes"][-1]))))
        print("         %s" % fit["shape"])
        print("         %s" % titles.get(c, ""))
        if fit["r_squared"] < 0.9:
            print("         warning: poor fit (R2=%.2f). The timings are noisy or the behaviour changes "
                  "across this range; do not quote an exponent from this." % fit["r_squared"])
    if len(rows) and len({r["size"] for r in rows}) < 3:
        print("\nOnly %d size(s) measured. Two points always fit a line: with three or more you can see "
              "whether they actually lie on one." % len({r['size'] for r in rows}))
    print("\nAn exponent is a measurement over the sizes tested, not a proof of asymptotic class. It "
          "says what happens in the range that was measured, which is usually the range that matters. "
          "Extrapolating an order of magnitude beyond the largest size measured is a guess.")
    data = load_json(task_path(args.task, "measurements.json"))
    data["scaling"] = {"fits": out, "computed_at": now_iso()}
    save_json(task_path(args.task, "measurements.json"), data)


def main() -> None:
    ap = argparse.ArgumentParser(description="FORGE measurement engine")
    sub = ap.add_subparsers(dest="cmd")

    def common(p):
        p.add_argument("--task", required=True)
        p.add_argument("--driver", default="tests/bench_driver.py")
        p.add_argument("--seed", type=int, default=7)
        p.add_argument("--label", default=None, help="tag a measurement session, e.g. after-simplification")

    p = sub.add_parser("env"); p.add_argument("--task", required=True); p.set_defaults(fn=cmd_env)
    p = sub.add_parser("calibrate"); common(p)
    p.add_argument("--candidate", required=True); p.add_argument("--size", type=int)
    p.add_argument("--reps", type=int); p.add_argument("--warmup", type=int); p.add_argument("--timeout", type=int, default=120)
    p.set_defaults(fn=cmd_calibrate)
    p = sub.add_parser("run"); common(p)
    p.add_argument("--candidate"); p.add_argument("--all", action="store_true")
    p.add_argument("--sizes"); p.add_argument("--reps", type=int); p.add_argument("--warmup", type=int)
    p.add_argument("--timeout", type=int); p.add_argument("--force", action="store_true")
    p.set_defaults(fn=cmd_run)
    p = sub.add_parser("table"); p.add_argument("--task", required=True); p.add_argument("--label"); p.set_defaults(fn=cmd_table)
    p = sub.add_parser("compare"); p.add_argument("--task", required=True); p.add_argument("--size", type=int)
    p.add_argument("--axis"); p.add_argument("--noise-floor", type=float, dest="noise_floor")
    p.add_argument("--label"); p.set_defaults(fn=cmd_compare)
    p = sub.add_parser("scaling"); p.add_argument("--task", required=True); p.add_argument("--label"); p.set_defaults(fn=cmd_scaling)
    args = ap.parse_args()
    if not getattr(args, "fn", None):
        ap.print_help(); sys.exit(1)
    if args.cmd == "run" and not args.all and not args.candidate:
        die("pass --candidate C-xx or --all")
    args.fn(args)


if __name__ == "__main__":
    main()
