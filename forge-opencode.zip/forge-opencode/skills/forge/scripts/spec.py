#!/usr/bin/env python3
"""FORGE spec manager: the contract every candidate is measured against.

The spec is the single most important artefact in FORGE. Candidates are only
comparable if they were built against the same target, so the spec is written
in phase 1, **frozen** before any candidate is generated, and hashed. The
harness and the benchmark runner stamp that hash into every result, and
report loudly if the spec changed afterwards.

Usage:
    spec.py interface --task T --language python --entry "top_n(records, n)" \
        --signature "def top_n(records: list[dict], n: int) -> list[dict]" \
        --contract "returns the n highest-scoring records, descending by score" \
        --contract "ties broken by id ascending" --contract "n >= len(records) returns all records"

    spec.py criterion --task T --statement "handles 100k records" \
        --measured-by "bench at n=100000 completes inside the timeout" --mandatory

    spec.py gate --task T --kind correctness --id G-1 --description "the designed test suite passes" \
        --command "python3 -m pytest tests -q" --mandatory

    spec.py axis --task T --id time --direction min --unit ms [--limit 500] [--pareto]
    spec.py axis --task T --id memory --direction min --unit MiB --limit 256 --pareto

    spec.py benchmark --task T --sizes 1000,10000,100000 --reps 9 --warmup 2 --noise-floor 5
    spec.py priorities --task T --source user --order time,maintainability,memory
    spec.py baseline --task T --exists yes --what "heapq.nlargest" --why-not-enough "none: it is sufficient"
    spec.py constraint --task T --text "no new third-party dependencies"
    spec.py freeze --task T
    spec.py check --task T
    spec.py show --task T
"""
from __future__ import annotations

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import (AXES, GATE_KINDS, die, load_json, load_schema, next_id, now_iso, save_json,  # noqa: E402
                     sha256_text, task_path, validate)


def spec_path(task: str) -> str:
    return task_path(task, "spec.json")


def load(task: str) -> dict:
    return load_json(spec_path(task))


def store(task: str, spec: dict) -> None:
    spec["updated_at"] = now_iso()
    save_json(spec_path(task), spec)


def canonical(spec: dict) -> str:
    """Stable text of the parts a candidate is measured against."""
    subset = {k: spec.get(k) for k in
              ("interface", "acceptance_criteria", "gates", "axes", "benchmark", "constraints", "non_goals")}
    return json.dumps(subset, sort_keys=True, ensure_ascii=False)


def spec_hash(spec: dict) -> str:
    return sha256_text(canonical(spec))[:16]


def require_unfrozen(spec: dict, what: str) -> None:
    if spec.get("frozen_at"):
        die("the spec was frozen at %s and %s would change what candidates are measured against.\n"
            "  If the requirement genuinely changed, run `spec.py freeze --task <T> --unfreeze --reason \"...\"`.\n"
            "  Every existing gate result and measurement then carries a stale spec hash and must be re-run."
            % (spec["frozen_at"], what))


def cmd_interface(args: argparse.Namespace) -> None:
    spec = load(args.task)
    require_unfrozen(spec, "changing the interface")
    iface = spec["interface"]
    if args.language:
        iface["language"] = args.language
    if args.entry:
        iface["entry_point"] = args.entry
    if args.signature:
        iface["signature"] = args.signature
    for c in args.contract or []:
        if c not in iface["contract"]:
            iface["contract"].append(c)
    store(args.task, spec)
    print("interface: %s %s" % (iface["language"], iface["entry_point"]))
    print("contract clauses: %d" % len(iface["contract"]))
    if len(iface["contract"]) < 3:
        print("warning: fewer than 3 contract clauses. The usual omissions are empty input, ties, "
              "and what happens when n exceeds the input size. An unstated clause becomes four "
              "different behaviours in four candidates.", file=sys.stderr)


def cmd_criterion(args: argparse.Namespace) -> None:
    spec = load(args.task)
    require_unfrozen(spec, "adding an acceptance criterion")
    if not args.measured_by:
        die("every acceptance criterion needs --measured-by: the concrete check that decides it. "
            "'fast' is not a criterion; 'median under 50 ms at n=100000 on the benchmark host' is.")
    ac = {
        "id": args.id or next_id("AC", [a["id"] for a in spec["acceptance_criteria"]], width=1),
        "statement": args.statement,
        "measured_by": args.measured_by,
        "kind": args.kind or "correctness",
        "mandatory": bool(args.mandatory),
    }
    spec["acceptance_criteria"].append(ac)
    store(args.task, spec)
    print(ac["id"])


def cmd_gate(args: argparse.Namespace) -> None:
    spec = load(args.task)
    require_unfrozen(spec, "adding a gate")
    if args.kind not in GATE_KINDS:
        die("--kind must be one of: " + ", ".join(GATE_KINDS))
    if not args.command and not args.manual:
        die("a gate needs either --command (a command whose exit status decides it) or --manual "
            "(a human or agent judgement, which must then name its evidence in gates.py record)")
    gate = {
        "id": args.id or next_id("G", [g["id"] for g in spec["gates"]], width=1),
        "kind": args.kind,
        "description": args.description,
        "command": args.command or "",
        "manual": bool(args.manual),
        "mandatory": bool(args.mandatory),
        "timeout_s": args.timeout,
    }
    spec["gates"].append(gate)
    store(args.task, spec)
    print(gate["id"])


def cmd_axis(args: argparse.Namespace) -> None:
    spec = load(args.task)
    require_unfrozen(spec, "adding a benchmark axis")
    if args.id not in AXES and not args.id.startswith("custom:"):
        die("--id must be one of %s, or custom:<name>" % ", ".join(AXES))
    if args.direction not in ("min", "max"):
        die("--direction must be min or max")
    axis = {
        "id": args.id, "direction": args.direction, "unit": args.unit or "",
        "limit": args.limit, "pareto": bool(args.pareto),
        "source": args.source or "measured",
    }
    spec["axes"] = [a for a in spec["axes"] if a["id"] != axis["id"]] + [axis]
    store(args.task, spec)
    print("%s (%s%s)%s" % (axis["id"], axis["direction"], ", limit %s" % axis["limit"] if axis["limit"] is not None else "",
                           " [pareto]" if axis["pareto"] else " [reported only]"))
    if axis["id"] == "size" and axis["pareto"]:
        print("warning: 'size' as a Pareto axis means fewer lines wins ties on its own. Fewer lines are "
              "not automatically better: a 12-line version that is slower or harder to read should lose "
              "to a 25-line one. Only do this if the requester explicitly asked for it.", file=sys.stderr)


def cmd_benchmark(args: argparse.Namespace) -> None:
    spec = load(args.task)
    require_unfrozen(spec, "changing the benchmark plan")
    b = spec["benchmark"]
    if args.sizes:
        try:
            b["sizes"] = [int(s) for s in args.sizes.split(",") if s.strip()]
        except ValueError:
            die("--sizes must be a comma-separated list of integers")
        if len(b["sizes"]) < 2:
            print("warning: one input size cannot show how a candidate scales. The 12-line sort and the "
                  "heap look identical at n=100 and differ by orders of magnitude at n=10,000,000. "
                  "Use at least three sizes spanning two decades.", file=sys.stderr)
    for key, val in (("reps", args.reps), ("warmup", args.warmup), ("timeout_s", args.timeout)):
        if val is not None:
            b[key] = val
    if args.noise_floor is not None:
        b["noise_floor_pct"] = args.noise_floor
    if b.get("reps", 0) < 5:
        print("warning: fewer than 5 repetitions cannot separate a real difference from noise.", file=sys.stderr)
    store(args.task, spec)
    print(json.dumps(b, indent=2))


def cmd_priorities(args: argparse.Namespace) -> None:
    spec = load(args.task)
    if args.source not in ("user", "unset", "inferred"):
        die("--source must be user, inferred or unset")
    if args.source == "inferred":
        die("priorities may not be inferred. If the requester has not stated a preference order, leave "
            "it unset: the selection phase then presents the trade-off and asks. Choosing for them and "
            "calling it an inference is how FORGE would quietly become an opinion generator.")
    order = [o.strip() for o in (args.order or "").split(",") if o.strip()]
    known = {a["id"] for a in spec["axes"]} | {"correctness", "maintainability", "simplicity", "security", "dependencies", "size"}
    unknown = [o for o in order if o not in known]
    if unknown:
        die("unknown priority axes: %s (known: %s)" % (", ".join(unknown), ", ".join(sorted(known))))
    spec["priorities"] = {"source": args.source, "order": order,
                          "weights": json.loads(args.weights) if args.weights else {},
                          "quote": args.quote or "", "recorded_at": now_iso()}
    store(args.task, spec)
    print("priorities (%s): %s" % (args.source, " > ".join(order) or "none"))


def cmd_baseline(args: argparse.Namespace) -> None:
    spec = load(args.task)
    if args.exists not in ("yes", "no", "unknown"):
        die("--exists must be yes, no or unknown")
    if args.exists == "yes" and not args.what:
        die("--what must name the existing thing (a standard-library call, a function in this codebase, "
            "or a dependency already in the lock file)")
    spec["baseline"] = {"exists": args.exists, "what": args.what or "",
                        "why_not_enough": args.why_not_enough or "", "searched": args.searched or ""}
    store(args.task, spec)
    print("baseline: %s %s" % (args.exists, args.what or ""))
    if args.exists == "yes":
        print("Register it as candidate C-01 with strategy=baseline. If it passes the gates and nothing "
              "beats it by more than the noise floor, it wins, and the right outcome of this task is to "
              "write no new code.")
    elif args.exists == "no" and not args.searched:
        print("warning: --exists no without --searched describing what you looked at is an assertion, "
              "not a finding. Say which standard library modules, which codebase paths and which "
              "existing dependencies you checked.", file=sys.stderr)


def cmd_constraint(args: argparse.Namespace) -> None:
    spec = load(args.task)
    require_unfrozen(spec, "adding a constraint")
    key = "non_goals" if args.non_goal else "constraints"
    if args.text not in spec[key]:
        spec[key].append(args.text)
    store(args.task, spec)
    print("%d %s" % (len(spec[key]), key))


def problems(spec: dict) -> list:
    out = []
    iface = spec["interface"]
    if not iface.get("entry_point"):
        out.append("interface.entry_point is empty: candidates would not even agree on what to call")
    if iface.get("language") in ("", "unknown"):
        out.append("interface.language is unknown")
    if len(iface.get("contract") or []) < 1:
        out.append("no contract clauses: implementers will each invent the edge-case behaviour")
    if not spec["acceptance_criteria"]:
        out.append("no acceptance criteria")
    for ac in spec["acceptance_criteria"]:
        if not ac.get("measured_by"):
            out.append("%s has no measured_by" % ac["id"])
    mandatory = [g for g in spec["gates"] if g.get("mandatory")]
    if not mandatory:
        out.append("no mandatory gate: without one, every candidate 'passes' and ranking is meaningless")
    if not any(g["kind"] == "correctness" for g in mandatory):
        out.append("no mandatory correctness gate")
    pareto = [a for a in spec["axes"] if a.get("pareto")]
    if not spec["axes"]:
        out.append("no axes: nothing would be measured")
    elif not pareto:
        out.append("no axis marked --pareto: the selection phase would have nothing to rank on")
    b = spec.get("benchmark") or {}
    if any(a["id"] in ("time", "memory", "throughput") for a in spec["axes"]):
        if not b.get("sizes"):
            out.append("benchmark.sizes is empty but a performance axis exists")
        if not b.get("reps"):
            out.append("benchmark.reps is unset")
    if spec["baseline"].get("exists") == "unknown":
        out.append("baseline.exists is unknown: nobody checked whether this already exists")
    return out


def cmd_check(args: argparse.Namespace) -> None:
    spec = load(args.task)
    errors = validate(spec, load_schema("spec.schema.json"))
    probs = problems(spec)
    for e in errors:
        print("schema: " + e)
    for p in probs:
        print("spec: " + p)
    if errors or probs:
        print("\n%d problem(s). The spec is not ready to freeze." % (len(errors) + len(probs)))
        sys.exit(1)
    print("spec is complete and consistent: %d acceptance criteria, %d gates (%d mandatory), "
          "%d axes (%d pareto), %d benchmark size(s), priorities=%s" % (
              len(spec["acceptance_criteria"]), len(spec["gates"]),
              sum(1 for g in spec["gates"] if g.get("mandatory")), len(spec["axes"]),
              sum(1 for a in spec["axes"] if a.get("pareto")),
              len(spec["benchmark"].get("sizes") or []), spec["priorities"]["source"]))


def cmd_freeze(args: argparse.Namespace) -> None:
    spec = load(args.task)
    if args.unfreeze:
        if not args.reason:
            die("--unfreeze needs --reason: what changed in the requirement")
        spec.setdefault("freeze_history", []).append(
            {"event": "unfrozen", "at": now_iso(), "reason": args.reason, "previous_hash": spec.get("spec_hash")})
        spec["frozen_at"] = None
        store(args.task, spec)
        print("spec unfrozen. Every gate result and measurement now carries a stale spec hash: re-run "
              "`harness.py run` and `bench.py run` for every candidate before comparing anything again.")
        return
    probs = problems(spec)
    if probs and not args.force:
        for p in probs:
            print("spec: " + p)
        die("the spec is incomplete; fix the above or pass --force (which records that you overrode it)")
    h = spec_hash(spec)
    spec["frozen_at"] = now_iso()
    spec["spec_hash"] = h
    if args.force and probs:
        spec.setdefault("freeze_history", []).append(
            {"event": "frozen with --force", "at": now_iso(), "unresolved": probs})
    spec.setdefault("freeze_history", []).append({"event": "frozen", "at": now_iso(), "hash": h})
    store(args.task, spec)
    print("spec frozen, hash %s" % h)
    print("Candidates may now be generated. Every implementer gets the same frozen spec and nothing else.")


def cmd_show(args: argparse.Namespace) -> None:
    spec = load(args.task)
    if args.json:
        print(json.dumps(spec, indent=2)); return
    print("# %s: %s" % (spec["task"], spec["title"]))
    print("\n%s\n" % (spec.get("statement") or ""))
    iface = spec["interface"]
    print("Interface: %s  %s" % (iface["language"], iface["signature"] or iface["entry_point"]))
    for c in iface["contract"]:
        print("  - " + c)
    print("\nAcceptance criteria")
    for ac in spec["acceptance_criteria"]:
        print("  %s %s%s\n      measured by: %s" % (
            ac["id"], ac["statement"], " [mandatory]" if ac["mandatory"] else "", ac["measured_by"]))
    print("\nGates")
    for g in spec["gates"]:
        print("  %s [%s]%s %s\n      %s" % (g["id"], g["kind"], " MANDATORY" if g["mandatory"] else "",
                                            g["description"], g["command"] or "(manual judgement)"))
    print("\nAxes")
    for a in spec["axes"]:
        print("  %-12s %s %-5s limit=%s %s" % (a["id"], a["direction"], a["unit"], a["limit"],
                                               "pareto" if a["pareto"] else "reported only"))
    print("\nBenchmark: %s" % json.dumps(spec["benchmark"]))
    print("Priorities (%s): %s" % (spec["priorities"]["source"], " > ".join(spec["priorities"]["order"]) or "none"))
    print("Baseline: %s %s" % (spec["baseline"]["exists"], spec["baseline"]["what"]))
    for c in spec["constraints"]:
        print("Constraint: " + c)
    for n in spec["non_goals"]:
        print("Non-goal: " + n)
    print("\nFrozen: %s  hash=%s" % (spec.get("frozen_at") or "no", spec.get("spec_hash") or "-"))


def main() -> None:
    ap = argparse.ArgumentParser(description="FORGE spec manager")
    sub = ap.add_subparsers(dest="cmd")

    def t(p):
        p.add_argument("--task", required=True)

    p = sub.add_parser("interface"); t(p)
    p.add_argument("--language"); p.add_argument("--entry"); p.add_argument("--signature")
    p.add_argument("--contract", action="append"); p.set_defaults(fn=cmd_interface)
    p = sub.add_parser("criterion"); t(p)
    p.add_argument("--id"); p.add_argument("--statement", required=True); p.add_argument("--measured-by")
    p.add_argument("--kind"); p.add_argument("--mandatory", action="store_true"); p.set_defaults(fn=cmd_criterion)
    p = sub.add_parser("gate"); t(p)
    p.add_argument("--id"); p.add_argument("--kind", required=True); p.add_argument("--description", required=True)
    p.add_argument("--command"); p.add_argument("--manual", action="store_true")
    p.add_argument("--mandatory", action="store_true"); p.add_argument("--timeout", type=int, default=300)
    p.set_defaults(fn=cmd_gate)
    p = sub.add_parser("axis"); t(p)
    p.add_argument("--id", required=True); p.add_argument("--direction", required=True); p.add_argument("--unit")
    p.add_argument("--limit", type=float); p.add_argument("--pareto", action="store_true")
    p.add_argument("--source"); p.set_defaults(fn=cmd_axis)
    p = sub.add_parser("benchmark"); t(p)
    p.add_argument("--sizes"); p.add_argument("--reps", type=int); p.add_argument("--warmup", type=int)
    p.add_argument("--timeout", type=int); p.add_argument("--noise-floor", type=float, dest="noise_floor")
    p.set_defaults(fn=cmd_benchmark)
    p = sub.add_parser("priorities"); t(p)
    p.add_argument("--source", required=True); p.add_argument("--order"); p.add_argument("--weights")
    p.add_argument("--quote"); p.set_defaults(fn=cmd_priorities)
    p = sub.add_parser("baseline"); t(p)
    p.add_argument("--exists", required=True); p.add_argument("--what"); p.add_argument("--why-not-enough")
    p.add_argument("--searched"); p.set_defaults(fn=cmd_baseline)
    p = sub.add_parser("constraint"); t(p)
    p.add_argument("--text", required=True); p.add_argument("--non-goal", action="store_true")
    p.set_defaults(fn=cmd_constraint)
    p = sub.add_parser("check"); t(p); p.set_defaults(fn=cmd_check)
    p = sub.add_parser("freeze"); t(p)
    p.add_argument("--force", action="store_true"); p.add_argument("--unfreeze", action="store_true")
    p.add_argument("--reason"); p.set_defaults(fn=cmd_freeze)
    p = sub.add_parser("show"); t(p); p.add_argument("--json", action="store_true"); p.set_defaults(fn=cmd_show)

    args = ap.parse_args()
    if not getattr(args, "fn", None):
        ap.print_help(); sys.exit(1)
    args.fn(args)


if __name__ == "__main__":
    main()
