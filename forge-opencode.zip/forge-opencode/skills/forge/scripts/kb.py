#!/usr/bin/env python3
"""FORGE knowledge base: measured facts that outlive the task.

Most of what a FORGE competition produces is thrown away by other workflows: the
losing candidates, the measurements that showed an approach does not pay, the
dependency that was not worth its weight, the abstraction that was removed. Those
are the expensive part, and they are reusable.

Three kinds of entry, kept apart because they have different authority:

* **Measured facts.** "Multiprocessing a 100k-record selection on 2 cores was
  11x slower than the serial standard-library call." A number, with the host and
  the date, that a future task can start from instead of re-measuring.
* **Patterns.** "Selection of the top k from n: the stdlib heap call wins up to
  roughly n=1e6; NumPy only pays once the data is already in arrays."
* **Rejected approaches.** What lost, in which task, and *why*, scoped to that
  task's spec and host.

A measured fact is only as good as its environment and its date. The tool stores
both and prints them with every entry, because a timing from another machine is
a hint, not a fact about this one. "Rejected in TASK-004" never means "never
usable": it means it lost against that spec, at those sizes, on that host.

Usage:
    kb.py import --task forge/tasks/TASK-001
    kb.py fact   --what "heapq.nlargest beat a 2-process pool 11x at n=100000" \\
                 --task TASK-001 --evidence "measurements.json: C-01 0.0091s vs C-05 0.102s" \\
                 --scope "CPython 3.13, 2 cores, 100-of-100k ints"
    kb.py pattern --name "top-k selection" --signature "select k best of n" \\
                  --guidance "stdlib heap call first; measure before parallelising" --task TASK-001
    kb.py search --text "top-k"
    kb.py brief  --about "selection,sorting"
    kb.py render [--root forge]
"""
from __future__ import annotations

import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import die, find_workspace, load_json, next_id, now_iso, save_json  # noqa: E402

FILES = {
    "measured_facts.md": ("facts", "Measured facts"),
    "winning_patterns.md": ("patterns", "Winning patterns"),
    "rejected_approaches.md": ("rejected", "Rejected approaches"),
}


def root_of(args: argparse.Namespace) -> str:
    root = getattr(args, "root", None)
    if getattr(args, "task", None) and not root and os.path.sep in str(args.task):
        root = os.path.dirname(os.path.dirname(os.path.abspath(args.task)))
    root = root or find_workspace() or "forge"
    if not os.path.isdir(os.path.join(root, "knowledge_base")):
        die("no knowledge base at %s (run workspace.py init)" % root)
    return root


def kb_path(root: str) -> str:
    return os.path.join(root, "knowledge_base", "patterns.json")


def load_kb(root: str) -> dict:
    data = load_json(kb_path(root), default={"facts": [], "patterns": [], "rejected": []})
    for key in ("facts", "patterns", "rejected"):
        data.setdefault(key, [])
    return data


def cmd_fact(args: argparse.Namespace) -> None:
    root = root_of(args)
    kb = load_kb(root)
    if not args.evidence:
        die("a measured fact needs --evidence naming where the numbers are (which task's "
            "measurements.json, which candidates, which figures). A remembered number is not a fact.")
    if not args.scope:
        die("a measured fact needs --scope: the runtime, the hardware, the input shape and the sizes "
            "it holds for. A timing without its environment is not transferable.")
    entry = {"id": next_id("F", [f["id"] for f in kb["facts"]]), "what": args.what,
             "task": args.task or "", "evidence": args.evidence, "scope": args.scope,
             "axis": args.axis or "", "recorded_at": now_iso()}
    kb["facts"].append(entry)
    save_json(kb_path(root), kb)
    print(entry["id"])
    render(root)


def cmd_pattern(args: argparse.Namespace) -> None:
    root = root_of(args)
    kb = load_kb(root)
    existing = next((p for p in kb["patterns"] if p["name"].lower() == args.name.lower()), None)
    if existing:
        if args.task and args.task not in existing["seen_in"]:
            existing["seen_in"].append(args.task)
        if args.guidance:
            existing.setdefault("guidance_history", []).append(
                {"at": now_iso(), "guidance": existing["guidance"]})
            existing["guidance"] = args.guidance
        existing["last_seen"] = now_iso()
        existing["confirmations"] = existing.get("confirmations", 1) + 1
        save_json(kb_path(root), kb)
        print("%s (now seen in %d task(s))" % (existing["id"], len(existing["seen_in"])))
        render(root); return
    entry = {"id": next_id("P", [p["id"] for p in kb["patterns"]]), "name": args.name,
             "signature": args.signature or "", "guidance": args.guidance or "",
             "seen_in": [args.task] if args.task else [], "confirmations": 1,
             "caveat": args.caveat or "", "first_seen": now_iso(), "last_seen": now_iso()}
    if not entry["guidance"]:
        die("a pattern needs --guidance: what a future task should actually do differently")
    kb["patterns"].append(entry)
    save_json(kb_path(root), kb)
    print(entry["id"])
    render(root)


def cmd_reject(args: argparse.Namespace) -> None:
    root = root_of(args)
    kb = load_kb(root)
    if not args.why:
        die("a rejected approach needs --why, with the measurement or failing gate that sank it")
    entry = {"id": next_id("X", [r["id"] for r in kb["rejected"]]), "approach": args.approach,
             "task": args.task or "", "why": args.why, "scope": args.scope or "",
             "would_reconsider_if": args.reconsider_if or "", "recorded_at": now_iso()}
    kb["rejected"].append(entry)
    save_json(kb_path(root), kb)
    print(entry["id"])
    render(root)


def cmd_import(args: argparse.Namespace) -> None:
    """Pull the obvious facts out of a finished task automatically."""
    root = root_of(args)
    task = args.task
    kb = load_kb(root)
    spec = load_json(os.path.join(task, "spec.json"))
    dec = load_json(os.path.join(task, "decisions.json"), default={})
    meas = load_json(os.path.join(task, "measurements.json"), default={"runs": []})
    cands = load_json(os.path.join(task, "candidates.json"), default={"items": []})["items"]
    final = dec.get("final") or {}
    env = meas.get("environment") or {}
    scope = "%s %s, %s, %d CPU(s)" % (env.get("implementation", "?"), env.get("python", "?"),
                                      env.get("machine", "?"), env.get("cpu_count") or 0)
    added = 0
    runs = [r for r in meas["runs"] if r.get("ok")]
    if runs and final.get("selected"):
        size = max(r["size"] for r in runs)
        at = {r["candidate"]: r for r in runs if r["size"] == size}
        win = at.get(final["selected"])
        titles = {c["id"]: c["title"] for c in cands}
        if win:
            for cid, r in sorted(at.items(), key=lambda kv: kv[1]["median_s"]):
                if cid == final["selected"] or not r.get("median_s") or not win.get("median_s"):
                    continue
                ratio = r["median_s"] / win["median_s"]
                if ratio < 1.2:
                    continue
                kb["facts"].append({
                    "id": next_id("F", [f["id"] for f in kb["facts"]]),
                    "what": "%s (%s) was %.1fx slower than %s (%s) at n=%d" % (
                        cid, titles.get(cid, ""), ratio, final["selected"],
                        titles.get(final["selected"], ""), size),
                    "task": spec["task"],
                    "evidence": "%s measurements.json: median %.6gs vs %.6gs, %d reps" % (
                        spec["task"], r["median_s"], win["median_s"], r.get("reps") or 0),
                    "scope": "%s; %s" % (scope, spec["title"]),
                    "axis": "time", "recorded_at": now_iso()})
                added += 1
    for c in cands:
        if c["status"] == "retired":
            kb["rejected"].append({
                "id": next_id("X", [r["id"] for r in kb["rejected"]]),
                "approach": "%s: %s" % (c["strategy"], c["title"]),
                "task": spec["task"], "why": c.get("retired_reason", "retired"),
                "scope": "%s; %s" % (scope, spec["title"]),
                "would_reconsider_if": "", "recorded_at": now_iso()})
            added += 1
    save_json(kb_path(root), kb)
    print("imported %d entry(ies) from %s" % (added, spec["task"]))
    if not final.get("selected"):
        print("note: this task has no selected candidate, so no winner/loser ratios were imported.")
    print("Add the judgement that a script cannot derive: `kb.py pattern` for what a future task "
          "should do differently, and `kb.py reject --reconsider-if` for the condition under which a "
          "losing approach would be worth another look.")
    render(root)


def cmd_search(args: argparse.Namespace) -> None:
    kb = load_kb(root_of(args))
    needle = (args.text or "").lower()

    def hit(blob):
        return needle in blob.lower() if needle else True
    for f in kb["facts"]:
        if hit(f["what"] + f.get("scope", "") + f.get("axis", "")):
            print("%-6s FACT     %s" % (f["id"], f["what"]))
            print("          scope: %s   [%s, %s]" % (f["scope"], f.get("task", "?"), f["recorded_at"][:10]))
    for p in kb["patterns"]:
        if hit(p["name"] + p.get("signature", "") + p.get("guidance", "")):
            print("%-6s PATTERN  %s (%dx)" % (p["id"], p["name"], p.get("confirmations", 1)))
            print("          %s" % p["guidance"])
            if p.get("caveat"):
                print("          caveat: " + p["caveat"])
    for r in kb["rejected"]:
        if hit(r["approach"] + r.get("why", "")):
            print("%-6s REJECTED %s  [%s]" % (r["id"], r["approach"], r.get("task", "?")))
            print("          why: %s" % r["why"])
            if r.get("would_reconsider_if"):
                print("          reconsider if: " + r["would_reconsider_if"])


def cmd_brief(args: argparse.Namespace) -> None:
    kb = load_kb(root_of(args))
    topics = [t.strip().lower() for t in (args.about or "").split(",") if t.strip()]

    def match(blob):
        return any(t in blob.lower() for t in topics) if topics else True
    print("Prior FORGE knowledge for this area. A measured fact holds for its scope and date, not "
          "universally; re-measure before relying on one from another host.\n")
    shown = 0
    for p in kb["patterns"]:
        if match(p["name"] + p.get("signature", "") + p.get("guidance", "")):
            print("- PATTERN %s: %s" % (p["id"], p["name"]))
            print("    %s" % p["guidance"])
            if p.get("caveat"):
                print("    caveat: %s" % p["caveat"])
            print("    seen in: %s" % ", ".join(p["seen_in"]))
            shown += 1
    for f in kb["facts"]:
        if match(f["what"] + f.get("scope", "")):
            print("- FACT %s: %s" % (f["id"], f["what"]))
            print("    scope: %s  (%s, %s)" % (f["scope"], f.get("task", "?"), f["recorded_at"][:10]))
            shown += 1
    for r in kb["rejected"]:
        if match(r["approach"] + r.get("why", "")):
            print("- REJECTED %s: %s" % (r["id"], r["approach"]))
            print("    why: %s" % r["why"])
            print("    scoped to %s. This does not mean it cannot work here." % (r.get("task") or "that task"))
            shown += 1
    if not shown:
        print("(nothing recorded for these topics yet)")
    else:
        print("\nUse this to choose which candidates are worth generating, never to skip measuring the "
              "ones you do generate.")


def render(root: str) -> None:
    kb = load_kb(root)
    kbdir = os.path.join(root, "knowledge_base")
    out = ["# Measured facts", "",
           "_Generated by `kb.py render`. Each fact holds for its scope and its date: a timing from "
           "another machine is a hint, not a fact about this one._", ""]
    if not kb["facts"]:
        out.append("_No entries yet._")
    for f in kb["facts"]:
        out += ["### %s" % f["id"], "", f["what"], "",
                "| | |", "|---|---|",
                "| Task | %s |" % (f.get("task") or "-"),
                "| Axis | %s |" % (f.get("axis") or "-"),
                "| Evidence | %s |" % f["evidence"],
                "| Scope | %s |" % f["scope"],
                "| Recorded | %s |" % f["recorded_at"], ""]
    with open(os.path.join(kbdir, "measured_facts.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(out).rstrip() + "\n")

    out = ["# Winning patterns", "",
           "_What to reach for first, and when it stops being the right answer. A pattern is a "
           "starting point for candidate generation, never a reason to skip measuring._", ""]
    if not kb["patterns"]:
        out.append("_No entries yet._")
    for p in kb["patterns"]:
        out += ["### %s: %s" % (p["id"], p["name"]), "",
                "**Signature:** %s" % (p.get("signature") or "-"), "",
                "**Guidance:** %s" % p["guidance"], ""]
        if p.get("caveat"):
            out += ["**Caveat:** %s" % p["caveat"], ""]
        out += ["Confirmed %d time(s), in %s. First seen %s." % (
            p.get("confirmations", 1), ", ".join(p["seen_in"]) or "-", p["first_seen"][:10]), ""]
    with open(os.path.join(kbdir, "winning_patterns.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(out).rstrip() + "\n")

    out = ["# Rejected approaches", "",
           "_What lost, where, and why. Every entry is scoped to its task's spec, sizes and host: "
           "'rejected there' is not 'never usable'._", ""]
    if not kb["rejected"]:
        out.append("_No entries yet._")
    for r in kb["rejected"]:
        out += ["### %s: %s" % (r["id"], r["approach"]), "",
                "- **Why:** %s" % r["why"],
                "- **Task:** %s" % (r.get("task") or "-"),
                "- **Scope:** %s" % (r.get("scope") or "-")]
        if r.get("would_reconsider_if"):
            out.append("- **Would reconsider if:** %s" % r["would_reconsider_if"])
        out.append("")
    with open(os.path.join(kbdir, "rejected_approaches.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(out).rstrip() + "\n")

    # index
    tdir = os.path.join(root, "tasks")
    rows = []
    if os.path.isdir(tdir):
        for t in sorted(d for d in os.listdir(tdir) if os.path.isdir(os.path.join(tdir, d))):
            spec = load_json(os.path.join(tdir, t, "spec.json"), default={})
            dec = load_json(os.path.join(tdir, t, "decisions.json"), default={})
            final = dec.get("final") or {}
            report = ("[report](tasks/%s/final_report.md)" % t
                      if os.path.exists(os.path.join(tdir, t, "final_report.md")) else "-")
            rows.append("| %s | %s | %s | %s | %s | %s |" % (
                t, spec.get("title", ""), spec.get("status", ""), final.get("verdict", "-"),
                final.get("selected") or "-", report))
    idx = ["# FORGE index", "", "## Tasks", "",
           "| ID | Title | Status | Verdict | Selected | Report |", "|---|---|---|---|---|---|"] + (
        rows or ["| - | none yet | | | | |"])
    idx += ["", "## Knowledge base", "",
            "| Measured facts | Patterns | Rejected approaches |", "|---|---|---|",
            "| %d | %d | %d |" % (len(kb["facts"]), len(kb["patterns"]), len(kb["rejected"])), "",
            "- [Measured facts](knowledge_base/measured_facts.md)",
            "- [Winning patterns](knowledge_base/winning_patterns.md)",
            "- [Rejected approaches](knowledge_base/rejected_approaches.md)", "",
            "_Every measured fact is scoped to a host and a date. Re-measure before relying on one._"]
    with open(os.path.join(root, "index.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(idx) + "\n")


def cmd_render(args: argparse.Namespace) -> None:
    root = root_of(args)
    render(root)
    print("rendered knowledge base and index under " + root)


def main() -> None:
    ap = argparse.ArgumentParser(description="FORGE knowledge base")
    sub = ap.add_subparsers(dest="cmd")
    p = sub.add_parser("import"); p.add_argument("--task", required=True); p.add_argument("--root"); p.set_defaults(fn=cmd_import)
    p = sub.add_parser("fact"); p.add_argument("--what", required=True); p.add_argument("--task")
    p.add_argument("--evidence"); p.add_argument("--scope"); p.add_argument("--axis"); p.add_argument("--root")
    p.set_defaults(fn=cmd_fact)
    p = sub.add_parser("pattern"); p.add_argument("--name", required=True); p.add_argument("--signature")
    p.add_argument("--guidance"); p.add_argument("--caveat"); p.add_argument("--task"); p.add_argument("--root")
    p.set_defaults(fn=cmd_pattern)
    p = sub.add_parser("reject"); p.add_argument("--approach", required=True); p.add_argument("--why")
    p.add_argument("--task"); p.add_argument("--scope"); p.add_argument("--reconsider-if"); p.add_argument("--root")
    p.set_defaults(fn=cmd_reject)
    p = sub.add_parser("search"); p.add_argument("--text"); p.add_argument("--root"); p.set_defaults(fn=cmd_search)
    p = sub.add_parser("brief"); p.add_argument("--about"); p.add_argument("--root"); p.set_defaults(fn=cmd_brief)
    p = sub.add_parser("render"); p.add_argument("--root"); p.set_defaults(fn=cmd_render)
    args = ap.parse_args()
    if not getattr(args, "fn", None):
        ap.print_help(); sys.exit(1)
    args.fn(args)


if __name__ == "__main__":
    main()
