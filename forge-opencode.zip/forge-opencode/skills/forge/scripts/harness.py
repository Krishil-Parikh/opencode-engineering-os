#!/usr/bin/env python3
"""FORGE gate harness: the part that stops an agent from grading its own homework.

Runs the spec's mandatory and advisory gates against each candidate and records
the result with the candidate's code hash and the spec hash. Also runs
**differential testing**: every candidate is given the same generated inputs and
their outputs are compared against each other. Four independent implementations
of one spec are a free oracle — any disagreement is a bug in at least one of
them, found without anybody having to write the expected answer down.

Gate commands run with the task directory as the working directory and these
environment variables set:

    FORGE_CANDIDATE      candidate id, e.g. C-02
    FORGE_CANDIDATE_DIR  absolute path to the candidate's directory
    FORGE_ENTRY          the candidate's entry file name
    FORGE_ENTRY_PATH     absolute path to the entry file
    PYTHONPATH           the candidate directory, prepended

So a Python gate command can be as simple as `python3 -m pytest tests -q`, with
the test suite importing the entry module by name.

Usage:
    harness.py run --task T --candidate C-01
    harness.py run --task T --all
    harness.py record --task T --candidate C-02 --gate G-4 --result pass \
        --evidence "reviewed by security-reviewer: no user input reaches eval; see review R-003"
    harness.py differential --task T --driver tests/driver.py --generator tests/gen.py \
        --cases 200 --seed 7 [--shrink]
    harness.py report --task T
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import (GATE_RESULTS, die, get_candidate, load_candidates, load_json, load_spec,  # noqa: E402
                     now_iso, save_json, sha256_text, task_path)

TAIL = 2500


def candidate_env(task: str, cand: dict) -> dict:
    env = dict(os.environ)
    cdir = os.path.abspath(os.path.join(task, cand["dir"]))
    env["FORGE_CANDIDATE"] = cand["id"]
    env["FORGE_CANDIDATE_DIR"] = cdir
    env["FORGE_ENTRY"] = cand["entry"]
    env["FORGE_ENTRY_PATH"] = os.path.join(cdir, cand["entry"])
    env["PYTHONPATH"] = cdir + (os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else "")
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    return env


def run_gate(task: str, cand: dict, gate: dict) -> dict:
    started = now_iso()
    if gate.get("manual"):
        return {"result": "not-run", "note": "manual gate: record it with `harness.py record`",
                "started_at": started}
    try:
        proc = subprocess.run(gate["command"], shell=True, cwd=os.path.abspath(task),
                              env=candidate_env(task, cand), capture_output=True, text=True,
                              timeout=gate.get("timeout_s") or 300)
    except subprocess.TimeoutExpired as exc:
        return {"result": "fail", "exit_code": None, "timed_out": True,
                "timeout_s": gate.get("timeout_s"), "started_at": started,
                "stdout": (exc.stdout or "")[-TAIL:] if isinstance(exc.stdout, str) else "",
                "stderr": (exc.stderr or "")[-TAIL:] if isinstance(exc.stderr, str) else "",
                "note": "exceeded the gate timeout. A gate timeout is a failure, not a slow pass."}
    except OSError as exc:
        return {"result": "error", "exit_code": None, "started_at": started, "stderr": str(exc),
                "note": "the gate command could not be launched"}
    return {"result": "pass" if proc.returncode == 0 else "fail", "exit_code": proc.returncode,
            "timed_out": False, "started_at": started,
            "stdout": proc.stdout[-TAIL:], "stderr": proc.stderr[-TAIL:]}


def store_result(task: str, entry: dict) -> None:
    path = task_path(task, "gates.json")
    data = load_json(path)
    data["results"] = [r for r in data["results"]
                       if not (r["candidate"] == entry["candidate"] and r["gate"] == entry["gate"])]
    data["results"].append(entry)
    save_json(path, data)


def cmd_run(args: argparse.Namespace) -> None:
    spec = load_spec(args.task)
    if not spec.get("frozen_at"):
        die("the spec is not frozen; freeze it before running gates")
    gates = spec["gates"]
    if not gates:
        die("the spec defines no gates. Add at least one mandatory correctness gate with `spec.py gate`.")
    if args.gate:
        gates = [g for g in gates if g["id"] == args.gate] or die("unknown gate " + args.gate)
    cands = [c for c in load_candidates(args.task)["items"] if c["status"] == "active"]
    if not args.all:
        cands = [get_candidate(args.task, args.candidate)]
    worst = 0
    for cand in cands:
        print("%s  %s" % (cand["id"], cand["title"]))
        for gate in gates:
            res = run_gate(args.task, cand, gate)
            entry = dict(res, candidate=cand["id"], gate=gate["id"], kind=gate["kind"],
                         mandatory=bool(gate.get("mandatory")), command=gate.get("command", ""),
                         code_hash=cand["code_hash"], spec_hash=spec.get("spec_hash"),
                         recorded_at=now_iso())
            store_result(args.task, entry)
            mark = {"pass": "ok  ", "fail": "FAIL", "error": "ERR ", "not-run": "--  ", "skipped": "skip"}[res["result"]]
            print("  %s %-5s [%s]%s %s" % (mark, gate["id"], gate["kind"],
                                           " mandatory" if gate.get("mandatory") else "", gate["description"]))
            if res["result"] in ("fail", "error"):
                if gate.get("mandatory"):
                    worst = max(worst, 1)
                tail = (res.get("stderr") or res.get("stdout") or "").strip().splitlines()
                for line in tail[-6:]:
                    print("       | " + line[:200])
    print()
    print("A candidate that fails one mandatory gate is out of the competition, whatever its "
          "benchmark numbers. Fix it and re-run, or retire it.")
    sys.exit(worst)


def cmd_record(args: argparse.Namespace) -> None:
    spec = load_spec(args.task)
    cand = get_candidate(args.task, args.candidate)
    gate = next((g for g in spec["gates"] if g["id"] == args.gate), None)
    if not gate:
        die("unknown gate " + args.gate)
    if args.result not in GATE_RESULTS:
        die("--result must be one of " + ", ".join(GATE_RESULTS))
    if not gate.get("manual") and args.result in ("pass", "fail"):
        die("%s has a command, so it is decided by running it, not by recording a judgement. "
            "Use `harness.py run --task %s --candidate %s --gate %s`." % (args.gate, args.task, args.candidate, args.gate))
    if args.result in ("pass", "fail") and not args.evidence:
        die("a manual gate result needs --evidence: what was examined, by whom, and what was found. "
            "A judgement with no evidence is an opinion, and opinions do not pass gates.")
    store_result(args.task, {
        "candidate": cand["id"], "gate": gate["id"], "kind": gate["kind"],
        "mandatory": bool(gate.get("mandatory")), "command": "", "manual": True,
        "result": args.result, "evidence": args.evidence or "", "reviewer": args.by or "unknown",
        "code_hash": cand["code_hash"], "spec_hash": spec.get("spec_hash"), "recorded_at": now_iso(),
    })
    print("%s %s -> %s" % (cand["id"], gate["id"], args.result))


# ----------------------------------------------------------------- differential
def run_driver(task: str, cand: dict, driver: str, case: str, timeout: int) -> dict:
    try:
        proc = subprocess.run([sys.executable, driver], cwd=os.path.abspath(task),
                              env=candidate_env(task, cand), input=case,
                              capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        return {"ok": False, "kind": "timeout", "detail": "driver exceeded %ds" % timeout}
    if proc.returncode != 0:
        return {"ok": False, "kind": "crash", "detail": (proc.stderr or "").strip()[-600:]}
    out = proc.stdout.strip()
    try:
        return {"ok": True, "value": json.loads(out) if out else None, "raw": out}
    except ValueError:
        return {"ok": False, "kind": "bad-output", "detail": "driver did not print JSON: " + out[:300]}


def normalise(value) -> str:
    return json.dumps(value, sort_keys=True, ensure_ascii=False)


def shrink_case(case_obj, task, cands, driver, timeout, disagrees):
    """Halve the longest list in the case while the disagreement survives."""
    if not isinstance(case_obj, dict):
        return case_obj
    best = case_obj
    for _ in range(14):
        key = None
        for k, v in best.items():
            if isinstance(v, list) and len(v) > 1:
                if key is None or len(v) > len(best[key]):
                    key = k
        if key is None:
            break
        improved = False
        for frac in (0.5, 0.75):
            trial = dict(best)
            cut = max(1, int(len(best[key]) * frac))
            trial[key] = best[key][:cut]
            for other in trial:
                if other != key and isinstance(trial[other], int) and trial[other] > len(trial[key]):
                    trial[other] = len(trial[key])
            if disagrees(normalise(trial)):
                best = trial
                improved = True
                break
        if not improved:
            break
    return best


def cmd_differential(args: argparse.Namespace) -> None:
    spec = load_spec(args.task)
    driver = args.driver
    if not os.path.exists(os.path.join(args.task, driver)):
        die("driver not found: %s (relative to the task directory). It must read one JSON case on "
            "stdin, call the candidate's entry point, and print the result as JSON on stdout." %
            os.path.join(args.task, driver))
    gen = os.path.join(args.task, args.generator)
    if not os.path.exists(gen):
        die("generator not found: %s. It must take <count> <seed> and print one JSON case per line." % gen)
    cands = [c for c in load_candidates(args.task)["items"] if c["status"] == "active"]
    if args.candidates:
        want = {c.strip() for c in args.candidates.split(",")}
        cands = [c for c in cands if c["id"] in want]
    if len(cands) < 2:
        die("differential testing needs at least two candidates; it works by making them disagree")
    proc = subprocess.run([sys.executable, args.generator, str(args.cases), str(args.seed)],
                          cwd=os.path.abspath(args.task), capture_output=True, text=True, timeout=300)
    if proc.returncode != 0:
        die("the generator failed: " + (proc.stderr or "").strip()[-600:])
    cases = [ln for ln in proc.stdout.splitlines() if ln.strip()]
    if not cases:
        die("the generator produced no cases")
    print("differential testing: %d case(s) x %d candidate(s): %s" % (
        len(cases), len(cands), ", ".join(c["id"] for c in cands)))

    def disagrees(case_text: str) -> bool:
        sigs = set()
        for c in cands:
            r = run_driver(args.task, c, driver, case_text, args.timeout)
            sigs.add(normalise(r["value"]) if r["ok"] else "ERROR:" + r["kind"])
        return len(sigs) > 1

    disagreements = []
    failures = []
    for i, case in enumerate(cases, 1):
        results = {}
        for c in cands:
            results[c["id"]] = run_driver(args.task, c, driver, case, args.timeout)
        groups = {}
        for cid, r in results.items():
            sig = normalise(r["value"]) if r["ok"] else "ERROR:%s:%s" % (r["kind"], r.get("detail", "")[:120])
            groups.setdefault(sig, []).append(cid)
        broken = [cid for cid, r in results.items() if not r["ok"]]
        if broken:
            failures.append({"case_index": i, "candidates": broken,
                             "detail": {cid: results[cid] for cid in broken}})
        if len(groups) > 1:
            entry = {"case_index": i, "case": json.loads(case), "groups": {}}
            for sig, ids in groups.items():
                entry["groups"][",".join(sorted(ids))] = (json.loads(sig) if not sig.startswith("ERROR:")
                                                          else sig)
            if args.shrink:
                small = shrink_case(json.loads(case), args.task, cands, driver, args.timeout, disagrees)
                entry["shrunk_case"] = small
                entry["shrunk"] = normalise(small) != normalise(json.loads(case))
            disagreements.append(entry)
            if len(disagreements) >= args.max_report:
                print("  stopping after %d disagreement(s)" % args.max_report)
                break

    out = {"task": spec["task"], "driver": driver, "generator": args.generator, "cases": len(cases),
           "seed": args.seed, "candidates": [c["id"] for c in cands],
           "candidate_hashes": {c["id"]: c["code_hash"] for c in cands},
           "spec_hash": spec.get("spec_hash"), "disagreements": disagreements,
           "driver_failures": failures, "run_at": now_iso()}
    save_json(task_path(args.task, "differential.json"), out)

    if failures:
        print("\n%d case(s) where a candidate crashed, timed out or printed non-JSON:" % len(failures))
        for f in failures[:5]:
            print("  case %d: %s" % (f["case_index"], ", ".join(f["candidates"])))
            for cid, det in list(f["detail"].items())[:2]:
                print("    %s %s: %s" % (cid, det["kind"], (det.get("detail") or "")[:200]))
    if not disagreements:
        print("\nAll candidates agreed on every case. That is evidence of consistency, not of "
              "correctness: they can agree and all be wrong. The designed test suite is what checks "
              "the contract; this checks that they implement the *same* contract.")
        print("wrote " + task_path(args.task, "differential.json"))
        return
    print("\n%d DISAGREEMENT(S). At least one candidate is wrong in each." % len(disagreements))
    for d in disagreements[:args.max_report]:
        print("\ncase %d%s:" % (d["case_index"], " (shrunk)" if d.get("shrunk") else ""))
        shown = d.get("shrunk_case", d["case"])
        print("  input: " + json.dumps(shown)[:400])
        for ids, value in d["groups"].items():
            print("  %-16s -> %s" % (ids, json.dumps(value)[:260]))
    print("\nResolve every disagreement before ranking anything. Decide which behaviour the contract "
          "requires: if the contract does not say, that is a gap in the spec and the requester "
          "decides, not the implementer who happened to guess.")
    print("wrote " + task_path(args.task, "differential.json"))
    sys.exit(1)


def cmd_report(args: argparse.Namespace) -> None:
    spec = load_spec(args.task)
    cands = [c for c in load_candidates(args.task)["items"] if c["status"] == "active"]
    results = load_json(task_path(args.task, "gates.json"))["results"]
    by = {(r["candidate"], r["gate"]): r for r in results}
    gates = spec["gates"]
    head = "%-6s " % "" + " ".join("%-6s" % g["id"] for g in gates) + "  verdict"
    print(head)
    print("%-6s " % "" + " ".join("%-6s" % ("MAND" if g.get("mandatory") else "adv") for g in gates))
    for c in cands:
        row = []
        blocked = []
        stale = False
        for g in gates:
            r = by.get((c["id"], g["id"]))
            if not r:
                row.append("-"); continue
            if r.get("code_hash") != c["code_hash"] or r.get("spec_hash") != spec.get("spec_hash"):
                stale = True
                row.append("stale")
                continue
            row.append({"pass": "ok", "fail": "FAIL", "error": "ERR", "not-run": "-", "skipped": "skip"}[r["result"]])
            if r["result"] in ("fail", "error") and g.get("mandatory"):
                blocked.append(g["id"])
        missing = [g["id"] for g in gates if g.get("mandatory") and (c["id"], g["id"]) not in by]
        verdict = ("BLOCKED by " + ",".join(blocked)) if blocked else (
            "incomplete: " + ",".join(missing) if missing else ("STALE" if stale else "eligible"))
        print("%-6s " % c["id"] + " ".join("%-6s" % x for x in row) + "  " + verdict)
    print("\nOnly candidates marked `eligible` may be ranked. Benchmarks on a candidate that fails a "
          "mandatory gate measure the speed of something that does not work.")


def main() -> None:
    ap = argparse.ArgumentParser(description="FORGE gate harness and differential tester")
    sub = ap.add_subparsers(dest="cmd")
    p = sub.add_parser("run"); p.add_argument("--task", required=True)
    p.add_argument("--candidate"); p.add_argument("--all", action="store_true"); p.add_argument("--gate")
    p.set_defaults(fn=cmd_run)
    p = sub.add_parser("record"); p.add_argument("--task", required=True); p.add_argument("--candidate", required=True)
    p.add_argument("--gate", required=True); p.add_argument("--result", required=True)
    p.add_argument("--evidence"); p.add_argument("--by"); p.set_defaults(fn=cmd_record)
    p = sub.add_parser("differential"); p.add_argument("--task", required=True)
    p.add_argument("--driver", default="tests/driver.py"); p.add_argument("--generator", default="tests/gen.py")
    p.add_argument("--cases", type=int, default=200); p.add_argument("--seed", type=int, default=1)
    p.add_argument("--candidates"); p.add_argument("--timeout", type=int, default=60)
    p.add_argument("--shrink", action="store_true"); p.add_argument("--max-report", type=int, default=5)
    p.set_defaults(fn=cmd_differential)
    p = sub.add_parser("report"); p.add_argument("--task", required=True); p.set_defaults(fn=cmd_report)
    args = ap.parse_args()
    if not getattr(args, "fn", None):
        ap.print_help(); sys.exit(1)
    if args.cmd == "run" and not args.all and not args.candidate:
        die("pass --candidate C-xx or --all")
    args.fn(args)


if __name__ == "__main__":
    main()
