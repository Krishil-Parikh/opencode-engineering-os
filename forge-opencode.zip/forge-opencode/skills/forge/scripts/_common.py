"""Shared helpers for the FORGE scripts. Standard library only (Python 3.8+)."""
from __future__ import annotations

import datetime as _dt
import hashlib
import json
import os
import re
import sys
from typing import Any, Dict, List, Optional

SCHEMA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "schemas")

GATE_KINDS = ["correctness", "regression", "security", "resource", "compatibility", "style", "custom"]
GATE_RESULTS = ["pass", "fail", "error", "skipped", "not-run"]
AXES = ["time", "memory", "throughput", "complexity", "dependencies", "size", "custom"]
STRATEGIES = ["baseline", "minimal", "performance", "maintainability", "alternative", "simplified", "hybrid"]
CHALLENGE_KINDS = [
    "correctness", "edge_case", "performance", "memory", "complexity", "maintainability",
    "security", "dependency", "concurrency", "api_design", "overengineering", "other",
]
CHALLENGE_STATUSES = ["open", "upheld", "rejected", "fixed", "accepted_tradeoff", "needs_measurement"]
VERDICTS = ["SELECTED", "SELECTED_WITH_TRADEOFF", "TIE_NEEDS_PRIORITIES", "NO_CANDIDATE_PASSES", "INSUFFICIENT_MEASUREMENT"]


def now_iso() -> str:
    return _dt.datetime.now(_dt.timezone.utc).replace(microsecond=0).isoformat()


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8", "replace")).hexdigest()


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def die(msg: str, code: int = 2) -> None:
    print("error: " + msg, file=sys.stderr)
    sys.exit(code)


def load_json(path: str, default: Any = None) -> Any:
    if not os.path.exists(path):
        if default is not None:
            return default
        die("file not found: " + path)
    with open(path, "r", encoding="utf-8") as fh:
        try:
            return json.load(fh)
        except json.JSONDecodeError as exc:
            die("invalid JSON in %s: %s" % (path, exc))


def save_json(path: str, data: Any) -> None:
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2, ensure_ascii=False)
        fh.write("\n")
    os.replace(tmp, path)


def next_id(prefix: str, existing: List[str], width: int = 3) -> str:
    top = 0
    pat = re.compile(r"^%s-(\d+)$" % re.escape(prefix))
    for ident in existing:
        m = pat.match(ident or "")
        if m:
            top = max(top, int(m.group(1)))
    return "%s-%0*d" % (prefix, width, top + 1)


def task_path(task: str, name: str) -> str:
    if not os.path.isdir(task):
        die("task directory not found: %s (create it with workspace.py new)" % task)
    return os.path.join(task, name)


def load_spec(task: str) -> Dict[str, Any]:
    return load_json(task_path(task, "spec.json"))


def load_candidates(task: str) -> Dict[str, Any]:
    return load_json(task_path(task, "candidates.json"), default={"task": os.path.basename(task), "items": []})


def get_candidate(task: str, cid: str) -> Dict[str, Any]:
    data = load_candidates(task)
    for c in data["items"]:
        if c["id"] == cid:
            return c
    die("unknown candidate %s (known: %s)" % (cid, ", ".join(c["id"] for c in data["items"]) or "none"))


def find_workspace(start: Optional[str] = None) -> Optional[str]:
    cur = os.path.abspath(start or os.getcwd())
    while True:
        cand = os.path.join(cur, "forge")
        if os.path.isdir(os.path.join(cand, "tasks")):
            return cand
        parent = os.path.dirname(cur)
        if parent == cur:
            return None
        cur = parent


# --------------------------------------------------------------------------
# Minimal JSON-Schema subset validator (same engine as the TRACE package).
# --------------------------------------------------------------------------
_TYPES = {
    "object": dict, "array": list, "string": str, "boolean": bool,
    "number": (int, float), "integer": int, "null": type(None),
}


def validate(instance: Any, schema: Dict[str, Any], path: str = "$") -> List[str]:
    errors: List[str] = []
    stype = schema.get("type")
    if stype:
        types = stype if isinstance(stype, list) else [stype]
        ok = False
        for t in types:
            py = _TYPES[t]
            if isinstance(instance, py) and not (t in ("number", "integer") and isinstance(instance, bool)):
                ok = True
        if not ok:
            return ["%s: expected %s, got %s" % (path, "/".join(types), type(instance).__name__)]
    if "enum" in schema and instance not in schema["enum"]:
        errors.append("%s: %r is not one of %s" % (path, instance, schema["enum"]))
    if isinstance(instance, str) and "pattern" in schema and not re.search(schema["pattern"], instance):
        errors.append("%s: %r does not match %s" % (path, instance, schema["pattern"]))
    if isinstance(instance, str) and "minLength" in schema and len(instance) < schema["minLength"]:
        errors.append("%s: string shorter than %d" % (path, schema["minLength"]))
    if isinstance(instance, (int, float)) and not isinstance(instance, bool):
        if "minimum" in schema and instance < schema["minimum"]:
            errors.append("%s: %s is below minimum %s" % (path, instance, schema["minimum"]))
        if "maximum" in schema and instance > schema["maximum"]:
            errors.append("%s: %s is above maximum %s" % (path, instance, schema["maximum"]))
    if isinstance(instance, dict):
        for key in schema.get("required", []):
            if key not in instance:
                errors.append("%s: missing required field '%s'" % (path, key))
        props = schema.get("properties", {})
        for key, value in instance.items():
            if key in props:
                errors.extend(validate(value, props[key], "%s.%s" % (path, key)))
            elif schema.get("additionalProperties") is False:
                errors.append("%s: unexpected field '%s'" % (path, key))
    if isinstance(instance, list):
        if "minItems" in schema and len(instance) < schema["minItems"]:
            errors.append("%s: needs at least %d item(s)" % (path, schema["minItems"]))
        if "items" in schema:
            for i, item in enumerate(instance):
                errors.extend(validate(item, schema["items"], "%s[%d]" % (path, i)))
    return errors


def load_schema(name: str) -> Dict[str, Any]:
    return load_json(os.path.join(SCHEMA_DIR, name))
