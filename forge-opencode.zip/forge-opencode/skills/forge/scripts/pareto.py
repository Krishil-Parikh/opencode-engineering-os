#!/usr/bin/env python3
"""FORGE selection: constraint-first gating, then a Pareto front, then a verdict.

Selection happens in a fixed order, and no step may be skipped:

1. **Gate.** A candidate that fails one mandatory gate is out, whatever its
   numbers. Speed is not a defence against being wrong.
2. **Front.** Among eligible candidates, compute the Pareto front on the axes
   the spec marked `--pareto`. A candidate is dominated only when another is
   better or tied on every axis and genuinely better (beyond the noise floor)
   on at least one.
3. **Verdict.** One candidate on the front is a selection. Several means a real
   trade-off: the tool reports it and, if the requester stated a priority order,
   applies it lexicographically. If they did not, the verdict is
   TIE_NEEDS_PRIORITIES and the question goes back to them.

Instead of pretending one candidate is universally better, FORGE names the
trade-off and selects according to the requester's priorities. It never invents
weights to manufacture a single winner.

Axis values come from the measurement and analysis records, never from an
argument: time, memory and throughput from `measurements.json`; complexity,
dependencies and size from `complexity.json`.

Usage:
    pareto.py eligible  --task T
    pareto.py front     --task T [--size N]
    pareto.py tradeoffs --task T [--size N]
    pareto.py select    --task T [--size N] [--note "..."]
    pareto.py show      --task T
"""
from __future__ import annotations

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import die, load_candidates, load_json, load_spec, now_iso, save_json, task_path  # noqa: E402

MEASURED = {"time": ("median_s", "s", "min"), "memory": ("rss_delta_kib", "KiB", "min"),
            "throughput": ("throughput_per_s", "1/s", "max")}
STATIC = {"complexity": ("total_cyclomatic", "", "min"), "dependencies": ("dependency_count", "", "min"),
          "size": ("sloc", "lines", "min")}


def eligibility(task: str) -> dict:
    spec = load_spec(task)
    cands = [c for c in load_candidates(task)["items"] if c["status"] == "active"]
    results = load_json(task_path(task, "gates.json"))["results"]
    by = {(r["candidate"], r["gate"]): r for r in results}
    mandatory = [g for g in spec["gates"] if g.get("mandatory")]
    out = {}
    for c in cands:
        failed, missing, stale = [], [], []
        for g in mandatory:
            r = by.get((c["id"], g["id"]))
            if not r:
                missing.append(g["id"]); continue
            if r.get("code_hash") != c["code_hash"] or r.get("spec_hash") != spec.get("spec_hash"):
                stale.append(g["id"]); continue
            if r["result"] in ("fail", "error", "not-run", "skipped"):
                failed.append(g["id"])
        out[c["id"]] = {"candidate": c["id"], "title": c["title"], "strategy": c["strategy"],
                        "eligible": not (failed or missing or stale),
                        "failed": failed, "missing": missing, "stale": stale}
    return out


def axis_values(task: str, size, axis_ids: list) -> dict:
    """{candidate: {axis: value}} from the measurement and analysis records."""
    meas = load_json(task_path(task, "measurements.json"), default={"runs": []})
    comp = load_json(task_path(task, "complexity.json"), default={"candidates": []})
    cands = {c["id"]: c for c in load_candidates(task)["items"]}
    runs = [r for r in meas["runs"] if r.get("ok")]
    sizes = sorted({r["size"] for r in runs})
    if size is None:
        size = sizes[-1] if sizes else None
    byc: dict = {}
    for r in runs:
        if r["size"] == size:
            byc.setdefault(r["candidate"], {})["_run"] = r
    for a in comp["candidates"]:
        byc.setdefault(a["candidate"], {})["_static"] = a
    values = {}
    for cid, blob in byc.items():
        row = {}
        run, static = blob.get("_run"), blob.get("_static")
        for axis in axis_ids:
            if axis in MEASURED and run:
                row[axis] = run.get(MEASURED[axis][0])
            elif axis in STATIC and static:
                if axis == "dependencies":
                    row[axis] = len(set(static.get("third_party_imports") or []) |
                                    set(cands.get(cid, {}).get("dependencies_added") or []))
                else:
                    row[axis] = static.get(STATIC[axis][0])
            else:
                row[axis] = None
        row["_run"] = run
        values[cid] = row
    return {"size": size, "values": values, "sizes": sizes}


def better(axis: str, a, b, floor_pct: float, run_a=None, run_b=None) -> str:
    """'a', 'b' or 'tie' on one axis, honouring the noise floor for timings."""
    if a is None or b is None:
        return "unmeasured"
    direction = (MEASURED.get(axis) or STATIC.get(axis) or (None, None, "min"))[2]
    lo = min(a, b)
    rel = (100.0 * abs(a - b) / lo) if lo else (0.0 if a == b else 100.0)
    if axis == "time" and run_a and run_b:
        overlap = not (run_a["p75_s"] < run_b["p25_s"] or run_b["p75_s"] < run_a["p25_s"])
        if overlap or rel < floor_pct:
            return "tie"
    elif axis in MEASURED:
        if rel < floor_pct:
            return "tie"
    else:
        if a == b:
            return "tie"
    if direction == "min":
        return "a" if a < b else "b"
    return "a" if a > b else "b"


def dominates(cid_a: str, cid_b: str, vals: dict, axes: list, floor: float) -> bool:
    strictly = False
    for axis in axes:
        res = better(axis, vals[cid_a].get(axis), vals[cid_b].get(axis), floor,
                     vals[cid_a].get("_run"), vals[cid_b].get("_run"))
        if res == "unmeasured":
            return False
        if res == "b":
            return False
        if res == "a":
            strictly = True
    return strictly


def compute_front(task: str, size):
    spec = load_spec(task)
    floor = spec["benchmark"].get("noise_floor_pct", 5.0)
    axes = [a["id"] for a in spec["axes"] if a.get("pareto")]
    if not axes:
        die("no axis is marked --pareto in the spec, so there is nothing to rank on. "
            "Mark at least one with `spec.py axis --task %s --id time --direction min --pareto`." % task)
    elig = eligibility(task)
    eligible = [cid for cid, e in elig.items() if e["eligible"]]
    av = axis_values(task, size, axes)
    vals = {cid: v for cid, v in av["values"].items() if cid in eligible}
    limits = {a["id"]: a.get("limit") for a in spec["axes"] if a.get("limit") is not None}
    over = {}
    for cid, row in list(vals.items()):
        for axis, limit in limits.items():
            v = row.get(axis)
            if v is None:
                continue
            direction = (MEASURED.get(axis) or STATIC.get(axis) or (None, None, "min"))[2]
            if (direction == "min" and v > limit) or (direction == "max" and v < limit):
                over.setdefault(cid, []).append("%s=%s violates the hard limit %s" % (axis, v, limit))
    for cid in over:
        vals.pop(cid, None)
    unmeasured = [cid for cid, row in vals.items() if any(row.get(a) is None for a in axes)]
    front = []
    for cid in vals:
        if cid in unmeasured:
            continue
        if not any(dominates(other, cid, vals, axes, floor) for other in vals if other != cid and other not in unmeasured):
            front.append(cid)
    return {"spec": spec, "axes": axes, "floor": floor, "eligibility": elig, "eligible": eligible,
            "size": av["size"], "sizes": av["sizes"], "values": vals, "front": sorted(front),
            "unmeasured": sorted(unmeasured), "limit_violations": over}


def cmd_eligible(args: argparse.Namespace) -> None:
    elig = eligibility(args.task)
    for cid, e in sorted(elig.items()):
        why = ""
        if e["failed"]:
            why = "fails mandatory " + ",".join(e["failed"])
        elif e["missing"]:
            why = "mandatory gate(s) not run: " + ",".join(e["missing"])
        elif e["stale"]:
            why = "stale result(s) for " + ",".join(e["stale"]) + " (code or spec changed since)"
        print("%-6s %-10s %-30s %s" % (cid, "ELIGIBLE" if e["eligible"] else "out", e["title"][:30], why))
    n = sum(1 for e in elig.values() if e["eligible"])
    print("\n%d of %d candidate(s) eligible for ranking." % (n, len(elig)))
    if n == 0:
        print("No candidate passes every mandatory gate. The honest verdict is NO_CANDIDATE_PASSES: "
              "report what each got wrong rather than ranking broken implementations.")


def print_table(res: dict) -> None:
    axes = res["axes"]
    print("n=%s   noise floor %.1f%%   pareto axes: %s\n" % (res["size"], res["floor"], ", ".join(axes)))
    print("%-6s " % "id" + " ".join("%-16s" % a for a in axes) + " front")
    for cid in sorted(res["values"]):
        row = res["values"][cid]
        cells = []
        for a in axes:
            v = row.get(a)
            cells.append("%-16s" % ("%.6g" % v if isinstance(v, float) else (str(v) if v is not None else "-")))
        print("%-6s " % cid + " ".join(cells) + (" YES" if cid in res["front"] else ""))
    for cid, reasons in res["limit_violations"].items():
        print("%-6s EXCLUDED: %s" % (cid, "; ".join(reasons)))
    for cid in res["unmeasured"]:
        print("%-6s not ranked: missing a measurement on a pareto axis" % cid)


def cmd_front(args: argparse.Namespace) -> None:
    res = compute_front(args.task, args.size)
    print_table(res)
    print("\nPareto front: %s" % (", ".join(res["front"]) or "empty"))
    dominated = [c for c in res["values"] if c not in res["front"] and c not in res["unmeasured"]]
    if dominated:
        print("Dominated: %s" % ", ".join(sorted(dominated)))
        for cid in sorted(dominated):
            by = [o for o in res["values"] if o != cid and dominates(o, cid, res["values"], res["axes"], res["floor"])]
            print("  %s is dominated by %s (better or tied on every axis, genuinely better on at least one)"
                  % (cid, ", ".join(sorted(by))))
    if len(res["front"]) > 1:
        print("\n%d candidates are on the front, so there is no universally better one. Run "
              "`pareto.py tradeoffs` to state the trade-off in the requester's terms." % len(res["front"]))


def cmd_tradeoffs(args: argparse.Namespace) -> None:
    res = compute_front(args.task, args.size)
    front = res["front"]
    if len(front) < 2:
        print("Only %d candidate on the front: there is no trade-off to articulate." % len(front))
        return
    titles = {c["id"]: c["title"] for c in load_candidates(args.task)["items"]}
    print("Trade-offs on the Pareto front at n=%s\n" % res["size"])
    rows = []
    for i, a in enumerate(front):
        for b in front[i + 1:]:
            wins_a, wins_b, ties = [], [], []
            for axis in res["axes"]:
                r = better(axis, res["values"][a].get(axis), res["values"][b].get(axis), res["floor"],
                           res["values"][a].get("_run"), res["values"][b].get("_run"))
                if r == "a":
                    wins_a.append(axis)
                elif r == "b":
                    wins_b.append(axis)
                else:
                    ties.append(axis)
            rows.append({"a": a, "b": b, "a_better_on": wins_a, "b_better_on": wins_b, "tied_on": ties,
                         "equivalent": not wins_a and not wins_b})
            print("  %s (%s)" % (a, titles.get(a, "")))
            print("  %s (%s)" % (b, titles.get(b, "")))
            for axis in res["axes"]:
                va, vb = res["values"][a].get(axis), res["values"][b].get(axis)
                verdict = ("%s better" % a if axis in wins_a else
                           "%s better" % b if axis in wins_b else "tie")
                print("      %-14s %-14s vs %-14s  -> %s" % (
                    axis, "%.6g" % va if isinstance(va, float) else va,
                    "%.6g" % vb if isinstance(vb, float) else vb, verdict))
            if not wins_a and not wins_b:
                print("      -> equivalent on every ranked axis. Both stay on the front; separate them "
                      "on something the ranking does not measure, or keep whichever is already there.")
            print()
    data = load_json(task_path(args.task, "decisions.json"))
    data["front"] = front
    data["tradeoffs"] = rows
    data["front_computed_at"] = now_iso()
    save_json(task_path(args.task, "decisions.json"), data)
    prio = res["spec"]["priorities"]
    if prio["source"] == "user" and prio["order"]:
        print("The requester's stated priority order is %s, so `pareto.py select` will apply it "
              "lexicographically." % " > ".join(prio["order"]))
    else:
        print("No priority order has been recorded. This is the question to put to the requester, in "
              "these terms:\n")
        for row in rows:
            if row["a_better_on"] and row["b_better_on"]:
                print("  %s is better on %s; %s is better on %s. Which matters more here?" % (
                    row["a"], " and ".join(row["a_better_on"]), row["b"], " and ".join(row["b_better_on"])))
        print("\nRecord the answer with:  spec.py priorities --task %s --source user --order <axes> "
              "--quote \"<their words>\"" % args.task)


def cmd_select(args: argparse.Namespace) -> None:
    res = compute_front(args.task, args.size)
    spec = res["spec"]
    prio = spec["priorities"]
    titles = {c["id"]: c["title"] for c in load_candidates(args.task)["items"]}
    front = res["front"]
    reasons = []
    verdict, selected = None, None
    if not res["eligible"]:
        verdict = "NO_CANDIDATE_PASSES"
        reasons.append("no candidate passes every mandatory gate")
    elif not res["values"]:
        verdict = "INSUFFICIENT_MEASUREMENT"
        reasons.append("eligible candidates exist but none has a usable measurement on the pareto axes")
    elif res["unmeasured"] and len(front) <= 1:
        verdict = "INSUFFICIENT_MEASUREMENT"
        reasons.append("candidate(s) %s are unmeasured on a pareto axis, so the front cannot be trusted"
                       % ", ".join(res["unmeasured"]))
    elif len(front) == 1:
        verdict, selected = "SELECTED", front[0]
        reasons.append("%s is on the front alone: nothing else is better or tied on every axis" % selected)
    else:
        if prio["source"] == "user" and prio["order"]:
            ranked = sorted(front, key=lambda cid: tuple(
                (res["values"][cid].get(ax) if res["values"][cid].get(ax) is not None else float("inf"))
                * (1 if (MEASURED.get(ax) or STATIC.get(ax) or (None, None, "min"))[2] == "min" else -1)
                for ax in prio["order"] if ax in res["axes"]))
            if not [ax for ax in prio["order"] if ax in res["axes"]]:
                verdict = "TIE_NEEDS_PRIORITIES"
                reasons.append("the stated priorities (%s) do not mention any pareto axis (%s)"
                               % (", ".join(prio["order"]), ", ".join(res["axes"])))
            else:
                verdict, selected = "SELECTED_WITH_TRADEOFF", ranked[0]
                reasons.append("%d candidates are on the front; the requester's priority order %s selects %s"
                               % (len(front), " > ".join(prio["order"]), selected))
                reasons.append("what this gives up: " + "; ".join(
                    "%s is better on %s" % (o, ", ".join(
                        ax for ax in res["axes"]
                        if better(ax, res["values"][o].get(ax), res["values"][selected].get(ax), res["floor"],
                                  res["values"][o].get("_run"), res["values"][selected].get("_run")) == "a"))
                    for o in front if o != selected) or "nothing measurable")
        else:
            verdict = "TIE_NEEDS_PRIORITIES"
            reasons.append("%s are all on the front and no priority order has been recorded"
                           % ", ".join(front))
            reasons.append("FORGE does not invent weights to produce a winner: ask which axis matters here")
    data = load_json(task_path(args.task, "decisions.json"))
    data["front"] = front
    data["final"] = {
        "verdict": verdict, "selected": selected,
        "selected_title": titles.get(selected or "", ""),
        "front": front, "axes": res["axes"], "size": res["size"],
        "noise_floor_pct": res["floor"],
        "priorities": prio, "reasons": reasons,
        "eligible": res["eligible"],
        "excluded_by_limits": res["limit_violations"],
        "unmeasured": res["unmeasured"],
        "values": {cid: {k: v for k, v in row.items() if not k.startswith("_")}
                   for cid, row in res["values"].items()},
        "note": args.note or "", "decided_at": now_iso(),
    }
    save_json(task_path(args.task, "decisions.json"), data)
    print("verdict: %s" % verdict)
    if selected:
        print("selected: %s  %s" % (selected, titles.get(selected, "")))
    for r in reasons:
        print("  - " + r)
    if verdict == "TIE_NEEDS_PRIORITIES":
        print("\nPut the question to the requester, then record their answer with `spec.py priorities` "
              "and run select again. Do not break the tie yourself.")
    if verdict == "NO_CANDIDATE_PASSES":
        print("\nReport what each candidate got wrong, with the failing gate and the evidence. A "
              "competition where nothing passes is a finding about the spec or the problem, not a "
              "reason to lower a gate.")


def cmd_show(args: argparse.Namespace) -> None:
    data = load_json(task_path(args.task, "decisions.json"))
    print(json.dumps(data, indent=2))


def main() -> None:
    ap = argparse.ArgumentParser(description="FORGE constraint-first selection and Pareto ranking")
    sub = ap.add_subparsers(dest="cmd")
    p = sub.add_parser("eligible"); p.add_argument("--task", required=True); p.set_defaults(fn=cmd_eligible)
    for name, fn in (("front", cmd_front), ("tradeoffs", cmd_tradeoffs)):
        p = sub.add_parser(name); p.add_argument("--task", required=True); p.add_argument("--size", type=int)
        p.set_defaults(fn=fn)
    p = sub.add_parser("select"); p.add_argument("--task", required=True); p.add_argument("--size", type=int)
    p.add_argument("--note"); p.set_defaults(fn=cmd_select)
    p = sub.add_parser("show"); p.add_argument("--task", required=True); p.set_defaults(fn=cmd_show)
    args = ap.parse_args()
    if not getattr(args, "fn", None):
        ap.print_help(); sys.exit(1)
    args.fn(args)


if __name__ == "__main__":
    main()
