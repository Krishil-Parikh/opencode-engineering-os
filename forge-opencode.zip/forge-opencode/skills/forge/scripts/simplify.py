#!/usr/bin/env python3
"""FORGE simplification pass.

The last phase before selection, and the one that most changes what gets
shipped. The leading candidate is handed to an agent whose only job is to remove
things, and whose output must survive the identical gates and benchmarks.

This is a controlled version of the simplicity-first principle: the simplified
version is not accepted because it looks cleaner, it is accepted because it
passed the same tests and did not regress beyond the noise floor on any axis the
spec ranks on.

A simplification that breaks a test is a bug. A simplification that loses
measurable performance the spec cares about is a trade-off, and goes back to the
requester rather than being quietly taken or quietly discarded.

Usage:
    simplify.py questions
    simplify.py attempt --task T --from C-01 --dir candidates/C-06 --entry solution.py \\
        --removed "the dispatch table: one entry, one caller" \\
        --removed "the retry wrapper: the spec names no retry behaviour" \\
        --answers 1,3,5
    simplify.py verify  --task T --id C-06 [--size N]
    simplify.py report  --task T
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import (die, get_candidate, load_json, load_spec, now_iso, save_json, task_path)  # noqa: E402

QUESTIONS = [
    "Can an abstraction be removed? A class with one implementation, a factory producing one type, "
    "an interface with one implementor, a layer that forwards and nothing more.",
    "Can a dependency be eliminated? What does it actually buy over the standard library here?",
    "Can several functions be collapsed? A chain of one-line helpers is harder to follow than the "
    "five lines they wrap.",
    "Can an existing library function do this? The standard library is tested by more people than "
    "this code ever will be.",
    "Are we duplicating functionality that already exists in this codebase? Search before writing.",
    "Can allocations be reduced? A copy per element, an intermediate list that is immediately "
    "consumed, a dict built to be read once.",
    "Are we issuing queries, requests or system calls we do not need, or doing per-item work that "
    "could be done per batch?",
    "Are we solving a problem that does not exist? A parameter with one value, a flag never set, a "
    "branch never taken, a case the spec explicitly excludes.",
]


def cmd_questions(args: argparse.Namespace) -> None:
    print("The simplification pass. Ask every question of the leading candidate, in order.\n")
    for i, q in enumerate(QUESTIONS, 1):
        print("%d. %s\n" % (i, q))
    print("Then produce a simplified candidate and verify it. The candidate must pass the identical "
          "mandatory gates and must not regress beyond the noise floor on any axis the spec ranks on.\n")
    print("Fewer lines are not the goal and are not evidence. If every answer is 'no', say so: that is "
          "a finding about a well-built candidate, not a failure of the pass. Removing something that "
          "was load-bearing is worse than leaving it.")


def cmd_attempt(args: argparse.Namespace) -> None:
    parent = get_candidate(args.task, args.src)
    if not args.removed:
        die("--removed is required, once per thing removed. A simplification pass that removed nothing "
            "should be recorded with `simplify.py attempt ... --removed \"nothing: every question "
            "answered no\"` and no new candidate directory.")
    cdir = args.dir if os.path.isabs(args.dir) else os.path.join(args.task, args.dir)
    if not os.path.isdir(cdir):
        die("candidate directory not found: %s (write the simplified version there first)" % cdir)
    cmd = [sys.executable, os.path.join(os.path.dirname(os.path.abspath(__file__)), "candidate.py"),
           "add", "--task", args.task, "--strategy", "simplified",
           "--title", args.title or ("simplified " + parent["id"]),
           "--dir", os.path.relpath(cdir, args.task), "--entry", args.entry,
           "--author", args.by or "simplification-agent",
           "--rationale", "Simplification of %s: %s" % (parent["id"], "; ".join(args.removed)),
           "--derived-from", parent["id"]]
    if args.id:
        cmd[cmd.index("add") + 1:cmd.index("add") + 1] = []
        cmd += ["--id", args.id]
    for t in args.tradeoff or []:
        cmd += ["--tradeoff", t]
    for d in args.dependency or []:
        cmd += ["--dependency", d]
    proc = subprocess.run(cmd, capture_output=True, text=True)
    if proc.returncode != 0:
        die("could not register the simplified candidate:\n" + (proc.stderr or proc.stdout))
    cid = proc.stdout.strip().splitlines()[0]
    answers = [int(a) for a in (args.answers or "").split(",") if a.strip().isdigit()]
    path = task_path(args.task, "simplification.json")
    data = load_json(path)
    data["attempts"].append({
        "candidate": cid, "derived_from": parent["id"], "by": args.by or "simplification-agent",
        "removed": args.removed, "questions_answered_yes": answers,
        "questions": {str(i): QUESTIONS[i - 1] for i in answers if 1 <= i <= len(QUESTIONS)},
        "verification": None, "attempted_at": now_iso(),
    })
    save_json(path, data)
    print(cid)
    print("Registered as a candidate derived from %s. It is not accepted until `simplify.py verify "
          "--task %s --id %s` passes: run its gates and its benchmarks first." % (parent["id"], args.task, cid))


def cmd_verify(args: argparse.Namespace) -> None:
    spec = load_spec(args.task)
    cand = get_candidate(args.task, args.id)
    if not cand.get("derived_from"):
        die("%s is not a simplification of anything (no derived_from). Verify it as an ordinary "
            "candidate with harness.py and bench.py." % args.id)
    parent_id = cand["derived_from"]
    floor = spec["benchmark"].get("noise_floor_pct", 5.0)
    gates = load_json(task_path(args.task, "gates.json"))["results"]
    meas = [r for r in load_json(task_path(args.task, "measurements.json"))["runs"] if r.get("ok")]
    sizes = sorted({r["size"] for r in meas})
    size = args.size or (sizes[-1] if sizes else None)

    problems, notes = [], []
    mandatory = [g for g in spec["gates"] if g.get("mandatory")]
    for g in mandatory:
        r = next((x for x in gates if x["candidate"] == cand["id"] and x["gate"] == g["id"]), None)
        if not r:
            problems.append("mandatory gate %s has not been run for %s" % (g["id"], cand["id"]))
        elif r.get("code_hash") != cand["code_hash"]:
            problems.append("gate %s was run against different code (hash %s, now %s)"
                            % (g["id"], (r.get("code_hash") or "?")[:8], cand["code_hash"][:8]))
        elif r["result"] != "pass":
            problems.append("mandatory gate %s is %s: the simplification broke behaviour the spec "
                            "requires, which makes it a bug and not a simplification" % (g["id"], r["result"]))

    axes = [a["id"] for a in spec["axes"] if a.get("pareto")]
    regressions, improvements = [], []
    for axis in axes:
        field = {"time": "median_s", "memory": "rss_delta_kib", "throughput": "throughput_per_s"}.get(axis)
        if not field:
            continue
        new = next((r for r in meas if r["candidate"] == cand["id"] and r["size"] == size), None)
        old = next((r for r in meas if r["candidate"] == parent_id and r["size"] == size), None)
        if not new or not old:
            problems.append("axis %s at n=%s is not measured for both %s and %s" % (axis, size, cand["id"], parent_id))
            continue
        nv, ov = new.get(field), old.get(field)
        if nv is None or ov is None:
            continue
        lo = min(nv, ov)
        rel = 100.0 * abs(nv - ov) / lo if lo else 0.0
        worse = nv > ov if axis != "throughput" else nv < ov
        overlap = (axis == "time" and not (new["p75_s"] < old["p25_s"] or old["p75_s"] < new["p25_s"]))
        if rel < floor or overlap:
            notes.append("%s: unchanged within noise (%.1f%% apart, floor %.1f%%)" % (axis, rel, floor))
        elif worse:
            regressions.append("%s: %.6g -> %.6g, %.1f%% worse" % (axis, ov, nv, rel))
        else:
            improvements.append("%s: %.6g -> %.6g, %.1f%% better" % (axis, ov, nv, rel))

    comp = load_json(task_path(args.task, "complexity.json"), default={"candidates": []})
    cnew = next((c for c in comp["candidates"] if c["candidate"] == cand["id"]), None)
    cold = next((c for c in comp["candidates"] if c["candidate"] == parent_id), None)
    static = {}
    if cnew and cold:
        for key in ("sloc", "total_cyclomatic", "max_nesting", "function_count", "smell_count"):
            static[key] = {"from": cold.get(key), "to": cnew.get(key)}
        static["dependencies"] = {"from": cold.get("third_party_imports"), "to": cnew.get("third_party_imports")}

    accepted = not problems and not regressions
    verdict = ("accepted" if accepted else
               ("rejected: broke a gate" if any("gate" in p for p in problems) else
                "rejected: regressed" if regressions else "incomplete"))
    attempt_path = task_path(args.task, "simplification.json")
    data = load_json(attempt_path)
    for a in data["attempts"]:
        if a["candidate"] == cand["id"]:
            a["verification"] = {"verdict": verdict, "size": size, "problems": problems,
                                 "regressions": regressions, "improvements": improvements,
                                 "within_noise": notes, "static": static,
                                 "noise_floor_pct": floor, "verified_at": now_iso()}
    save_json(attempt_path, data)

    print("%s (simplification of %s): %s\n" % (cand["id"], parent_id, verdict.upper()))
    for p in problems:
        print("  problem: " + p)
    for r in regressions:
        print("  REGRESSION: " + r)
    for i in improvements:
        print("  improvement: " + i)
    for n in notes:
        print("  " + n)
    if static:
        print("\n  static change:")
        for k, v in static.items():
            if v["from"] != v["to"]:
                print("    %-16s %s -> %s" % (k, v["from"], v["to"]))
    print()
    if accepted:
        print("Accepted: it passes the same mandatory gates and regresses on nothing beyond the noise "
              "floor. It now competes as an ordinary candidate, so re-run `pareto.py select`.")
    elif regressions and not problems:
        print("Rejected on measurement, not on taste. The simpler version costs real performance on an "
              "axis the spec ranks on. If the requester would rather have the simplicity, that is their "
              "trade-off to make: put the numbers to them and record the answer with `spec.py priorities`.")
    elif problems:
        print("Rejected: it is not a simplification, it is a change in behaviour. Removing something "
              "load-bearing is worse than leaving it in.")


def cmd_report(args: argparse.Namespace) -> None:
    data = load_json(task_path(args.task, "simplification.json"))
    if not data["attempts"]:
        print("No simplification pass recorded. The pass is mandatory before selection: the leading "
              "candidate has to be handed to an agent whose only job is to remove things.")
        return
    for a in data["attempts"]:
        v = a.get("verification") or {}
        print("%s  from %s  by %s  -> %s" % (a["candidate"], a["derived_from"], a["by"],
                                             (v.get("verdict") or "not yet verified").upper()))
        for r in a["removed"]:
            print("    removed: " + r)
        for key in ("regressions", "improvements", "problems"):
            for line in v.get(key, []):
                print("    %s: %s" % (key[:-1], line))
        if a.get("questions_answered_yes"):
            print("    questions answered yes: %s" % ", ".join(str(q) for q in a["questions_answered_yes"]))
        print()


def main() -> None:
    ap = argparse.ArgumentParser(description="FORGE simplification pass")
    sub = ap.add_subparsers(dest="cmd")
    p = sub.add_parser("questions"); p.set_defaults(fn=cmd_questions)
    p = sub.add_parser("attempt"); p.add_argument("--task", required=True)
    p.add_argument("--from", dest="src", required=True); p.add_argument("--dir", required=True)
    p.add_argument("--entry", required=True); p.add_argument("--id"); p.add_argument("--title")
    p.add_argument("--removed", action="append"); p.add_argument("--answers")
    p.add_argument("--tradeoff", action="append"); p.add_argument("--dependency", action="append")
    p.add_argument("--by"); p.set_defaults(fn=cmd_attempt)
    p = sub.add_parser("verify"); p.add_argument("--task", required=True); p.add_argument("--id", required=True)
    p.add_argument("--size", type=int); p.set_defaults(fn=cmd_verify)
    p = sub.add_parser("report"); p.add_argument("--task", required=True); p.set_defaults(fn=cmd_report)
    args = ap.parse_args()
    if not getattr(args, "fn", None):
        ap.print_help(); sys.exit(1)
    args.fn(args)


if __name__ == "__main__":
    main()
