#!/usr/bin/env python3
"""FORGE report generator.

Builds final_report.md from the task's records, so the report can only claim what
the records support. It refuses to name a winner when the verdict says there
isn't one, prints every number with its spread and its host, and shows the
losing candidates and the challenges against the winner rather than quietly
deleting them.

Usage:
    report_generator.py --task forge/tasks/TASK-001 [--notes notes.md] [--out final_report.md]
"""
from __future__ import annotations

import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import die, load_json, now_iso, task_path  # noqa: E402

VERDICT_TEXT = {
    "SELECTED": "Selected. One candidate is on the Pareto front alone: nothing else is better or "
                "tied on every ranked axis.",
    "SELECTED_WITH_TRADEOFF": "Selected with a trade-off. Several candidates are on the front, and "
                              "the requester's stated priority order picked this one. What it gives "
                              "up is listed below.",
    "TIE_NEEDS_PRIORITIES": "No selection. Several candidates are on the front and no priority order "
                            "has been recorded. The question below goes back to the requester; FORGE "
                            "does not invent weights to manufacture a winner.",
    "NO_CANDIDATE_PASSES": "No selection. No candidate passes every mandatory gate. What each one got "
                           "wrong is listed below.",
    "INSUFFICIENT_MEASUREMENT": "No selection. The measurements do not support a comparison. What is "
                                "missing is listed below.",
}


def fmt(v, unit=""):
    if v is None:
        return "-"
    if isinstance(v, float):
        return "%.6g%s" % (v, unit)
    return "%s%s" % (v, unit)


def build(task: str, notes: str) -> str:
    spec = load_json(task_path(task, "spec.json"))
    cands = load_json(task_path(task, "candidates.json"))["items"]
    gates = load_json(task_path(task, "gates.json"))["results"]
    meas = load_json(task_path(task, "measurements.json"), default={"runs": [], "environment": None})
    comp = load_json(task_path(task, "complexity.json"), default={"candidates": []})
    revs = load_json(task_path(task, "reviews.json"), default={"challenges": []})
    simp = load_json(task_path(task, "simplification.json"), default={"attempts": []})
    dec = load_json(task_path(task, "decisions.json"), default={})
    diff = load_json(task_path(task, "differential.json"), default=None)
    final = dec.get("final")
    if not final:
        die("no verdict recorded. Run `pareto.py select --task %s` first." % task)

    byid = {c["id"]: c for c in cands}
    static = {c["candidate"]: c for c in comp["candidates"]}
    runs = [r for r in meas["runs"] if r.get("ok")]
    sizes = sorted({r["size"] for r in runs})
    env = meas.get("environment") or {}
    verdict = final["verdict"]
    sel = final.get("selected")
    out = []
    w = out.append

    w("# %s: %s" % (spec["task"], spec["title"]))
    w("")
    w("_FORGE competitive implementation report. Generated %s from the task records._" % now_iso())
    w("")
    w("| | |")
    w("|---|---|")
    w("| Verdict | **%s** |" % verdict.replace("_", " ").title())
    if sel:
        w("| Selected | **%s** — %s |" % (sel, final.get("selected_title") or byid.get(sel, {}).get("title", "")))
    w("| Candidates | %d generated, %d eligible |" % (len(cands), len(final.get("eligible") or [])))
    w("| Ranked on | %s |" % ", ".join(final.get("axes") or []))
    w("| Measured at | n=%s |" % final.get("size"))
    w("| Noise floor | %.1f%% |" % (final.get("noise_floor_pct") or 0))
    w("| Spec hash | `%s` |" % (spec.get("spec_hash") or "-"))
    w("")

    # 1 -----------------------------------------------------------------
    w("## 1. Outcome")
    w("")
    w(VERDICT_TEXT.get(verdict, verdict))
    w("")
    for r in final.get("reasons", []):
        w("- " + r)
    w("")
    if sel:
        c = byid.get(sel, {})
        w("### The selected implementation")
        w("")
        w("`%s` — %s, strategy **%s**, by %s." % (os.path.join(c.get("dir", ""), c.get("entry", "")),
                                                  c.get("title", ""), c.get("strategy", ""), c.get("author", "")))
        w("")
        if c.get("rationale"):
            w("> " + c["rationale"])
            w("")
        if c.get("declared_tradeoffs"):
            w("Declared trade-offs:")
            w("")
            for t in c["declared_tradeoffs"]:
                w("- " + t)
            w("")
        deps = c.get("dependencies_added") or []
        w("Dependencies added: %s" % (", ".join(deps) if deps else "**none** (standard library only)"))
        w("")
    if verdict == "TIE_NEEDS_PRIORITIES":
        w("### The question for the requester")
        w("")
        for row in dec.get("tradeoffs", []):
            if row.get("a_better_on") and row.get("b_better_on"):
                w("- %s is better on %s; %s is better on %s. Which matters more here?" % (
                    row["a"], " and ".join(row["a_better_on"]), row["b"], " and ".join(row["b_better_on"])))
        w("")

    # 2 -----------------------------------------------------------------
    w("## 2. What was asked for")
    w("")
    if spec.get("statement"):
        w(spec["statement"])
        w("")
    iface = spec["interface"]
    w("**Interface.** `%s` in %s." % (iface.get("signature") or iface.get("entry_point"), iface.get("language")))
    w("")
    w("**Contract.**")
    w("")
    for clause in iface.get("contract", []):
        w("1. " + clause)
    w("")
    if spec["acceptance_criteria"]:
        w("**Acceptance criteria.**")
        w("")
        w("| | Criterion | Decided by | Mandatory |")
        w("|---|---|---|---|")
        for ac in spec["acceptance_criteria"]:
            w("| %s | %s | %s | %s |" % (ac["id"], ac["statement"].replace("|", "/"),
                                         ac["measured_by"].replace("|", "/"), "yes" if ac.get("mandatory") else "no"))
        w("")
    if spec["constraints"] or spec["non_goals"]:
        for x in spec["constraints"]:
            w("- Constraint: " + x)
        for x in spec["non_goals"]:
            w("- Non-goal: " + x)
        w("")
    b = spec["baseline"]
    head = {"yes": "Yes: `%s`." % (b.get("what") or "?"), "no": "No.",
            "unknown": "Not established."}.get(b.get("exists"), "-")
    w("**Did this already exist?** " + head)
    if b.get("why_not_enough"):
        w("")
        w("Why that is not the end of it: %s" % b["why_not_enough"])
    if b.get("searched"):
        w("")
        w("Searched: %s" % b["searched"])
    w("")

    # 3 -----------------------------------------------------------------
    w("## 3. The candidates")
    w("")
    w("| | Strategy | Implementation | Dependencies | Status |")
    w("|---|---|---|---|---|")
    for c in cands:
        w("| %s | %s | %s | %s | %s |" % (
            c["id"], c["strategy"], c["title"].replace("|", "/"),
            ", ".join(c.get("dependencies_added") or []) or "stdlib only",
            c["status"] + (": " + c.get("retired_reason", "") if c["status"] == "retired" else "")))
    w("")
    for c in cands:
        if c.get("derived_from"):
            w("- %s was derived from %s." % (c["id"], c["derived_from"]))
    w("")

    # 4 -----------------------------------------------------------------
    w("## 4. Mandatory gates")
    w("")
    glist = spec["gates"]
    by = {(r["candidate"], r["gate"]): r for r in gates}
    w("| | " + " | ".join("%s<br>%s" % (g["id"], g["kind"]) for g in glist) + " | Eligible |")
    w("|---|" + "---|" * (len(glist) + 1))
    for c in cands:
        cells = []
        for g in glist:
            r = by.get((c["id"], g["id"]))
            if not r:
                cells.append("-")
            elif r.get("code_hash") not in (None, c["code_hash"]):
                cells.append("stale")
            else:
                cells.append({"pass": "pass", "fail": "**FAIL**", "error": "**ERR**",
                              "not-run": "-", "skipped": "skip"}[r["result"]])
        cells.append("yes" if c["id"] in (final.get("eligible") or []) else "no")
        w("| %s | " % c["id"] + " | ".join(cells) + " |")
    w("")
    for g in glist:
        w("- **%s** (%s%s): %s" % (g["id"], g["kind"], ", mandatory" if g.get("mandatory") else "",
                                   g["description"]))
    w("")
    blocked = [c for c in cands if c["id"] not in (final.get("eligible") or []) and c["status"] == "active"]
    if blocked:
        w("A candidate that fails one mandatory gate is out of the competition, whatever its benchmark "
          "numbers: speed is not a defence against being wrong.")
        w("")
    if diff and (diff.get("disagreements") or diff.get("driver_failures")):
        w("### Differential testing")
        w("")
        w("%d case(s) were generated and run through every candidate. Four independent implementations "
          "of one spec are a free oracle: any disagreement is a bug in at least one of them, found "
          "without writing the expected answer down." % diff.get("cases", 0))
        w("")
        for d in diff.get("disagreements", [])[:4]:
            case = d.get("shrunk_case", d.get("case"))
            w("**Case %s**%s: `%s`" % (d.get("case_index"), " (shrunk)" if d.get("shrunk") else "",
                                       str(case)[:200]))
            w("")
            for ids, value in d.get("groups", {}).items():
                w("- `%s` returned `%s`" % (ids, str(value)[:160]))
            w("")

    # 5 -----------------------------------------------------------------
    w("## 5. Measurements")
    w("")
    if not runs:
        w("No measurements were taken.")
        w("")
    else:
        ranked = [c["id"] for c in cands if any(r["candidate"] == c["id"] for r in runs)]
        w("Median wall-clock seconds, with the interquartile spread as a percentage of the median. "
          "Each figure is the median of %d repetitions after %d warmup call(s), in a fresh process."
          % (runs[0].get("reps") or 0, runs[0].get("warmup") or 0))
        w("")
        w("| n | " + " | ".join(ranked) + " |")
        w("|---|" + "---|" * len(ranked))
        for size in sizes:
            cells = []
            for cid in ranked:
                r = next((x for x in runs if x["candidate"] == cid and x["size"] == size), None)
                cells.append("%.6g (±%.0f%%)" % (r["median_s"], r["rel_spread_pct"]) if r else "-")
            w("| %d | " % size + " | ".join(cells) + " |")
        w("")
        if any(r.get("rss_delta_kib") is not None for r in runs):
            w("Peak resident-memory growth during the timed calls, KiB:")
            w("")
            w("| n | " + " | ".join(ranked) + " |")
            w("|---|" + "---|" * len(ranked))
            for size in sizes:
                cells = []
                for cid in ranked:
                    r = next((x for x in runs if x["candidate"] == cid and x["size"] == size), None)
                    cells.append(str(r.get("rss_delta_kib")) if r and r.get("rss_delta_kib") is not None else "-")
                w("| %d | " % size + " | ".join(cells) + " |")
            w("")
            w("Memory is compared with resident-set growth rather than `tracemalloc`, which counts "
              "only Python-level allocations and is blind to anything a C extension allocates.")
            w("")
        scaling = (meas.get("scaling") or {}).get("fits") or {}
        if scaling:
            w("### Measured scaling")
            w("")
            w("| | Growth | Fit | Reading |")
            w("|---|---|---|---|")
            for cid, fit in scaling.items():
                if fit.get("exponent") is None:
                    continue
                w("| %s | n^%.3g | R²=%.3f | %s |" % (cid, fit["exponent"], fit.get("r_squared") or 0,
                                                      fit.get("shape", "")))
            w("")
            w("An exponent is a measurement over the sizes tested, not a proof of asymptotic class. It "
              "describes the range measured, and extrapolating an order of magnitude beyond the largest "
              "size is a guess.")
            w("")
        cal = meas.get("calibration")
        if cal:
            w("**Noise calibration.** The same code measured twice differed by %.1f%% in the median "
              "(within-round spread %.1f%%), so differences below the %.1f%% noise floor are reported "
              "as ties rather than results." % (cal["apparent_difference_pct"], cal["worst_rel_spread_pct"],
                                                final.get("noise_floor_pct") or 0))
            w("")
        if env:
            w("**Host.** %s, %s %s, %s CPU(s), load %s at capture. Measurements are comparable within "
              "this host and session only." % (env.get("platform"), env.get("implementation"),
                                               env.get("python"), env.get("cpu_count"), env.get("loadavg_1m")))
            w("")

    # 6 -----------------------------------------------------------------
    if static:
        w("## 6. Static analysis")
        w("")
        w("| | sloc | cyclomatic | worst fn | nesting | fns | deps | signals |")
        w("|---|---|---|---|---|---|---|---|")
        for c in cands:
            a = static.get(c["id"])
            if not a:
                continue
            w("| %s | %s | %s | %s | %s | %s | %s | %s |" % (
                c["id"], a.get("sloc"), a.get("total_cyclomatic"), a.get("max_cyclomatic") or "-",
                a.get("max_nesting"), a.get("function_count"),
                ", ".join(a.get("third_party_imports") or []) or "stdlib",
                a.get("smell_count") or 0))
        w("")
        w("Size is reported because the requester may care and because a jump in it is worth "
          "explaining. It is not a ranking axis: a shorter candidate that is slower or harder to follow "
          "should lose to a longer one.")
        w("")
        for c in cands:
            a = static.get(c["id"]) or {}
            smells = {k: v for k, v in (a.get("smells") or {}).items() if v and k != "notes"}
            if smells:
                w("- **%s**: %s" % (c["id"], "; ".join("%s (%d)" % (k, len(v)) for k, v in smells.items())))
        w("")

    # 7 -----------------------------------------------------------------
    w("## 7. Adversarial review")
    w("")
    chs = revs.get("challenges") or []
    if not chs:
        w("No challenges were recorded.")
        w("")
    else:
        w("| | Against | Kind | Severity | Status | Claim |")
        w("|---|---|---|---|---|---|")
        for ch in chs:
            w("| %s | %s | %s | %s | **%s** | %s |" % (
                ch["id"], ch["against"], ch["kind"], ch.get("severity", ""), ch["status"],
                ch["claim"].replace("|", "/")[:120]))
        w("")
        for ch in chs:
            if ch["status"] in ("upheld", "fixed", "accepted_tradeoff"):
                w("**%s** against %s — %s" % (ch["id"], ch["against"], ch["status"]))
                w("")
                w("- Claim: %s" % ch["claim"])
                w("- Basis: %s" % ch["basis"])
                if ch.get("resolution_evidence"):
                    w("- Resolved by %s: %s" % (ch.get("resolved_by", "?"), ch["resolution_evidence"]))
                if ch.get("accepted_by"):
                    w("- Trade-off accepted by: %s" % ch["accepted_by"])
                w("")
        unresolved = [ch for ch in chs if ch["status"] in ("open", "needs_measurement")]
        if unresolved:
            w("**Unresolved challenges.** Each is a measurement nobody ran or a question nobody answered:")
            w("")
            for ch in unresolved:
                w("- %s against %s: %s%s" % (ch["id"], ch["against"], ch["claim"],
                                             (" Proposed check: " + ch["proposed_test"]) if ch.get("proposed_test") else ""))
            w("")

    # 8 -----------------------------------------------------------------
    w("## 8. Simplification pass")
    w("")
    attempts = simp.get("attempts") or []
    if not attempts:
        w("No simplification pass was recorded. The pass is mandatory before selection: the leading "
          "candidate should be handed to an agent whose only job is to remove things.")
        w("")
    for a in attempts:
        v = a.get("verification") or {}
        w("**%s**, from %s, by %s — **%s**" % (a["candidate"], a["derived_from"], a["by"],
                                               (v.get("verdict") or "not verified").upper()))
        w("")
        for r in a["removed"]:
            w("- removed: " + r)
        for key, label in (("problems", "problem"), ("regressions", "regression"),
                           ("improvements", "improvement"), ("within_noise", "unchanged")):
            for line in v.get(key, []):
                w("- %s: %s" % (label, line))
        st = v.get("static") or {}
        for k, pair in st.items():
            if pair.get("from") != pair.get("to"):
                w("- %s: %s → %s" % (k, pair.get("from"), pair.get("to")))
        w("")
    if attempts:
        w("A simplification is accepted because it passed the same mandatory gates and regressed on "
          "nothing beyond the noise floor, not because it reads better.")
        w("")

    # 9 -----------------------------------------------------------------
    w("## 9. Selection")
    w("")
    vals = final.get("values") or {}
    axes = final.get("axes") or []
    if vals:
        w("| | " + " | ".join(axes) + " | On the front |")
        w("|---|" + "---|" * (len(axes) + 1))
        for cid in sorted(vals):
            row = vals[cid]
            w("| %s | " % cid + " | ".join(fmt(row.get(a)) for a in axes) + " | %s |" % (
                "**yes**" if cid in (final.get("front") or []) else "no"))
        w("")
    for cid, reasons in (final.get("excluded_by_limits") or {}).items():
        w("- %s excluded: %s" % (cid, "; ".join(reasons)))
    for cid in final.get("unmeasured") or []:
        w("- %s not ranked: missing a measurement on a ranked axis" % cid)
    w("")
    prio = final.get("priorities") or {}
    w("**Priorities.** %s" % (
        "Stated by the requester: %s.%s" % (" > ".join(prio.get("order") or []),
                                            ' "%s"' % prio["quote"] if prio.get("quote") else "")
        if prio.get("source") == "user" else
        "Not stated. Where the front has more than one member, the choice goes back to the requester."))
    w("")
    tradeoffs = dec.get("tradeoffs") or []
    if tradeoffs:
        w("**The trade-off, stated plainly.**")
        w("")
        for row in tradeoffs:
            if not row["a_better_on"] and not row["b_better_on"]:
                w("- %s and %s are **equivalent** on every ranked axis (%s), so both stay on the front. "
                  "Separate them on something the ranking does not measure, such as which one the next "
                  "person will find easier to read." % (
                      row["a"], row["b"], ", ".join(row["tied_on"]) or "none"))
            else:
                w("- %s is better on %s; %s is better on %s%s." % (
                    row["a"], ", ".join(row["a_better_on"]) or "nothing",
                    row["b"], ", ".join(row["b_better_on"]) or "nothing",
                    "; tied on " + ", ".join(row["tied_on"]) if row["tied_on"] else ""))
        w("")

    # 10 ----------------------------------------------------------------
    w("## 10. What was not chosen, and why")
    w("")
    for c in cands:
        if sel and c["id"] == sel:
            continue
        reasons = []
        if c["status"] == "retired":
            reasons.append(c.get("retired_reason", "retired"))
        bad = [r for r in gates if r["candidate"] == c["id"] and r.get("mandatory") and r["result"] in ("fail", "error")]
        if bad:
            reasons.append("fails mandatory gate(s) " + ", ".join(sorted({r["gate"] for r in bad})))
        up = [ch["id"] for ch in chs if ch["against"] == c["id"] and ch["status"] == "upheld"]
        if up:
            reasons.append("upheld challenge(s) " + ", ".join(up))
        if c["id"] in vals and c["id"] not in (final.get("front") or []):
            reasons.append("dominated on the ranked axes")
        w("- **%s** (%s): %s" % (c["id"], c["title"], "; ".join(reasons) or "on the front but not selected"))
    w("")
    w("The losing candidates are kept with their measurements. An approach that lost here lost against "
      "*this* spec, at *these* sizes, on *this* host.")
    w("")

    if notes.strip():
        w("## 11. Notes")
        w("")
        w(notes.strip())
        w("")

    w("---")
    w("_Never accept the first working implementation. Generate alternatives, challenge them, measure "
      "them, simplify them and verify the winner._")
    return "\n".join(out) + "\n"


def main() -> None:
    ap = argparse.ArgumentParser(description="Generate the FORGE final report")
    ap.add_argument("--task", required=True)
    ap.add_argument("--notes")
    ap.add_argument("--out")
    args = ap.parse_args()
    notes = ""
    if args.notes:
        if not os.path.exists(args.notes):
            die("notes file not found: " + args.notes)
        notes = open(args.notes, "r", encoding="utf-8").read()
    text = build(args.task, notes)
    out = args.out or task_path(args.task, "final_report.md")
    with open(out, "w", encoding="utf-8") as fh:
        fh.write(text)
    print("wrote " + out)


if __name__ == "__main__":
    main()
