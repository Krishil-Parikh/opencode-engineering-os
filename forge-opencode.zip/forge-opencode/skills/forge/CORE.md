# FORGE — Framework for Optimized and Reliable Generation Engineering

> Never accept the first working implementation. Generate alternatives, challenge them, measure them, simplify them and verify the winner.

A competitive, measurement-driven coding skill. It does not ask an agent *"is this implementation optimised?"* — it asks *"can you demonstrate that this implementation is better under predefined engineering constraints?"*

This directory is the portable core. The three platform packages (`claude-code/`, `opencode/`, `github-copilot/`) each contain a copy of it alongside a platform-specific entry point.

## What it does

| Capability | Where |
|---|---|
| A frozen, hashed contract that candidates are measured against | `core/requirements_protocol.md`, `scripts/spec.py` |
| Independent candidates under distinct strategy mandates | `core/candidate_generation.md`, `agents/*_implementer.md` |
| Correctness as a gate, not a score | `core/evaluation_gates.md`, `scripts/harness.py` |
| Differential testing: independent candidates as a free oracle | `core/correctness_and_tests.md`, `harness.py differential` |
| Benchmarks with calibration, medians, spreads and a noise floor | `core/measurement_protocol.md`, `scripts/bench.py` |
| Measured scaling exponents, not claimed complexity | `bench.py scaling` |
| Mechanical detection of overengineering | `core/antipatterns.md`, `scripts/complexity.py` |
| Adversarial review where every challenge needs a basis | `core/adversarial_review.md`, `scripts/review.py` |
| A verified simplification pass | `core/simplification_pass.md`, `scripts/simplify.py` |
| Pareto selection that refuses to invent weights | `core/pareto_selection.md`, `scripts/pareto.py` |
| A knowledge base of measured facts with their scope | `core/knowledge_base.md`, `scripts/kb.py` |

## Layout

```
core/        twelve protocol documents. forge_engine.md is the spine; read it first
agents/      one standalone brief per role. _candidate_submission.md is shared by the implementers
scripts/     eleven working Python 3.8+ tools, standard library only
schemas/     JSON Schema for the spec, candidates, measurements, challenges and decisions
reports/     the report template and what belongs in the notes
examples/    a runnable competition with five real candidates and two real bugs
```

## Scripts

All take `--help`. Run them from the repository root.

| Script | Purpose |
|---|---|
| `workspace.py` | Create and inspect the `forge/` workspace and tasks |
| `spec.py` | Build, check, freeze and hash the contract |
| `candidate.py` | Register candidates with code hashes, trade-offs and dependencies |
| `harness.py` | Run the gates; differential-test candidates against each other with shrinking |
| `bench.py` | Calibrate the host, measure, tabulate, compare with a noise floor, fit scaling |
| `complexity.py` | AST analysis and overengineering detectors |
| `review.py` | Adversarial challenges and their evidence-backed resolutions |
| `simplify.py` | The eight questions, and mechanical verification of the result |
| `pareto.py` | Eligibility, the Pareto front, trade-offs, the verdict |
| `report_generator.py` | `final_report.md` from the records |
| `kb.py` | Measured facts, patterns and rejected approaches, with scope and date |

## Try it

```bash
cd examples/top_n
bash walkthrough.sh
cat forge/tasks/TASK-001/final_report.md
```

Five candidates compete on "return the top 100 of 100,000 records by score". Two of them misread the same contract clause and the differential tester localises it to a three-record input. A third passes the entire test suite while violating a clause at the sizes that matter, and a reviewer finds it by reading the design. The measurement contradicts the obvious reading of the code. The verdict is a question rather than a winner, because the fastest candidate costs a dependency and nobody said whether that matters.

## The nine phases

1. **Requirements** — the contract, the acceptance criteria, the baseline question; freeze and hash
2. **Test design** — the suite from the spec, before any candidate exists
3. **Candidates** — independent implementations under distinct mandates
4. **Gates** — correctness first; differential testing; fix or retire
5. **Review** — attack what the tests did not, with a basis for every claim
6. **Measurement** — calibrate, then measure; medians, spreads, scaling
7. **Simplification** — remove things, then prove nothing broke
8. **Selection** — eligibility, then the Pareto front, then a verdict
9. **Report and learn** — the deliverable, and the facts worth keeping

Each phase has an exit gate in `core/forge_engine.md`.

## The design decisions that matter

**No single score.** Collapsing correctness, speed, memory, complexity and dependency cost into one weighted number means the answer comes from the weights, and the weights were invented. FORGE ranks on a Pareto front and, when more than one candidate survives, names the trade-off and asks.

**Correctness is a filter, not a criterion.** A candidate failing one mandatory gate is out, whatever its numbers. Speed is not a defence against being wrong.

**A difference below the noise is not a difference.** `bench.py calibrate` measures the same candidate twice to find out what the host's noise actually is, and comparisons below that are reported as ties.

**Fewer lines are not better.** Size is reported, never ranked on by default. In the example, the accepted simplification was two lines *longer*.

**The baseline competes.** If the standard library already does this, it is candidate C-01 and everything else must beat it on a measurement. Sometimes the right outcome is to write no new code at all.

**Three of the five verdicts are not a winner.** `TIE_NEEDS_PRIORITIES`, `NO_CANDIDATE_PASSES` and `INSUFFICIENT_MEASUREMENT` are first-class results.

## Where the ideas come from

| Source | Borrowed | What it actually is |
|---|---|---|
| Community "Karpathy guidelines" skill | Think before coding, simplicity first, surgical changes, goal-driven execution | A **community-authored** skill (originally Forrest Chang, later Multica AI) built from Karpathy's public criticisms of LLM code. **Not an official Karpathy release.** It shapes behaviour; it generates and benchmarks nothing. FORGE treats it as the floor |
| Karpathy's `autoresearch` | Experiment, measure, keep or discard | An agent edits `train.py`, trains under a fixed 5-minute budget, and the change is kept or reverted by **validation bits per byte**. One objective; general software has several, which is why FORGE uses a Pareto front |
| AgentCoder | Separate coding, testing and execution | Never let the coding agent be the only judge of its own code |
| SWE-Debate | Adversarial multi-agent reasoning | Dependency-graph traces, specialised perspectives, three debate rounds, then an MCTS patch agent. Agents challenge assumptions rather than voting |
| RankAgent | Generate and systematically rank alternatives | Ranking by generated tests rather than by asking a model which looks best |

## Honest limits

- The scripts measure time, memory, scaling, complexity and dependency count. **Maintainability and readability are not measured**; they are argued in review and used to separate candidates the measurements cannot.
- Automatic static analysis is precise for Python (AST) and heuristic for other languages, which it states in its output.
- `tracemalloc` cannot see C-extension allocations, so memory is compared with resident-set growth.
- A measured growth exponent describes the sizes tested; it is not a proof of asymptotic class.
- Measurements are comparable within one host and one session. The tooling records the host and refuses to compare across changed code or spec hashes.
- The benchmark drivers shipped here are Python. For another language, write the equivalent drivers; the JSON contract on stdin and stdout is all `bench.py` requires.
- The scoring defaults in `forge_config.json` are engineering defaults, not validated constants.

## Pairs with TRACE

FORGE makes sure the software being written is as simple and effective as possible. TRACE investigates why software failed. They share an evidence discipline, a workspace convention and the right to refuse an answer. Either works alone: see `core/integration_with_trace.md`.
