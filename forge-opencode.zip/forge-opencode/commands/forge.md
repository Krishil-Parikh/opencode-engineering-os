---
description: Run a FORGE competitive implementation
agent: build
---

Load the FORGE skill with `skill({ id: "forge" })` and run the competition for the work described
below. Follow the nine phases in order and respect every exit gate. Decide the tier first: if the
answer is already in the standard library, say so and stop rather than running a competition. Report
the verdict in your first two sentences, and never describe the outcome more confidently than the
verdict allows.

Work: $ARGUMENTS
