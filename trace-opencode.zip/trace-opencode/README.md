# TRACE for OpenCode

Tournament-based Root-cause Analysis and Code Examination: an autonomous, adversarial debugging and
root-cause analysis skill.

> Every error has an execution history. Every hypothesis needs evidence. Every conclusion must survive
> verification.

## Install

**Project** (shared with the team through the repository):

```bash
mkdir -p .opencode/skills .opencode/agents .opencode/commands
cp -r skills/trace    .opencode/skills/
cp    agents/*.md     .opencode/agents/
cp    commands/*.md   .opencode/commands/
```

**Global** (every project):

```bash
mkdir -p ~/.config/opencode/skills ~/.config/opencode/agents ~/.config/opencode/commands
cp -r skills/trace    ~/.config/opencode/skills/
cp    agents/*.md     ~/.config/opencode/agents/
cp    commands/*.md   ~/.config/opencode/commands/
```

The skill **id comes from the directory name**, so the directory must stay `trace`. The frontmatter
`name` is only a display label. OpenCode also discovers skills from `.claude/skills/` and
`.agents/skills/`, so a repository that already carries the Claude Code package needs no second copy.

## Use it

```
/trace asyncio.exceptions.CancelledError in services/payment.py, logs/app.log, started 09:47 today
```

Or let the model load it when a request matches the description, or load it yourself:

```
skill({ id: "trace" })
```

Writing `@trace` in a prompt loads it too. For the full experience, switch to the **trace** primary
agent (Tab, or `--agent trace`): it runs as `mode: primary`, which is what gives it the `task` tool for
delegating to the helper subagents.

## How it fits together on OpenCode

| Piece | Where it goes | What it is |
|---|---|---|
| `skills/trace/SKILL.md` | `.opencode/skills/trace/` | The orchestrator's operating manual, loaded on demand by the `skill` tool |
| supporting directories | beside `SKILL.md` | Read when a step calls for them. OpenCode reports the skill's base directory and a sample of its files on load; contents are not loaded automatically |
| `agents/trace.md` | `.opencode/agents/` | The orchestrator, `mode: primary`, so it can delegate |
| `agents/trace-*.md` | `.opencode/agents/` | 14 helpers, `mode: subagent`, invoked with the `task` tool |
| `commands/trace.md` | `.opencode/commands/` | `/trace <error>` |

## If delegation does not work

Custom agents in some OpenCode versions do not receive the `task` tool at all, and an agent's `skill`
or `task` permission can hide the tool rather than failing loudly. Two things help:

```jsonc
// opencode.json
{
  "$schema": "https://opencode.ai/config.json",
  "permissions": [
    { "action": "skill", "resource": "trace", "effect": "allow" }
  ]
}
```

and running as the **trace** primary agent rather than from a subagent. If delegation still is not
available, the investigation still works: the skill plays each role in sequence, writing each role's
output to disk before starting the next, and says so in the report — with the verdict capped at
PROBABLE unless a prediction was confirmed by an actual run.

## The 15 agents

`trace` is the primary orchestrator. The 14 helpers are subagents:

| Agent | Phase | Lens |
|---|---|---|
| `trace-log-analyst` | 1 Collect | Correlated timeline, gaps, log coverage |
| `trace-stacktrace-analyst` | 1 Collect | Frames, Layer 1, exception chains |
| `trace-codebase-mapper` | 1 Map | Static call graph, possible paths, hotspots |
| `trace-git-investigator` | 1 Collect | Regression or latent defect, read-only git |
| `trace-telemetry-investigator` | 1 Collect | Spans, metrics, live-process instruments |
| `trace-execution-path-analyst` | 2 Investigate | What actually ran, observed versus inferred |
| `trace-exception-propagation-analyst` | 2 Investigate | Caught, translated, swallowed, replaced |
| `trace-concurrency-analyst` | 2 Investigate | Interleaving, races, blocked loops, stalls |
| `trace-cancellation-analyst` | 2 Investigate | Who ended it, timeout hierarchy, cleanup |
| `trace-data-state-analyst` | 2 Investigate | Values, stored state, resources and leaks |
| `trace-dependency-analyst` | 2 Investigate | The peer's behaviour and our handling of it |
| `trace-adversarial-reviewer` | 3 Compete | Duel judge, scoring against the ledger |
| `trace-verifier` | 4 Verify | Tries to refute the champion |
| `trace-knowledge-curator` | 8, 10 | Findings, statuses, the persistent knowledge base |

## What you get

```
skills/trace/
├── SKILL.md                     the operating manual: the ten steps, the rules, the commands
├── CORE.md                      what the portable core contains, and its honest limits
├── core/                        ten protocol documents (read the one you need, not all of them)
│   ├── investigation_engine.md      the spine: roles, tiers, every step's exit gate
│   ├── hierarchical_localization.md file, then function, then statement — with and without probes
│   ├── evidence_protocol.md         FACT / INFERENCE / ASSUMPTION, absence, correlation, staleness
│   ├── execution_reconstruction.md  the three layers, timelines, gaps, async, cancellation, batches
│   ├── instrumentation_playbook.md  Mode B: what to add, where, snippets, production safety
│   ├── hypothesis_scoring.md        criterion anchors, ledger caps, thresholds, judging rules
│   ├── tournament_protocol.md       entry requirements, brackets, duels, cross-examination
│   ├── root_cause_verification.md   the verification checklist and the counterfactual
│   ├── knowledge_base.md            workspace layout, finding fields, status transitions
│   └── failure_signatures.md        15 failure families, their mechanisms, discriminating checks
├── agents/                      one standalone brief per role (+ _submission.md for the six lenses)
├── scripts/                     10 working Python 3.8+ tools, standard library only
├── schemas/                     JSON Schema for evidence, hypotheses, findings, tournament
├── reports/investigation_template.md
└── examples/sample_incident/    a runnable incident and a complete scripted investigation
```

## Try it before you trust it

```bash
cd skills/trace/examples/sample_incident
python3 run_incident.py          # reproduces the failure, writes logs/app.log
bash walkthrough.sh              # the full ten-step investigation, scripted
cat debugging/investigations/BUG-001/final_report.md
```

The walkthrough runs all ten steps against the sample incident: it registers three rival hypotheses,
eliminates one by a refuted prediction and one on evidence score, verifies the survivor with a
counterfactual experiment, and produces a CONFIRMED report plus three knowledge-base entries. It is the
best documentation of the order of operations.

## The ten steps

1. **Receive** — exception, message, timestamp, service, constraints
2. **Collect** — logs, traces, stack traces, source, git
3. **Map** — functions, dependencies, possible execution paths
4. **Hypothesize** — independent explanations
5. **Investigate** — specialised agents, one lens each, working alone
6. **Compete** — evidence-based adversarial duels
7. **Verify** — independent check of the strongest hypothesis
8. **Preserve** — every meaningful secondary finding
9. **Report** — actionable root-cause analysis
10. **Learn** — verified patterns to the persistent knowledge base

## The design decisions that matter

**Evidence-driven, not debate-driven.** A debate selects the most convincing explanation; an
investigation selects the explanation best supported by reality. `score.py` caps every criterion score
at what the evidence ledger contains, so persuasion cannot buy a verdict. One refuted prediction
eliminates a hypothesis outright, whatever its total would have been.

**Three layers, kept separate.** Where the failure surfaced, what triggered it this time, and what
standing property made it possible. A report that stops at the first is not a root-cause analysis.

**Start with 6 to 8 agents, not 60.** Expand only when a specific open question needs a lens nobody has
used. No skill can guarantee a number of simultaneous agents in any case: spawning, concurrency limits
and tool permissions belong to the host platform.

**Insufficient evidence is a first-class verdict.** Without it, the format itself pressures an agent
into inventing a root cause because a winner has to be produced.

**Losers' findings are retained.** The database theory that lost may have found a real connection leak.
It goes to the knowledge base with an honest status, and re-observation never upgrades that status.

## Honest limits

- Source analysis reconstructs *possible* call paths. It cannot recover runtime history that was never
  logged or traced. The ledger's grades keep that visible in every sentence.
- A static call graph over-approximates and is blind to dynamic dispatch, callbacks and framework wiring.
- Automatic probe insertion is Python-only. Other languages get snippets to place by hand; the analysis
  and removal tooling works for all of them.
- The scoring weights and thresholds are engineering defaults in `debugging/trace_config.json`, not
  validated constants.
- Probes edit source files. They belong in a reproduction environment or a scratch copy, never a live
  checkout. `probe.py status` must report zero probed files before you report.
- The scripts need Python 3.8 or later and nothing else. No network access, no third-party packages.

## Workspace it creates

```
debugging/
├── investigations/BUG-001/   context, error_context, brief, timeline, evidence, hypotheses,
│                             tournament, findings, duels/, verification, fix, final_report
├── knowledge_base/           findings.json + rendered markdown by category and status
├── trace_config.json         scoring weights and thresholds for this codebase
└── index.md                  every investigation with its confidence, and knowledge-base counts
```

Commit `debugging/` for shared debugging memory, but check excerpts for secrets and personal data
first, and consider `.gitignore`-ing `investigations/*/logs/`.
