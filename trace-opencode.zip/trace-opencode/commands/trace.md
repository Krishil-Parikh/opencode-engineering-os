---
description: Run a TRACE root-cause investigation on a failure
agent: build
---

Load the TRACE skill with `skill({ id: "trace" })` and run the investigation on the failure described
below. Follow the ten steps in order and respect every exit gate. Report the confidence level in your
first two sentences.

Failure: $ARGUMENTS
