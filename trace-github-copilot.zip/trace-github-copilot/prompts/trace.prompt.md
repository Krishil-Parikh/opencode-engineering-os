---
mode: agent
description: Run a TRACE root-cause investigation on a failure
---

Switch to the **trace** agent and run a TRACE root-cause investigation on the failure below.

Follow the ten steps in `.github/skills/trace/SKILL.md` in order and respect every exit gate. Use the
specialised subagents for the collect, investigate, compete and verify phases. Report the confidence
level in your first two sentences, and never describe the root cause more confidently than the verdict
allows.

Failure: ${input:failure:Paste the error, stack trace, or incident description}
