# TRACE for GitHub Copilot

Tournament-based Root-cause Analysis and Code Examination: an autonomous, adversarial debugging and
root-cause analysis skill.

> Every error has an execution history. Every hypothesis needs evidence. Every conclusion must survive
> verification.

## Install

**Workspace** (shared with the team through the repository):

```bash
mkdir -p .github/skills .github/agents .github/prompts
cp -r skills/trace    .github/skills/
cp    agents/*.md     .github/agents/
cp    prompts/*.md    .github/prompts/      # VS Code only
```

**Personal** (every repository you open):

```bash
mkdir -p ~/.copilot/skills ~/.copilot/agents
cp -r skills/trace  ~/.copilot/skills/
cp    agents/*.md   ~/.copilot/agents/
```

Copilot also discovers skills from `.claude/skills/` and `.agents/skills/`, so a repository that
already carries the Claude Code package needs no second copy of the skill — only the agents differ.

## Use it

- **VS Code**: pick **trace** in the agent dropdown, or run `/trace` and paste the error.
- **Copilot CLI**: `/agent trace`, then describe the failure.
- **Any surface**: just describe the failure. The skill's description is written to trigger on "root
  cause", "why did this fail", "investigate this incident", "RCA", "postmortem", "it only fails in
  production" and "intermittent".

## How it fits together on Copilot

| Piece | Where it goes | What it is |
|---|---|---|
| `skills/trace/SKILL.md` | `.github/skills/trace/` | The operating manual, activated automatically when a request matches |
| supporting directories | beside `SKILL.md` | Read when a step calls for them |
| `agents/trace.agent.md` | `.github/agents/` | The orchestrator. `user-invocable: true`, so it appears in the picker |
| `agents/trace-*.agent.md` | `.github/agents/` | 14 helpers. `user-invocable: false`, so they stay out of the picker and serve only as subagents |
| `prompts/trace.prompt.md` | `.github/prompts/` | `/trace` in VS Code |

## Surface differences worth knowing

| Customization | Copilot CLI | VS Code | Coding agent |
|---|---|---|---|
| Agent skills (`.github/skills/*/SKILL.md`) | yes | yes | yes |
| Custom agents (`.github/agents/*.agent.md`) | yes | yes | yes |
| Prompt files (`.github/prompts/*.prompt.md`) | no | yes | no |

A tool named in an agent's `tools` list that the host does not provide is ignored rather than failing,
so the same agent files work on every surface. **Subagent support varies by surface and setting**, so
the skill never assumes delegation worked: if a helper cannot be invoked it plays each role itself, one
at a time, writing each role's output to disk before starting the next, and says so in the report —
with the verdict capped at PROBABLE unless a prediction was confirmed by an actual run.

The scripts need a terminal (`runCommands` / `runInTerminal`). Without one, the skill keeps the same
files by hand in the same formats, computes the scores from the rubric showing the arithmetic, applies
the caps strictly, and records in the report that the ledger was maintained manually.

## The 15 agents

`trace` is the user-invocable orchestrator. The 14 helpers are subagent-only:

| Agent | Phase | Lens |
|---|---|---|
| `trace-log-analyst` | 1 Collect | Correlated timeline, gaps, log coverage |
| `trace-stacktrace-analyst` | 1 Collect | Frames, Layer 1, exception chains |
| `trace-codebase-mapper` | 1 Map | Static call graph, possible paths, hotspots |
| `trace-git-investigator` | 1 Collect | Regression or latent defect, read-only git |
| `trace-telemetry-investigator` | 1 Collect | Spans, metrics, live-process instruments |
| `trace-execution-path-analyst` | 2 Investigate | What actually ran, observed versus inferred |
| `trace-exception-propagation-analyst` | 2 Investigate | Caught, translated, swallowed, replaced |
| `trace-concurrency-analyst` | 2 Investigate | Interleaving, races, blocked loops, stalls |
| `trace-cancellation-analyst` | 2 Investigate | Who ended it, timeout hierarchy, cleanup |
| `trace-data-state-analyst` | 2 Investigate | Values, stored state, resources and leaks |
| `trace-dependency-analyst` | 2 Investigate | The peer's behaviour and our handling of it |
| `trace-adversarial-reviewer` | 3 Compete | Duel judge, scoring against the ledger |
| `trace-verifier` | 4 Verify | Tries to refute the champion |
| `trace-knowledge-curator` | 8, 10 | Findings, statuses, the persistent knowledge base |

## What you get

```
skills/trace/
├── SKILL.md                     the operating manual: the ten steps, the rules, the commands
├── CORE.md                      what the portable core contains, and its honest limits
├── core/                        ten protocol documents (read the one you need, not all of them)
│   ├── investigation_engine.md      the spine: roles, tiers, every step's exit gate
│   ├── hierarchical_localization.md file, then function, then statement — with and without probes
│   ├── evidence_protocol.md         FACT / INFERENCE / ASSUMPTION, absence, correlation, staleness
│   ├── execution_reconstruction.md  the three layers, timelines, gaps, async, cancellation, batches
│   ├── instrumentation_playbook.md  Mode B: what to add, where, snippets, production safety
│   ├── hypothesis_scoring.md        criterion anchors, ledger caps, thresholds, judging rules
│   ├── tournament_protocol.md       entry requirements, brackets, duels, cross-examination
│   ├── root_cause_verification.md   the verification checklist and the counterfactual
│   ├── knowledge_base.md            workspace layout, finding fields, status transitions
│   └── failure_signatures.md        15 failure families, their mechanisms, discriminating checks
├── agents/                      one standalone brief per role (+ _submission.md for the six lenses)
├── scripts/                     10 working Python 3.8+ tools, standard library only
├── schemas/                     JSON Schema for evidence, hypotheses, findings, tournament
├── reports/investigation_template.md
└── examples/sample_incident/    a runnable incident and a complete scripted investigation
```

## Try it before you trust it

```bash
cd skills/trace/examples/sample_incident
python3 run_incident.py          # reproduces the failure, writes logs/app.log
bash walkthrough.sh              # the full ten-step investigation, scripted
cat debugging/investigations/BUG-001/final_report.md
```

The walkthrough runs all ten steps against the sample incident: it registers three rival hypotheses,
eliminates one by a refuted prediction and one on evidence score, verifies the survivor with a
counterfactual experiment, and produces a CONFIRMED report plus three knowledge-base entries. It is the
best documentation of the order of operations.

## The ten steps

1. **Receive** — exception, message, timestamp, service, constraints
2. **Collect** — logs, traces, stack traces, source, git
3. **Map** — functions, dependencies, possible execution paths
4. **Hypothesize** — independent explanations
5. **Investigate** — specialised agents, one lens each, working alone
6. **Compete** — evidence-based adversarial duels
7. **Verify** — independent check of the strongest hypothesis
8. **Preserve** — every meaningful secondary finding
9. **Report** — actionable root-cause analysis
10. **Learn** — verified patterns to the persistent knowledge base

## The design decisions that matter

**Evidence-driven, not debate-driven.** A debate selects the most convincing explanation; an
investigation selects the explanation best supported by reality. `score.py` caps every criterion score
at what the evidence ledger contains, so persuasion cannot buy a verdict. One refuted prediction
eliminates a hypothesis outright, whatever its total would have been.

**Three layers, kept separate.** Where the failure surfaced, what triggered it this time, and what
standing property made it possible. A report that stops at the first is not a root-cause analysis.

**Start with 6 to 8 agents, not 60.** Expand only when a specific open question needs a lens nobody has
used. No skill can guarantee a number of simultaneous agents in any case: spawning, concurrency limits
and tool permissions belong to the host platform.

**Insufficient evidence is a first-class verdict.** Without it, the format itself pressures an agent
into inventing a root cause because a winner has to be produced.

**Losers' findings are retained.** The database theory that lost may have found a real connection leak.
It goes to the knowledge base with an honest status, and re-observation never upgrades that status.

## Honest limits

- Source analysis reconstructs *possible* call paths. It cannot recover runtime history that was never
  logged or traced. The ledger's grades keep that visible in every sentence.
- A static call graph over-approximates and is blind to dynamic dispatch, callbacks and framework wiring.
- Automatic probe insertion is Python-only. Other languages get snippets to place by hand; the analysis
  and removal tooling works for all of them.
- The scoring weights and thresholds are engineering defaults in `debugging/trace_config.json`, not
  validated constants.
- Probes edit source files. They belong in a reproduction environment or a scratch copy, never a live
  checkout. `probe.py status` must report zero probed files before you report.
- The scripts need Python 3.8 or later and nothing else. No network access, no third-party packages.

## Workspace it creates

```
debugging/
├── investigations/BUG-001/   context, error_context, brief, timeline, evidence, hypotheses,
│                             tournament, findings, duels/, verification, fix, final_report
├── knowledge_base/           findings.json + rendered markdown by category and status
├── trace_config.json         scoring weights and thresholds for this codebase
└── index.md                  every investigation with its confidence, and knowledge-base counts
```

Commit `debugging/` for shared debugging memory, but check excerpts for secrets and personal data
first, and consider `.gitignore`-ing `investigations/*/logs/`.
