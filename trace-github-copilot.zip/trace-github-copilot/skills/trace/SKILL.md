---
name: trace
description: >-
  Autonomous adversarial root-cause analysis for a failure that needs a root cause rather than a patch.
  Runs an evidence-driven ten-step investigation: hierarchical fault localization (file, then function,
  then statement), retrospective execution reconstruction for failures that cannot be re-run, specialised
  investigator agents, adversarial hypothesis duels scored against an evidence ledger, independent
  verification, and a persistent knowledge base. Use for exceptions in long-running processes, background
  workers and scheduled jobs; CancelledError, timeouts, hangs, races, leaks, intermittent and
  environment-dependent failures; and any incident needing a written analysis someone else can check.
  Triggers on "root cause", "why did this fail", "debug this exception", "investigate this incident",
  "RCA", "postmortem", "this only fails in production", "it fails intermittently".
license: MIT
---

# TRACE — Tournament-based Root-cause Analysis and Code Examination

> Every error has an execution history. Every hypothesis needs evidence. Every conclusion must survive verification.

An autonomous, adversarial debugging and root-cause analysis system. You are its orchestrator.

**This is not an agent debate system. It is an evidence-driven investigation system that happens to use agent debates.** A debate selects the most convincing explanation. An investigation selects the explanation best supported by reality. Every rule below serves the second.

## When to use this

Use TRACE when a failure needs a *root cause*, not a patch:

- An exception in a long-running process, a scheduled job or a background worker, where the failed execution cannot be re-run.
- A failure that surfaced far from anything that looks wrong: `CancelledError`, a timeout, a `None` where an object should be.
- An intermittent, load-dependent or environment-dependent failure.
- A failure where two or more explanations are plausible and picking wrong is expensive.
- A production incident that needs a written analysis someone else can check.

Do **not** use it for: a syntax error, a failing test with an obvious diff, a one-line fix the stack trace already identifies, or a feature request. The machinery costs more than those are worth. If the stack trace plus one file read gives a complete three-layer answer, write that answer and stop.

## The three layers, which the whole method exists to separate

| Layer | Name | Question | Example |
|---|---|---|---|
| 1 | Failure location | Where did the exception surface? | `services/payment.py:142` |
| 2 | Failure trigger | Which event or condition caused the failure **this time**? | "The request budget expired while the payment call was in flight" |
| 3 | Root cause | What defect, wrong assumption or external condition made the failure **possible**? | "The request budget is shorter than the payment client's retry policy, and cancellation is unhandled on that path" |

Checks you must apply to your own output:

- If your "root cause" is a `file:line`, you have written Layer 1.
- If your "root cause" is something that happened, you have written Layer 2.
- If fixing your "root cause" would not stop the same trigger causing the same failure, you do not have Layer 3.

**The actual source can be several functions, several tasks or several services away from where the exception surfaced.** A report that stops at Layer 1 is not a root-cause analysis.

## The worked example you must understand before starting

```
09:47:01 process_order started
09:47:02 fetch_customer completed
09:47:03 check_inventory completed
09:47:04 process_payment started
09:47:05 CancelledError
```

A basic debugging agent concludes `process_payment()` caused the error. **That is not established.** `CancelledError` is not raised by the code that fails; it is injected into a task by something else and surfaces wherever that task happened to be waiting. All of these fit the five lines equally well: the payment service was too slow and a timeout fired; the parent task was cancelled; the HTTP client disconnected; a cancellation token propagated from upstream; the application was shutting down.

What the lines establish: the first three steps ran, `process_payment` started at 09:47:04, a `CancelledError` was logged at 09:47:05, and there is no completion line. What they do not establish: who cancelled, why, and whether `process_payment` did anything wrong.

`examples/sample_incident/` is this scenario, runnable, with the answer and a full scripted investigation.

## Mode A and Mode B

The hardest real constraint: the backend started at 9:00, a scheduled process ran at 9:15, a worker processed 40,000 records, a function failed at 9:47, and the process is still running. You cannot restart it and expect the same execution again.

**Mode A, retrospective.** Reconstruct what happened from what it left behind: traces and spans, stack traces, application and worker and scheduler and database logs, existing debug statements, correlation ids, metrics, git history, source code and static call graphs. The first six tell you what *did* happen. The last two tell you what *could* have. Source-code analysis cannot recover runtime history that was never logged or traced, and the ledger's grades keep that distinction visible in every sentence.

**Mode B, instrumented.** When Mode A cannot discriminate: B1 reproduce and probe in a safe environment; B2 design instrumentation for the next occurrence, deploy it through the normal release path, and close this investigation as PROVISIONAL or INSUFFICIENT with the plan as its deliverable. Mode B never means restarting production to see whether it happens again.

## Scaling: do not spend 60 agents on every bug

| Tier | When | What runs |
|---|---|---|
| **T1** | Trace and logs point at one place, the path is visible end to end, one explanation accounts for everything | Steps 1 to 4 alone, one hypothesis, predictions checked, then verification. Steps 8 to 10 as usual |
| **T2** (default for anything non-trivial) | The failure surfaced far from any obvious cause; async, concurrency, cancellation, timeouts, retries, shared state or a dependency are involved; two or more explanations are plausible | 2 to 3 collectors, then 3 to 4 investigators from the routing table, duels only between genuine rivals, verifier |
| **T3** | T2 ended narrow or insufficient; high severity; recurring; spans services | All collectors, all six lenses, full tournament, verifier, second verifier pass if the first found gaps |

Start with 6 to 8 specialised agents at most, and expand only when a specific open question needs a lens nobody has used. Give each added agent one written question. If you are adding agents without a question for each, the bottleneck is evidence, not analysis: go to Mode B.

**Routing table.**

| Signal in the evidence | Dispatch |
|---|---|
| `CancelledError`, `context canceled`, `AbortError`, a timeout value on the path, shutdown messages near the failure | cancellation, concurrency |
| Intermittent, order-dependent, load-dependent, vanishes under a debugger | concurrency, data-state |
| Wrong value, `None`/`null`/`undefined`, constraint violation, fails on specific records only | data-state, execution-path |
| An exception translated, wrapped, logged-and-swallowed, or a short/truncated stack | exception-propagation |
| Connection reset, DNS, TLS, 5xx from a peer, pool exhaustion, rate limit, a queue or database in the trace | dependency, cancellation |
| Started at a point in time with no traffic change | git-history first, then whatever the diff points to |
| The same path succeeds for other inputs at the same time | data-state, execution-path |
| Nothing above, or the logs stop with no error at all | execution-path, exception-propagation, and plan Mode B |

The execution-path lens is always included from T2 upward: every other lens argues from a path and someone must establish it.

## The ten steps

Mandatory sequence. Each has an exit gate in `core/investigation_engine.md`; do not pass a gate you cannot meet, carry the gap forward instead, where it will cap the final confidence. Run commands from the repository root.

### 1. Receive

```
python3 <SKILL_DIR>/scripts/workspace.py new --title "<short title>" --error "<exception>" --when "<first observed>" --service "<service>" --mode A
```

Prints the investigation directory; call it `INV`. Then: fill `INV/error_context.md` with the error **pasted verbatim**; establish the constraints by asking the user if they were not given (may the process be restarted, may instrumentation be added, can it be reproduced elsewhere, is there sensitive data in the logs, what is the budget) and record them with `workspace.py set`; search the knowledge base with `kb.py search --text "<exception type>"`; choose the tier and write down why.

### 2. Collect

```
python3 <SKILL_DIR>/scripts/log_parser.py <logs> --around "<time>" --window 120 --format text
python3 <SKILL_DIR>/scripts/log_parser.py <logs> --corr <id> --out INV/timeline.json
python3 <SKILL_DIR>/scripts/stacktrace_parser.py <file with trace> --root . --format text
python3 <SKILL_DIR>/scripts/git_suspects.py --root . recent --files <path files> --before "<failure time>"
```

Find the correlation key **first** (the parser's `summary.ids` lists every id-shaped key it saw). A timeline of one request among forty thousand is useless unless it is that request's timeline. Pull the context window unfiltered too: causes from outside the execution appear there.

Record every observation that matters through the ledger tool, which reads the excerpt from disk itself:

```
python3 <SKILL_DIR>/scripts/evidence_collector.py add --inv INV --class log --grade FACT \
    --file logs/app.log --lines 412-413 --timestamp "09:47:04" --by log-analyst \
    --summary "process_payment started 1s before the CancelledError"
```

### 3. Map

```
python3 <SKILL_DIR>/scripts/call_graph.py index --root . --out INV/callgraph.json
python3 <SKILL_DIR>/scripts/call_graph.py enclosing <file> <line> --graph INV/callgraph.json
python3 <SKILL_DIR>/scripts/call_graph.py callers <function> --depth 4 --graph INV/callgraph.json
python3 <SKILL_DIR>/scripts/call_graph.py paths <entry> <failing function> --graph INV/callgraph.json
python3 <SKILL_DIR>/scripts/call_graph.py hotspots --graph INV/callgraph.json
```

Then overlay the timeline on the code: for each step of the candidate path, mark `observed` (a log line, span, stack frame or probe shows it ran) or `inferred`. List everything that can reach into the path from outside: timers, schedulers, signal handlers, cancellation, callbacks, queue consumers, other tasks touching the same state, middleware, decorators.

A static graph shows which calls are **possible**, never which happened. Every edge is INFERENCE-grade until a runtime artefact confirms it.

### 4. Hypothesize

Write `INV/brief.md`: ledger facts with ids, the candidate path with its observed and inferred marks, the open questions, and the knowledge-base entries for the files on the path with their statuses intact (`kb.py brief --files ...`). **No theory, no adjectives.** A brief with a theory in it produces investigators who all agree with the theory.

### 5. Investigate

Dispatch the investigators chosen from the routing table. Each gets its brief from `agents/`, plus `agents/_submission.md`, plus `INV/brief.md`. Each works alone and sees no other investigator's output.

On return: add each cited observation to the ledger yourself (the tool re-reads the file, which catches misquotes and invented line numbers); register hypotheses with `add-hypothesis`; register findings with `add-finding`; **merge duplicates** (same Layer 3 = one hypothesis); and test any prediction existing evidence can settle, with `set-prediction`. A hypothesis refuted here never needs a duel.

### 6. Compete

Skip if only one hypothesis survives. Otherwise king-of-the-hill duels, ordered so the pair disagreeing about the most cheaply checkable fact meets first. Each advocate reads the rival's submission and updates "why the rival is less likely" and "what would disprove me". The judge cross-examines both and assigns five raw scores. Then:

```
python3 <SKILL_DIR>/scripts/score.py duel --inv INV --a H-01 --b H-02 \
    --scores-a log=3,source=1,path=2,alternatives=2,verification=2 \
    --scores-b log=4,source=4,path=4,alternatives=3,verification=3 \
    --judge adversarial-reviewer --rationale "<evidence ids per criterion>"
```

The tool caps each score at what the ledger supports, deducts for unanswered contradicting facts, eliminates anything with a refuted prediction, and decides the outcome. A **narrow** result (margin under 10) eliminates nobody: the judge names the evidence that would separate them and you go and get it.

### 7. Verify

Brief the verifier from the ledger **files** with the champion's id and nothing else: not the duel transcripts, not the judge's rationale, not your opinion. A verifier asked to confirm will confirm. It re-derives the path independently, tests every untested prediction, attempts the falsifiers, looks for a simpler explanation, runs `recheck`, and returns `pass`, `partial` or `fail`.

```
python3 <SKILL_DIR>/scripts/evidence_collector.py recheck --inv INV
python3 <SKILL_DIR>/scripts/score.py score --inv INV --id H-02 --scores ... --judge verifier --rationale "..."
python3 <SKILL_DIR>/scripts/score.py verdict --inv INV --verification pass --verifier verifier --notes "..."
```

If verification fails, the champion is refuted. Take what refuted it back to step 4. **Do not promote the runner-up without verifying it in turn.**

### 8. Preserve

Sweep every investigator's output, every eliminated hypothesis, the hotspot list and the verifier's leftovers into findings with file, line, description, evidence, severity, confidence, verification status and whether each relates to the original bug.

### 9. Report

```
python3 <SKILL_DIR>/scripts/evidence_collector.py validate --inv INV
python3 <SKILL_DIR>/scripts/report_generator.py --inv INV --fix-file INV/fix.md
```

Write `INV/fix.md` first: the Layer 3 fix, then the trigger mitigation if worthwhile, then the failure-mode fix (so the system fails in a designed way when the trigger recurs), then the observability fix (whatever made this investigation slow), then any data repair. Name files and lines, and state what each change costs on the healthy path. Guidance: `reports/investigation_template.md`.

### 10. Learn

```
python3 <SKILL_DIR>/scripts/kb.py import --inv INV
python3 <SKILL_DIR>/scripts/kb.py record-hypotheses --inv INV
python3 <SKILL_DIR>/scripts/probe.py status --manifest INV/probes.json    # must be 0 if probes were used
```

## Hierarchical fault localization

The narrowing technique at the heart of TRACE, for when the failure *can* be re-run. Full procedure, including the retrospective form that uses existing log statements as fixed probes, in `core/hierarchical_localization.md`.

| Stage | Question | Probes |
|---|---|---|
| 1 | Which file? | One numbered label per file, at entry to every function. "Failure follows entry into F056" |
| 2 | Which function and which call? | One ENTER label per function, one CALL label before each statement that makes a call |
| 3 | Which statement? | One label before every statement, with selected variables |

```
python3 <SKILL_DIR>/scripts/probe.py stage1 --root src --manifest INV/probes.json
<run the failing scenario>  2> run1.err
python3 <SKILL_DIR>/scripts/probe.py analyze run1.err --manifest INV/probes.json
python3 <SKILL_DIR>/scripts/probe.py remove --manifest INV/probes.json

python3 <SKILL_DIR>/scripts/probe.py stage2 --file src/services/payment.py --manifest INV/probes.json
python3 <SKILL_DIR>/scripts/probe.py stage3 --file src/services/payment.py --function process_payment --vars attempt
```

Every inserted line ends with `# TRACE-PROBE`; the manifest stores each file's hash before probing, and `remove` verifies byte-identical restoration. One stage at a time: insert, run, analyse, remove. **Never probe a live production checkout** — probes edit source files. Automatic insertion is Python; `probe.py snippet --lang go|js|ts|java|ruby|rust|csharp|php` prints the line to place by hand, and the analysis and removal tooling works for every language.

In async or multi-threaded code the last probe printed is the last to *run*, not necessarily the one that failed: cancellation surfaces at whichever await the scheduler chose.

## Evidence rules

**No claim without a ledger id. No ledger entry without a locator. No conclusion resting on anything weaker than a FACT.**

| Grade | Means | Requires |
|---|---|---|
| FACT | Directly observed, re-checkable by anyone | A locator (file + line range, or the exact command, or a URL) and a verbatim excerpt |
| INFERENCE | Derived from other items by a stated step | `derived_from` ids and the `reasoning` |
| ASSUMPTION | Believed, not checked | Labelling. It may never be the sole support for a conclusion |

Tests: could a sceptical colleague see this for themselves in under a minute (FACT) or would they have to follow your argument (INFERENCE)? Does the sentence contain "because", "so", "must have", "probably" (at most INFERENCE)? Is it about what code *does at runtime* based only on reading it (INFERENCE — the FACT is what the code *says*)?

`evidence_collector.py` is the only writer of the ledger, and for file-backed items it reads the excerpt from disk itself. An agent cannot supply a paraphrase, a tidied version, or lines that do not exist. Absence evidence (`--class absence`) requires `--search-scope`, and before relying on it confirm that the source covers the time, that the event would have been logged, that your search would have matched, and that the pipeline did not drop it. Full protocol: `core/evidence_protocol.md`.

## Scoring

| Criterion | Weight | Question |
|---|---|---|
| `log` | 25% | Does runtime evidence show this happened? |
| `source` | 25% | Has the code been read and shown to behave as the hypothesis needs? |
| `path` | 20% | One coherent path, consistent with the timeline, nothing unexplained? |
| `alternatives` | 15% | Each rival shown less likely, with evidence? |
| `verification` | 15% | Predictions tested, by reproduction or independent check? |

Raw scores are 0 to 4 per criterion (anchors in `core/hypothesis_scoring.md`). These are initial engineering weights, not validated constants; they live in `debugging/trace_config.json`.

**Winning a debate must not mean winning the investigation.** An agent can be extremely persuasive and completely wrong, so the tool caps each raw score at what the ledger supports: no FACT-grade runtime evidence caps `log` at 1; no source evidence caps `source` at 1; no observed path step caps `path` at 1; rebuttals without FACT evidence cap `alternatives` at 1; no confirmed prediction caps `verification` at 1. Unanswered contradicting FACTs cost 10 points each. **One refuted prediction eliminates the hypothesis outright.**

| Confidence | Requires |
|---|---|
| CONFIRMED | verification pass, total ≥ 80, no untested predictions, margin ≥ 10 |
| PROBABLE | verification pass or partial, total ≥ 65, margin ≥ 10 |
| PROVISIONAL | total ≥ 50 and margin ≥ 10, but verification not run or total under 65 |
| INSUFFICIENT_EVIDENCE | best total under 50, or top two within 10, or nothing survives, or verification failed |

**The final winner is allowed to declare that the available evidence is insufficient.** So are you, the judge and the verifier. This is extremely important: without it, the format itself pressures an AI into hallucinating a root cause because a winner has to be produced. INSUFFICIENT_EVIDENCE is a successful outcome when it is true, delivered with what is established, the leading candidates, exactly which observations would decide between them, and the instrumentation plan that will produce them.

Never let your wording to the user exceed the confidence level.

## Losers' findings are retained

Suppose the tournament concludes the cause was a cancellation-propagation bug, but along the way one agent found a connection leak, another a race condition, another an unhandled exception in a different worker, another a suspicious retry mechanism. None caused this incident. Each may cause the next. They go to the knowledge base with: file and line, description, evidence, severity, confidence, whether verified, and whether related to the original bug.

**An unverified finding must never silently become an established fact.** Status is `confirmed` (verified, FACT evidence, named verifier), `suspicious` (evidence points that way, verification incomplete), `unverified` (noticed, unchecked) or `disproven` (checked, not a problem). Re-observation never upgrades a status: two people noticing the same smell is two noticings. Only `kb.py promote`, with FACT-grade evidence and a named verifier, reaches `confirmed`. When you quote the knowledge base, carry the status in the same sentence, and never write "known issue" for anything not `confirmed`.

Eliminated hypotheses are recorded too, scoped to their incident: "outscored in BUG-001" is not "impossible".

## Engine failure modes to watch in yourself

| Failure mode | Guard |
|---|---|
| Anchoring on Layer 1 | The three-layer discipline. Layer 1 is a location, not a cause |
| Narrative before evidence | `brief.md` may contain only ledger facts with ids |
| Persuasion winning | Ledger caps, and a rationale citing ids per criterion |
| Convergence by contamination | Neutral brief, isolated investigators |
| Absence read as presence | Absence evidence needs a search scope and established coverage |
| Static path read as runtime path | `observed: false` on every step with no runtime artefact |
| Forced winner | INSUFFICIENT_EVIDENCE is first-class |
| Verification by the author | The verifier is briefed from files, not from the debate |
| Lost findings | Step 8 is mandatory and has its own gate |
| Fact laundering | Knowledge-base status travels with every entry |
| Probes left behind | The manifest, the marker, and the step 10 gate |

## Dispatching agents on GitHub Copilot

Copilot discovers this skill automatically from `.github/skills/trace/` (or `~/.copilot/skills/trace/`)
and activates it when a request matches the description. `<SKILL_DIR>` below is
`.github/skills/trace` for a workspace install.

**Custom agents** live in `.github/agents/<name>.agent.md`. The helper agents set
`user-invocable: false`, so they stay out of the agent picker and are available only as subagents. The
entry point, `trace.agent.md`, is user-invocable: select it from the agent picker in VS Code, or run
`/agent trace` in Copilot CLI.

Delegate to a helper with the **agent tool** (it must be in your `tools` list, and the helper must be
named in your `agents` list, both of which `trace.agent.md` already does):

```
Use the trace-log-analyst agent with this prompt:

You are acting as the log analyst. Read and follow .github/skills/trace/agents/log_analyst.md.

Investigation: debugging/investigations/BUG-001
Read: debugging/investigations/BUG-001/error_context.md
Repository root: .      Logs: logs/app.log, logs/worker.log
Skill directory (scripts and core documents): .github/skills/trace

Your question: build the correlated timeline for the failing execution and establish log coverage.

Return: proposed evidence items (class, grade, file + line range, one neutral sentence each) and write
the timeline to debugging/investigations/BUG-001/timeline.json.
```

| Step | Agents |
|---|---|
| 2 Collect | `trace-log-analyst`, `trace-stacktrace-analyst`, `trace-git-investigator`, `trace-telemetry-investigator` |
| 3 Map | `trace-codebase-mapper` |
| 5 Investigate | 3 to 4 lenses from `trace-execution-path-analyst`, `trace-exception-propagation-analyst`, `trace-concurrency-analyst`, `trace-cancellation-analyst`, `trace-data-state-analyst`, `trace-dependency-analyst` |
| 6 Compete | `trace-adversarial-reviewer`, once per duel, sequentially |
| 7 Verify | `trace-verifier` |
| 8, 10 Preserve and learn | `trace-knowledge-curator` |

Keep the briefing to the five fields above. No encouragement, no hints about what you expect, no
summary of what other agents found: "I think this is a cancellation problem, please confirm" destroys
the value of the agent you are about to spend.

**Surfaces differ in what they support.** Skills and custom agents work in Copilot CLI, VS Code and the
Copilot coding agent; prompt files (`/trace`) are VS Code only; a tool named in `tools` that the host
does not provide is simply ignored. Subagent support varies by surface and setting, so **never assume
delegation worked**: if a helper cannot be invoked, play each role yourself, one at a time, writing each
role's output to disk before starting the next, and do not revise an earlier hypothesis in light of a
later lens. For the verifier, set your own earlier reasoning aside and follow the checklist literally
from the files. State in the report that roles were not independently executed, and cap the verdict at
PROBABLE unless a prediction was confirmed by an actual run.

**Running commands.** The scripts need a terminal (`runCommands` / `runInTerminal`). Without it, keep
the same files by hand in the same formats: quote evidence with `file:line` and verbatim text, compute
scores from the rubric showing the arithmetic, and apply the caps yourself, strictly. Say in the report
that the ledger was maintained manually.

## Reference documents

Read the one you need; do not load them all.

| File | Read it when |
|---|---|
| `core/investigation_engine.md` | The spine: roles, tiers, every step's gate, degraded operation. Read first |
| `core/hierarchical_localization.md` | Localizing with probes, or retrospectively with existing log statements |
| `core/evidence_protocol.md` | Grading, collecting, citing, absence, correlation, staleness, sensitive data |
| `core/execution_reconstruction.md` | The three layers, timelines, gaps, async, cancellation, batches, distributed |
| `core/instrumentation_playbook.md` | Mode B: what to add, where, with language snippets and production safety rules |
| `core/hypothesis_scoring.md` | Criterion anchors, caps, penalties, thresholds, judging rules |
| `core/tournament_protocol.md` | Entry requirements, brackets, duel anatomy, cross-examination questions |
| `core/root_cause_verification.md` | The verification checklist, counterfactuals, what to do when it fails |
| `core/knowledge_base.md` | Workspace layout, finding fields, status transitions, maintenance |
| `core/failure_signatures.md` | A field guide: 15 failure families, their mechanisms and discriminating checks |
| `agents/*.md` | One standalone brief per role. `_submission.md` is shared by the six lenses |
| `reports/investigation_template.md` | What the report contains and how to write the fix section |
| `examples/sample_incident/walkthrough.sh` | The best documentation of the order of operations |

## Hard rules

1. Never restart, redeploy or hot-edit a running production process to reproduce a failure.
2. Probes and experiments go in a reproduction environment or a scratch copy, never a live checkout.
3. Never commit probe lines. `probe.py status` must report zero before you report.
4. Never record a FACT without a locator and a verbatim excerpt the tool read from disk.
5. Never mark an inferred execution-path step as observed.
6. Never name a root cause the verdict does not support, and never describe it more confidently than the verdict allows.
7. Never promote a finding to `confirmed` without FACT evidence and an independent check.
8. Never put secrets or personal data in an excerpt, a probe variable or a report.
9. Never judge a duel in which you authored a side without recording that you were not independent.
10. Stop and report when evidence stops moving the scores. More agents will not help; more evidence might.
