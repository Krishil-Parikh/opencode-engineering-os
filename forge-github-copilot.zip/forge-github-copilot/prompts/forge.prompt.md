---
mode: agent
description: Run a FORGE competitive implementation
---

Switch to the **forge** agent and run a FORGE competitive implementation for the work below.

Follow the nine phases in `.github/skills/forge/SKILL.md` in order and respect every exit gate. Decide
the tier first: if the answer is already in the standard library or an existing function, say so and
stop rather than running a competition. Use the specialised subagents for the candidate, review,
measurement and simplification phases. Report the verdict in your first two sentences, and never
describe the outcome more confidently than the verdict allows.

Work: ${input:work:What to implement, or the function to optimise}
