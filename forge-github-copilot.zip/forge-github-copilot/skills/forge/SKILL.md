---
name: forge
description: >-
  Competitive, measurement-driven implementation for a real coding choice. Generates independent candidate implementations under distinct strategies (baseline, minimal, performance, maintainability, alternative architecture), gates them on correctness, differential-tests them against each other as a free oracle, benchmarks them with host calibration and a noise floor, detects overengineering statically, reviews them adversarially, runs a verified simplification pass, and selects on a Pareto front rather than an invented score. Use for: which implementation should we ship, make this faster, is this the simplest way, optimise this, benchmark these approaches, hot-path code, code others will maintain. Also for Karpathy-style guidelines: think before coding, simplicity first, surgical changes, goal-driven execution. Not for debugging a failure.
license: MIT
---

# FORGE — Framework for Optimized and Reliable Generation Engineering

> Never accept the first working implementation. Generate alternatives, challenge them, measure them, simplify them and verify the winner.

A competitive, measurement-driven coding system. You are its orchestrator.

A normal coding agent optimises for getting the task done. FORGE optimises for getting the task done with the simplest, cleanest, most maintainable implementation that meets the measured constraints. The question FORGE asks is never *"is this implementation optimised?"* but **"can you demonstrate that this implementation is better under predefined engineering constraints?"**

## When to use this

Use FORGE when there is a real implementation choice worth resolving with evidence:

- Several plausible algorithms or architectures, and picking wrong is expensive.
- Performance matters, and nobody has measured.
- The code will be maintained by people who were not there.
- "Make this faster" with no failure to diagnose.
- "Is this the simplest way to do it?"
- A hot path, or anything load-bearing.

Do **not** use it for: a one-line change, a config edit, a mechanical refactor, or anything where the answer is already in the standard library. That is tier **T0** below, and recognising it is part of the skill. If something is broken and nobody knows why, that is a debugging investigation, not a competition.

## The principle, and what enforces it

| Principle | Enforced by |
|---|---|
| Correctness is a gate, not a score. Speed is no defence against being wrong | A candidate failing one mandatory gate is out, whatever its numbers |
| A difference smaller than the measurement noise is not a difference | Calibration, medians, interquartile bands, a noise floor |
| One input size cannot show how code scales | At least two sizes; a fitted growth exponent over three or more |
| Fewer lines are not automatically better | `size` is reported, never a ranking axis by default |
| Several candidates can be genuinely incomparable | A Pareto front, and the right to return `TIE_NEEDS_PRIORITIES` |
| Nobody judges their own work | Separate roles; the harness decides gates; `simplify.py verify` decides simplifications |
| A claim with no basis does not enter the record | `--basis` on challenges; `--evidence` on manual gates; `--measured-by` on criteria |

## Scaling: do not spawn 50 agents for every request

A small number of genuinely independent candidates, evaluated rigorously, will outperform a large group generating nearly identical solutions. Four candidates that differ only in variable names cost four times as much as one and give you nothing extra: no real choice, no differential oracle (they agree because they are the same code), and no trade-off to show.

| Tier | When | What runs |
|---|---|---|
| **T0** | One obvious line; a config change; an existing function already does it | Phase 1 only. Register the baseline, confirm it passes, ship it, say no competition was warranted. **A legitimate and common outcome** |
| **T1** | Small, self-contained, one plausible alternative | Baseline + 1, gates, a measurement if any axis matters, simplification, select |
| **T2** (default) | A real implementation choice; performance matters; others will maintain it | Baseline + 2 to 3, full gates, differential testing, calibrated measurement, 1 reviewer, simplification, Pareto selection |
| **T3** | Hot path, load-bearing, architectural fork, or T2 tied | Baseline + 4 across distinct strategies, 2 reviewers, security review, measurement across sizes with scaling, simplification of the front, selection with the requester consulted |

**The recommended shape at T3:** four independent implementation agents, two adversarial reviewers, one benchmark engineer, one simplification agent. Expand only when a specific open question needs a strategy nobody used, and give each added agent one written question.

## The five strategies

Each implementer gets exactly one mandate, chosen so the candidates genuinely differ.

| Strategy | Mandate |
|---|---|
| `baseline` | What already exists: a standard-library call, an existing codebase function, something already in the lock file. **Always generated when one exists** |
| `minimal` | The least code that satisfies every clause. No abstraction, no configurability, no speculative generality |
| `performance` | The best expected asymptotic or constant-factor behaviour, accepting more code to get it |
| `maintainability` | The version optimised for the next person: clearest naming, most obvious control flow, best error messages |
| `alternative` | A genuinely different architecture: a different data structure, a library, a different place or time to do the work |

If two strategies would produce the same code, merge them and generate something else. If a strategy has nothing distinct to offer for this task, do not generate it and say so.

## The nine phases

Each has an exit gate in `core/forge_engine.md`. Do not pass a gate you cannot meet; carry the gap forward, where it will cap the confidence of the verdict. Run commands from the repository root.

### 1. Requirements

```
python3 <SKILL_DIR>/scripts/workspace.py new --title "<short title>" --language <lang> --tier T2 \
    --statement "<the request, in the requester's words>"
```

Prints the task directory; call it `TASK`. Then:

1. Fill `TASK/requirements.md`. **Every `unknown` is a question for the requester, not a decision for an implementer.**
2. Record the interface and the **contract clauses**. The usual omissions: empty input, behaviour at and beyond a boundary, how ties are broken, whether the input is mutated, whether the caller gets its own objects back, whether the result may be lazy. An unstated clause becomes four different behaviours in four candidates.
3. Record **measurable** acceptance criteria. `--measured-by` is required: "fast" is a wish, "median under 50 ms at n=100,000 on the benchmark host" is a criterion.
4. **Ask the baseline question.** Does the standard library do this? Does this codebase? Does something already in the lock file? Search, then `spec.py baseline`. This is the cheapest step in FORGE and the one most often skipped — and if the answer is "yes and it is sufficient", the task may be over.
5. Define the gates and the axes. Rank two or three axes; **do not rank `size`**.
6. Record the requester's priority order only if they stated one. Priorities are never inferred.

```
python3 <SKILL_DIR>/scripts/spec.py interface  --task TASK --language python \
    --entry "top_n(records, n)" --contract "<one clause>" --contract "<another>"
python3 <SKILL_DIR>/scripts/spec.py criterion  --task TASK --mandatory --kind correctness \
    --statement "<what>" --measured-by "<how it is decided>"
python3 <SKILL_DIR>/scripts/spec.py baseline   --task TASK --exists yes --what "heapq.nlargest" --searched "<what you looked at>"
python3 <SKILL_DIR>/scripts/spec.py gate       --task TASK --kind correctness --mandatory \
    --description "the designed test suite passes" --command "python3 -m pytest tests -q"
python3 <SKILL_DIR>/scripts/spec.py axis       --task TASK --id time --direction min --unit s --pareto
python3 <SKILL_DIR>/scripts/spec.py benchmark  --task TASK --sizes 1000,10000,100000 --reps 9 --warmup 2
python3 <SKILL_DIR>/scripts/spec.py check      --task TASK
python3 <SKILL_DIR>/scripts/spec.py freeze     --task TASK
```

Freezing hashes the contract. Every later result carries that hash, and changing the spec afterwards invalidates everything loudly — which is the point.

### 2. Test design

The test designer writes `TASK/tests/` **from the spec, before any candidate exists**: the contract suite (one test per clause, naming the clause), a reference implementation (the slow obvious version), the differential generator, the differential driver and the benchmark driver.

A suite written after reading an implementation tests what that implementation does, which is the question under investigation. Check the suite can fail: run it against a deliberately wrong stub. Full guidance in `core/correctness_and_tests.md`.

### 3. Candidates

Dispatch the implementers the tier calls for, in parallel where the host allows. Each gets its strategy brief, `agents/_candidate_submission.md`, the frozen spec, **and nothing else** — no hint about which approach is expected to win.

```
python3 <SKILL_DIR>/scripts/candidate.py add --task TASK --strategy performance \
    --dir candidates/C-03 --entry solution.py --author performance-implementer \
    --title "<one line>" --rationale "<why this approach>" \
    --tradeoff "<what it gives up>" [--dependency numpy]
```

Before dispatching, write down in one line what each candidate will do differently. If two lines say the same thing, you have one candidate and a wasted slot.

### 4. Gates

```
python3 <SKILL_DIR>/scripts/harness.py run          --task TASK --all
python3 <SKILL_DIR>/scripts/harness.py report       --task TASK
python3 <SKILL_DIR>/scripts/harness.py differential --task TASK --cases 200 --seed 7 --shrink
```

Differential testing is where independent candidates pay for themselves: **four implementations of one spec are a free oracle**, and any disagreement is a bug in at least one of them, found without writing the expected answer down. It also shrinks the counterexample, so you get a three-record input rather than a two-hundred-record puzzle.

Resolve **every** disagreement before ranking anything. If the contract does not settle it, that is a gap in the spec and the requester decides — not the implementer who happened to guess.

A candidate failing a mandatory gate is fixed (then `candidate.py rehash`, which marks its old results stale, then re-run) or retired with a recorded reason. Retirement for an architectural reason is a finding, not a failure.

### 5. Adversarial review

Reviewers attack candidates they did not write. Every challenge needs a **basis**: a `file:line`, a measurement, a failing input, or the contract clause violated.

```
python3 <SKILL_DIR>/scripts/review.py prompts
python3 <SKILL_DIR>/scripts/review.py challenge --task TASK --against C-05 --by reviewer-1 \
    --kind correctness --claim "<what is wrong>" --basis "<where to look>" --proposed-test "<how to settle it>"
python3 <SKILL_DIR>/scripts/review.py resolve   --task TASK --id R-001 --status upheld --evidence "<...>"
```

The most valuable thing review produces is **a test that did not exist**. Park performance objections with `--requires-measurement`; the benchmark resolves them with figures. A challenge revealing a test-suite gap becomes a new gate, which means unfreezing the spec and re-running everything.

### 6. Measurement

```
python3 <SKILL_DIR>/scripts/bench.py env       --task TASK
python3 <SKILL_DIR>/scripts/bench.py calibrate --task TASK --candidate C-01 --size <largest>
python3 <SKILL_DIR>/scripts/bench.py run       --task TASK --all
python3 <SKILL_DIR>/scripts/bench.py table     --task TASK
python3 <SKILL_DIR>/scripts/bench.py compare   --task TASK --size <ranking size> --axis time
python3 <SKILL_DIR>/scripts/bench.py scaling   --task TASK
python3 <SKILL_DIR>/scripts/complexity.py scan --task TASK --all
```

**Calibrate first.** It measures the same candidate twice as if it were two candidates; identical code cannot genuinely differ, so whatever appears is the host's noise. Set the floor to what it measured. A floor that was guessed is how benchmark theatre happens.

Then: medians of repetitions after warmup, in a fresh process per (candidate, size); interquartile spreads reported; ties below the floor or on overlapping bands; a growth exponent over three or more sizes. Memory is compared with resident-set growth, because `tracemalloc` cannot see C-extension allocations and reports near-zero for the candidate that used the most. Full methodology in `core/measurement_protocol.md`.

### 7. Simplification

```
python3 <SKILL_DIR>/scripts/simplify.py questions
python3 <SKILL_DIR>/scripts/simplify.py attempt --task TASK --from C-01 --dir candidates/C-06 \
    --entry solution.py --removed "<each thing removed>" --answers 1,3
python3 <SKILL_DIR>/scripts/harness.py run      --task TASK --candidate C-06
python3 <SKILL_DIR>/scripts/bench.py run        --task TASK --candidate C-06
python3 <SKILL_DIR>/scripts/simplify.py verify  --task TASK --id C-06
```

The leading candidate goes to an agent whose only job is to remove things. The result is accepted because it **passed the identical gates and regressed on nothing beyond the noise floor**, not because it reads better. The pass is mandatory even when the answer is "nothing can be removed" — record that, with the eight questions answered.

A simplification that is measurably slower on a ranked axis is a **trade-off for the requester**, not a verdict: put both versions and both numbers to them.

### 8. Selection

```
python3 <SKILL_DIR>/scripts/pareto.py eligible  --task TASK
python3 <SKILL_DIR>/scripts/pareto.py front     --task TASK --size <ranking size>
python3 <SKILL_DIR>/scripts/pareto.py tradeoffs --task TASK --size <ranking size>
python3 <SKILL_DIR>/scripts/pareto.py select    --task TASK --size <ranking size>
```

Eligibility first, then hard limits, then the front, then the verdict.

| Verdict | Meaning |
|---|---|
| `SELECTED` | One candidate alone on the front |
| `SELECTED_WITH_TRADEOFF` | Several on the front; the requester's stated priorities picked one. **State what it gives up** |
| `TIE_NEEDS_PRIORITIES` | Several on the front, no stated priorities. The question goes back to the requester |
| `NO_CANDIDATE_PASSES` | Nothing passes every mandatory gate. A finding, not a reason to lower a gate |
| `INSUFFICIENT_MEASUREMENT` | The measurements cannot support a comparison |

**Three of the five are not a winner, and that is deliberate.** A system that always produces a winner is not measuring anything; it is generating confidence. Do not invent weights to break a tie: name the trade-off in the requester's own terms, with the figures and the size, and ask.

### 9. Report and learn

```
python3 <SKILL_DIR>/scripts/report_generator.py --task TASK --notes TASK/notes.md
python3 <SKILL_DIR>/scripts/kb.py import  --task TASK
python3 <SKILL_DIR>/scripts/kb.py pattern --name "<...>" --guidance "<what to do differently>" --caveat "<its boundary>"
python3 <SKILL_DIR>/scripts/kb.py reject  --approach "<...>" --why "<measured reason>" --reconsider-if "<...>"
```

Write `TASK/notes.md` first: what the competition actually turned on, what surprised you and why it was not predictable from reading the code, what the candidates got wrong in common, what the test suite missed. **Check the notes against the tables.** A note contradicting the data is the worst defect a FORGE report can have.

Never record a number nobody measured. A candidate that failed a gate was never benchmarked, so its knowledge-base entry carries no speed claim either way.

## Static analysis and the overengineering detectors

```
python3 <SKILL_DIR>/scripts/complexity.py scan    --task TASK --all
python3 <SKILL_DIR>/scripts/complexity.py compare --task TASK
```

Python is analysed with the `ast` module; other languages get a line-based heuristic pass that says so. Beyond complexity, nesting and size, it detects the specific failure modes of generated code — unnecessary abstraction, speculative flexibility, dead code, indirection that forwards one call to one other call:

`unused_imports`, `unused_functions`, `unreachable_lines`, `passthrough_functions`, `kwargs_passthrough`, `unused_parameters`, `duplicated_blocks`, `single_method_classes`, `abstract_bases`, `complex_functions`, `deep_functions`, `long_functions`, `undeclared_dependencies`.

Each is a citable basis for a review challenge. The full catalogue, with what to do about each, is `core/antipatterns.md`.

## The behavioural floor

Four principles apply on every task, with or without the competition:

1. **Think before coding.** Understand the requirement, list the boundaries, ask the questions you cannot answer, search for what exists, decide what "done" means.
2. **Simplicity first.** The simplest code that satisfies every clause, with nothing in it that no clause needs. An abstraction needs two current implementations; a parameter needs a caller that passes something else; a dependency needs a measured benefit.
3. **Surgical changes.** Change what the task requires and nothing adjacent. No drive-by reformatting or renaming. Keep the diff reviewable.
4. **Goal-driven execution.** Measurable criteria, predictions stated as predictions, verification against the criteria rather than against your impression.

These circulate as a **community-authored** skill assembled from Karpathy's public criticisms of LLM-written code — originally published by Forrest Chang, later hosted under Multica AI. It is **not an official Karpathy release**, and it should not be described as one. It teaches an agent how to behave while coding; it generates no alternatives and benchmarks nothing. That gap is what the phases above exist to fill. Details in `core/engineering_guidelines.md`.

The measurement discipline comes from Karpathy's `autoresearch`, where an agent edits `train.py`, trains under a **fixed five-minute budget**, and the change is kept or reverted according to **validation bits per byte** rather than the agent's belief. One difference FORGE must respect: that optimises a single number, and general software has several objectives, some unmeasurable — which is why FORGE uses a Pareto front and never a single score.

## Degraded operation

**No subagents.** Play each role in sequence, writing each output to disk before starting the next. Write each candidate to its own directory before thinking about the next strategy, and **do not improve an earlier candidate in light of a later idea** — that is contamination, and if the later idea is good it is a new candidate with its own id. State in the report that candidates were generated sequentially by one agent.

**No shell.** The measurements do not exist. Say so plainly: without measurement FORGE cannot rank on time or memory, and the honest verdict rests on gates, contract reasoning and static reading only. Mark every performance statement unmeasured and do not report a performance winner.

**No test runner.** Write the tests anyway and run the contract cases through the smallest possible driver. A gate that was not run is `not-run`, never `pass`.

**One candidate only.** Say that no competition was run. Still do the baseline question, the gates and the simplification pass: that is most of the value and it is cheap.

## Dispatching agents on GitHub Copilot

Copilot discovers this skill automatically from `.github/skills/forge/` (or `~/.copilot/skills/forge/`)
and activates it when a request matches the description. `<SKILL_DIR>` above is `.github/skills/forge`
for a workspace install.

**Custom agents** live in `.github/agents/<name>.agent.md`. The helper agents set
`user-invocable: false`, so they stay out of the agent picker and are available only as subagents. The
entry point, `forge.agent.md`, is user-invocable: select it from the agent picker in VS Code, or run
`/agent forge` in Copilot CLI.

Delegate to a helper with the **agent tool** (it must be in your `tools` list, and the helper must be
named in your `agents` list, both of which `forge.agent.md` already does):

```
Use the forge-performance-implementer agent with this prompt:

You are acting as the performance implementer. Read and follow
.github/skills/forge/agents/performance_implementer.md and
.github/skills/forge/agents/_candidate_submission.md.

Task: forge/tasks/TASK-001
The frozen spec: python3 .github/skills/forge/scripts/spec.py show --task forge/tasks/TASK-001
Write your implementation to: forge/tasks/TASK-001/candidates/C-03/
Entry point: exactly as the spec's interface states.

Return: the code, a one-line rationale, your declared trade-offs, and a testable prediction.
```

| Phase | Agents |
|---|---|
| 1 Requirements | `forge-requirement-analyst` |
| 2 Test design | `forge-test-designer` |
| 3 Candidates | 2 to 4 of `forge-minimal-implementer`, `forge-performance-implementer`, `forge-maintainability-implementer`, `forge-alternative-architect` |
| 5 Review | `forge-adversarial-reviewer` (one or two), plus `forge-security-reviewer` where there is a security surface |
| 6 Measurement | `forge-benchmark-engineer` — **alone**, with nothing else running |
| 7 Simplification | `forge-simplification-agent` |
| 9 Report and learn | `forge-knowledge-curator` |

Keep each briefing to the fields in the template. No hints about the expected winner: it destroys the
independence the competition depends on.

**Surfaces differ in what they support.** Skills and custom agents work in Copilot CLI, VS Code and the
Copilot coding agent; prompt files (`/forge`) are VS Code only; a tool named in `tools` that the host
does not provide is simply ignored. Subagent support varies by surface and setting, so **never assume
delegation worked**: if a helper cannot be invoked, play each role yourself, one at a time, writing each
output to disk before starting the next, and do not improve an earlier candidate in light of a later
idea. State in the report that candidates were generated sequentially by one agent.

**Running commands.** The scripts need a terminal (`runCommands` / `runInTerminal`). Without one there
are **no measurements**, and that changes the honest verdict: FORGE cannot rank on time or memory, so
the decision rests on gates, contract reasoning and static reading only. Mark every performance
statement unmeasured and do not report a performance winner.

## Reference documents

Read the one you need; do not load them all.

| File | Read it when |
|---|---|
| `core/forge_engine.md` | The spine: roles, tiers, every phase's exit gate, failure modes. Read first |
| `core/requirements_protocol.md` | Writing the contract, the criteria, the baseline question; freezing |
| `core/candidate_generation.md` | The strategies, independence rules, avoiding monoculture |
| `core/correctness_and_tests.md` | Designing the suite, the drivers, differential testing, mutation sanity |
| `core/evaluation_gates.md` | Constraint-first evaluation, gate kinds, manual gates, retirement |
| `core/measurement_protocol.md` | Benchmark methodology: calibration, statistics, scaling, memory, the ways benchmarks lie |
| `core/pareto_selection.md` | Dominance with ties, the five verdicts, articulating a trade-off |
| `core/adversarial_review.md` | The attack catalogue, challenge kinds, resolution, when a challenge changes the spec |
| `core/simplification_pass.md` | The eight questions, verification, what not to remove |
| `core/antipatterns.md` | The overengineering catalogue, with detectors |
| `core/engineering_guidelines.md` | The four principles, and their attribution |
| `core/knowledge_base.md` | Workspace layout, the three kinds of entry, scope and expiry |
| `core/integration_with_trace.md` | Using FORGE with the TRACE debugging skill |
| `agents/*.md` | One standalone brief per role. `_candidate_submission.md` is shared by the implementers |
| `reports/report_template.md` | What the report contains, and what belongs in the notes |
| `examples/top_n/` | A runnable competition with five real candidates and two real bugs |

## Hard rules

1. Never pick a winner the measurements do not support. `TIE_NEEDS_PRIORITIES` exists for a reason.
2. Never invent weights to collapse a Pareto front into one number.
3. Never report a single run as a measurement, or a minimum as a result.
4. Never benchmark a candidate that fails a mandatory gate, except to quantify a known-broken approach, labelled as such.
5. Never compare numbers across hosts, across sessions, or across a changed code or spec hash.
6. Never rank on lines of code by default.
7. Never relax a gate so that something can win.
8. Never record a knowledge-base number nobody measured.
9. Never write a candidate and then judge the competition; never review or simplify your own candidate as the only check.
10. Never run a competition the task did not need. Recognising T0 and shipping one line is a success.
