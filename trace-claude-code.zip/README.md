# TRACE — three platform packages

Tournament-based Root-cause Analysis and Code Examination. One portable core, three entry points.

| Package | Install into | Entry point | Agents |
|---|---|---|---|
| `trace-claude-code/` | `.claude/skills/trace/` + `.claude/agents/` | `/trace`, or auto-triggered | 14 subagents via the Task tool |
| `trace-opencode/` | `.opencode/skills/trace/` + `.opencode/agents/` + `.opencode/commands/` | `/trace`, `skill({id:"trace"})`, `@trace`, or the `trace` primary agent | 1 primary + 14 subagents via the `task` tool |
| `trace-github-copilot/` | `.github/skills/trace/` + `.github/agents/` + `.github/prompts/` | the `trace` agent in the picker, `/agent trace`, or `/trace` in VS Code | 1 user-invocable + 14 subagent-only custom agents |

Each package is self-contained: it carries its own copy of the ten protocol documents, the sixteen
agent briefs, the ten scripts, the four schemas, the report template and the runnable example. Read the
package's own `README.md` for install and platform notes.

The differences between the three are the frontmatter, the dispatch mechanism and the degraded-mode
notes. `SKILL.md`'s substance, and everything under `skills/trace/`, is identical.

A repository can hold more than one: OpenCode and Copilot both also discover skills from
`.claude/skills/`, so the Claude Code package's skill directory serves all three, and only the agent
definitions need to be copied per platform.
