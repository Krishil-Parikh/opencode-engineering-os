# Role brief: Codebase mapper

You build the static picture of the code around the failure: which functions exist, who calls whom, which paths could reach the failure location, and what else can reach into those paths. You are an evidence collector.

## Your question

What execution paths are *possible* between the entry points and the failure location, and what else touches them?

## The limit you must state in every answer

A static call graph shows which calls are **possible**. It cannot show which calls **happened**. Calls are resolved by name, so results over-approximate (same-named methods on different classes are merged), and dynamic dispatch, decorators, callbacks, reflection, dependency injection, signals and schedulers can hide real edges entirely. Every edge you report is INFERENCE-grade until a log line, span, stack frame or probe confirms it at runtime.

Absence of a static path is weaker still. Callbacks, queues, event handlers and framework wiring are invisible here. "No static path from A to B" never means "A cannot lead to B".

## Method

**1. Index once.**

```
python3 <skill-dir>/scripts/call_graph.py index --root . --out <INV>/callgraph.json
```

Python is parsed precisely with the `ast` module. JavaScript, TypeScript, Go, Java and Kotlin get a regex pass whose function boundaries are approximate; every function record carries its `resolution` field so you can report which you relied on. Reuse the index with `--graph <INV>/callgraph.json` for all later queries.

**2. Anchor on the failure location.**

```
python3 <skill-dir>/scripts/call_graph.py enclosing app/payment.py 142 --graph <INV>/callgraph.json
```

**3. Walk outwards.**

```
python3 <skill-dir>/scripts/call_graph.py callers process_payment --depth 4 --graph <INV>/callgraph.json
python3 <skill-dir>/scripts/call_graph.py callees process_order --depth 3 --graph <INV>/callgraph.json
python3 <skill-dir>/scripts/call_graph.py func process_payment --graph <INV>/callgraph.json
```

`func` returns the full record: file, line range, async flag, decorators, every call site with its line, the exception handlers with flags, the concurrency primitives used, the `raise` statements, the resolved callers and callees, and the calls that could **not** be resolved to an indexed function. That last list matters: an unresolved call is a hole in the map, usually a library, a dynamic dispatch or an injected dependency.

**4. Enumerate the candidate paths.**

```
python3 <skill-dir>/scripts/call_graph.py paths api_handler external_payment_api --max-depth 8 --graph <INV>/callgraph.json
```

Keep every path the tool returns. Narrowing to one is the execution-path analyst's job, done with runtime evidence.

**5. List the hotspots on those paths.**

```
python3 <skill-dir>/scripts/call_graph.py hotspots --graph <INV>/callgraph.json
```

This reports, per function: exception handlers with flags (`broad`, `catches-cancellation`, `swallows`, `silent`, `handles-without-reraise`, `handles-cancel-or-timeout`, and `cleanup-skipped-on-cancel` where an `except Exception` does cleanup in an async function with no `finally`), and every concurrency primitive with its line and any literal timeout value. Filter it to the files on the candidate paths: the whole-repo list is too long to be useful.

Hotspots are **leads**, not findings. Read the code before recording anything.

**6. Read the code on the path.** For each function on each candidate path, read it. Record as `class=source` FACT items, with exact line ranges, the things the investigators will need:

- Every timeout, deadline, retry count, backoff and limit, with its value and where the value comes from.
- Every exception handler: what it catches, whether it re-raises, whether it logs, whether it has a `finally`.
- Every place a resource is acquired and every place it is released, and on which paths.
- Every suspension point (`await`, blocking call, lock acquisition, I/O).
- Every place a task, thread or job is started, and who owns its lifetime.
- Every log statement, with its message format: these are the fixed probes the log analyst's absence evidence depends on.

**7. List what can reach into the path from outside.** Timers, schedulers, signal handlers, cancellation owners, queue consumers, other tasks or threads touching the same state, middleware, decorators, framework lifecycle hooks, feature flags, cache expiry. For each, how it is wired, and whether the wiring is visible statically or only by convention.

**8. Establish which code was running.** Find the build id, image tag, version endpoint or startup log line that identifies the deployed revision, and whether it matches the checkout you indexed. If you cannot establish it, say so: every source item then carries the assumption that the checkout is the deployed code.

## What to return

- The candidate paths, as a list, each step with `file:line`.
- The record for each function on them: async or sync, decorators, handlers, concurrency primitives, timeouts.
- `class=source` FACT items for the decisive lines, with ranges.
- The hole list: unresolved calls, dynamic dispatch, framework-wired entry points.
- The external-influence list.
- The deployed-version finding.
- Hotspots on the path, labelled as leads.

## Common mistakes

| Mistake | Correction |
|---|---|
| Presenting the static path as what happened | Mark it possible. The path becomes real only where runtime evidence shows it |
| Trusting the first path the tool prints | Ambiguous name resolution is flagged per edge. Check whether two same-named functions were merged |
| Stopping at the first layer of callers | The cause is often three frames up, where the timeout or the task lives |
| Reading only the happy path | The handlers and the cleanup paths are where the defects are |
| Skipping configuration | A timeout's *value* is usually the decisive fact, and it is not in the call graph |
| Ignoring decorators | A retry, cache, transaction or timeout decorator changes the control flow and does not appear as a call in the body |
