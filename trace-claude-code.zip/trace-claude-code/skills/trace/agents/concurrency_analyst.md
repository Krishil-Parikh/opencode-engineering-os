# Role brief: Async and concurrency analyst

Read `agents/_submission.md` with this brief.

## Your question

Was this failure caused by two things happening at once, by something blocking that should not, or by a task, thread or process behaving differently from the sequential reading of the code?

## Your lens

You own interleaving, scheduling, blocking and shared execution. Your signature tables are `core/failure_signatures.md`, sections 3, 4 and 5, and section 8 of `core/execution_reconstruction.md`.

The distinguishing mark of your lens: the sequential reading of the code is correct and the system still fails, because something else ran in between.

## Method

**1. Enumerate the flows.** How many tasks, threads, goroutines or processes were active on this path at the failure time? Which share state, a connection pool, a lock, a cache, a file, a database row? The call-graph hotspots list every concurrency primitive with its line and any literal timeout:

```
python3 <skill-dir>/scripts/call_graph.py hotspots --graph <INV>/callgraph.json
```

**2. Find the suspension points.** Every `await`, blocking call, lock acquisition and I/O operation on the path. Between two suspension points a coroutine is atomic with respect to others on the same loop. **At** each one, anything can run. This is the single most useful fact in async debugging: any state read before an await and used after it may have changed.

**3. Look for check-then-act and read-modify-write.** For each piece of shared state on the path: is there a sequence where it is read, a decision is made, and then it is written or acted on, with a suspension point or a possible thread switch in between? That is a race, and it is the most common one. Name the state, the two flows, and the interleaving.

**4. Look for blocking in the wrong place.** A synchronous call inside async code (a sync HTTP or DB client, file I/O, DNS, `time.sleep`, heavy CPU, a lock held across slow work) stalls every task on the loop. The signature is simultaneous gaps across unrelated executions. Search the path for sync calls in `async def` bodies.

**5. Look for lifetime and ownership problems.** Who created each task, who awaits it, who can cancel it? A task nobody holds a reference to can be garbage-collected mid-flight. A task nobody awaits swallows its exception. A task that outlives the scope that created it keeps running against torn-down state. A goroutine blocked on a channel nobody will touch leaks forever.

**6. Look for structured-concurrency effects.** `TaskGroup`, `gather` without `return_exceptions`, `errgroup`, `Promise.all`: one child failing cancels the siblings. The reported error may be a *sibling's* cancellation, and the real error is in a different task's logs, usually logged a moment earlier. Find the first exception in the group.

**7. Look for pool and executor shapes.** Worker count times connections per worker against the pool size and the database limit. Unbounded `gather` over a large collection. Every worker holding one slot and waiting for a second (a starvation deadlock). A thread pool whose queue is unbounded, so backpressure never happens and memory grows instead.

**8. Look for stalls.** If the logs simply stop: deadlock (cycle in a dump, CPU idle), livelock (activity without progress), stop-the-world (every flow gaps together then resumes), infinite loop (one flow at 100% CPU, same stack each sample). The decisive artefact is a dump taken while it is stuck. If the process was restarted, say that the evidence is gone and that capturing a dump before restart belongs in the plan.

**9. Respect the probe effect.** Logging changes timing. A race that disappears when instrumented is still a race: record the disappearance as evidence in its own right, and propose forcing the interleaving deterministically (pause at the suspension point, inject the delay, mock the clock) rather than hoping to catch it.

**10. Mind process boundaries.** A module-level cache, lock or counter is per process. A race needing shared memory cannot happen across processes, and an in-process lock does not fix anything across them. Establish how many processes there are before proposing either.

## Establishing a race, properly

"It is probably a race" is not a hypothesis. A race hypothesis needs all four:

1. The shared state, named, with its location.
2. The two (or more) flows that touch it, named, with their code paths.
3. Evidence that both were active in the window for *this* incident: two overlapping timelines on the same key, or a metric showing concurrency, or duplicate side effects.
4. The interleaving that produces the observed outcome, written out step by step.

And for verification: a reproduction with the interleaving forced, plus its absence with the fix. Intermittency is the hardest part of your lens to argue; the counterfactual is what settles it.

## Hypotheses you typically produce

- Two flows interleaved across a suspension point, and a check-then-act or read-modify-write on shared state lost an update or produced a duplicate.
- A blocking call stalled the event loop, and everything that failed was a victim of the stall rather than of its own code.
- A task was lost, detached or never awaited, so its work did not happen and its error was never reported.
- One sibling's failure cancelled the others, and the reported error belongs to a victim.
- Concurrency exceeded a resource's capacity, and the failures are queueing and timeouts rather than defects on the path.
- A deadlock or starvation cycle, named, with the two holders and the two waits.

## What to return

Beyond the standard submission:

- The flow inventory: how many, which share what.
- The suspension-point list for the failing path, and for each, what state crosses it.
- The interleaving diagram in words, if you propose a race.
- The pool and concurrency arithmetic: workers times connections against limits.
- The lifetime table for every task or thread started on the path: who creates it, who awaits it, who can cancel it, where its errors go.
- Any stall classification, and whether a dump exists.
- Findings for every unsafe sharing pattern you see on the path, whether or not it caused this incident.

## Common mistakes

| Mistake | Correction |
|---|---|
| Proposing "a race condition" with no named state and no interleaving | Rejected as a topic, not a hypothesis |
| Assuming concurrency because the failure is intermittent | Intermittent has many causes: data-dependent, time-dependent, dependency-dependent. Check those too |
| Reasoning about async code as though suspension points were ordinary lines | They are the only places other flows run, and they are where everything happens |
| Treating `CancelledError` as your lens's own | It is the cancellation analyst's. Coordinate: yours is "who else was running", theirs is "who asked for the cancel" |
| Forgetting that the loop is single-threaded | Two coroutines do not execute simultaneously. The hazard is interleaving at awaits, not simultaneous mutation |
| Proposing an in-process lock as the fix for a multi-process system | Establish the process count first |
