# Role brief: Cancellation and timeout analyst

Read `agents/_submission.md` with this brief.

## Your question

Who ended this execution, and why? Which timer fired, which budget expired, who called cancel, and what was left half-done?

## Your lens

You own every mechanism that stops work from outside: cancellation, timeouts, deadlines, abort signals, interruption, shutdown. Your signature tables are `core/failure_signatures.md`, sections 1 and 2, and section 9 of `core/execution_reconstruction.md`.

The fact that defines your lens: **the exception names the victim, not the culprit.** A `CancelledError` is not raised by the code that fails. It is injected into a task by something else, and it surfaces at whichever suspension point that task happened to be waiting on, chosen by the scheduler. The stack trace tells you where the task was. It tells you nothing about who ended it.

## Method

**1. Identify the mechanism from the exception type.**

| Exception | Meaning |
|---|---|
| A timeout type raised by a wrapper (`TimeoutError` from `wait_for` or `asyncio.timeout`, `context deadline exceeded`, `SocketTimeoutException`, `ETIMEDOUT`) | A timer **owned by code on this stack** fired. The frames name the wrapper. Its configured duration should match the gap |
| A cancellation type (`CancelledError`, `context canceled`, `AbortError`, `OperationCanceledException`, `TaskCanceledException`, `InterruptedException`) | Something **outside this frame** requested cancellation. Find the owner of the cancel scope, token, context or task handle |

This single distinction resolves a large fraction of cancellation incidents. Make it first, and state it.

**2. Build the timeout hierarchy table.** This is your central artefact and is often the root cause on one page. List every time limit on the path, from the outermost entry (client, load balancer, gateway, framework) to the innermost call (socket connect, socket read, query, lock acquisition), with:

| Layer | Where set | Value | Worst case including retries |
|---|---|---|---|

For any layer with retries, the worst case is roughly `attempts × per-attempt timeout + (attempts − 1) × backoff`, more with exponential or jittered backoff, plus connection setup. Then compare each layer with the one enclosing it.

**Every place where an inner worst case exceeds its enclosing limit is a place where the outer layer will cut the inner one off mid-flight.** When that happens the system fails in an undesigned way: the inner code's own error handling never runs, so instead of a handled timeout you get a cancellation surfacing at a random await, and whatever cleanup lived on the inner error path does not happen.

Get the values from configuration, from library defaults where nothing is set (note which default and from which version), and ideally from a startup log line that printed the effective value.

**3. Compute the elapsed times.** From the execution's start to the failure, and from each sub-operation's start to the failure. Compare each against the table. A failure at a round interval after the *execution* started points at the owner of that budget, whatever the inner code was doing. A failure at a round interval after an *inner call* started points at that call's own timeout.

**4. Find the cancel sites.** Search the path and its callers for: `task.cancel()`, `cancel()` on a scope or context, `AbortController.abort()`, `Future.cancel()`, `Thread.interrupt()`, `context.WithTimeout`/`WithCancel`/`WithDeadline` and their `defer cancel()`, `wait` with a timeout followed by a cancel, watchdogs, supervisors, deduplication logic, leader-change handlers. For each: who owns it, what triggers it, and does it log anything? The commonest answer is "it logs nothing", which is why nobody knows who cancelled.

**5. Rule out the other cancellers.** Work through the mechanism table in `core/failure_signatures.md` section 1 and exclude each with evidence:

- **Caller's budget.** Elapsed from start matches a configured budget; the caller is awaiting the task in the outermost frames.
- **Client disconnect.** Proxy or access log shows the connection closed first (499, `client closed request`, reset). Interval matches no configured value.
- **Upstream deadline.** The inbound request carried a deadline; the upstream logged a timeout for the same trace id slightly earlier.
- **Sibling failure in a structured group.** The real error is in another task's logs, usually moments before. Find the first exception in the group.
- **Shutdown.** SIGTERM, "shutting down", drain or lifespan messages; many executions cancelled in the same instant; grace period shorter than in-flight work.
- **Explicit application logic.** A superseded request, deduplication, a watchdog, a user action.
- **Scope exit.** A timeout context whose `cancel` ran while work continued in a child that outlives it.

**6. Follow the cancellation through cleanup.** When the task was cancelled:

- Which `finally` blocks and context-manager exits ran? Does any of them await something that could itself be cancelled or hang?
- Which cleanup sits in an `except Exception`? In Python 3.8+ `CancelledError` derives from `BaseException`, so that block **does not run**. The call-graph hotspots flag this as `cleanup-skipped-on-cancel`.
- Is cancellation caught and suppressed anywhere (bare `except`, `except BaseException`, `suppress`, Kotlin `catch (e: Exception)` without rethrow, `InterruptedException` caught without restoring the flag)? Then the task continued after being told to stop, and the canceller may wait forever.
- What state was left half-done: reserved and not charged, charged and not recorded, message consumed and not acknowledged, connection checked out, row locked, lock held, file partially written?

Half-done state after cancellation is the commonest source of secondary findings in TRACE investigations and frequently the cause of the *next* incident. Record each as a finding even when it is not this incident's root cause.

**7. Check how it was reported.** A cancellation surfacing as a generic 500 with no indication that a budget expired is its own defect: it makes every future occurrence of this incident equally hard to diagnose. Note it.

## Hypotheses you typically produce

- The caller's budget is shorter than the callee's worst case, so the caller cancels mid-retry and the failure surfaces inside the callee, far from the real defect. (The sample incident.)
- A client disconnect cancelled the handler, and the "failure" is the server noticing, not malfunctioning.
- A sibling task's genuine error cancelled this one; the reported error is a victim's.
- Shutdown cancelled in-flight work because the grace period is shorter than the longest operation.
- A cancellation was swallowed, so the work continued against torn-down state.
- There is no timeout at all, so the failure is a hang that something else eventually ended.

## What to return

Beyond the standard submission:

- The mechanism classification (timer on this stack, versus external cancellation), with the evidence for it.
- The timeout hierarchy table, complete, with every inversion marked.
- The elapsed-time computations against that table.
- The cancel-site inventory, with whether each logs anything.
- The exclusion table: each alternative canceller, and the evidence excluding it or the observation that would.
- The cleanup analysis: what ran, what did not, what state is left.
- Findings for every cancellation-unsafe cleanup path and every missing timeout on the path.
- Instrumentation items: a log line at each cancel site with the reason, elapsed time and budget; cancellation reasons carried in the cancel call (Python's `cancel(msg=...)`, Go's `WithCancelCause`); span status set on cancel.

## Common mistakes

| Mistake | Correction |
|---|---|
| "`CancelledError` in `process_payment`, so the payment code is broken" | The payment code was the victim. Find the canceller |
| Reading the stack's deepest frame as the cause | It is where the task was waiting, chosen by the scheduler |
| Assuming the nearest timeout fired | Compute the elapsed time and match it to a value. The nearest timeout is often *not* the one that fired |
| Taking a config file's value as the effective one | Overrides, environment, library defaults and stale processes. Prefer a startup log line |
| Ignoring retries when computing the worst case | Three attempts of 0.6s is 2.4s with backoff, not 0.6s. This is where inversions hide |
| Treating cancellation as the end of the analysis | The half-done state it left is often the real impact, with its own root cause |
| Recommending "raise the timeout" as the fix | That moves the boundary. The root cause is usually the inconsistency between layers, and the fix is to make them consistent and to fail in a designed way |
