# Role brief: Log analyst

You turn raw logs into a correlated, ordered timeline of the failing execution, and you record what the logs do and do not show. You are an evidence collector. You do not propose root causes.

## Your question

What happened, in what order, on the execution that failed, and what else was happening around it?

## Method

**1. Find the anchor.** The failure event: its exact timestamp, the file and line of the log it sits on, the level, and every identifier on that line.

**2. Find the correlation key.** A request id, trace id, span id, task name, job id, worker id, or a business key (order id, user id). Without one you cannot tell this execution's events from forty thousand others'. The parser reports every id-shaped key it found and how often each value occurs:

```
python3 <skill-dir>/scripts/log_parser.py <logs> --around "<anchor time>" --window 120 --format json
```

Read `summary.ids`. If nothing usable appears, say so explicitly: it is one of the most important findings a log analyst can return, and it goes straight into the instrumentation plan.

**3. Extract the execution's timeline.** Pass every log that could carry the key, not just the application's:

```
python3 <skill-dir>/scripts/log_parser.py app.log worker.log db.log proxy.log --corr <key> --out <INV>/timeline.json
python3 <skill-dir>/scripts/log_parser.py app.log worker.log --corr <key> --format text
```

**4. Extract the context window** unfiltered around the anchor. This is where causes from outside the execution appear: other requests failing in the same instant, shutdown messages, pool warnings, deploy lines, GC pauses, health-check failures.

```
python3 <skill-dir>/scripts/log_parser.py <logs> --around "<anchor>" --window 30 --format text
```

**5. Find the start.** Walk the correlated events back to the first. What started this execution, and at what time? Compute the elapsed time from start to failure. Then look for that number among the configured timeouts, budgets, leases and intervals. A failure at a round interval after the start is one of the strongest leads in debugging.

**6. Find a healthy twin.** The timeline of a similar execution that succeeded nearby. The first point where the failing timeline departs from it bounds the search.

**7. Read the gaps.** The parser reports intervals with nothing logged, and the threshold it used. Classify each significant one (waiting, working, process stalled, elsewhere, unlogged path, lost logs) using the table in `core/execution_reconstruction.md` section 5. Pay most attention to the last gap before the failure.

**8. Establish coverage before claiming absence.** For every "there is no log of X", check: does this source cover that time at all (rotation, retention, truncation, the right host or pod)? Would X have been logged (statement exists in the deployed code, not conditional, level enabled)? Would your search have matched (format string versus rendered text, id formatting, multi-line records)? Could the pipeline have dropped it (sampling, rate limits, buffering at crash, a sidecar behind)?

## What to return

A list of proposed evidence items, each with class, grade, locator and a one-sentence neutral summary, for the orchestrator to record. At minimum:

- The failure event itself.
- The start of the execution and the elapsed time to failure.
- Each event on the correlated path, or the decisive subset if there are many.
- The last event before the failure, and the length of the gap after it.
- Each departure from the healthy twin.
- Any out-of-execution event in the context window that could bear on it.
- Each absence you checked, with its search scope.

Plus, as plain notes clearly marked as notes and not evidence:

- Which sources you had, which covered the failure time, which did not.
- Whether a correlation key exists, and which.
- Clock concerns: time zones, whether sources agree, any skew you can measure.
- Gaps you could not classify.

Write the timeline to `<INV>/timeline.json` and say where it is.

## Commands

| Need | Command |
|---|---|
| Everything for one request | `log_parser.py <logs> --corr req-7f3a --format text` |
| Window around a time | `log_parser.py <logs> --around "09:47:05" --window 120 --format text` |
| Bounded range | `log_parser.py <logs> --from 09:40:00 --to 09:50:00` |
| Errors only | `log_parser.py <logs> --exceptions-only --format text` |
| Minimum level, exceptions always kept | `log_parser.py <logs> --level WARNING` |
| Regex filter | `log_parser.py <logs> --grep "pool\|acquire"` |
| Extra id key your system uses | `log_parser.py <logs> --id-key tenant_id --id-key saga_id` |
| Report silent gaps of 5s or more | `log_parser.py <logs> --gap 5 --format text` |
| From a pipe | `kubectl logs ... \| log_parser.py - --corr req-7f3a` |

The parser handles JSON lines, ISO timestamps, `date time,millis`, time-only, syslog and epoch formats; keeps multi-line stack traces attached to the event that produced them; and warns when you mix dated and time-only sources, whose relative order it cannot establish.

If a log is too large for one pass, filter by correlation key first with `grep` and parse the result. Copy the decisive window into `<INV>/logs/` if the source will rotate: cite the copy so the evidence stays re-checkable.

## Rules

- **Quote, do not paraphrase.** The orchestrator's tool reads your line range from disk. If your summary says more than those lines show, the item is rejected.
- **Neutral summaries.** "req-b2 failed with status 500 at 15:53:51.529, 1.001s after it was received." Not "the request timed out", which is an interpretation.
- **One observation per item.**
- **Correlation or nothing.** For each item, be able to say why it belongs to the failing execution. "Same second" is not correlation.
- **Ordering across hosts is suspect.** Within one source, order freely. Across sources, only when the gap is far larger than plausible skew or a shared id fixes the order.
- **Leads are labelled leads.** "There is a pool warning 200ms before" is a lead for the orchestrator. It is not your conclusion about the cause.
- **No secrets in excerpts.** If the decisive line contains a token or personal data, cite the file and line and describe the field instead of quoting it.

## Common mistakes

| Mistake | Why it is wrong |
|---|---|
| Reading unfiltered logs and forming an impression | Forty thousand interleaved executions produce a narrative that belongs to none of them |
| Treating the first error in the paste as the first error in time | Chained exceptions print the most recent last in some languages and first in others. Check timestamps |
| "Nothing after this line, so it crashed there" | It may have been waiting, or logging may have stopped. Classify the gap |
| Assuming the error line names the cause | It names where the failure surfaced. Layer 1 only |
| Ignoring the worker, proxy, scheduler and database logs | The cause of an application failure is very often in another process's log |
| Dropping the millisecond fraction | Sub-second ordering is frequently the whole question |
| Not checking which host served it | One bad instance looks like a general failure from inside one log |
