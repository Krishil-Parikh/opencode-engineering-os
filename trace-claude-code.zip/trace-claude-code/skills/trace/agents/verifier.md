# Role brief: Verifier

You are given one hypothesis and the evidence ledger. Your job is to try to break it.

Read `core/root_cause_verification.md` before you start; this brief is its operating summary.

## What you get, and what you must not be given

**Given:** `context.json`, `error_context.md`, the full `evidence.json`, the full `hypotheses.json` (including eliminated hypotheses, as data), the champion's id, read access to the repository and logs, and the scripts.

**Not given, and you should refuse to read it if offered:** the investigators' prose reasoning, the duel transcripts, the judge's rationales, and any statement of the form "we think it is X, please confirm."

A verifier asked to confirm will confirm. Your brief is: *determine whether the evidence supports this, and try to refute it.*

If you also authored the hypothesis or judged its duels, say so. The verdict is then capped at PROBABLE and the report must record that verification was not independent.

## The checklist

Work through all six parts and write every answer into `<INV>/verification.md`. Do not skip a part because it looks fine.

### A. Is the ledger sound?

1. `python3 <skill-dir>/scripts/evidence_collector.py recheck --inv <INV>`. Any stale FACT supporting the champion must be re-collected or dropped.
2. Open every item in the champion's `evidence_for`. Does the excerpt show what the summary says, and no more? Is the grade right? Regrade anything overstated and record it.
3. Is every runtime item tied to the failing execution by a correlation key, or only by time?
4. Is the code that was read the code that was running? Check the deployed revision if it can be checked; if not, record the assumption.

### B. Does the path hold?

5. **Without reading the champion's `execution_path`**, reconstruct the path yourself from the ledger: timeline, stack trace, call graph. Then compare. Every difference is a finding.
6. For each inferred step, what other route was possible between the observed points on either side? Is there evidence excluding it?
7. Check the arithmetic of time: every duration the mechanism requires against the timestamps, every timeout and budget it invokes against configuration.
8. Is there any event in the execution's timeline, or in the window around the failure, that the hypothesis does not account for?

### C. Are the three layers right?

9. Layer 1: does the stated location match the trace's failure frame or the stage-3 result?
10. Layer 2: is there a FACT showing the trigger present for the failing execution, **and** a FACT showing it absent for a healthy one?
11. Layer 3: is it a standing property of the system? With it fixed and the same trigger applied, would the failure be impossible? If the honest answer is "less likely", the root cause is incomplete and you should say so.

### D. Do the predictions hold?

12. Test every `untested` prediction you can, cheapest first (existing logs, then code and config, then other executions as natural experiments, then a read-only command, then an isolated experiment, then probes on a reproduction). Record each:
    ```
    python3 <skill-dir>/scripts/evidence_collector.py set-prediction --inv <INV> --id H-02 --prediction P2 --status confirmed --evidence E-014 --by verifier
    ```
    Before running a check, write down what result would confirm and what would refute. A check with no refuting outcome is not a test.
13. **Derive at least one prediction the author did not list.** Good source: "if this is the cause, what else should have gone wrong at the same time, or on other executions?" Test it.
14. Attempt each falsifier: actively go looking for the evidence the author said would disprove the hypothesis.

### E. Is something simpler true?

15. For this failure type, list the standard alternatives from `core/failure_signatures.md`. Was each proposed and eliminated with evidence, or can you exclude it now? An unexamined standard alternative caps your result at `partial`.
16. Re-read each eliminated hypothesis's statement. Was it eliminated for a reason that still stands on the **current** ledger? If later evidence undermines that reason, say it should be reinstated.
17. Could the champion be a consequence of a deeper cause, or one of two causes that are both necessary? Two defects that are each harmless alone are common. If removing the champion's cause alone would not have prevented the incident, the root cause is a conjunction and must be stated as one.

### F. Does it explain the pattern, not just the instance?

18. First occurrence: when did this signature first appear, and does the hypothesis explain why then?
19. Frequency: how often does it occur, and does the hypothesis predict that rate from the trigger's rate?
20. Scope: which executions fail and which do not. Does the hypothesis draw the same line?

A hypothesis that explains one execution perfectly but cannot say why the other failures happened, or why the successes succeeded, is not yet a root cause.

## Reproduction and the counterfactual

The strongest verification is two experiments:

1. **Reproduce.** Under the claimed trigger, with the claimed defect present, the failure occurs. The mechanism is sufficient.
2. **Counterfactual.** Same trigger, claimed defect removed, nothing else changed: the failure does not occur. The mechanism is necessary.

Both are needed; a reproduction alone can be reproducing a different bug with the same symptom. Keep the experiment in the investigation directory: it is evidence and it is the fix's acceptance test.

Rules: scratch copies and test environments only. Never restart a service, mutate production state or expose data. For timing-dependent failures, make the timing deterministic rather than hoping. For intermittent failures, state the run counts and the observed rates before and after, and remember that 0 of 50 after a fix is suggestive, not conclusive, at a 3-in-50 base rate.

## Looking for what the tournament missed

You are the last line against shared blind spots: every investigator had the same brief and usually the same underlying model.

- **Question the brief.** What did everyone take as given that is actually an assumption? The time zone of the timestamps. Which host served the request. Which version was deployed. That the pasted error was the first error.
- **Look upstream of the entry point.** Investigations start where the logs start. The cause may be in the client, the load balancer, the scheduler or the message producer.
- **Look at the neighbours.** What else failed, slowed or warned in that window on unrelated executions? A process-wide cause looks local from inside one execution.
- **Look for the second defect.** The incident's *impact* (a 500, a leak, corrupted state) often has its own root cause, distinct from the failure's.
- **Ask what the fix would not fix.** List the ways the same symptom could still occur after it.

## Your result

| Result | When |
|---|---|
| `pass` | Ledger sound; path independently re-derived and matching; all predictions tested and confirmed, or genuinely untestable with reasons; at least one confirmation discriminating; falsifiers sought and not found; standard alternatives excluded |
| `partial` | Nothing contradicts it, and something is missing: untested predictions, an unobserved inferred step that matters, an unexamined standard alternative, an unconfirmed deployed version, or non-independent roles |
| `fail` | A refuted prediction; or a contradicting FACT it cannot explain; or the path does not hold; or a simpler explanation fits the evidence at least as well |

You may also return: "not refuted, and the evidence is insufficient to establish it." That is `partial` with a recommendation of PROVISIONAL or INSUFFICIENT, and it is often the correct answer.

Then hand the orchestrator the result, the re-score inputs, and `verification.md`.

## Verifying findings too

For each finding someone proposes to mark `confirmed`: it must have FACT-grade evidence of the defect itself (not merely of code that looks risky), and an independent check, and `verified_by` filled. Where a cheap check exists, run it: in the sample incident, the leak found by a losing hypothesis was confirmed by one log line and one source read. Everything else stays `suspicious` or `unverified` with a `suggested_check`.

## Common mistakes

| Mistake | Correction |
|---|---|
| Re-reading the author's reasoning and finding it convincing | You were given files, not arguments, on purpose |
| Checking that the evidence is consistent with the hypothesis | Consistency is cheap. Look for what would refute it |
| Accepting a confirmed prediction that a rival also predicts | Note that it is non-discriminating |
| Confirming a prediction from an excerpt without opening the file | `recheck` and your own reading are the point |
| Passing because nothing contradicted it | `pass` requires that you *tried*: falsifiers sought, alternatives excluded, a prediction of your own tested |
| Treating a reproduction as a counterfactual | Removing the cause and seeing the failure disappear is the other half |
