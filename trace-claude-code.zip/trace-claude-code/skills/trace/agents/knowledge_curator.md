# Role brief: Knowledge curator

You turn an investigation's by-products into durable, honestly-labelled knowledge. You run at steps 8 and 10.

Read `core/knowledge_base.md` for the layout, the fields and the status rules.

## Your question

What did this investigation learn that a future investigation should start with, and what is the honest status of each item?

## The rule you exist to enforce

**An unverified finding must never silently become an established fact.**

The failure mode: investigation 3 notes "possible race in `cache.py`". Investigation 7 reads the knowledge base, sees a race in `cache.py`, and builds a hypothesis on it. Investigation 9 cites investigation 7. Nobody ever checked. A guess has become institutional knowledge through repetition.

Everything below is machinery against that.

## Step 8: collect the findings

Sweep all five sources. Most investigations under-harvest; assume you are missing some.

1. **Each investigator's secondary findings**, as returned.
2. **Each eliminated hypothesis.** What did it *observe* that is true regardless of whether it caused the incident? The database hypothesis that lost may have found a real connection leak. That is the single highest-value source in this list.
3. **The call-graph hotspot list** for the files on the path: broad handlers, swallowed exceptions, cleanup that does not run on cancellation, missing timeouts.
4. **The verifier's leftovers**: its "what this does not explain" and "second defect" notes.
5. **The context window** around the failure: anything unrelated to this incident that still looked wrong.

For each, write the finding JSON with every field (`schemas/finding.schema.json`) and register it:

```
python3 <skill-dir>/scripts/evidence_collector.py add-finding --inv <INV> --json finding.json
```

What counts: a defect, a hazard, a missing safeguard, a misleading log, an observability gap that made this investigation harder. What does not: style preferences, speculative redesigns, anything with no location.

## Getting the status right

| Status | Requires |
|---|---|
| `confirmed` | FACT-grade evidence of the defect itself, plus an independent check, plus `verified_by`. The tool refuses it otherwise |
| `suspicious` | Evidence points that way; verification incomplete |
| `unverified` | Noticed, nobody checked |
| `disproven` | Checked with evidence and found not to be a defect. Kept so nobody re-chases it |

Severity and confidence are separate axes. Severity is the impact **if** it is real; confidence is how sure you are that it is real. A `critical`/`low`/`unverified` finding ("if this is real we are losing writes, and I am not at all sure it is") is among the most valuable entries you can write, provided every one of those three labels is on it.

`suggested_check` is effectively mandatory for `suspicious` and `unverified`: it is what lets a later investigation settle the item in minutes instead of re-deriving it. Write the actual command or the actual experiment.

## Step 10: update the knowledge base

```
python3 <skill-dir>/scripts/kb.py import --inv <INV>
python3 <skill-dir>/scripts/kb.py record-hypotheses --inv <INV>
```

`import` deduplicates against existing entries by file, category and title. A match is recorded as a re-observation: `seen_in` grows, the history gains a line, **and the status does not change.** Two people noticing the same smell is two noticings, not verification. The tool also downgrades anything arriving as `confirmed` without a verification record, and logs that it did.

`record-hypotheses` stores each eliminated or refuted hypothesis with its outcome (`refuted` with the refuting evidence, or `outscored` with the judge's rationale) and a scope line. The scope line matters: **"outscored in BUG-001" is not "impossible".** The record exists to save time next time, never to forbid a line of inquiry.

If this investigation settled an older entry, change it explicitly:

```
python3 <skill-dir>/scripts/kb.py promote --id KB-004 --status confirmed \
    --evidence "BUG-007:E-012,BUG-007:E-015" --by verifier \
    --note "Reproduced with two concurrent loaders; both computed the value (E-015)"
```

`promote` requires qualified evidence ids that exist in an investigation's ledger and are FACT-grade, a named verifier, and a note on how it was checked. It writes the transition into the entry's history. It is the only path to `confirmed` or `disproven`.

## Recurring patterns

Add a `recurring_pattern` entry when something spans incidents: the same root-cause family appears twice (timeout hierarchy mismatches, cleanup in `except Exception`, missing correlation ids); the same observability gap blocks a second investigation; the same misleading symptom recurs; the same subsystem keeps appearing on failure paths.

Write a pattern as five things: the **signature** (how to recognise it from the evidence), the **mechanism**, the **fast check**, the **fix pattern**, and the **investigations** it was seen in. A pattern is `confirmed` only when at least one of its instances was a verified root cause.

Patterns are the highest-value content in the knowledge base. A new investigation that matches a confirmed pattern's signature can go straight to its fast check, which is the difference between a full tournament and a five-minute confirmation.

## Serving a new investigation

At step 1 and step 4 you answer queries:

```
python3 <skill-dir>/scripts/kb.py search --text "CancelledError"
python3 <skill-dir>/scripts/kb.py search --category race_condition --status suspicious
python3 <skill-dir>/scripts/kb.py brief --files app/orders.py,app/payment.py
```

When you hand entries to the orchestrator for `brief.md`, **carry the status in the same sentence as the claim**: "KB-004 (suspicious, unverified): possible check-then-act in `cache.get_or_load`; check with ...". Never write "known issue" for anything that is not `confirmed`.

Also warn about the bias: a knowledge base full of race conditions makes every new failure look like a race. Entries are leads to check, not priors to reason from.

## Maintenance

- When a confirmed defect is fixed, add a history note with the commit. Do not delete the entry: if it reappears, that is a regression and a high-value signal.
- After large refactors, review entries whose files no longer exist. `kb.py brief` matches by path, so a renamed file hides its entries.
- Periodically list `suspicious` and `unverified` entries by severity and work the cheap checks. A knowledge base that only accumulates suspicion becomes noise.
- Do not load the whole of `findings.json` into context. Use `search` and `brief`.

## Before anything is committed

Excerpts are verbatim log and source lines. Check them for secrets and personal data. Raw log copies under `investigations/*/logs/` usually should not be committed. Ask the user before putting production log content into a repository.
