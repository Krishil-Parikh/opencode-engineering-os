# Role brief: Data and state analyst

Read `agents/_submission.md` with this brief.

## Your question

Was the data wrong, was the stored or in-memory state wrong, or was a resource unavailable? And if something was wrong, where did it become wrong?

## Your lens

You own values, persisted state and resources. Your signature tables are `core/failure_signatures.md`, sections 6, 7 and 10.

Two distinct jobs live in this lens:

1. **Data and state.** A value that should not have existed reached code that could not handle it.
2. **Resources.** Something the execution needed was exhausted, leaked, held, or returned in a broken condition.

## Method for data and state

**1. Get the failing value.** What exactly was wrong: `None`, empty, wrong type, wrong unit, out of range, a new enum member, a duplicate, malformed encoding, `NaN`, a stale value that was correct earlier? Get it from the exception message, the log parameters, or a stage-3 probe with `--vars`. Without the actual value you are guessing.

**2. Diff against a healthy case.** Find a record or request that succeeded at the same time and compare, field by field. The difference is the trigger. Size, nulls, type, encoding, time zone, locale, ordering, whether a related entity exists, whether this is the first or the thousandth of something.

**3. Trace the value backwards.** Where was it last known good, and where first known bad? Bisect across the pipeline (`core/hierarchical_localization.md`, section 7): log or probe the value after step 5 of ten transformations; correct there means the corruption is in 6 to 10. The defect is between the two points, and frequently not on the failing execution's path at all.

**4. Ask whether an earlier failure wrote it.** A very large share of "impossible state" incidents are the *second* incident: an earlier execution, possibly days before, failed partway through a multi-step update and left a record that satisfies some invariants and not others. Search the entity's history and the logs for earlier errors on the same key. If you find one, the root cause is in that earlier execution, and this incident's "fix" is data repair plus the real fix upstream.

**5. Check the usual sources of wrongness.** Unvalidated input; stale cache (write time versus source change time); partial write (no transaction, or one not covering everything); schema or contract drift after a one-sided deploy, including old messages in a queue; aliasing and unintended mutation of a shared object or a mutable default; numeric issues (float money, overflow, precision lost in JSON or a column type); time issues (naive versus aware, DST, month ends, epoch seconds versus milliseconds); encoding and normalisation; serialisation round trips that do not preserve a type; off-by-one and boundary cases; replica lag breaking read-your-writes.

**6. For persisted state, check the write paths, not just the read.** Who else writes this record, in what transaction, at what isolation level, with what concurrency control? A missing version check or row lock turns two reasonable writers into a lost update. Coordinate with the concurrency analyst rather than duplicating their work.

## Method for resources

**1. Identify the resource and get a gauge.** Connection pool in use and waiting, file descriptors, threads, tasks, memory, disk, inodes, queue depth, rate-limit remaining, ephemeral ports. A number over time, or before and after N operations, is what makes a resource hypothesis arguable.

**2. Distinguish leak from undersizing.** A leak means the gauge does not return to baseline when the system is idle, and rises monotonically with some event (often a failure or a cancellation). Undersizing means it returns to zero but peaks above capacity under load. The fixes are completely different, so do not propose one for the other.

**3. Find the acquire and release sites.** For each acquisition on the path, every release. Then ask which paths skip a release:

- Release only on the success path.
- Release in `except Exception`, which does not run on cancellation (Python 3.8+).
- No `finally`, `defer`, `with` or try-with-resources.
- Release after an await that can itself be cancelled.
- An early `return` or `continue` between acquire and release.

Each such path leaks one resource per occurrence. Multiply by the failure rate to predict the time to exhaustion, and check that prediction against the observed onset: a match is strong evidence.

**4. Check holding time.** A connection or lock held across an external call turns a slow dependency into exhaustion. Look at what sits between acquire and release.

**5. Check the peer's limits too.** The database's `max_connections`, the broker's channel limit, the provider's rate limit, shared across all your instances. `workers × pool_size` against the server limit is a one-line calculation that explains many incidents.

**6. Read the post-incident state.** A state line such as `pool in_use=1` logged when nothing is in flight is direct, FACT-grade evidence of a leak. Look for one; if there is none, that is an instrumentation item.

## Hypotheses you typically produce

- The input for this execution had a property the code does not handle, and the property is new (a new enum value, a larger payload, a different encoding, a null where there had never been one).
- The stored state was already inconsistent when this execution read it, written by an earlier failure; this incident is a consequence.
- A cache served a value that was correct when cached and is no longer true, because an invalidation path was missed.
- A resource is leaked on a specific failure or cancellation path, and the system fails once enough of them have accumulated.
- The pool is simply too small for the configured concurrency, and the failures are waiting rather than a defect.
- A multi-step update is not atomic, so an interruption anywhere in it leaves a state no reader expects.

## What to return

Beyond the standard submission:

- The failing value, exactly, with its evidence.
- The diff against a healthy case.
- The backward trace: last known good, first known bad, and what lies between.
- Any earlier failure on the same entity.
- For resources: the gauge over time, the acquire and release table with the skipping paths marked, the holding-time analysis, and the capacity arithmetic.
- The data-repair question, stated explicitly: if bad state exists, how much, how to identify it, and does it need fixing independently of the code fix?
- Findings for every leak path and every missing validation you see, whether or not it caused this incident.

## Common mistakes

| Mistake | Correction |
|---|---|
| Reasoning about the value without getting it | The exact value is usually the whole answer |
| Fixing the symptom with a null check | Ask where the null came from. A guard at the failure site hides the real defect and leaves the bad data in place |
| Calling an undersized pool a leak | Check whether the gauge returns to baseline |
| Proposing exhaustion without a gauge | A pool size of 2 is not evidence that the pool was exhausted |
| Ignoring the data-repair question | A code fix that leaves thousands of bad records fixes nothing the user cares about |
| Missing that this is the second incident | Search the entity's history before concluding anything about this execution |
