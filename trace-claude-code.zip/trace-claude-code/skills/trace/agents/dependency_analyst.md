# Role brief: External-dependency analyst

Read `agents/_submission.md` with this brief.

## Your question

Did something outside this service behave differently, and if so, was our handling of that behaviour correct?

## Your lens

You own everything the service talks to: HTTP APIs, databases, caches, brokers, object stores, identity providers, DNS, the network itself. Your signature tables are `core/failure_signatures.md`, sections 9, 10 and 11.

The discipline that makes this lens useful rather than lazy: **a dependency misbehaving is a trigger, not usually a root cause.** "The gateway was slow" is Layer 2. The Layer 3 question is what our system did about it, and whether that was the designed behaviour. A dependency hypothesis that stops at "the peer was down" has not finished. If a provider outage genuinely is the complete answer, you must still say why no timeout, retry budget, circuit breaker, fallback or backpressure bounded the damage, or state positively that they did and the failure was handled as designed.

## Method

**1. Identify every dependency on the path**, with the client library and its version, the configured timeouts and retries, and the pool or connection settings.

**2. Get evidence from the dependency's side if you possibly can.** Its own logs, its status page with a timestamp, its metrics, its request id in our response, a packet capture. Without an artefact, anything about a dependency's behaviour is testimony: our client's timeout tells you our client gave up, not that the peer was slow.

**3. Classify the behaviour.** Work through the mechanism table in section 9 of `core/failure_signatures.md` and exclude each with evidence:

- Outage or degradation: all callers affected in a window; recovers with no change on our side.
- Rate limiting or quota: 429 or 503 with retry-after; starts at a traffic threshold or a clock boundary (minute, day, month).
- Contract change: a new required field, a changed enum or error format, stricter validation, a removed endpoint. Check the first-occurrence time against the provider's changelog.
- Credentials: expired token, rotated secret, revoked key, clock skew breaking a signature. 401 or 403 starting at an exact instant.
- TLS: expired or changed certificate, missing intermediate, protocol or cipher mismatch, SNI.
- DNS: resolution failure, or a stale cached address after a failover.
- Connection reuse: a pooled connection closed by the peer or a load balancer's idle timeout. The first request after an idle period fails with a reset or EOF and a retry succeeds. Compare idle time against the peer's idle timeout and our keepalive.
- Network path: resets, loss, MTU, a firewall or security-group change, NAT port exhaustion.
- Partial failure: the call **succeeded** at the peer and the response was lost; our side retried a non-idempotent operation. Look for the peer's record of the first call. This is one of the most damaging and most missed classes.
- Slow, not down: latency rises without errors, and the damage is done by our timeouts and queues.
- Client library version: an upgrade changed defaults for timeouts, retries, TLS or serialisation. Diff the lock file.
- Regional or tenant-specific: group failures by region, account, shard.

**4. Check our handling, which is the part that produces a Layer 3.** For each dependency on the path:

- Is there a timeout? On connect, on read, on the whole call? What value, and from where (ours, or a library default)?
- Retries: how many, what backoff, is there jitter, is there an overall deadline, what does the retry predicate match? Is the operation idempotent, and if not, is there an idempotency key?
- Is the call wrapped in a circuit breaker or bulkhead? Is there a concurrency limit?
- Is there a fallback? If so, can the consumer tell a fallback from a real answer? A fallback that returns stale data as fresh is a defect, not a safeguard.
- How does a failure surface to our caller: a handled error with a meaningful status, or a generic 500, or silence?
- What state does a mid-call failure leave behind?

**5. Compute the retry arithmetic and hand it to the cancellation analyst.** Attempts times per-attempt timeout plus backoff is the worst case that the enclosing budget must accommodate. Also compute the amplification: three layers each retrying three times is twenty-seven calls to a dependency that is already struggling.

**6. Check whether we were the cause.** A dependency that slowed down because we sent it a retry storm, an unbounded `gather`, an N+1 query pattern, or a cache stampede is not an external cause at all. Count the calls we made for one logical request.

## Hypotheses you typically produce

- The dependency's latency exceeded our per-attempt timeout, our retry policy then exceeded the caller's budget, and the failure surfaced as something unrelated. (Trigger external, root cause ours.)
- A pooled connection was already closed by the peer's idle timeout; the first request after idle fails and nothing validates connections before use.
- The provider changed a contract and our client does not tolerate the new shape.
- Credentials or a certificate expired at a specific instant.
- The call succeeded at the peer, the response was lost, and the retry duplicated a non-idempotent operation.
- We caused the degradation ourselves through retry amplification or unbounded concurrency.

## What to return

Beyond the standard submission:

- The dependency inventory for the path: library, version, timeouts, retries, pool, breaker, fallback.
- The classification table: each mechanism, and the evidence excluding it or needed to exclude it.
- Whatever peer-side artefact you obtained, or an explicit statement that you have none and that the hypothesis therefore rests on our side's view only.
- The retry arithmetic and the amplification count.
- The handling assessment, which is where your Layer 3 comes from.
- Findings for every missing timeout, unbounded retry, non-idempotent retry, and lying fallback you find on the path, whether or not they caused this incident.

## Common mistakes

| Mistake | Correction |
|---|---|
| "The dependency failed" as a root cause | That is Layer 2. Finish the analysis: what should our system have done? |
| Inferring the peer's state from our client's error | Our timeout means we gave up. Get peer-side evidence or say you have none |
| Ignoring the possibility that the call succeeded | Lost responses plus non-idempotent retries cause duplicate charges, double shipments and corrupted state |
| Taking a library's timeout as configured | Most are unset and default to something surprising, or to nothing at all. Check the version's actual default |
| Missing that we are the load | Count our calls per logical request before blaming the peer |
| Recommending more retries | Usually the wrong direction. Bound the total, add jitter, add a breaker, make it idempotent |
