# How to submit a hypothesis (read this with your lens brief)

Every investigator in phase 2 returns the same artefact: one or more hypotheses in the schema, plus any secondary findings. This document is the format and the rules. Your lens brief says what to look for; this says how to hand it in.

## You work alone

You do not see other investigators' hypotheses before submitting. You have `brief.md`, the evidence ledger, the repository and the logs. If you find yourself writing "as the other agent noted", you have been contaminated: strike it.

Your brief contains no theory on purpose. Do not ask the orchestrator what it thinks. Do not treat the order of facts in the brief as a hint.

## Your lens is a place to look, not a conclusion to reach

You were dispatched because signals in the evidence matched your lens. That is a reason to look, not a reason to find. **"No hypothesis from this lens: the evidence shows nothing in my area, and here is what I checked"** is a valid and useful submission. A lens with nothing to say is information, and a forced hypothesis from a lens that does not fit wastes a duel and pollutes the knowledge base.

## The six parts

A hypothesis is admissible only with all six. They are the fields of `schemas/hypothesis.schema.json`, which is also the duel submission format.

| # | Part | Field |
|---|---|---|
| 1 | The proposed root cause, stated so that it could be wrong | `statement`, `layers` |
| 2 | Evidence from the logs | `evidence_for`, runtime-class ids |
| 3 | Relevant source-code locations | `evidence_for`, source-class ids |
| 4 | The exact execution path | `execution_path` |
| 5 | Why each competing hypothesis is less likely | `rival_rebuttals` |
| 6 | What evidence would disprove your own hypothesis | `falsifiers`, `predictions` |

Part 6 is the one that matters most and the one agents most often skimp. A hypothesis that cannot say what would disprove it is not competing, it is asserting, and it will be refused entry to the tournament.

In phase 2 you write part 5 blind: address the standard alternatives for this failure type (`core/failure_signatures.md`) rather than named rivals you have not seen. You will rewrite it against the real rival at the start of a duel.

## The three layers

`layers` has three fields and they are not interchangeable (`core/execution_reconstruction.md`, section 1):

- `failure_location` — Layer 1. Where the exception surfaced. A `file:line`.
- `trigger` — Layer 2. The event or condition that made it fail *this time*. Answers "why now and not the previous ten thousand times".
- `root_cause` — Layer 3. The standing property of the system that made the failure possible. It was true before the incident and is still true now.

Self-check before submitting: if your `root_cause` is a `file:line`, you have written Layer 1 in the Layer 3 field. If it is something that happened, you have written Layer 2. If fixing it would not stop the same trigger from causing the same failure, it is incomplete.

## The execution path

Ordered, outermost first. Each step: what ran, where, and whether it was **observed**.

```json
"execution_path": [
  {"step": "api_handler()", "location": "app/api.py:10", "observed": true, "evidence": ["E-001", "E-004"]},
  {"step": "process_payment() attempt 2 awaiting external_payment_api()", "location": "app/payment.py:23", "observed": true, "evidence": ["E-004"]},
  {"step": "api_handler budget expires, task.cancel()", "location": "app/api.py:15", "observed": false, "evidence": ["E-005", "E-003"]}
]
```

`observed: true` requires a runtime artefact for that step: a log line it emitted, a span, a stack frame, or a probe. A step deduced from code and timing is `observed: false` however certain it feels. Marking an inferred step as observed will be caught by the verifier and will cost you the duel.

Include steps from *other* flows that act on this one (the canceller, the other writer), placed where they take effect. Honest `false` marks are not a weakness: they tell the orchestrator exactly which observation would raise confidence, and that observation becomes a prediction or an instrumentation item.

## Predictions

A prediction is: "if this hypothesis is true, then X is observable by doing Y." Each needs an id, a statement, a concrete check, and status `untested`.

```json
"predictions": [
  {"id": "P1", "statement": "The failure is logged exactly one request budget after the request was received, regardless of what the payment client was doing",
   "check": "Compare the timestamps of 'request received' and 'request failed' for req-b2", "status": "untested", "evidence": []},
  {"id": "P2", "statement": "With the request budget raised above the retry worst case, the same slow order ends in RuntimeError, not CancelledError",
   "check": "Re-run the failing request in a scratch copy with REQUEST_TIMEOUT_S=3.0", "status": "untested", "evidence": []}
]
```

Make them **discriminating**: a prediction a rival would also make tests nothing and scores nothing. "The error will appear in the log" is worthless. "The gap will be exactly 1.0s and not 2.4s" separates two hypotheses.

Prefer predictions that can be checked from evidence that already exists. Those get tested immediately. Next best: an isolated experiment. Last: instrumentation for the next occurrence.

Also state, for each, what result would **refute** you. If no result would, it is not a test.

## Falsifiers

Plain sentences naming the observations that would prove you wrong. Write them as though you expect someone to go looking, because someone will.

```json
"falsifiers": [
  "The gap between 'request received' and 'request failed' is not about 1.0s",
  "The outermost frame of the trace is not the caller awaiting the task it cancelled",
  "Raising the request budget above the retry worst case still yields CancelledError"
]
```

## Assumptions

Anything you believe and did not check goes in `assumptions`, in plain words. This is not a confession, it is a work list for the verifier. Hiding an assumption and having the verifier find it is far worse than declaring it.

## Evidence

- Cite ledger ids. Every claim in your statement and rebuttals must trace to one.
- Need something not yet in the ledger? Propose it: class, grade, file and line range (or the exact command), and a one-sentence neutral summary. The orchestrator adds it with the tool, which **re-reads the file**. If the lines do not say what you claimed, the item is rejected and you are told. Do not paraphrase, tidy, or reconstruct an excerpt from memory.
- Grade honestly (`core/evidence_protocol.md`, section 2). What the code *says* is a FACT about the source. What it *does at runtime* is a prediction until something observed it.
- Knowledge-base entries: carry their status in the same sentence. Only `confirmed` entries may be relied on; anything else must be re-established with fresh evidence in this ledger, and doing so becomes one of your predictions.

## Secondary findings

Anything you noticed that looks wrong but did not cause this incident still goes in, in the finding schema. This is not optional and it is not a consolation prize: a leak found while chasing a wrong hypothesis is one of the most valuable things an investigation produces.

```json
{
  "title": "send_confirmation swallows every exception silently",
  "file": "app/orders.py", "line": 14,
  "description": "A bare `except Exception: pass` hides any failure to send the confirmation. Nothing is logged, so a customer could be charged without being notified and no log line would show it.",
  "evidence": [], "severity": "medium", "confidence": "medium",
  "status": "suspicious", "verified": false,
  "related_to_original_bug": "no", "category": "unhandled_exception",
  "discovered_by": "<your role>",
  "suggested_check": "Pass a customer dict with a malformed email and confirm that no log line is produced"
}
```

Status must be honest: `confirmed` only with FACT evidence of the defect and an independent check (which you cannot give your own finding), otherwise `suspicious` or `unverified`. Severity is impact if real; confidence is how sure you are it is real. A `critical`/`low` finding is legitimate and valuable, as long as its status says `unverified`.

## What you return

1. One JSON file per hypothesis, in the schema.
2. One JSON file per secondary finding.
3. A short note, in prose, of: what you checked and found nothing in, which assumptions you had to make, and the single observation that would most help your lens. Mark it clearly as notes, not evidence.

Do not return a narrative essay. The ledger and the schema carry the argument.

## Rules that get hypotheses rejected

- A `root_cause` that is a location or an event.
- An `execution_path` with inferred steps marked observed.
- No falsifier, or no prediction with a concrete check.
- A claim with no evidence id.
- An excerpt that does not match the file.
- "Probably", "likely", "must have" in the `statement` without a corresponding assumption or inference-grade citation.
- Two hypotheses from you that assert the same Layer 3 root cause: merge them yourself before submitting.
