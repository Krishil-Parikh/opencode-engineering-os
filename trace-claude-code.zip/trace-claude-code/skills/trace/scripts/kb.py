#!/usr/bin/env python3
"""TRACE knowledge base: persistent debugging intelligence across investigations.

Losing hypotheses often uncover real problems that are not the bug being
chased. Those findings are kept here so later investigations start with them.
The one rule this tool enforces above all others:

    An unverified finding never silently becomes an established fact.

Every finding carries an explicit status (confirmed | suspicious | unverified |
disproven) and can only become `confirmed` through `promote`, which demands
evidence and a named verifier and records the transition in its history.

Usage:
    kb.py import  --inv debugging/investigations/BUG-001   (copy that investigation's findings into the KB)
    kb.py search  [--file services/payment.py] [--text "pool"] [--category race_condition] [--status suspicious]
    kb.py promote --id F-003 --status confirmed --evidence "BUG-004:E-012" --by verifier --note "reproduced under load"
    kb.py promote --id F-002 --status disproven --evidence "BUG-004:E-015" --by verifier --note "pool is recycled, see ..."
    kb.py record-hypotheses --inv INV     (store eliminated/refuted hypotheses so they are not re-chased blindly)
    kb.py render  [--root debugging]      (regenerate the markdown files and index.md from findings.json)
    kb.py brief   --files a.py,b.py       (what a new investigation should know about these files)
"""
from __future__ import annotations

import argparse
import os
import sys
from typing import Any, Dict, List

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import (FINDING_STATUSES, die, find_workspace, load_json, load_schema, next_id, now_iso,  # noqa: E402
                     save_json, validate)

CATEGORY_FILES = {
    "race_condition": ("known_race_conditions.md", "Known race conditions"),
    "suspicious_function": ("suspicious_functions.md", "Suspicious functions"),
    "dependency_failure": ("dependency_failures.md", "Dependency failures"),
    "unhandled_exception": ("unhandled_exceptions.md", "Unhandled exceptions"),
    "recurring_pattern": ("recurring_patterns.md", "Recurring patterns"),
    "resource_leak": ("resource_leaks.md", "Resource leaks"),
    "other": ("other_findings.md", "Other findings"),
}
STATUS_TITLES = [
    ("confirmed", "Confirmed defects", "Verified with evidence. Safe to rely on."),
    ("suspicious", "Suspicious patterns", "Evidence points this way but verification is incomplete. Treat as a lead."),
    ("unverified", "Unverified observations", "Noticed, not checked. Do NOT cite as fact. Verify before use."),
    ("disproven", "Disproven", "Checked and found not to be a problem. Kept so nobody re-chases it."),
]


def root_of(args: argparse.Namespace) -> str:
    root = getattr(args, "root", None)
    if getattr(args, "inv", None) and not root:
        root = os.path.dirname(os.path.dirname(os.path.abspath(args.inv)))
    root = root or find_workspace() or "debugging"
    if not os.path.isdir(os.path.join(root, "knowledge_base")):
        die("no knowledge base at %s (run workspace.py init)" % root)
    return root


def kb_path(root: str) -> str:
    return os.path.join(root, "knowledge_base", "findings.json")


def load_kb(root: str) -> Dict[str, Any]:
    data = load_json(kb_path(root), default={"findings": [], "disproven_hypotheses": []})
    data.setdefault("findings", [])
    data.setdefault("disproven_hypotheses", [])
    return data


def same_finding(a: Dict[str, Any], b: Dict[str, Any]) -> bool:
    return (a.get("file") == b.get("file") and a.get("category") == b.get("category")
            and a.get("title", "").strip().lower() == b.get("title", "").strip().lower())


def cmd_import(args: argparse.Namespace) -> None:
    root = root_of(args)
    kb = load_kb(root)
    inv_findings = load_json(os.path.join(args.inv, "findings.json"), default={"findings": []})
    bug = os.path.basename(os.path.normpath(args.inv))
    schema = load_schema("finding.schema.json")
    added = updated = 0
    for f in inv_findings["findings"]:
        errors = validate(f, schema)
        if errors:
            die("finding %s is invalid:\n  %s" % (f.get("id"), "\n  ".join(errors)))
        existing = next((k for k in kb["findings"] if same_finding(k, f)), None)
        qualified = ["%s:%s" % (bug, e) for e in f.get("evidence", [])]
        if existing:
            if bug not in existing.setdefault("seen_in", []):
                existing["seen_in"].append(bug)
            existing["last_seen"] = now_iso()
            for q in qualified:
                if q not in existing.setdefault("evidence_refs", []):
                    existing["evidence_refs"].append(q)
            existing.setdefault("history", []).append({
                "at": now_iso(), "event": "seen again in %s as %s (%s)" % (bug, f["id"], f["status"])})
            # Re-observation alone never upgrades status. A second sighting is still not verification.
            updated += 1
            continue
        entry = dict(f)
        entry["source_id"] = "%s:%s" % (bug, f["id"])
        entry["id"] = next_id("KB", [k["id"] for k in kb["findings"]])
        entry["evidence_refs"] = qualified
        entry["evidence"] = []
        entry["seen_in"] = [bug]
        entry["last_seen"] = now_iso()
        if entry["status"] == "confirmed" and not (entry.get("verified") and qualified and entry.get("verified_by")):
            entry["status"] = "suspicious"
            entry["verified"] = False
            entry.setdefault("history", []).append({
                "at": now_iso(), "event": "imported as suspicious: marked confirmed in %s without verification record" % bug})
        entry.setdefault("history", []).append({"at": now_iso(), "event": "imported from %s as %s" % (bug, entry["status"])})
        kb["findings"].append(entry)
        added += 1
    save_json(kb_path(root), kb)
    print("knowledge base: %d added, %d re-observed (status unchanged)" % (added, updated))
    render(root)


def cmd_promote(args: argparse.Namespace) -> None:
    root = root_of(args)
    kb = load_kb(root)
    entry = next((k for k in kb["findings"] if k["id"] == args.id), None)
    if not entry:
        die("unknown knowledge-base id %s" % args.id)
    if args.status not in FINDING_STATUSES:
        die("--status must be one of " + ", ".join(FINDING_STATUSES))
    if args.status in ("confirmed", "disproven"):
        if not args.evidence or not args.by or not args.note:
            die("moving a finding to '%s' requires --evidence BUG-xxx:E-yyy, --by <verifier> and --note <how it was checked>" % args.status)
        for ref in args.evidence.split(","):
            ref = ref.strip()
            if ":" not in ref:
                die("evidence must be qualified as BUG-xxx:E-yyy, got %r" % ref)
            bug, eid = ref.split(":", 1)
            ledger = load_json(os.path.join(root, "investigations", bug, "evidence.json"), default=None)
            if ledger is None:
                die("investigation %s not found under %s" % (bug, root))
            item = next((i for i in ledger["items"] if i["id"] == eid), None)
            if not item:
                die("%s has no evidence item %s" % (bug, eid))
            if item["grade"] != "FACT":
                die("%s is %s-grade; a status change to '%s' needs FACT-grade evidence" % (ref, item["grade"], args.status))
            if ref not in entry.setdefault("evidence_refs", []):
                entry["evidence_refs"].append(ref)
    old = entry["status"]
    entry["status"] = args.status
    entry["verified"] = args.status in ("confirmed", "disproven")
    if entry["verified"]:
        entry["verified_by"] = args.by
    entry.setdefault("history", []).append({
        "at": now_iso(), "event": "%s -> %s" % (old, args.status), "by": args.by or "", "note": args.note or "",
        "evidence": args.evidence or ""})
    save_json(kb_path(root), kb)
    print("%s: %s -> %s" % (entry["id"], old, args.status))
    render(root)


def cmd_record_hypotheses(args: argparse.Namespace) -> None:
    root = root_of(args)
    kb = load_kb(root)
    bug = os.path.basename(os.path.normpath(args.inv))
    hyps = load_json(os.path.join(args.inv, "hypotheses.json"))
    n = 0
    for h in hyps["items"]:
        if h["status"] not in ("eliminated", "refuted"):
            continue
        key = "%s:%s" % (bug, h["id"])
        if any(d["ref"] == key for d in kb["disproven_hypotheses"]):
            continue
        refuted = [p for p in h.get("predictions", []) if p.get("status") == "refuted"]
        kb["disproven_hypotheses"].append({
            "ref": key, "title": h["title"], "statement": h["statement"], "lens": h.get("lens"),
            "outcome": "refuted" if refuted or h["status"] == "refuted" else "outscored",
            "why": "; ".join("%s refuted (%s)" % (p["id"], ", ".join(p.get("evidence", []))) for p in refuted)
                   or (h.get("scores") or {}).get("rationale", "lost on evidence score"),
            "total": (h.get("scores") or {}).get("total"), "recorded_at": now_iso(),
            "scope": "Applies to %s only. 'Outscored' is NOT 'impossible': the same cause can be real in another incident." % bug})
        n += 1
    save_json(kb_path(root), kb)
    print("recorded %d eliminated hypothesis(es) from %s" % (n, bug))
    render(root)


def matches(entry: Dict[str, Any], args: argparse.Namespace) -> bool:
    if args.file and args.file not in (entry.get("file") or ""):
        return False
    if args.category and entry.get("category") != args.category:
        return False
    if args.status and entry.get("status") != args.status:
        return False
    if args.text:
        blob = " ".join(str(entry.get(k, "")) for k in ("title", "description", "file", "suggested_check")).lower()
        if args.text.lower() not in blob:
            return False
    return True


def fmt(entry: Dict[str, Any]) -> str:
    loc = "%s:%s" % (entry.get("file"), entry.get("line")) if entry.get("line") else str(entry.get("file"))
    return "%s  [%s%s]  %s/%s  %s  %s  (seen in %s)" % (
        entry["id"], entry["status"].upper(), "" if entry.get("verified") else ", NOT VERIFIED",
        entry.get("severity"), entry.get("confidence"), loc, entry["title"], ", ".join(entry.get("seen_in", [])))


def cmd_search(args: argparse.Namespace) -> None:
    kb = load_kb(root_of(args))
    hits = [k for k in kb["findings"] if matches(k, args)]
    for k in hits:
        print(fmt(k))
        print("      " + k["description"])
    if args.text:
        for d in kb["disproven_hypotheses"]:
            if args.text.lower() in (d["title"] + " " + d["statement"]).lower():
                print("%s  [PAST HYPOTHESIS, %s]  %s" % (d["ref"], d["outcome"], d["title"]))
    print("%d finding(s)" % len(hits))


def cmd_brief(args: argparse.Namespace) -> None:
    kb = load_kb(root_of(args))
    files = [f.strip() for f in args.files.split(",") if f.strip()]
    hits = [k for k in kb["findings"] if any(f in (k.get("file") or "") or (k.get("file") or "") in f for f in files)]
    if not hits:
        print("knowledge base has nothing on these files"); return
    print("Prior TRACE knowledge for this area. Status matters: only CONFIRMED entries are facts.\n")
    order = {s: i for i, s in enumerate(FINDING_STATUSES)}
    for k in sorted(hits, key=lambda e: order[e["status"]]):
        print("- " + fmt(k))
        print("    " + k["description"])
        if k.get("suggested_check") and k["status"] in ("suspicious", "unverified"):
            print("    verify with: " + k["suggested_check"])


def render(root: str) -> None:
    kb = load_kb(root)
    kbdir = os.path.join(root, "knowledge_base")
    for category, (fname, title) in CATEGORY_FILES.items():
        entries = [k for k in kb["findings"] if k.get("category") == category]
        out: List[str] = ["# %s" % title, "",
                          "_Generated by `kb.py render` from findings.json. Edit the JSON through kb.py, not this file._", ""]
        if not entries:
            out.append("_No entries yet._")
        for status, heading, blurb in STATUS_TITLES:
            group = [k for k in entries if k["status"] == status]
            if not group:
                continue
            out += ["## %s" % heading, "", "> %s" % blurb, ""]
            for k in group:
                loc = "%s:%s" % (k.get("file"), k.get("line")) if k.get("line") else str(k.get("file"))
                out += ["### %s: %s" % (k["id"], k["title"]), "",
                        "| Field | Value |", "|---|---|",
                        "| Location | `%s` |" % loc,
                        "| Severity | %s |" % k.get("severity"),
                        "| Confidence | %s |" % k.get("confidence"),
                        "| Status | **%s** |" % k["status"],
                        "| Verified | %s%s |" % ("yes" if k.get("verified") else "no",
                                                  " (by %s)" % k["verified_by"] if k.get("verified_by") and k.get("verified") else ""),
                        "| Related to original bug | %s |" % k.get("related_to_original_bug"),
                        "| Evidence | %s |" % (", ".join(k.get("evidence_refs", [])) or "none recorded"),
                        "| Seen in | %s |" % ", ".join(k.get("seen_in", [])),
                        "| Discovered by | %s |" % k.get("discovered_by"), "",
                        k["description"], ""]
                if k.get("suggested_check"):
                    out += ["**How to verify:** %s" % k["suggested_check"], ""]
                if k.get("history"):
                    out += ["<details><summary>History</summary>", ""]
                    out += ["- %s: %s%s" % (h["at"], h["event"], (" (%s)" % h["note"]) if h.get("note") else "") for h in k["history"]]
                    out += ["", "</details>", ""]
        with open(os.path.join(kbdir, fname), "w", encoding="utf-8") as fh:
            fh.write("\n".join(out).rstrip() + "\n")
    out = ["# Disproven hypotheses", "",
           "_Explanations that were tested and lost in a past investigation. Each entry is scoped to its incident: "
           "'outscored there' does not mean 'cannot happen here'._", ""]
    if not kb["disproven_hypotheses"]:
        out.append("_No entries yet._")
    for d in kb["disproven_hypotheses"]:
        out += ["## %s: %s" % (d["ref"], d["title"]), "", d["statement"], "",
                "- Outcome: **%s**%s" % (d["outcome"], (" (score %s)" % d["total"]) if d.get("total") is not None else ""),
                "- Why: %s" % d["why"], "- Scope: %s" % d["scope"], ""]
    with open(os.path.join(kbdir, "disproven_hypotheses.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(out).rstrip() + "\n")
    # index.md
    inv_dir = os.path.join(root, "investigations")
    rows = []
    for bug in sorted(d for d in os.listdir(inv_dir) if os.path.isdir(os.path.join(inv_dir, d))):
        ctx = load_json(os.path.join(inv_dir, bug, "context.json"), default={})
        tour = load_json(os.path.join(inv_dir, bug, "tournament.json"), default={})
        final = tour.get("final") or {}
        report = "[report](investigations/%s/final_report.md)" % bug if os.path.exists(os.path.join(inv_dir, bug, "final_report.md")) else "-"
        rows.append("| %s | %s | %s | %s | %s | %s |" % (bug, ctx.get("title", ""), ctx.get("first_observed", ""),
                                                        ctx.get("status", ""), final.get("confidence", "-"), report))
    counts = {s: sum(1 for k in kb["findings"] if k["status"] == s) for s in FINDING_STATUSES}
    idx = ["# TRACE debugging index", "", "## Investigations", "",
           "| ID | Title | First observed | Status | Confidence | Report |", "|---|---|---|---|---|---|"] + (rows or ["| - | none yet | | | | |"])
    idx += ["", "## Knowledge base", "",
            "| Confirmed | Suspicious | Unverified | Disproven | Past hypotheses |", "|---|---|---|---|---|",
            "| %d | %d | %d | %d | %d |" % (counts["confirmed"], counts["suspicious"], counts["unverified"],
                                            counts["disproven"], len(kb["disproven_hypotheses"])), ""]
    idx += ["- [%s](knowledge_base/%s)" % (title, fname) for fname, title in CATEGORY_FILES.values()]
    idx += ["- [Disproven hypotheses](knowledge_base/disproven_hypotheses.md)", "",
            "_Only entries marked **confirmed** are established facts. Everything else is a lead._"]
    with open(os.path.join(root, "index.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(idx) + "\n")


def cmd_render(args: argparse.Namespace) -> None:
    root = root_of(args)
    render(root)
    print("rendered knowledge base and index under " + root)


def main() -> None:
    ap = argparse.ArgumentParser(description="TRACE knowledge base")
    sub = ap.add_subparsers(dest="cmd")
    p = sub.add_parser("import"); p.add_argument("--inv", required=True); p.add_argument("--root"); p.set_defaults(fn=cmd_import)
    p = sub.add_parser("promote"); p.add_argument("--id", required=True); p.add_argument("--status", required=True)
    p.add_argument("--evidence"); p.add_argument("--by"); p.add_argument("--note"); p.add_argument("--root"); p.set_defaults(fn=cmd_promote)
    p = sub.add_parser("record-hypotheses"); p.add_argument("--inv", required=True); p.add_argument("--root"); p.set_defaults(fn=cmd_record_hypotheses)
    p = sub.add_parser("search"); p.add_argument("--file"); p.add_argument("--text"); p.add_argument("--category"); p.add_argument("--status")
    p.add_argument("--root"); p.set_defaults(fn=cmd_search)
    p = sub.add_parser("brief"); p.add_argument("--files", required=True); p.add_argument("--root"); p.set_defaults(fn=cmd_brief)
    p = sub.add_parser("render"); p.add_argument("--root"); p.set_defaults(fn=cmd_render)
    args = ap.parse_args()
    if not getattr(args, "fn", None):
        ap.print_help(); sys.exit(1)
    args.fn(args)


if __name__ == "__main__":
    main()
