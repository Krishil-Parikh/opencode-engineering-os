#!/usr/bin/env python3
"""TRACE stack-trace parser.

Extracts frames from Python, Node/TypeScript, Java/Kotlin and Go traces found
anywhere in a file (logs included), understands chained exceptions, and
separates application frames from library/runtime frames.

Usage:
    stacktrace_parser.py app.log [--root .] [--format text]
    some_command 2>&1 | stacktrace_parser.py - --root .

For each trace it reports:
    surface_frame   deepest frame overall       (where the exception was raised)
    failure_frame   deepest APPLICATION frame   (Layer 1: failure location)
    entry_frame     outermost application frame (where your code was entered)
    chain           cause / context links between exceptions

The surface location is Layer 1 only. It is where the failure became visible,
not necessarily where it was triggered or why it was possible.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
from typing import Any, Dict, List, Optional

RE_PY_HEAD = re.compile(r"Traceback \(most recent call last\):")
RE_PY_FRAME = re.compile(r'^\s*File "(?P<file>[^"]+)", line (?P<line>\d+), in (?P<func>.+?)\s*$')
RE_PY_EXC = re.compile(r"^(?P<type>[A-Za-z_][\w.]*)(?::\s*(?P<msg>.*))?$")
RE_PY_CAUSE = re.compile(r"The above exception was the direct cause of the following exception")
RE_PY_CONTEXT = re.compile(r"During handling of the above exception, another exception occurred")
RE_NODE_FRAME = re.compile(r"^\s*at (?:async )?(?:(?P<func>[^\s(]+(?: \[as [^\]]+\])?) \()?(?P<file>(?:file://)?[^():\s]+):(?P<line>\d+):(?P<col>\d+)\)?\s*$")
RE_NODE_HEAD = re.compile(r"^(?:Uncaught )?(?P<type>[A-Z][\w.]*(?:Error|Exception|Rejection)[\w.]*)(?::\s*(?P<msg>.*))?$")
RE_JAVA_FRAME = re.compile(r"^\s*at (?P<func>[\w.$<>]+)\((?P<file>[\w.$]+\.(?:java|kt|scala|groovy))(?::(?P<line>\d+))?\)\s*$")
RE_JAVA_HEAD = re.compile(r"^(?:Exception in thread \"[^\"]*\" |Caused by: )?(?P<type>(?:[a-z_][\w]*\.)+[A-Z][\w$]*(?:Exception|Error|Throwable)[\w$]*)(?::\s*(?P<msg>.*))?$")
RE_GO_HEAD = re.compile(r"^(?:panic: (?P<msg>.*)|goroutine (?P<gid>\d+) \[(?P<state>[^\]]+)\]:)$")
RE_GO_FILE = re.compile(r"^\s+(?P<file>/[^\s:]+\.go):(?P<line>\d+)(?: \+0x[0-9a-f]+)?\s*$")
RE_GO_FUNC = re.compile(r"^(?P<func>[\w./*()\[\]·-]+)\(.*\)\s*$")
RE_TS_PREFIX = re.compile(r"^\S*\d{2}:\d{2}:\d{2}\S*\s+(?:\S+\s+){0,3}?(?=Traceback|[A-Za-z_.]+(?:Error|Exception))")

LIBRARY_HINTS = (
    "site-packages", "dist-packages", "/lib/python", "\\lib\\python", "node_modules", "node:internal",
    "internal/", "<frozen", "/usr/lib/", "/usr/local/lib/", "/go/pkg/mod/", "/usr/local/go/src/",
    "GOROOT", "java.base/", "jdk.internal",
)
JAVA_LIB_PREFIXES = ("java.", "javax.", "jdk.", "sun.", "kotlin.", "kotlinx.", "scala.", "org.springframework.",
                     "org.apache.", "io.netty.", "reactor.", "com.sun.", "org.hibernate.", "com.zaxxer.")


def is_app_frame(frame: Dict[str, Any], root: Optional[str], lang: str) -> bool:
    path = frame.get("file") or ""
    if lang == "java":
        return not (frame.get("func") or "").startswith(JAVA_LIB_PREFIXES)
    if any(h in path for h in LIBRARY_HINTS):
        return False
    if root:
        cand = path.replace("file://", "")
        if cand.startswith("<"):
            return False
        parts = [p for p in cand.replace("\\", "/").split("/") if p]
        # A deployed path (/srv/app/services/x.py) rarely equals the local checkout path, so match by
        # the longest trailing sub-path that exists under the repository root.
        for i in range(len(parts)):
            if os.path.exists(os.path.join(root, *parts[i:])):
                return True
        return False
    return not path.startswith("<")


def finish(trace: Dict[str, Any], root: Optional[str]) -> Dict[str, Any]:
    lang = trace["language"]
    frames = trace["frames"]
    # Normalise order to outermost-first (Python/Go-goroutine already are; Node and Java are innermost-first).
    if lang in ("node", "java"):
        frames = list(reversed(frames))
    for f in frames:
        f["app"] = is_app_frame(f, root, lang)
    trace["frames"] = frames
    app = [f for f in frames if f["app"]]
    trace["surface_frame"] = frames[-1] if frames else None
    trace["failure_frame"] = app[-1] if app else None
    trace["entry_frame"] = app[0] if app else None
    trace["app_frame_count"] = len(app)
    trace["note"] = ("failure_frame is Layer 1 (where it surfaced in your code). "
                     "Trigger and root cause may be in a caller, another task, or another service.")
    return trace


def parse(text: str, root: Optional[str]) -> List[Dict[str, Any]]:
    lines = text.splitlines()
    traces: List[Dict[str, Any]] = []
    i = 0
    link_next: Optional[str] = None
    while i < len(lines):
        raw = lines[i]
        line = raw
        # ---------------- Python
        if RE_PY_HEAD.search(line):
            trace = {"language": "python", "start_line": i + 1, "frames": [], "exception_type": None,
                     "message": None, "link_to_previous": link_next}
            link_next = None
            i += 1
            while i < len(lines):
                m = RE_PY_FRAME.match(lines[i])
                if m:
                    frame = {"file": m.group("file"), "line": int(m.group("line")), "func": m.group("func"), "code": None}
                    if i + 1 < len(lines) and lines[i + 1].startswith("    ") and not RE_PY_FRAME.match(lines[i + 1]):
                        frame["code"] = lines[i + 1].strip()
                        i += 1
                    trace["frames"].append(frame)
                    i += 1
                    continue
                stripped = lines[i].strip()
                if stripped.startswith(("^", "~")) or stripped.startswith("[Previous line repeated"):
                    i += 1
                    continue
                m = RE_PY_EXC.match(stripped)
                if m and trace["frames"]:
                    trace["exception_type"] = m.group("type")
                    trace["message"] = m.group("msg")
                    i += 1
                break
            trace["end_line"] = i
            traces.append(finish(trace, root))
            continue
        if RE_PY_CAUSE.search(line):
            link_next = "caused_by_previous"   # previous trace is the direct cause (raise ... from)
            i += 1
            continue
        if RE_PY_CONTEXT.search(line):
            link_next = "raised_while_handling_previous"
            i += 1
            continue
        # ---------------- Go
        m = RE_GO_HEAD.match(line.strip())
        if m and (line.startswith("panic:") or line.startswith("goroutine ")):
            trace = {"language": "go", "start_line": i + 1, "frames": [], "exception_type": "panic" if m.group("msg") else "goroutine",
                     "message": m.group("msg") or ("goroutine %s [%s]" % (m.group("gid"), m.group("state"))),
                     "link_to_previous": None}
            i += 1
            pending: Optional[str] = None
            while i < len(lines):
                cur = lines[i]
                if not cur.strip():
                    if trace["frames"]:
                        break
                    i += 1
                    continue
                g = RE_GO_HEAD.match(cur.strip())
                if g and cur.startswith("goroutine ") and not trace["frames"]:
                    trace["message"] = (trace["message"] or "") + " | goroutine %s [%s]" % (g.group("gid"), g.group("state"))
                    i += 1
                    continue
                fm = RE_GO_FILE.match(cur)
                if fm and pending:
                    trace["frames"].append({"file": fm.group("file"), "line": int(fm.group("line")), "func": pending, "code": None})
                    pending = None
                    i += 1
                    continue
                fn = RE_GO_FUNC.match(cur.strip())
                if fn and not cur.startswith((" ", "\t")):
                    pending = fn.group("func")
                    i += 1
                    continue
                break
            trace["frames"].reverse()  # Go prints innermost first
            trace["end_line"] = i
            if trace["frames"]:
                traces.append(finish(trace, root))
            continue
        # ---------------- Java / Node (header line followed by "at ..." frames)
        stripped = line.strip()
        stripped = stripped[RE_TS_PREFIX.match(stripped).end():] if RE_TS_PREFIX.match(stripped) else stripped
        nxt = lines[i + 1] if i + 1 < len(lines) else ""
        jm = RE_JAVA_HEAD.match(stripped)
        nm = RE_NODE_HEAD.match(stripped)
        if (jm or nm) and (RE_JAVA_FRAME.match(nxt) or RE_NODE_FRAME.match(nxt)):
            is_java = bool(RE_JAVA_FRAME.match(nxt))
            head = jm if (is_java and jm) else (nm or jm)
            trace = {"language": "java" if is_java else "node", "start_line": i + 1, "frames": [],
                     "exception_type": head.group("type"), "message": head.group("msg"),
                     "link_to_previous": "root_cause_of_previous" if stripped.startswith("Caused by:") or line.strip().startswith("Caused by:") else None}
            i += 1
            rx = RE_JAVA_FRAME if is_java else RE_NODE_FRAME
            while i < len(lines):
                fm = rx.match(lines[i])
                if fm:
                    trace["frames"].append({"file": fm.group("file"), "line": int(fm.group("line") or 0),
                                            "func": fm.group("func") or "<anonymous>", "code": None})
                    i += 1
                    continue
                if re.match(r"^\s*\.\.\. \d+ (?:more|common frames omitted)", lines[i]):
                    i += 1
                    continue
                break
            trace["end_line"] = i
            traces.append(finish(trace, root))
            continue
        i += 1
    for n, t in enumerate(traces, 1):
        t["n"] = n
    return traces


def to_text(traces: List[Dict[str, Any]]) -> str:
    out: List[str] = []
    for t in traces:
        out.append("trace #%d  [%s]  %s: %s   (input lines %d-%d)" % (
            t["n"], t["language"], t["exception_type"], t["message"] or "", t["start_line"], t["end_line"]))
        if t.get("link_to_previous"):
            out.append("  link: %s (trace #%d)" % (t["link_to_previous"], t["n"] - 1))
        for f in t["frames"]:
            out.append("  %s %s:%s  in %s%s" % ("APP" if f["app"] else "lib", f["file"], f["line"], f["func"],
                                                 "    | " + f["code"] if f.get("code") else ""))
        ff = t.get("failure_frame")
        if ff:
            out.append("  => Layer 1 failure location: %s:%s in %s" % (ff["file"], ff["line"], ff["func"]))
        else:
            out.append("  => no application frame identified (pass --root, or the failure is entirely in library code)")
        out.append("")
    if not traces:
        out.append("no stack traces recognised")
    return "\n".join(out)


def main() -> None:
    ap = argparse.ArgumentParser(description="Parse stack traces (TRACE)")
    ap.add_argument("file", help="file containing traces, or - for stdin")
    ap.add_argument("--root", help="repository root, used to tell application frames from library frames")
    ap.add_argument("--format", choices=["json", "text"], default="json")
    args = ap.parse_args()
    text = sys.stdin.read() if args.file == "-" else open(args.file, "r", encoding="utf-8", errors="replace").read()
    traces = parse(text, args.root)
    print(to_text(traces) if args.format == "text" else json.dumps({"traces": traces}, indent=2))


if __name__ == "__main__":
    main()
