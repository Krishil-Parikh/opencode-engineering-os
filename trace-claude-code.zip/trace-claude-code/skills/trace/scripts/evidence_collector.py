#!/usr/bin/env python3
"""TRACE evidence ledger.

Every claim in a TRACE investigation must point at an evidence item in
evidence.json. This tool is the only writer of that file, which is what makes
the ledger trustworthy: it reads excerpts from disk itself (so quotes cannot
be paraphrased or invented), hashes them, enforces the grade rules, and can
re-check every FACT later.

Usage:
    evidence_collector.py add --inv INV --class log --grade FACT \
        --summary "process_payment started 1s before CancelledError" \
        --file logs/app.log --lines 412-413 [--timestamp 09:47:04] [--by log-analyst] \
        [--supports H-02] [--contradicts H-01]
    evidence_collector.py add --inv INV --class runtime --grade FACT \
        --summary "pool size is 5" --command "grep -n POOL_SIZE config.py" --excerpt "12:POOL_SIZE = 5"
    evidence_collector.py add --inv INV --class absence --grade FACT \
        --summary "no 'payment completed' event for req-7f3a" \
        --search-scope "logs/app.log 09:40-09:50, grep 'payment completed'" --command "grep -c ..." --excerpt "0"
    evidence_collector.py add --inv INV --class source --grade INFERENCE \
        --summary "timeout fires before the retry can finish" --derived-from E-004,E-007 --reasoning "..."

    evidence_collector.py link --inv INV --evidence E-003 --supports H-01 [--contradicts H-02]
    evidence_collector.py add-hypothesis    --inv INV --json hypothesis.json
    evidence_collector.py update-hypothesis --inv INV --id H-01 --json patch.json
    evidence_collector.py set-prediction    --inv INV --id H-01 --prediction P1 --status confirmed --evidence E-009
    evidence_collector.py add-finding       --inv INV --json finding.json
    evidence_collector.py recheck  --inv INV     (re-reads every file-backed FACT and compares hashes)
    evidence_collector.py list     --inv INV [--hypothesis H-01] [--grade FACT]
    evidence_collector.py validate --inv INV

Grades
    FACT        directly observed and re-checkable: has a locator (file+lines, or the exact command) and a verbatim excerpt
    INFERENCE   derived from other evidence by stated reasoning: needs --derived-from and --reasoning
    ASSUMPTION  not checked. Allowed, but can never be the sole support of a conclusion
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from typing import Any, Dict, List

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import (EVIDENCE_CLASSES, GRADES, die, inv_path, load_json, load_schema, next_id, now_iso,  # noqa: E402
                     parse_line_range, read_lines, save_json, sha256_text, validate)

MAX_EXCERPT = 4000


def split_ids(value: str) -> List[str]:
    return [v.strip() for v in (value or "").split(",") if v.strip()]


def load_ledger(inv: str) -> Dict[str, Any]:
    return load_json(inv_path(inv, "evidence.json"))


def load_hyps(inv: str) -> Dict[str, Any]:
    return load_json(inv_path(inv, "hypotheses.json"))


def check_hyp_ids(inv: str, ids: List[str]) -> None:
    known = {h["id"] for h in load_hyps(inv).get("items", [])}
    missing = [i for i in ids if i not in known]
    if missing:
        die("unknown hypothesis id(s): %s (known: %s)" % (", ".join(missing), ", ".join(sorted(known)) or "none"))


def cmd_add(args: argparse.Namespace) -> None:
    ledger = load_ledger(args.inv)
    items = ledger["items"]
    if args.cls not in EVIDENCE_CLASSES:
        die("--class must be one of: " + ", ".join(EVIDENCE_CLASSES))
    if args.grade not in GRADES:
        die("--grade must be one of: " + ", ".join(GRADES))
    source: Dict[str, Any] = {}
    excerpt = args.excerpt
    if args.file:
        if not os.path.exists(args.file):
            die("evidence file does not exist: %s (a FACT must be re-checkable)" % args.file)
        source["path"] = os.path.relpath(args.file)
        if args.lines:
            start, end = parse_line_range(args.lines)
            source["line_start"], source["line_end"] = start, end
            from_disk = read_lines(args.file, start, end)
            if excerpt and excerpt.strip() != from_disk.strip():
                die("--excerpt does not match %s:%s on disk. Omit --excerpt and let the tool read the lines." % (args.file, args.lines))
            excerpt = from_disk
    if args.command:
        source["command"] = args.command
    for key in ("timestamp", "commit", "url"):
        if getattr(args, key):
            source[key] = getattr(args, key)
    if args.search_scope:
        source["search_scope"] = args.search_scope
    derived = split_ids(args.derived_from)

    # Grade rules -----------------------------------------------------------
    if args.grade == "FACT":
        if not (("path" in source and "line_start" in source) or "command" in source or "url" in source):
            die("a FACT needs a locator: --file with --lines, or --command, or --url")
        if not excerpt:
            die("a FACT needs a verbatim excerpt (read from --file/--lines, or pass --excerpt with the command output)")
    if args.grade == "INFERENCE":
        if not derived:
            die("an INFERENCE needs --derived-from E-xxx[,E-yyy] naming the evidence it rests on")
        if not args.reasoning:
            die("an INFERENCE needs --reasoning: the step that takes you from the cited evidence to this claim")
    if args.cls == "absence" and not args.search_scope:
        die("absence evidence needs --search-scope: what was searched, where, and over which time range. "
            "'Not found' only counts where coverage is established.")
    known = {i["id"] for i in items}
    missing = [d for d in derived if d not in known]
    if missing:
        die("--derived-from names unknown evidence: " + ", ".join(missing))
    supports, contradicts = split_ids(args.supports), split_ids(args.contradicts)
    check_hyp_ids(args.inv, supports + contradicts)
    if excerpt and len(excerpt) > MAX_EXCERPT:
        die("excerpt is %d characters; narrow the line range to the decisive lines (max %d)" % (len(excerpt), MAX_EXCERPT))

    eid = next_id("E", [i["id"] for i in items])
    item = {
        "id": eid, "class": args.cls, "grade": args.grade, "summary": args.summary, "source": source,
        "excerpt": excerpt or "", "sha256": sha256_text(excerpt) if excerpt else None,
        "derived_from": derived, "reasoning": args.reasoning or "",
        "supports": supports, "contradicts": contradicts,
        "collected_by": args.by or "orchestrator", "collected_at": now_iso(), "notes": args.notes or "",
        "recheck": None,
    }
    errors = validate(item, load_schema("evidence.schema.json"))
    if errors:
        die("evidence item failed schema validation:\n  " + "\n  ".join(errors))
    items.append(item)
    save_json(inv_path(args.inv, "evidence.json"), ledger)
    _sync_hypothesis_links(args.inv, eid, supports, contradicts)
    print(eid)


def _sync_hypothesis_links(inv: str, eid: str, supports: List[str], contradicts: List[str]) -> None:
    if not supports and not contradicts:
        return
    hyps = load_hyps(inv)
    for h in hyps["items"]:
        if h["id"] in supports and eid not in h["evidence_for"]:
            h["evidence_for"].append(eid)
        if h["id"] in contradicts and eid not in h["evidence_against"]:
            h["evidence_against"].append(eid)
    save_json(inv_path(inv, "hypotheses.json"), hyps)


def cmd_link(args: argparse.Namespace) -> None:
    ledger = load_ledger(args.inv)
    item = next((i for i in ledger["items"] if i["id"] == args.evidence), None)
    if not item:
        die("unknown evidence id " + args.evidence)
    supports, contradicts = split_ids(args.supports), split_ids(args.contradicts)
    check_hyp_ids(args.inv, supports + contradicts)
    for h in supports:
        if h not in item["supports"]:
            item["supports"].append(h)
    for h in contradicts:
        if h not in item["contradicts"]:
            item["contradicts"].append(h)
    save_json(inv_path(args.inv, "evidence.json"), ledger)
    _sync_hypothesis_links(args.inv, item["id"], supports, contradicts)
    print("linked " + item["id"])


def _read_json_arg(value: str) -> Any:
    text = sys.stdin.read() if value == "-" else open(value, "r", encoding="utf-8").read()
    try:
        return json.loads(text)
    except ValueError as exc:
        die("invalid JSON: %s" % exc)


def _check_evidence_refs(inv: str, ids: List[str], where: str) -> None:
    known = {i["id"] for i in load_ledger(inv)["items"]}
    missing = sorted(set(i for i in ids if i not in known))
    if missing:
        die("%s cites evidence that is not in the ledger: %s. Add it with `add` first; uncited claims are not allowed." % (where, ", ".join(missing)))


def cmd_add_hypothesis(args: argparse.Namespace) -> None:
    hyps = load_hyps(args.inv)
    data = _read_json_arg(args.json)
    data.setdefault("id", next_id("H", [h["id"] for h in hyps["items"]], width=2))
    data.setdefault("status", "active")
    for key in ("evidence_for", "evidence_against", "assumptions", "predictions", "falsifiers",
                "rival_rebuttals", "execution_path", "secondary_findings"):
        data.setdefault(key, [])
    data.setdefault("scores", None)
    data.setdefault("created_at", now_iso())
    errors = validate(data, load_schema("hypothesis.schema.json"))
    if errors:
        die("hypothesis failed schema validation:\n  " + "\n  ".join(errors))
    if any(h["id"] == data["id"] for h in hyps["items"]):
        die("hypothesis id %s already exists; use update-hypothesis" % data["id"])
    refs = list(data["evidence_for"]) + list(data["evidence_against"])
    for p in data["predictions"]:
        refs.extend(p.get("evidence", []))
    for r in data["rival_rebuttals"]:
        refs.extend(r.get("evidence", []))
    _check_evidence_refs(args.inv, refs, "hypothesis " + data["id"])
    warnings = []
    if not data["falsifiers"]:
        warnings.append("no falsifiers: state what observation would prove this hypothesis wrong")
    if not data["predictions"]:
        warnings.append("no predictions: a hypothesis that predicts nothing cannot be verified")
    if not data["evidence_for"]:
        warnings.append("no supporting evidence cited yet")
    hyps["items"].append(data)
    save_json(inv_path(args.inv, "hypotheses.json"), hyps)
    ledger = load_ledger(args.inv)
    for item in ledger["items"]:
        if item["id"] in data["evidence_for"] and data["id"] not in item["supports"]:
            item["supports"].append(data["id"])
        if item["id"] in data["evidence_against"] and data["id"] not in item["contradicts"]:
            item["contradicts"].append(data["id"])
    save_json(inv_path(args.inv, "evidence.json"), ledger)
    print(data["id"])
    for w in warnings:
        print("warning: " + w, file=sys.stderr)


def cmd_update_hypothesis(args: argparse.Namespace) -> None:
    hyps = load_hyps(args.inv)
    target = next((h for h in hyps["items"] if h["id"] == args.id), None)
    if not target:
        die("unknown hypothesis " + args.id)
    patch = _read_json_arg(args.json) if args.json else {}
    for pair in args.set or []:
        if "=" not in pair:
            die("--set expects key=value")
        k, v = pair.split("=", 1)
        patch[k] = v
    list_fields = ("evidence_for", "evidence_against", "assumptions", "predictions", "falsifiers",
                   "rival_rebuttals", "execution_path", "secondary_findings")
    for key, value in patch.items():
        if key == "id":
            continue
        if key in list_fields and args.append and isinstance(value, list):
            target.setdefault(key, []).extend(v for v in value if v not in target[key])
        else:
            target[key] = value
    target["updated_at"] = now_iso()
    errors = validate(target, load_schema("hypothesis.schema.json"))
    if errors:
        die("updated hypothesis failed schema validation:\n  " + "\n  ".join(errors))
    refs = list(target["evidence_for"]) + list(target["evidence_against"])
    for p in target["predictions"]:
        refs.extend(p.get("evidence", []))
    _check_evidence_refs(args.inv, refs, "hypothesis " + target["id"])
    save_json(inv_path(args.inv, "hypotheses.json"), hyps)
    print("updated " + target["id"])


def cmd_set_prediction(args: argparse.Namespace) -> None:
    hyps = load_hyps(args.inv)
    target = next((h for h in hyps["items"] if h["id"] == args.id), None)
    if not target:
        die("unknown hypothesis " + args.id)
    pred = next((p for p in target["predictions"] if p["id"] == args.prediction), None)
    if not pred:
        die("hypothesis %s has no prediction %s" % (args.id, args.prediction))
    if args.status not in ("untested", "confirmed", "refuted", "untestable"):
        die("--status must be untested|confirmed|refuted|untestable")
    ev = split_ids(args.evidence)
    if args.status in ("confirmed", "refuted") and not ev:
        die("a prediction can only be marked %s with --evidence E-xxx showing the check that was run" % args.status)
    _check_evidence_refs(args.inv, ev, "prediction " + args.prediction)
    ledger = load_ledger(args.inv)
    grades = {i["id"]: i["grade"] for i in ledger["items"]}
    if args.status in ("confirmed", "refuted") and not any(grades[e] == "FACT" for e in ev):
        die("marking a prediction %s needs at least one FACT-grade evidence item" % args.status)
    pred["status"] = args.status
    pred["evidence"] = ev
    pred["checked_by"] = args.by or "verifier"
    pred["checked_at"] = now_iso()
    save_json(inv_path(args.inv, "hypotheses.json"), hyps)
    print("%s %s -> %s" % (args.id, args.prediction, args.status))
    if args.status == "refuted":
        print("note: a refuted prediction eliminates %s as stated. Amend it into a NEW hypothesis (new id) "
              "if a repaired version is worth testing; never edit the old one to fit." % args.id, file=sys.stderr)


def cmd_add_finding(args: argparse.Namespace) -> None:
    path = inv_path(args.inv, "findings.json")
    data = load_json(path)
    finding = _read_json_arg(args.json)
    finding.setdefault("id", next_id("F", [f["id"] for f in data["findings"]]))
    finding.setdefault("investigation", data.get("investigation"))
    finding.setdefault("status", "unverified")
    finding.setdefault("verified", False)
    finding.setdefault("related_to_original_bug", "unknown")
    finding.setdefault("evidence", [])
    finding.setdefault("first_seen", now_iso())
    errors = validate(finding, load_schema("finding.schema.json"))
    if errors:
        die("finding failed schema validation:\n  " + "\n  ".join(errors))
    _check_evidence_refs(args.inv, finding["evidence"], "finding " + finding["id"])
    if finding["status"] == "confirmed":
        if not finding["verified"] or not finding["evidence"] or not finding.get("verified_by"):
            die("a finding can only be 'confirmed' with verified=true, at least one evidence id, and verified_by. "
                "Otherwise record it as 'suspicious' or 'unverified'.")
    data["findings"].append(finding)
    save_json(path, data)
    print(finding["id"])


def cmd_recheck(args: argparse.Namespace) -> None:
    ledger = load_ledger(args.inv)
    ok = stale = unverifiable = 0
    for item in ledger["items"]:
        src = item.get("source", {})
        if item["grade"] != "FACT" or "path" not in src or "line_start" not in src:
            if item["grade"] == "FACT":
                unverifiable += 1
                item["recheck"] = {"at": now_iso(), "result": "not-file-backed", "note": "re-run the recorded command to re-check"}
            continue
        if not os.path.exists(src["path"]):
            stale += 1
            item["recheck"] = {"at": now_iso(), "result": "missing-file"}
            print("STALE  %s  %s no longer exists" % (item["id"], src["path"]))
            continue
        with open(src["path"], "r", encoding="utf-8", errors="replace") as fh:
            lines = fh.read().splitlines()
        current = "\n".join(lines[src["line_start"] - 1:src["line_end"]])
        if sha256_text(current) == item["sha256"]:
            ok += 1
            item["recheck"] = {"at": now_iso(), "result": "match"}
        elif item["excerpt"] in "\n".join(lines):
            ok += 1
            item["recheck"] = {"at": now_iso(), "result": "moved", "note": "excerpt still present but at different lines (file grew or was edited)"}
            print("MOVED  %s  excerpt still present in %s, line numbers changed" % (item["id"], src["path"]))
        else:
            stale += 1
            item["recheck"] = {"at": now_iso(), "result": "mismatch"}
            print("STALE  %s  %s:%d-%d no longer matches the recorded excerpt" % (item["id"], src["path"], src["line_start"], src["line_end"]))
    save_json(inv_path(args.inv, "evidence.json"), ledger)
    print("recheck: %d match, %d stale, %d FACT(s) backed by a command rather than a file" % (ok, stale, unverifiable))
    if stale:
        print("Stale FACTs must be re-collected or downgraded before they support a conclusion.")
        sys.exit(3)


def cmd_list(args: argparse.Namespace) -> None:
    ledger = load_ledger(args.inv)
    for item in ledger["items"]:
        if args.grade and item["grade"] != args.grade:
            continue
        if args.hypothesis and args.hypothesis not in item["supports"] + item["contradicts"]:
            continue
        src = item.get("source", {})
        loc = ("%s:%s-%s" % (src["path"], src.get("line_start", "?"), src.get("line_end", "?"))) if "path" in src \
            else (src.get("command") or src.get("url") or "-")
        rel = ""
        if item["supports"]:
            rel += " +" + ",".join(item["supports"])
        if item["contradicts"]:
            rel += " -" + ",".join(item["contradicts"])
        print("%s  %-10s %-10s %s  [%s]%s" % (item["id"], item["grade"], item["class"], item["summary"], loc, rel))


def cmd_validate(args: argparse.Namespace) -> None:
    problems: List[str] = []
    ledger = load_ledger(args.inv)
    ev_schema, hyp_schema, find_schema = (load_schema("evidence.schema.json"), load_schema("hypothesis.schema.json"),
                                          load_schema("finding.schema.json"))
    ids = set()
    for item in ledger["items"]:
        problems.extend("evidence " + e for e in validate(item, ev_schema, item.get("id", "?")))
        if item.get("id") in ids:
            problems.append("duplicate evidence id " + item["id"])
        ids.add(item.get("id"))
        for d in item.get("derived_from", []):
            if d not in ids and d not in {i["id"] for i in ledger["items"]}:
                problems.append("%s derives from unknown %s" % (item["id"], d))
    hyps = load_hyps(args.inv)
    grades = {i["id"]: i["grade"] for i in ledger["items"]}
    for h in hyps["items"]:
        problems.extend("hypothesis " + e for e in validate(h, hyp_schema, h.get("id", "?")))
        for e in h.get("evidence_for", []) + h.get("evidence_against", []):
            if e not in ids:
                problems.append("%s cites missing evidence %s" % (h["id"], e))
        if h.get("status") in ("champion", "verified") and not any(grades.get(e) == "FACT" for e in h.get("evidence_for", [])):
            problems.append("%s is %s but has no FACT-grade supporting evidence" % (h["id"], h["status"]))
        if h.get("status") in ("champion", "verified") and any(p.get("status") == "refuted" for p in h.get("predictions", [])):
            problems.append("%s is %s but has a refuted prediction" % (h["id"], h["status"]))
    findings = load_json(inv_path(args.inv, "findings.json"), default={"findings": []})
    for f in findings["findings"]:
        problems.extend("finding " + e for e in validate(f, find_schema, f.get("id", "?")))
        if f.get("status") == "confirmed" and not (f.get("verified") and f.get("evidence")):
            problems.append("finding %s is 'confirmed' without verification evidence" % f["id"])
    tournament = load_json(inv_path(args.inv, "tournament.json"), default={})
    problems.extend("tournament " + e for e in validate(tournament, load_schema("tournament.schema.json")))
    if problems:
        print("\n".join(problems))
        print("\n%d problem(s)" % len(problems))
        sys.exit(1)
    print("ok: %d evidence item(s), %d hypothesis(es), %d finding(s), %d tournament round(s)" % (
        len(ledger["items"]), len(hyps["items"]), len(findings["findings"]), len(tournament.get("rounds", []))))


def main() -> None:
    ap = argparse.ArgumentParser(description="TRACE evidence ledger")
    sub = ap.add_subparsers(dest="cmd")
    p = sub.add_parser("add")
    p.add_argument("--inv", required=True); p.add_argument("--class", dest="cls", required=True)
    p.add_argument("--grade", required=True); p.add_argument("--summary", required=True)
    p.add_argument("--file"); p.add_argument("--lines"); p.add_argument("--excerpt"); p.add_argument("--command")
    p.add_argument("--timestamp"); p.add_argument("--commit"); p.add_argument("--url"); p.add_argument("--search-scope")
    p.add_argument("--derived-from", default=""); p.add_argument("--reasoning"); p.add_argument("--supports", default="")
    p.add_argument("--contradicts", default=""); p.add_argument("--by"); p.add_argument("--notes")
    p.set_defaults(fn=cmd_add)
    p = sub.add_parser("link"); p.add_argument("--inv", required=True); p.add_argument("--evidence", required=True)
    p.add_argument("--supports", default=""); p.add_argument("--contradicts", default=""); p.set_defaults(fn=cmd_link)
    p = sub.add_parser("add-hypothesis"); p.add_argument("--inv", required=True); p.add_argument("--json", required=True)
    p.set_defaults(fn=cmd_add_hypothesis)
    p = sub.add_parser("update-hypothesis"); p.add_argument("--inv", required=True); p.add_argument("--id", required=True)
    p.add_argument("--json"); p.add_argument("--set", action="append"); p.add_argument("--append", action="store_true",
                                                                                      help="extend list fields instead of replacing them")
    p.set_defaults(fn=cmd_update_hypothesis)
    p = sub.add_parser("set-prediction"); p.add_argument("--inv", required=True); p.add_argument("--id", required=True)
    p.add_argument("--prediction", required=True); p.add_argument("--status", required=True)
    p.add_argument("--evidence", default=""); p.add_argument("--by"); p.set_defaults(fn=cmd_set_prediction)
    p = sub.add_parser("add-finding"); p.add_argument("--inv", required=True); p.add_argument("--json", required=True)
    p.set_defaults(fn=cmd_add_finding)
    p = sub.add_parser("recheck"); p.add_argument("--inv", required=True); p.set_defaults(fn=cmd_recheck)
    p = sub.add_parser("list"); p.add_argument("--inv", required=True); p.add_argument("--hypothesis"); p.add_argument("--grade")
    p.set_defaults(fn=cmd_list)
    p = sub.add_parser("validate"); p.add_argument("--inv", required=True); p.set_defaults(fn=cmd_validate)
    args = ap.parse_args()
    if not getattr(args, "fn", None):
        ap.print_help(); sys.exit(1)
    args.fn(args)


if __name__ == "__main__":
    main()
