#!/usr/bin/env python3
"""TRACE probe tool: hierarchical fault localization with removable print probes.

This automates the three-stage narrowing technique at the heart of TRACE:

  Stage 1 (which FILE)      every function in every file prints that file's
                            number on entry.  "Error occurs after entering
                            F056" -> investigate file 56.
  Stage 2 (which FUNCTION)  inside the suspect file, every function gets a
                            distinct ENTER probe and a probe before each
                            statement that makes a call.
  Stage 3 (which STATEMENT) inside the suspect function, a probe before
                            every statement, optionally printing variables.

Every inserted line ends with the marker comment `# TRACE-PROBE`, so removal
is exact and complete. A manifest records each file's hash before and after,
and `remove` verifies the file is byte-identical to the original.

Usage:
    probe.py stage1 --root src [--include "app/**/*.py"] [--manifest probes.json] [--ctx]
    probe.py stage2 --file src/services/payment.py [--manifest probes.json] [--ctx]
    probe.py stage3 --file src/services/payment.py --function process_payment [--vars order,attempt]
    probe.py analyze run_output.log [--manifest probes.json]
    probe.py remove --manifest probes.json            (or: --root src)
    probe.py status --manifest probes.json
    probe.py snippet --lang js|ts|go|java|ruby|rust|csharp|php

Automatic insertion supports Python. For other languages `snippet` prints the
probe line to place by hand; `analyze` and `remove` work for every language.

SAFETY. Probes change source files. Use them in a reproduction environment or
on a branch, never by hot-editing a production checkout. Probes go to stderr
with flush so they survive a crash. Run `remove` and confirm "restored: N,
mismatched: 0" before you commit or report.
"""
from __future__ import annotations

import argparse
import ast
import fnmatch
import os
import re
import sys
from typing import Any, Dict, List, Optional, Tuple

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import die, load_json, now_iso, save_json, sha256_text  # noqa: E402

MARKER = "# TRACE-PROBE"
SKIP_DIRS = {".git", "node_modules", "venv", ".venv", "env", "__pycache__", "dist", "build", ".tox",
             "site-packages", "migrations", "debugging"}
RE_PROBE_OUT = re.compile(r"\[TRACE-PROBE (?P<stage>S[123]) (?P<label>[^\]]+)\]")
RE_MARKER_LINE = re.compile(r"(#|//|--)\s*TRACE-PROBE\s*$")

SNIPPETS = {
    "js": 'console.error("[TRACE-PROBE S2 <label>]"); // TRACE-PROBE',
    "ts": 'console.error("[TRACE-PROBE S2 <label>]"); // TRACE-PROBE',
    "go": 'fmt.Fprintln(os.Stderr, "[TRACE-PROBE S2 <label>]") // TRACE-PROBE',
    "java": 'System.err.println("[TRACE-PROBE S2 <label>]"); // TRACE-PROBE',
    "ruby": '$stderr.puts "[TRACE-PROBE S2 <label>]" # TRACE-PROBE',
    "rust": 'eprintln!("[TRACE-PROBE S2 <label>]"); // TRACE-PROBE',
    "csharp": 'Console.Error.WriteLine("[TRACE-PROBE S2 <label>]"); // TRACE-PROBE',
    "php": 'fwrite(STDERR, "[TRACE-PROBE S2 <label>]\\n"); // TRACE-PROBE',
}


def probe_line(indent: str, stage: str, label: str, ctx: bool, variables: Optional[List[str]] = None) -> str:
    label = label.replace('"', "'").replace("\\", "/").replace("{", "(").replace("}", ")")
    parts = '"[TRACE-PROBE %s %s]"' % (stage, label)
    extra: List[str] = []
    if ctx:
        extra.append('"thread=" + __import__("threading").current_thread().name')
    for v in variables or []:
        # locals().get avoids NameError when the variable is not bound yet at this statement.
        extra.append('"%s=" + repr(locals().get("%s", "<unbound>"))[:200]' % (v, v))
    args = ", ".join([parts] + extra)
    return '%sprint(%s, file=__import__("sys").stderr, flush=True)  %s' % (indent, args, MARKER)


def is_docstring(stmt: ast.stmt) -> bool:
    return isinstance(stmt, ast.Expr) and isinstance(getattr(stmt, "value", None), ast.Constant) \
        and isinstance(stmt.value.value, str)


def stmt_first_line(stmt: ast.stmt) -> int:
    decorators = getattr(stmt, "decorator_list", None) or []
    return min([stmt.lineno] + [d.lineno for d in decorators])


def insertable(stmt: ast.stmt, lines: List[str]) -> Optional[Tuple[int, str]]:
    """Return (line_number, indent) if a probe can go on its own line before stmt."""
    lineno = stmt_first_line(stmt)
    text = lines[lineno - 1]
    indent = text[:len(text) - len(text.lstrip())]
    col = stmt.col_offset if lineno == stmt.lineno else len(indent)
    if text[:col].strip():
        return None  # statement shares a line with something else, e.g. `if x: return` or `a = 1; b = 2`
    return lineno, indent


def child_blocks(stmt: ast.stmt) -> List[List[ast.stmt]]:
    blocks: List[List[ast.stmt]] = []
    for field in ("body", "orelse", "finalbody"):
        value = getattr(stmt, field, None)
        if isinstance(value, list) and value and isinstance(value[0], ast.stmt):
            blocks.append(value)
    for handler in getattr(stmt, "handlers", []) or []:
        blocks.append(handler.body)
    for case in getattr(stmt, "cases", []) or []:
        blocks.append(case.body)
    return blocks


def called_names(stmt: ast.stmt) -> List[str]:
    names: List[str] = []
    header_only = stmt
    nodes: List[ast.AST] = []
    if child_blocks(stmt) and not isinstance(stmt, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
        # Compound statement: only look at its header expressions, the bodies get their own probes.
        for field in ("test", "iter", "items", "subject", "context_expr"):
            value = getattr(header_only, field, None)
            if isinstance(value, list):
                nodes.extend(value)
            elif isinstance(value, ast.AST):
                nodes.append(value)
    elif isinstance(stmt, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
        return []
    else:
        nodes = [stmt]
    for node in nodes:
        for sub in ast.walk(node):
            if isinstance(sub, ast.Call):
                fn = sub.func
                if isinstance(fn, ast.Name):
                    names.append(fn.id)
                elif isinstance(fn, ast.Attribute):
                    names.append(fn.attr)
    seen, out = set(), []
    for n in names:
        if n not in seen:
            seen.add(n); out.append(n)
    return out


class Collector(ast.NodeVisitor):
    def __init__(self) -> None:
        self.stack: List[str] = []
        self.functions: List[Tuple[str, ast.AST]] = []

    def _fn(self, node: ast.AST) -> None:
        qual = ".".join(self.stack + [node.name])
        self.functions.append((qual, node))
        self.stack.append(node.name)
        self.generic_visit(node)
        self.stack.pop()

    visit_FunctionDef = _fn
    visit_AsyncFunctionDef = _fn

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        self.stack.append(node.name)
        self.generic_visit(node)
        self.stack.pop()


def first_real_stmt(fn: ast.AST) -> Optional[ast.stmt]:
    body = list(fn.body)
    if body and is_docstring(body[0]):
        body = body[1:]
    return body[0] if body else None


def walk_statements(block: List[ast.stmt], nested_functions: bool = False):
    for stmt in block:
        if is_docstring(stmt):
            continue
        yield stmt
        if isinstance(stmt, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) and not nested_functions:
            continue
        for sub in child_blocks(stmt):
            for inner in walk_statements(sub, nested_functions):
                yield inner


def plan_file(path: str, rel: str, stage: str, file_no: int, ctx: bool,
              function: Optional[str], variables: Optional[List[str]]) -> Tuple[List[Tuple[int, str]], List[str], List[str]]:
    with open(path, "r", encoding="utf-8") as fh:
        source = fh.read()
    lines = source.splitlines()
    tree = ast.parse(source, filename=rel)
    col = Collector()
    col.visit(tree)
    inserts: List[Tuple[int, str]] = []
    skipped: List[str] = []
    labels: List[str] = []

    def add(stmt: ast.stmt, label: str, st: str, vars_: Optional[List[str]] = None) -> None:
        spot = insertable(stmt, lines)
        if spot is None:
            skipped.append("%s:%d (statement shares its line; reformat or probe by hand)" % (rel, stmt.lineno))
            return
        inserts.append((spot[0], probe_line(spot[1], st, label, ctx, vars_)))
        labels.append(label)

    if stage == "S1":
        for qual, fn in col.functions:
            stmt = first_real_stmt(fn)
            if stmt is None:
                continue
            add(stmt, "F%03d %s" % (file_no, rel), "S1")
    elif stage == "S2":
        for idx, (qual, fn) in enumerate(col.functions, 1):
            stmt = first_real_stmt(fn)
            if stmt is None:
                continue
            tag = "F%03d.fn%02d %s" % (file_no, idx, qual)
            add(stmt, tag + " ENTER", "S2")
            for inner in walk_statements(fn.body):
                names = called_names(inner)
                if names:
                    add(inner, "%s CALL->%s L%d" % (tag, "+".join(names[:4]), inner.lineno), "S2")
    elif stage == "S3":
        matches = [(q, f) for q, f in col.functions if q == function or q.split(".")[-1] == function]
        if not matches:
            die("function %r not found in %s. Available: %s" % (function, rel, ", ".join(q for q, _ in col.functions)))
        if len(matches) > 1:
            die("function name %r is ambiguous in %s: use one of %s" % (function, rel, ", ".join(q for q, _ in matches)))
        qual, fn = matches[0]
        n = 0
        for inner in walk_statements(fn.body):
            n += 1
            add(inner, "%s L%d stmt#%02d %s" % (qual, inner.lineno, n, type(inner).__name__), "S3", variables)
    return inserts, skipped, labels


def apply_inserts(path: str, inserts: List[Tuple[int, str]]) -> Tuple[str, str]:
    with open(path, "r", encoding="utf-8") as fh:
        original = fh.read()
    lines = original.split("\n")
    # Stable ordering: several probes for the same line keep their planned order.
    indexed = list(enumerate(inserts))
    for _order, (lineno, text) in sorted(indexed, key=lambda x: (-x[1][0], -x[0])):
        lines.insert(lineno - 1, text)
    updated = "\n".join(lines)
    try:
        ast.parse(updated)
    except SyntaxError as exc:
        die("probing %s would break its syntax (line %s); file left untouched" % (path, exc.lineno))
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(updated)
    return sha256_text(original), sha256_text(updated)


def load_manifest(path: str) -> Dict[str, Any]:
    return load_json(path, default={"created_at": now_iso(), "files": {}, "numbering": {}, "history": []})


def record(manifest: Dict[str, Any], path: str, before: str, after: str, stage: str, count: int, labels: List[str]) -> None:
    key = os.path.abspath(path)
    entry = manifest["files"].get(key)
    if entry is None:
        entry = {"original_sha256": before, "stages": []}
        manifest["files"][key] = entry
    entry["probed_sha256"] = after
    entry["stages"].append({"stage": stage, "probes": count, "at": now_iso()})
    entry.setdefault("labels", []).extend(labels)


def iter_python_files(root: str, includes: List[str]) -> List[str]:
    out: List[str] = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = sorted(d for d in dirnames if d not in SKIP_DIRS and not d.startswith("."))
        for fn in sorted(filenames):
            if not fn.endswith(".py"):
                continue
            rel = os.path.relpath(os.path.join(dirpath, fn), root)
            if includes and not any(fnmatch.fnmatch(rel, pat) for pat in includes):
                continue
            out.append(os.path.join(dirpath, fn))
    return out


def has_probes(path: str) -> bool:
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        return any(RE_MARKER_LINE.search(line.rstrip("\n")) for line in fh)


def cmd_stage1(args: argparse.Namespace) -> None:
    manifest = load_manifest(args.manifest)
    files = iter_python_files(args.root, args.include)
    if not files:
        die("no Python files found under %s" % args.root)
    total = 0
    for n, path in enumerate(files, 1):
        rel = os.path.relpath(path, args.root)
        if has_probes(path):
            print("skip %s (already probed; run remove first)" % rel); continue
        try:
            inserts, skipped, labels = plan_file(path, rel, "S1", n, args.ctx, None, None)
        except SyntaxError as exc:
            print("skip %s (syntax error line %s)" % (rel, exc.lineno)); continue
        manifest["numbering"]["F%03d" % n] = rel
        if not inserts:
            continue
        before, after = apply_inserts(path, inserts)
        record(manifest, path, before, after, "S1", len(inserts), [])
        total += len(inserts)
        print("F%03d  %-50s %d probe(s)" % (n, rel, len(inserts)))
    manifest["history"].append({"cmd": "stage1", "root": os.path.abspath(args.root), "probes": total, "at": now_iso()})
    save_json(args.manifest, manifest)
    print("\nstage 1: %d probe(s) in %d file(s). Manifest: %s" % (total, len(manifest["files"]), args.manifest))
    print("Next: run the failing scenario, capture stderr, then `probe.py analyze <output>`.")


def _single(args: argparse.Namespace, stage: str) -> None:
    manifest = load_manifest(args.manifest)
    path = args.file
    if not os.path.exists(path):
        die("file not found: " + path)
    rel = os.path.relpath(path)
    if has_probes(path):
        die("%s already contains probes. Run `probe.py remove --manifest %s` first so stages do not stack." % (rel, args.manifest))
    file_no = 0
    for key, value in manifest.get("numbering", {}).items():
        if os.path.normpath(value) == os.path.normpath(rel) or os.path.normpath(path).endswith(os.path.normpath(value)):
            file_no = int(key[1:])
    variables = [v.strip() for v in (getattr(args, "vars", None) or "").split(",") if v.strip()]
    for v in variables:
        if not v.isidentifier():
            die("--vars takes plain variable names, got %r" % v)
    inserts, skipped, labels = plan_file(path, rel, stage, file_no, args.ctx, getattr(args, "function", None), variables)
    if not inserts:
        die("nothing to probe in %s" % rel)
    before, after = apply_inserts(path, inserts)
    if os.path.abspath(path) in manifest["files"]:
        before = manifest["files"][os.path.abspath(path)]["original_sha256"]
    record(manifest, path, before, after, stage, len(inserts), labels)
    manifest["history"].append({"cmd": stage, "file": os.path.abspath(path), "probes": len(inserts), "at": now_iso()})
    save_json(args.manifest, manifest)
    print("%s: inserted %d probe(s) into %s" % (stage, len(inserts), rel))
    for s in skipped:
        print("  not probed: " + s)
    print("Manifest: %s. Run the scenario, then `probe.py analyze <output> --manifest %s`." % (args.manifest, args.manifest))


def cmd_stage2(args: argparse.Namespace) -> None:
    _single(args, "S2")


def cmd_stage3(args: argparse.Namespace) -> None:
    _single(args, "S3")


def cmd_remove(args: argparse.Namespace) -> None:
    targets: List[str] = []
    manifest = None
    if args.manifest and os.path.exists(args.manifest):
        manifest = load_manifest(args.manifest)
        targets.extend(manifest["files"].keys())
    if args.root:
        for dirpath, dirnames, filenames in os.walk(args.root):
            dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS and not d.startswith(".")]
            for fn in filenames:
                p = os.path.abspath(os.path.join(dirpath, fn))
                if p not in targets and os.path.splitext(fn)[1] in (
                        ".py", ".js", ".jsx", ".ts", ".tsx", ".go", ".java", ".kt", ".rb", ".rs", ".cs", ".php", ".mjs", ".cjs"):
                    targets.append(p)
    if not targets:
        die("nothing to do: pass --manifest and/or --root")
    restored = mismatched = removed_lines = 0
    for path in targets:
        if not os.path.exists(path):
            print("missing: " + path); continue
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            content = fh.read()
        lines = content.split("\n")
        kept = [ln for ln in lines if not RE_MARKER_LINE.search(ln)]
        if len(kept) == len(lines):
            continue
        removed_lines += len(lines) - len(kept)
        new = "\n".join(kept)
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(new)
        entry = manifest["files"].get(path) if manifest else None
        if entry and sha256_text(new) != entry["original_sha256"]:
            mismatched += 1
            print("MISMATCH: %s differs from its pre-probe content (was it edited while probed?). Review with git diff." % path)
        else:
            restored += 1
            if entry:
                entry["removed_at"] = now_iso()
    if manifest:
        manifest["history"].append({"cmd": "remove", "at": now_iso(), "restored": restored, "mismatched": mismatched})
        save_json(args.manifest, manifest)
    print("removed %d probe line(s); restored: %d, mismatched: %d" % (removed_lines, restored, mismatched))
    if mismatched:
        sys.exit(3)


def cmd_status(args: argparse.Namespace) -> None:
    manifest = load_manifest(args.manifest)
    live = 0
    for path, entry in manifest["files"].items():
        present = os.path.exists(path) and has_probes(path)
        live += present
        print("%s  %s  stages=%s" % ("PROBED " if present else "clean  ", path, [s["stage"] for s in entry["stages"]]))
    print("%d file(s) still contain probes" % live)
    if live:
        sys.exit(4)


def cmd_analyze(args: argparse.Namespace) -> None:
    text = sys.stdin.read() if args.output == "-" else open(args.output, "r", encoding="utf-8", errors="replace").read()
    numbering = {}
    if args.manifest and os.path.exists(args.manifest):
        numbering = load_manifest(args.manifest).get("numbering", {})
    hits: List[Tuple[int, str, str, str]] = []
    threads: Dict[str, List[Tuple[int, str, str]]] = {}
    for lineno, line in enumerate(text.splitlines(), 1):
        m = RE_PROBE_OUT.search(line)
        if not m:
            continue
        tm = re.search(r"thread=(\S+)", line[m.end():])
        thread = tm.group(1) if tm else "-"
        hits.append((lineno, m.group("stage"), m.group("label"), line[m.end():].strip()))
        threads.setdefault(thread, []).append((lineno, m.group("stage"), m.group("label")))
    if not hits:
        print("no TRACE-PROBE output found. Either the probed code never ran, stderr was not captured, "
              "or the process ran a different build. None of these is evidence about the bug yet.")
        sys.exit(1)
    error_line = None
    for lineno, line in enumerate(text.splitlines(), 1):
        if re.search(r"Traceback \(most recent call last\)|\b\w+(Error|Exception)\b|panic:", line) and "TRACE-PROBE" not in line:
            error_line = lineno
            break
    print("probe hits: %d   output lines: %d   first error-looking line: %s" % (
        len(hits), len(text.splitlines()), error_line or "none found"))
    # Compressed sequence
    print("\nsequence (consecutive repeats collapsed):")
    prev, count = None, 0
    seq: List[str] = []
    for _ln, stage, label, _rest in hits:
        key = "%s %s" % (stage, label)
        if key == prev:
            count += 1
        else:
            if prev is not None:
                seq.append(prev + (" x%d" % count if count > 1 else ""))
            prev, count = key, 1
    seq.append(prev + (" x%d" % count if count > 1 else ""))
    for s in seq[-args.tail:]:
        print("  " + s)
    if len(seq) > args.tail:
        print("  (showing last %d of %d distinct steps)" % (args.tail, len(seq)))
    before_error = [h for h in hits if error_line is None or h[0] < error_line] or hits
    last = before_error[-1]
    print("\nlast probe reached before the failure: [%s %s]  (output line %d)" % (last[1], last[2], last[0]))
    if last[3]:
        print("  values: " + last[3])
    stage, label = last[1], last[2]
    if stage == "S1":
        fid = label.split()[0]
        print("=> Stage 1 result: the failure follows entry into %s (%s)." % (fid, numbering.get(fid, label.split(" ", 1)[-1])))
        print("   Next: probe.py remove, then probe.py stage2 --file <that file>.")
    elif stage == "S2":
        print("=> Stage 2 result: execution reached this point of the function and did not reach the next probe.")
        print("   If the label is CALL->x, the failure is inside x or in evaluating that statement.")
        print("   Next: probe.py remove, then stage3 on the function named in the label (or stage2 on the callee's file).")
    else:
        print("=> Stage 3 result: the statement at this label started and the following statement's probe never fired.")
        print("   That statement is the Layer 1 failure location. Now establish trigger and root cause; do not stop here.")
    if len(threads) > 1:
        cutoff = error_line if error_line is not None else float("inf")
        print("\nper-thread last probe before the failure (concurrent code: 'last overall' can mislead):")
        for thread, items in sorted(threads.items()):
            before = [i for i in items if i[0] < cutoff] or items
            print("  %-24s %s %s" % (thread, before[-1][1], before[-1][2]))
    print("\nCaveat: in async or multi-threaded code the last probe printed is the last to RUN, not necessarily the one "
          "that failed. Cancellation and timeouts surface at an await point chosen by the scheduler.")


def cmd_snippet(args: argparse.Namespace) -> None:
    if args.lang == "python":
        print(probe_line("", "S2", "<label>", False))
    else:
        print(SNIPPETS[args.lang])
    print("\nKeep the trailing TRACE-PROBE comment: `probe.py remove --root <dir>` deletes every line that ends with it.")
    print("Label convention: S1 'F<nnn> <file>', S2 'F<nnn>.fn<nn> <function> ENTER|CALL-><callee> L<line>', "
          "S3 '<function> L<line> stmt#<nn>'.")


def main() -> None:
    ap = argparse.ArgumentParser(description="Hierarchical print-probe localization (TRACE)")
    sub = ap.add_subparsers(dest="cmd")
    p = sub.add_parser("stage1"); p.add_argument("--root", required=True); p.add_argument("--include", action="append", default=[])
    p.add_argument("--manifest", default="probes.json"); p.add_argument("--ctx", action="store_true", help="append thread name")
    p.set_defaults(fn=cmd_stage1)
    p = sub.add_parser("stage2"); p.add_argument("--file", required=True); p.add_argument("--manifest", default="probes.json")
    p.add_argument("--ctx", action="store_true"); p.set_defaults(fn=cmd_stage2)
    p = sub.add_parser("stage3"); p.add_argument("--file", required=True); p.add_argument("--function", required=True)
    p.add_argument("--vars", help="comma-separated local variable names to print"); p.add_argument("--manifest", default="probes.json")
    p.add_argument("--ctx", action="store_true"); p.set_defaults(fn=cmd_stage3)
    p = sub.add_parser("remove"); p.add_argument("--manifest"); p.add_argument("--root"); p.set_defaults(fn=cmd_remove)
    p = sub.add_parser("status"); p.add_argument("--manifest", default="probes.json"); p.set_defaults(fn=cmd_status)
    p = sub.add_parser("analyze"); p.add_argument("output"); p.add_argument("--manifest", default="probes.json")
    p.add_argument("--tail", type=int, default=25); p.set_defaults(fn=cmd_analyze)
    p = sub.add_parser("snippet"); p.add_argument("--lang", required=True, choices=["python"] + sorted(SNIPPETS)); p.set_defaults(fn=cmd_snippet)
    args = ap.parse_args()
    if not getattr(args, "fn", None):
        ap.print_help(); sys.exit(1)
    args.fn(args)


if __name__ == "__main__":
    main()
