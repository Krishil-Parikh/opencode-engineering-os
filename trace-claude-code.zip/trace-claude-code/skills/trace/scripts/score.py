#!/usr/bin/env python3
"""TRACE scoring and tournament ledger.

A judge supplies five raw criterion scores (0-4) per hypothesis. This tool
then does what a persuasive agent cannot talk its way around: it reads the
evidence ledger and CAPS each criterion at what the recorded evidence can
actually support, applies penalties for unanswered contradicting facts,
eliminates hypotheses with refuted predictions, and only then computes the
weighted total. Winning a debate is not winning the investigation.

Criteria and default weights (engineering defaults, tunable in
debugging/trace_config.json; they are not validated constants):

    log           25   direct evidence from logs / traces / runtime output
    source        25   source-code verification
    path          20   execution-path consistency
    alternatives  15   alternative hypotheses eliminated
    verification  15   reproducibility or independent verification

Usage:
    score.py score --inv INV --id H-01 --scores log=3,source=4,path=3,alternatives=2,verification=1 \
                   --judge adversarial-reviewer --rationale "..."
    score.py duel  --inv INV --a H-01 --b H-02 --scores-a log=3,... --scores-b log=2,... \
                   --judge adversarial-reviewer --rationale "..." [--needs "evidence that would separate them"]
    score.py merge --inv INV --from H-03 --into H-02 --judge NAME --rationale "..."
    score.py rank  --inv INV
    score.py verdict --inv INV --verification pass|partial|fail|not-run [--verifier NAME] [--notes TEXT]
    score.py weights [--inv INV]
"""
from __future__ import annotations

import argparse
import os
import sys
from typing import Any, Dict, List, Optional, Tuple

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import CRITERIA, DEFAULT_WEIGHTS, die, inv_path, load_json, now_iso, save_json  # noqa: E402

DEFAULT_THRESHOLDS = {"confirmed": 80, "probable": 65, "provisional": 50, "min_margin": 10}
RUNTIME_CLASSES = {"log", "stacktrace", "telemetry", "runtime"}
CODE_CLASSES = {"source", "git", "config"}
CONTRADICTION_PENALTY = 10
MAX_PENALTY = 30


def load_config(inv: str) -> Tuple[Dict[str, int], Dict[str, int]]:
    weights, thresholds = dict(DEFAULT_WEIGHTS), dict(DEFAULT_THRESHOLDS)
    root = os.path.dirname(os.path.dirname(os.path.abspath(inv)))
    cfg = load_json(os.path.join(root, "trace_config.json"), default={})
    weights.update({k: v for k, v in cfg.get("weights", {}).items() if k in CRITERIA})
    thresholds.update(cfg.get("thresholds", {}))
    if sum(weights.values()) != 100:
        die("weights in trace_config.json must sum to 100, got %d" % sum(weights.values()))
    return weights, thresholds


def parse_scores(text: str) -> Dict[str, int]:
    out: Dict[str, int] = {}
    for pair in text.split(","):
        if "=" not in pair:
            die("scores look like log=3,source=4,path=3,alternatives=2,verification=1")
        k, v = pair.split("=", 1)
        k = k.strip()
        if k not in CRITERIA:
            die("unknown criterion %r (expected: %s)" % (k, ", ".join(CRITERIA)))
        try:
            val = int(v)
        except ValueError:
            die("score for %s must be an integer 0-4" % k)
        if not 0 <= val <= 4:
            die("score for %s must be between 0 and 4" % k)
        out[k] = val
    missing = [c for c in CRITERIA if c not in out]
    if missing:
        die("missing score(s) for: " + ", ".join(missing))
    return out


def usable_evidence(ledger: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    out = {}
    for item in ledger["items"]:
        stale = (item.get("recheck") or {}).get("result") in ("mismatch", "missing-file")
        if not stale:
            out[item["id"]] = item
    return out


def compute(h: Dict[str, Any], raw: Dict[str, int], evidence: Dict[str, Dict[str, Any]],
            weights: Dict[str, int]) -> Dict[str, Any]:
    caps: Dict[str, str] = {}
    capped = dict(raw)

    def cap(criterion: str, limit: int, reason: str) -> None:
        if capped[criterion] > limit:
            capped[criterion] = limit
            caps[criterion] = "capped at %d: %s" % (limit, reason)

    facts_for = [evidence[e] for e in h.get("evidence_for", []) if e in evidence and evidence[e]["grade"] == "FACT"]
    runtime_facts = [e for e in facts_for if e["class"] in RUNTIME_CLASSES]
    code_facts = [e for e in facts_for if e["class"] in CODE_CLASSES]
    if not runtime_facts:
        cap("log", 1, "no FACT-grade log/stacktrace/telemetry/runtime evidence supports it")
    elif len(runtime_facts) == 1:
        cap("log", 3, "only one FACT-grade runtime evidence item; 4 needs independent corroboration")
    if not code_facts:
        cap("source", 1, "no FACT-grade source/git/config evidence; the code was not shown to behave as claimed")

    path = h.get("execution_path", [])
    observed = [s for s in path if s.get("observed")]
    if not path:
        cap("path", 0, "no execution path submitted")
    elif not observed:
        cap("path", 1, "no step of the execution path was observed at runtime; the whole path is inferred from code")
    elif len(observed) < len(path):
        cap("path", 3, "%d of %d path steps are inferred rather than observed" % (len(path) - len(observed), len(path)))

    rebuttals = h.get("rival_rebuttals", [])
    backed = [r for r in rebuttals if any(e in evidence and evidence[e]["grade"] == "FACT" for e in r.get("evidence", []))]
    if not rebuttals:
        cap("alternatives", 0, "no competing hypothesis was addressed")
    elif not backed:
        cap("alternatives", 1, "rivals were argued against without FACT-grade evidence")

    preds = h.get("predictions", [])
    confirmed = [p for p in preds if p.get("status") == "confirmed"]
    untested = [p for p in preds if p.get("status") == "untested"]
    refuted = [p for p in preds if p.get("status") == "refuted"]
    if not preds:
        cap("verification", 1, "no testable predictions were stated")
    elif not confirmed:
        cap("verification", 1, "no prediction has been independently confirmed")
    elif untested:
        cap("verification", 3, "%d prediction(s) still untested" % len(untested))

    unanswered = [e for e in h.get("evidence_against", [])
                  if e in evidence and evidence[e]["grade"] == "FACT" and e not in h.get("addressed_contradictions", [])]
    penalty = min(MAX_PENALTY, CONTRADICTION_PENALTY * len(unanswered))

    weighted = sum(weights[c] * capped[c] / 4.0 for c in CRITERIA)
    total = max(0.0, round(weighted - penalty, 1))
    eliminated = None
    if refuted:
        eliminated = "prediction(s) %s refuted" % ", ".join(p["id"] for p in refuted)
        total = 0.0
    return {"raw": raw, "capped": capped, "caps_applied": caps, "penalty": penalty,
            "unanswered_contradictions": unanswered, "weighted": round(weighted, 1), "total": total,
            "eliminated_reason": eliminated,
            "evidence_counts": {"runtime_facts": len(runtime_facts), "code_facts": len(code_facts),
                                "path_steps": len(path), "path_observed": len(observed),
                                "rebuttals_backed": len(backed), "predictions_confirmed": len(confirmed),
                                "predictions_untested": len(untested), "predictions_refuted": len(refuted)}}


def load_all(inv: str) -> Tuple[Dict[str, Any], Dict[str, Any], Dict[str, Any]]:
    return (load_json(inv_path(inv, "hypotheses.json")), load_json(inv_path(inv, "evidence.json")),
            load_json(inv_path(inv, "tournament.json")))


def get_h(hyps: Dict[str, Any], hid: str) -> Dict[str, Any]:
    h = next((x for x in hyps["items"] if x["id"] == hid), None)
    if not h:
        die("unknown hypothesis " + hid)
    return h


def describe(hid: str, result: Dict[str, Any]) -> str:
    lines = ["%s  total=%.1f  (weighted %.1f, penalty %d)" % (hid, result["total"], result["weighted"], result["penalty"])]
    for c in CRITERIA:
        note = result["caps_applied"].get(c, "")
        lines.append("    %-13s raw %d -> %d  %s" % (c, result["raw"][c], result["capped"][c], note))
    if result["unanswered_contradictions"]:
        lines.append("    unanswered contradicting FACTs: " + ", ".join(result["unanswered_contradictions"]))
    if result["eliminated_reason"]:
        lines.append("    ELIMINATED: " + result["eliminated_reason"])
    return "\n".join(lines)


def record_score(h: Dict[str, Any], result: Dict[str, Any], judge: str, rationale: str) -> None:
    h["scores"] = dict(result, judge=judge, rationale=rationale, at=now_iso())
    if result["eliminated_reason"] and h["status"] not in ("merged",):
        h["status"] = "refuted"


def cmd_score(args: argparse.Namespace) -> None:
    hyps, ledger, _ = load_all(args.inv)
    weights, _thr = load_config(args.inv)
    h = get_h(hyps, args.id)
    result = compute(h, parse_scores(args.scores), usable_evidence(ledger), weights)
    record_score(h, result, args.judge, args.rationale)
    save_json(inv_path(args.inv, "hypotheses.json"), hyps)
    print(describe(args.id, result))


def cmd_duel(args: argparse.Namespace) -> None:
    hyps, ledger, tournament = load_all(args.inv)
    weights, thresholds = load_config(args.inv)
    if args.a == args.b:
        die("a hypothesis cannot duel itself")
    if len(args.rationale.strip()) < 20:
        die("--rationale must explain the decision in terms of evidence ids, not style")
    ha, hb = get_h(hyps, args.a), get_h(hyps, args.b)
    for h in (ha, hb):
        if h["status"] in ("merged", "refuted"):
            die("%s is %s and cannot duel" % (h["id"], h["status"]))
    evidence = usable_evidence(ledger)
    ra = compute(ha, parse_scores(args.scores_a), evidence, weights)
    rb = compute(hb, parse_scores(args.scores_b), evidence, weights)
    record_score(ha, ra, args.judge, args.rationale)
    record_score(hb, rb, args.judge, args.rationale)
    margin = round(abs(ra["total"] - rb["total"]), 1)
    winner: Optional[str]
    loser: Optional[str]
    if ra["eliminated_reason"] and rb["eliminated_reason"]:
        outcome, winner, loser = "both_eliminated", None, None
    elif ra["eliminated_reason"] or rb["eliminated_reason"]:
        outcome = "elimination"
        winner, loser = (args.b, args.a) if ra["eliminated_reason"] else (args.a, args.b)
    else:
        winner, loser = (args.a, args.b) if ra["total"] >= rb["total"] else (args.b, args.a)
        outcome = "win" if margin >= thresholds["min_margin"] else "narrow"
    if outcome == "narrow" and not args.needs:
        die("the margin is %.1f (< %d). A narrow duel does not eliminate anyone: pass --needs describing the "
            "evidence that would separate these hypotheses, then go and collect it." % (margin, thresholds["min_margin"]))
    by_id = {args.a: ha, args.b: hb}
    retained: List[str] = []
    if outcome in ("win", "elimination") and winner and loser:
        if by_id[loser]["status"] != "refuted":
            by_id[loser]["status"] = "eliminated"
        by_id[loser]["eliminated_by"] = winner
        by_id[winner]["status"] = "champion"
        retained = list(by_id[loser].get("secondary_findings", []))
        for other in hyps["items"]:
            if other["status"] == "champion" and other["id"] != winner:
                other["status"] = "active"
    elif outcome == "narrow":
        ha["status"] = hb["status"] = "active"
    entry = {
        "round": len(tournament["rounds"]) + 1, "a": args.a, "b": args.b,
        "raw_scores": {args.a: ra["raw"], args.b: rb["raw"]},
        "capped_scores": {args.a: ra["capped"], args.b: rb["capped"]},
        "caps_applied": {args.a: ra["caps_applied"], args.b: rb["caps_applied"]},
        "penalties": {args.a: ra["penalty"], args.b: rb["penalty"]},
        "totals": {args.a: ra["total"], args.b: rb["total"]}, "margin": margin,
        "outcome": outcome, "winner": winner, "loser": loser, "judge": args.judge,
        "rationale": args.rationale, "retained_findings": retained, "at": now_iso(),
    }
    if args.needs:
        entry["discriminating_evidence_needed"] = args.needs
    tournament["rounds"].append(entry)
    save_json(inv_path(args.inv, "hypotheses.json"), hyps)
    save_json(inv_path(args.inv, "tournament.json"), tournament)
    print("round %d: %s vs %s" % (entry["round"], args.a, args.b))
    print(describe(args.a, ra))
    print(describe(args.b, rb))
    if outcome == "win":
        print("=> %s advances (margin %.1f). %s is eliminated; its findings are retained." % (winner, margin, loser))
    elif outcome == "elimination":
        print("=> %s advances because %s was eliminated by its own refuted prediction." % (winner, loser))
    elif outcome == "narrow":
        print("=> NARROW (margin %.1f). Nobody is eliminated. Collect: %s" % (margin, args.needs))
    else:
        print("=> BOTH ELIMINATED. Return to step 4 and generate new hypotheses from what refuted them.")


def cmd_merge(args: argparse.Namespace) -> None:
    hyps, _ledger, tournament = load_all(args.inv)
    src, dst = get_h(hyps, args.src), get_h(hyps, args.into)
    if len(args.rationale.strip()) < 20:
        die("--rationale must say why these are the same explanation (same Layer 3 root cause)")
    src["status"] = "merged"
    src["merged_into"] = dst["id"]
    for key in ("evidence_for", "evidence_against", "secondary_findings", "falsifiers", "assumptions"):
        for v in src.get(key, []):
            if v not in dst.setdefault(key, []):
                dst[key].append(v)
    known = {p["id"] for p in dst.get("predictions", [])}
    for p in src.get("predictions", []):
        q = dict(p)
        if q["id"] in known:
            q["id"] = "P%d" % (len(dst["predictions"]) + 1)
        dst["predictions"].append(q)
        known.add(q["id"])
    tournament["rounds"].append({
        "round": len(tournament["rounds"]) + 1, "a": src["id"], "b": dst["id"], "totals": {},
        "outcome": "merge", "winner": dst["id"], "loser": None, "judge": args.judge,
        "rationale": args.rationale, "retained_findings": [], "at": now_iso()})
    save_json(inv_path(args.inv, "hypotheses.json"), hyps)
    save_json(inv_path(args.inv, "tournament.json"), tournament)
    print("merged %s into %s (evidence and predictions carried over; re-score %s)" % (src["id"], dst["id"], dst["id"]))


def ranked(hyps: Dict[str, Any]) -> List[Dict[str, Any]]:
    scored = [h for h in hyps["items"] if h.get("scores")]
    return sorted(scored, key=lambda h: -h["scores"]["total"])


def cmd_rank(args: argparse.Namespace) -> None:
    hyps, _l, _t = load_all(args.inv)
    rows = ranked(hyps)
    unscored = [h["id"] for h in hyps["items"] if not h.get("scores") and h["status"] == "active"]
    print("%-6s %-11s %6s  %s" % ("id", "status", "total", "title"))
    for h in rows:
        print("%-6s %-11s %6.1f  %s" % (h["id"], h["status"], h["scores"]["total"], h["title"]))
    if unscored:
        print("not yet scored: " + ", ".join(unscored))


def cmd_verdict(args: argparse.Namespace) -> None:
    hyps, _ledger, tournament = load_all(args.inv)
    _weights, thr = load_config(args.inv)
    reasons: List[str] = []
    live = [h for h in ranked(hyps) if h["status"] in ("active", "champion", "verified")]
    unscored = [h["id"] for h in hyps["items"] if not h.get("scores") and h["status"] == "active"]
    if unscored:
        die("active hypotheses have not been scored: %s. Score or eliminate them before a verdict." % ", ".join(unscored))
    champion = live[0] if live else None
    # Runner-up is the best OTHER scored explanation that was not refuted or merged, eliminated ones included:
    # a champion must stay clear of every rival, not only of those still standing.
    others = [h for h in ranked(hyps) if h["status"] not in ("refuted", "merged") and (not champion or h["id"] != champion["id"])]
    runner = others[0] if others else None
    confidence = "INSUFFICIENT_EVIDENCE"
    margin = None
    if champion is None:
        reasons.append("no surviving hypothesis: every candidate was eliminated or refuted")
    else:
        total = champion["scores"]["total"]
        margin = round(total - runner["scores"]["total"], 1) if runner else None
        preds = champion.get("predictions", [])
        untested = [p["id"] for p in preds if p["status"] == "untested"]
        if args.verification == "fail":
            champion["status"] = "refuted"
            reasons.append("independent verification failed for %s; it cannot be reported as the root cause" % champion["id"])
        elif total < thr["provisional"]:
            reasons.append("best total %.1f is below the provisional threshold %d" % (total, thr["provisional"]))
        elif margin is not None and margin < thr["min_margin"]:
            reasons.append("%s (%.1f) and %s (%.1f) are separated by %.1f, below the minimum margin %d: "
                           "the evidence does not discriminate between them" % (
                               champion["id"], total, runner["id"], runner["scores"]["total"], margin, thr["min_margin"]))
        else:
            if args.verification == "pass" and total >= thr["confirmed"] and not untested:
                confidence = "CONFIRMED"
            elif args.verification in ("pass", "partial") and total >= thr["probable"]:
                confidence = "PROBABLE"
                if untested:
                    reasons.append("prediction(s) %s remain untested" % ", ".join(untested))
                if args.verification == "partial":
                    reasons.append("verification was partial")
                if total < thr["confirmed"]:
                    reasons.append("total %.1f is below the confirmed threshold %d" % (total, thr["confirmed"]))
            else:
                confidence = "PROVISIONAL"
                if args.verification == "not-run":
                    reasons.append("independent verification has not been run")
                elif total < thr["probable"]:
                    reasons.append("total %.1f is below the probable threshold %d" % (total, thr["probable"]))
            champion["status"] = "verified" if confidence in ("CONFIRMED", "PROBABLE") else "champion"
    if confidence == "INSUFFICIENT_EVIDENCE":
        reasons.append("TRACE declines to name a root cause. Report the leading candidates, what is established, "
                       "and the specific evidence (Mode B instrumentation) that would decide it.")
        for h in hyps["items"]:
            if h["status"] == "champion":
                h["status"] = "insufficient"
    final = {
        "champion": champion["id"] if champion and confidence != "INSUFFICIENT_EVIDENCE" else None,
        "leading_candidates": [h["id"] for h in live[:3]],
        "total": champion["scores"]["total"] if champion else None,
        "runner_up": runner["id"] if runner else None, "margin": margin,
        "verification": args.verification, "verifier": args.verifier or "unspecified",
        "verification_notes": args.notes or "", "confidence": confidence, "verdict": confidence,
        "reasons": reasons, "thresholds": thr, "decided_at": now_iso(),
    }
    tournament["final"] = final
    save_json(inv_path(args.inv, "tournament.json"), tournament)
    save_json(inv_path(args.inv, "hypotheses.json"), hyps)
    ctx_path = inv_path(args.inv, "context.json")
    ctx = load_json(ctx_path, default={})
    if ctx:
        ctx["status"] = "concluded" if confidence in ("CONFIRMED", "PROBABLE") else "open-" + confidence.lower()
        ctx["confidence"] = confidence
        save_json(ctx_path, ctx)
    print("verdict: %s" % confidence)
    if final["champion"]:
        print("root-cause hypothesis: %s  total=%.1f  margin=%s" % (final["champion"], final["total"], margin))
    for r in reasons:
        print("  - " + r)


def cmd_weights(args: argparse.Namespace) -> None:
    weights, thr = load_config(args.inv) if args.inv else (DEFAULT_WEIGHTS, DEFAULT_THRESHOLDS)
    for c in CRITERIA:
        print("%-13s %d" % (c, weights[c]))
    print("thresholds: %s" % thr)


def main() -> None:
    ap = argparse.ArgumentParser(description="TRACE scoring and tournament ledger")
    sub = ap.add_subparsers(dest="cmd")
    p = sub.add_parser("score"); p.add_argument("--inv", required=True); p.add_argument("--id", required=True)
    p.add_argument("--scores", required=True); p.add_argument("--judge", required=True); p.add_argument("--rationale", required=True)
    p.set_defaults(fn=cmd_score)
    p = sub.add_parser("duel"); p.add_argument("--inv", required=True); p.add_argument("--a", required=True); p.add_argument("--b", required=True)
    p.add_argument("--scores-a", required=True); p.add_argument("--scores-b", required=True)
    p.add_argument("--judge", required=True); p.add_argument("--rationale", required=True); p.add_argument("--needs")
    p.set_defaults(fn=cmd_duel)
    p = sub.add_parser("merge"); p.add_argument("--inv", required=True); p.add_argument("--from", dest="src", required=True)
    p.add_argument("--into", required=True); p.add_argument("--judge", required=True); p.add_argument("--rationale", required=True)
    p.set_defaults(fn=cmd_merge)
    p = sub.add_parser("rank"); p.add_argument("--inv", required=True); p.set_defaults(fn=cmd_rank)
    p = sub.add_parser("verdict"); p.add_argument("--inv", required=True)
    p.add_argument("--verification", required=True, choices=["pass", "partial", "fail", "not-run"])
    p.add_argument("--verifier"); p.add_argument("--notes"); p.set_defaults(fn=cmd_verdict)
    p = sub.add_parser("weights"); p.add_argument("--inv"); p.set_defaults(fn=cmd_weights)
    args = ap.parse_args()
    if not getattr(args, "fn", None):
        ap.print_help(); sys.exit(1)
    args.fn(args)


if __name__ == "__main__":
    main()
