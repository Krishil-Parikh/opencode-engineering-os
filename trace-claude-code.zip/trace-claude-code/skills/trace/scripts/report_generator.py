#!/usr/bin/env python3
"""TRACE report generator.

Builds final_report.md for one investigation from its JSON ledgers, so the
report can only say what the ledgers support. It refuses to print a root
cause when the verdict is INSUFFICIENT_EVIDENCE, and every claim carries its
evidence ids and grade.

Usage:
    report_generator.py --inv debugging/investigations/BUG-001 [--fix-file fix.md] [--out final_report.md]

`--fix-file` is a markdown file with the recommended fix written by the
orchestrator (section 7). Without it the section lists what is still needed.
"""
from __future__ import annotations

import argparse
import os
import sys
from typing import Any, Dict, List

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import die, inv_path, load_json, now_iso  # noqa: E402

CONFIDENCE_TEXT = {
    "CONFIRMED": "Confirmed. Independent verification passed, every stated prediction was checked, and no evidence contradicts it.",
    "PROBABLE": "Probable. The evidence favours this explanation and verification did not contradict it, but gaps remain (listed below).",
    "PROVISIONAL": "Provisional. This is the best-supported hypothesis so far, pending the confirmation listed below. Do not treat it as established.",
    "INSUFFICIENT_EVIDENCE": "Insufficient evidence. TRACE does not name a root cause for this incident.",
}


def cite(ids: List[str], ev: Dict[str, Dict[str, Any]]) -> str:
    if not ids:
        return "_no evidence cited_"
    return ", ".join("%s (%s)" % (i, ev[i]["grade"] if i in ev else "missing") for i in ids)


def loc(item: Dict[str, Any]) -> str:
    src = item.get("source", {})
    if "path" in src:
        if "line_start" in src:
            end = src.get("line_end", src["line_start"])
            return "`%s:%s%s`" % (src["path"], src["line_start"], "-%s" % end if end != src["line_start"] else "")
        return "`%s`" % src["path"]
    if "command" in src:
        return "`$ %s`" % src["command"]
    return src.get("url", "-")


def build(inv: str, fix_text: str) -> str:
    ctx = load_json(inv_path(inv, "context.json"))
    ledger = load_json(inv_path(inv, "evidence.json"))
    hyps = load_json(inv_path(inv, "hypotheses.json"))
    tour = load_json(inv_path(inv, "tournament.json"))
    findings = load_json(inv_path(inv, "findings.json"), default={"findings": []})
    final = tour.get("final")
    if not final:
        die("no verdict recorded. Run `score.py verdict --inv %s --verification ...` first." % inv)
    ev = {i["id"]: i for i in ledger["items"]}
    by_id = {h["id"]: h for h in hyps["items"]}
    conf = final["confidence"]
    champ = by_id.get(final["champion"]) if final.get("champion") else None
    out: List[str] = []
    w = out.append

    w("# %s: %s" % (ctx["id"], ctx["title"]))
    w("")
    w("_TRACE root-cause report. Generated %s from the investigation ledgers._" % now_iso())
    w("")
    w("| | |")
    w("|---|---|")
    w("| Error | %s |" % ctx.get("error", "unknown"))
    w("| First observed | %s |" % ctx.get("first_observed", "unknown"))
    w("| Service | %s |" % ctx.get("service", "unknown"))
    w("| Mode | %s |" % ("A (retrospective)" if ctx.get("mode") == "A" else "B (instrumented)"))
    w("| Confidence | **%s** |" % conf.replace("_", " ").title())
    w("")

    # 1 ------------------------------------------------------------------
    w("## 1. Root cause")
    w("")
    if champ:
        w(champ["layers"]["root_cause"])
        w("")
        w("> %s" % champ["statement"])
        w("")
        w("Hypothesis %s, proposed by %s (%s lens). Evidence score %.1f / 100%s." % (
            champ["id"], champ["owner"], champ["lens"].replace("_", " "), final["total"],
            (", %.1f ahead of %s" % (final["margin"], final["runner_up"])) if final.get("runner_up") and final.get("margin") is not None else ""))
    else:
        w("**Not determined.** The available evidence does not support naming a root cause.")
        w("")
        for r in final.get("reasons", []):
            w("- " + r)
        cands = [by_id[c] for c in final.get("leading_candidates", []) if c in by_id]
        if cands:
            w("")
            w("Leading candidates, none established:")
            w("")
            w("| Hypothesis | Score | Proposed root cause |")
            w("|---|---|---|")
            for h in cands:
                w("| %s %s | %s | %s |" % (h["id"], h["title"], (h.get("scores") or {}).get("total", "-"), h["layers"]["root_cause"]))
    w("")

    lead = champ or (by_id.get(final["leading_candidates"][0]) if final.get("leading_candidates") else None)

    # 2, 3 ---------------------------------------------------------------
    w("## 2. Failure location")
    w("")
    w("_Layer 1: where the failure surfaced._")
    w("")
    w(lead["layers"]["failure_location"] if lead else "unknown")
    w("")
    w("## 3. Originating trigger")
    w("")
    w("_Layer 2: the event or condition that made it fail this time._")
    w("")
    if lead:
        w(lead["layers"]["trigger"] + ("" if champ else "  _(per leading candidate %s; not established)_" % lead["id"]))
    else:
        w("unknown")
    w("")

    # 4 ------------------------------------------------------------------
    w("## 4. Execution path")
    w("")
    if lead and lead.get("execution_path"):
        w("```")
        for depth, step in enumerate(lead["execution_path"]):
            prefix = "" if depth == 0 else "    " * (depth - 1) + "└── "
            tag = "[observed]" if step.get("observed") else "[inferred]"
            w("%s%s  %s  %s%s" % (prefix, step["step"], step.get("location", ""), tag,
                                  "  " + ",".join(step.get("evidence", [])) if step.get("evidence") else ""))
        w("```")
        w("")
        inferred = [s["step"] for s in lead["execution_path"] if not s.get("observed")]
        if inferred:
            w("Steps marked `[inferred]` come from reading the code, not from runtime evidence: %s." % ", ".join("`%s`" % s for s in inferred))
        else:
            w("Every step is backed by runtime evidence.")
    else:
        w("No execution path was established.")
    w("")

    # 5 ------------------------------------------------------------------
    w("## 5. Evidence")
    w("")
    if lead:
        w("### Supporting %s" % lead["id"])
        w("")
        w("| ID | Grade | Class | What it shows | Where |")
        w("|---|---|---|---|---|")
        for e in lead.get("evidence_for", []):
            if e in ev:
                w("| %s | %s | %s | %s | %s |" % (e, ev[e]["grade"], ev[e]["class"], ev[e]["summary"].replace("|", "/"), loc(ev[e])))
        w("")
        against = [e for e in lead.get("evidence_against", []) if e in ev]
        if against:
            w("### Contradicting or complicating %s" % lead["id"])
            w("")
            w("| ID | Grade | What it shows | Addressed? |")
            w("|---|---|---|---|")
            for e in against:
                w("| %s | %s | %s | %s |" % (e, ev[e]["grade"], ev[e]["summary"].replace("|", "/"),
                                             "yes" if e in lead.get("addressed_contradictions", []) else "**no**"))
            w("")
        if lead.get("predictions"):
            w("### Predictions tested")
            w("")
            w("| | If the hypothesis is true, then | Check | Result | Evidence |")
            w("|---|---|---|---|---|")
            for p in lead["predictions"]:
                w("| %s | %s | %s | **%s** | %s |" % (p["id"], p["statement"].replace("|", "/"), p["check"].replace("|", "/"),
                                                     p["status"], ", ".join(p.get("evidence", [])) or "-"))
            w("")
        if lead.get("assumptions"):
            w("### Assumptions not checked")
            w("")
            for a in lead["assumptions"]:
                w("- " + a)
            w("")
        if lead.get("falsifiers"):
            w("### What would prove this wrong")
            w("")
            for f in lead["falsifiers"]:
                w("- " + f)
            w("")
    grades = {}
    for item in ledger["items"]:
        grades[item["grade"]] = grades.get(item["grade"], 0) + 1
    w("Ledger totals: %s. Full ledger: `evidence.json`." % ", ".join("%d %s" % (v, k) for k, v in sorted(grades.items())))
    stale = [i["id"] for i in ledger["items"] if (i.get("recheck") or {}).get("result") in ("mismatch", "missing-file")]
    if stale:
        w("")
        w("**Stale evidence excluded from scoring:** %s." % ", ".join(stale))
    w("")

    # Alternatives ------------------------------------------------------
    w("### Alternatives considered")
    w("")
    w("| Hypothesis | Lens | Status | Score | Why it lost or what is unresolved |")
    w("|---|---|---|---|---|")
    for h in hyps["items"]:
        if lead and h["id"] == lead["id"] and champ:
            continue
        sc = h.get("scores") or {}
        why = sc.get("eliminated_reason") or ""
        if not why:
            rounds = [r for r in tour["rounds"] if r.get("loser") == h["id"]]
            why = rounds[-1]["rationale"] if rounds else (("merged into " + h["merged_into"]) if h.get("merged_into") else sc.get("rationale", ""))
        w("| %s %s | %s | %s | %s | %s |" % (h["id"], h["title"], h["lens"].replace("_", " "), h["status"],
                                           sc.get("total", "-"), (why or "-").replace("|", "/").replace("\n", " ")))
    w("")
    if tour["rounds"]:
        w("<details><summary>Tournament record (%d round%s)</summary>" % (len(tour["rounds"]), "" if len(tour["rounds"]) == 1 else "s"))
        w("")
        for r in tour["rounds"]:
            totals = ", ".join("%s %.1f" % kv for kv in r.get("totals", {}).items())
            w("- Round %d: %s vs %s. Outcome **%s**%s. %s Judge: %s. %s" % (
                r["round"], r["a"], r["b"], r["outcome"], (" (winner %s)" % r["winner"]) if r.get("winner") else "",
                ("Totals: %s." % totals) if totals else "", r["judge"], r["rationale"]))
            for hid, caps in (r.get("caps_applied") or {}).items():
                for crit, note in caps.items():
                    w("  - %s %s %s" % (hid, crit, note))
            if r.get("discriminating_evidence_needed"):
                w("  - Needed to separate them: %s" % r["discriminating_evidence_needed"])
        w("")
        w("</details>")
        w("")

    # 6 ------------------------------------------------------------------
    w("## 6. Other discovered issues")
    w("")
    if findings["findings"]:
        w("| ID | Finding | Location | Severity | Status | Verified | Related to this bug |")
        w("|---|---|---|---|---|---|---|")
        for f in findings["findings"]:
            where = "%s:%s" % (f["file"], f["line"]) if f.get("line") else f["file"]
            w("| %s | %s | `%s` | %s | %s | %s | %s |" % (
                f["id"], f["title"].replace("|", "/"), where, f["severity"], f["status"].capitalize(),
                "yes" if f["verified"] else "no", f["related_to_original_bug"]))
        w("")
        w("Only findings marked **Confirmed** are established. The rest are leads recorded in the knowledge base for later verification.")
    else:
        w("None recorded.")
    w("")

    # 7 ------------------------------------------------------------------
    w("## 7. Recommended fix")
    w("")
    if fix_text.strip():
        w(fix_text.strip())
        if conf in ("PROVISIONAL", "INSUFFICIENT_EVIDENCE"):
            w("")
            w("> The root cause is not established. Treat the above as mitigation and as instrumentation to settle the question, not as a verified fix.")
    elif conf == "INSUFFICIENT_EVIDENCE":
        w("No fix is recommended because no root cause is established. Deploy the instrumentation in `instrumentation_plan.md` and re-run TRACE on the next occurrence.")
    else:
        w("_Not written yet. Provide `--fix-file`._")
    w("")
    plan = inv_path(inv, "instrumentation_plan.md")
    if os.path.exists(plan):
        w("Instrumentation for the next occurrence: see `instrumentation_plan.md`.")
        w("")

    # 8 ------------------------------------------------------------------
    w("## 8. Confidence")
    w("")
    w("**%s**" % conf.replace("_", " ").title())
    w("")
    w(CONFIDENCE_TEXT[conf])
    w("")
    for r in final.get("reasons", []):
        w("- " + r)
    w("- Verification: %s (by %s)%s" % (final["verification"], final.get("verifier", "unspecified"),
                                       ". " + final["verification_notes"] if final.get("verification_notes") else ""))
    if lead:
        untested = [p for p in lead.get("predictions", []) if p["status"] == "untested"]
        if untested:
            w("")
            w("To raise confidence, run:")
            w("")
            for p in untested:
                w("- %s: %s" % (p["id"], p["check"]))
    w("")
    w("---")
    w("_Every error has an execution history. Every hypothesis needs evidence. Every conclusion must survive verification._")
    return "\n".join(out) + "\n"


def main() -> None:
    ap = argparse.ArgumentParser(description="Generate the TRACE final report")
    ap.add_argument("--inv", required=True)
    ap.add_argument("--fix-file")
    ap.add_argument("--out")
    args = ap.parse_args()
    fix = ""
    if args.fix_file:
        if not os.path.exists(args.fix_file):
            die("fix file not found: " + args.fix_file)
        fix = open(args.fix_file, "r", encoding="utf-8").read()
    text = build(args.inv, fix)
    out = args.out or inv_path(args.inv, "final_report.md")
    with open(out, "w", encoding="utf-8") as fh:
        fh.write(text)
    print("wrote " + out)


if __name__ == "__main__":
    main()
