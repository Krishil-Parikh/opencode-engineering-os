"""Shared helpers for the TRACE scripts. Standard library only (Python 3.8+)."""
from __future__ import annotations

import datetime as _dt
import hashlib
import json
import os
import re
import sys
from typing import Any, Dict, List, Optional

SCHEMA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "schemas")

EVIDENCE_CLASSES = [
    "log", "stacktrace", "source", "git", "telemetry", "config",
    "runtime", "absence", "knowledge_base", "testimony",
]
GRADES = ["FACT", "INFERENCE", "ASSUMPTION"]
HYPOTHESIS_STATUSES = [
    "active", "eliminated", "merged", "champion", "verified", "refuted", "insufficient",
]
FINDING_STATUSES = ["confirmed", "suspicious", "unverified", "disproven"]
SEVERITIES = ["critical", "high", "medium", "low", "info"]
CONFIDENCES = ["high", "medium", "low"]
FINDING_CATEGORIES = [
    "race_condition", "suspicious_function", "dependency_failure",
    "unhandled_exception", "recurring_pattern", "resource_leak", "other",
]
CRITERIA = ["log", "source", "path", "alternatives", "verification"]
DEFAULT_WEIGHTS = {"log": 25, "source": 25, "path": 20, "alternatives": 15, "verification": 15}


def now_iso() -> str:
    return _dt.datetime.now(_dt.timezone.utc).replace(microsecond=0).isoformat()


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8", "replace")).hexdigest()


def die(msg: str, code: int = 2) -> None:
    print("error: " + msg, file=sys.stderr)
    sys.exit(code)


def load_json(path: str, default: Any = None) -> Any:
    if not os.path.exists(path):
        if default is not None:
            return default
        die("file not found: " + path)
    with open(path, "r", encoding="utf-8") as fh:
        try:
            return json.load(fh)
        except json.JSONDecodeError as exc:
            die("invalid JSON in %s: %s" % (path, exc))


def save_json(path: str, data: Any) -> None:
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2, ensure_ascii=False)
        fh.write("\n")
    os.replace(tmp, path)


def next_id(prefix: str, existing: List[str], width: int = 3) -> str:
    top = 0
    pat = re.compile(r"^%s-(\d+)$" % re.escape(prefix))
    for ident in existing:
        m = pat.match(ident or "")
        if m:
            top = max(top, int(m.group(1)))
    return "%s-%0*d" % (prefix, width, top + 1)


def inv_path(inv: str, name: str) -> str:
    if not os.path.isdir(inv):
        die("investigation directory not found: %s (create it with workspace.py new)" % inv)
    return os.path.join(inv, name)


def read_lines(path: str, start: int, end: int) -> str:
    """Return lines start..end (1-based, inclusive) of a text file."""
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        lines = fh.read().splitlines()
    if start < 1 or start > len(lines):
        die("%s has %d lines; cannot read line %d" % (path, len(lines), start))
    return "\n".join(lines[start - 1:min(end, len(lines))])


def parse_line_range(spec: str) -> "tuple[int, int]":
    m = re.match(r"^(\d+)(?:-(\d+))?$", spec.strip())
    if not m:
        die("line range must look like 42 or 40-58, got: " + spec)
    start = int(m.group(1))
    end = int(m.group(2) or start)
    if end < start:
        die("line range end is before start: " + spec)
    return start, end


# --------------------------------------------------------------------------
# Minimal JSON-Schema subset validator (type, required, properties, enum,
# pattern, items, minimum, maximum, minItems, additionalProperties=false).
# Enough for the bundled schemas; avoids a jsonschema dependency.
# --------------------------------------------------------------------------
_TYPES = {
    "object": dict, "array": list, "string": str, "boolean": bool,
    "number": (int, float), "integer": int, "null": type(None),
}


def validate(instance: Any, schema: Dict[str, Any], path: str = "$") -> List[str]:
    errors: List[str] = []
    stype = schema.get("type")
    if stype:
        types = stype if isinstance(stype, list) else [stype]
        ok = False
        for t in types:
            py = _TYPES[t]
            if isinstance(instance, py) and not (t in ("number", "integer") and isinstance(instance, bool)):
                ok = True
        if not ok:
            return ["%s: expected %s, got %s" % (path, "/".join(types), type(instance).__name__)]
    if "enum" in schema and instance not in schema["enum"]:
        errors.append("%s: %r is not one of %s" % (path, instance, schema["enum"]))
    if isinstance(instance, str) and "pattern" in schema and not re.search(schema["pattern"], instance):
        errors.append("%s: %r does not match %s" % (path, instance, schema["pattern"]))
    if isinstance(instance, str) and "minLength" in schema and len(instance) < schema["minLength"]:
        errors.append("%s: string shorter than %d" % (path, schema["minLength"]))
    if isinstance(instance, (int, float)) and not isinstance(instance, bool):
        if "minimum" in schema and instance < schema["minimum"]:
            errors.append("%s: %s is below minimum %s" % (path, instance, schema["minimum"]))
        if "maximum" in schema and instance > schema["maximum"]:
            errors.append("%s: %s is above maximum %s" % (path, instance, schema["maximum"]))
    if isinstance(instance, dict):
        for key in schema.get("required", []):
            if key not in instance:
                errors.append("%s: missing required field '%s'" % (path, key))
        props = schema.get("properties", {})
        for key, value in instance.items():
            if key in props:
                errors.extend(validate(value, props[key], "%s.%s" % (path, key)))
            elif schema.get("additionalProperties") is False:
                errors.append("%s: unexpected field '%s'" % (path, key))
    if isinstance(instance, list):
        if "minItems" in schema and len(instance) < schema["minItems"]:
            errors.append("%s: needs at least %d item(s)" % (path, schema["minItems"]))
        if "items" in schema:
            for i, item in enumerate(instance):
                errors.extend(validate(item, schema["items"], "%s[%d]" % (path, i)))
    return errors


def load_schema(name: str) -> Dict[str, Any]:
    return load_json(os.path.join(SCHEMA_DIR, name))


def find_workspace(start: Optional[str] = None) -> Optional[str]:
    """Walk upward looking for a debugging/ workspace."""
    cur = os.path.abspath(start or os.getcwd())
    while True:
        cand = os.path.join(cur, "debugging")
        if os.path.isdir(os.path.join(cand, "investigations")):
            return cand
        parent = os.path.dirname(cur)
        if parent == cur:
            return None
        cur = parent
