#!/usr/bin/env python3
"""TRACE git-history investigator helper. Read-only: runs git log / blame / diff only.

Answers "what changed near the failure, and when?" without touching the
working tree. It never checks out, resets, stashes or bisects by itself.

Usage:
    git_suspects.py recent  --files services/payment.py,services/orders.py [--since "14 days ago"] [--before 2026-11-10T09:47:05]
    git_suspects.py blame   --file services/payment.py --lines 130-150
    git_suspects.py window  --before 2026-11-10T09:47:05 [--hours 72]     (everything merged shortly before the failure)
    git_suspects.py pickaxe --text "wait_for" [--files services/]          (commits that added/removed a string)
    git_suspects.py bisect-plan --good <sha> --bad <sha> --test "pytest tests/test_orders.py -k cancel"

A commit close in time to the first failure is a LEAD (INFERENCE-grade). It
becomes a cause only when the diff is read and shown to produce the failure.
"""
from __future__ import annotations

import argparse
import os
import subprocess
import sys
from typing import List

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import die, parse_line_range  # noqa: E402


def git(root: str, *args: str) -> str:
    try:
        res = subprocess.run(["git", "-C", root] + list(args), capture_output=True, text=True, timeout=120)
    except FileNotFoundError:
        die("git is not installed")
    except subprocess.TimeoutExpired:
        die("git %s timed out" % " ".join(args[:2]))
    if res.returncode != 0:
        die("git %s failed: %s" % (" ".join(args[:2]), res.stderr.strip()))
    return res.stdout


def ensure_repo(root: str) -> None:
    res = subprocess.run(["git", "-C", root, "rev-parse", "--is-inside-work-tree"], capture_output=True, text=True)
    if res.returncode != 0:
        die("%s is not inside a git repository; git history is unavailable as an evidence source" % os.path.abspath(root))


FMT = "%h|%ad|%an|%s"


def cmd_recent(args: argparse.Namespace) -> None:
    ensure_repo(args.root)
    files = [f.strip() for f in args.files.split(",") if f.strip()]
    opts = ["log", "--date=iso-strict", "--pretty=format:" + FMT, "--numstat", "--since", args.since]
    if args.before:
        opts += ["--before", args.before]
    out = git(args.root, *opts, "--", *files)
    if not out.strip():
        print("no commits touched these paths in the window (since %s%s)" % (args.since, ", before " + args.before if args.before else ""))
        print("That rules out a recent code change HERE only. Dependencies, config, data and infrastructure can still have changed.")
        return
    print(out)
    churn = {}
    for line in out.splitlines():
        parts = line.split("\t")
        if len(parts) == 3 and parts[0].isdigit():
            churn[parts[2]] = churn.get(parts[2], 0) + int(parts[0]) + int(parts[1] if parts[1].isdigit() else 0)
    if churn:
        print("\nchurn in window (lines changed):")
        for path, n in sorted(churn.items(), key=lambda kv: -kv[1]):
            print("  %6d  %s" % (n, path))
    print("\nNext: `git -C %s show <sha> -- <file>` for each candidate, and record the relevant hunk as class=git evidence." % args.root)


def cmd_blame(args: argparse.Namespace) -> None:
    ensure_repo(args.root)
    start, end = parse_line_range(args.lines)
    out = git(args.root, "blame", "--date=short", "-L", "%d,%d" % (start, end), "--", args.file)
    print(out.rstrip())
    shas = sorted({line.split()[0].lstrip("^") for line in out.splitlines() if line.strip()})
    print("\ncommits touching these lines:")
    for sha in shas:
        if set(sha) == {"0"}:
            print("  (uncommitted local changes)"); continue
        print("  " + git(args.root, "log", "-1", "--date=iso-strict", "--pretty=format:" + FMT, sha).strip())


def cmd_window(args: argparse.Namespace) -> None:
    ensure_repo(args.root)
    import datetime as dt
    try:
        before = dt.datetime.fromisoformat(args.before.replace("Z", "+00:00"))
    except ValueError:
        die("--before must be an ISO timestamp such as 2026-11-10T09:47:05")
    since = (before - dt.timedelta(hours=args.hours)).isoformat()
    base = ["log", "--date=iso-strict", "--pretty=format:" + FMT, "--name-only", "--before", args.before]
    out = git(args.root, *base, "--since", since)
    if not out.strip():
        out = git(args.root, *base, "-n", "15")
        print("(no commits in the %dh window; showing up to 15 commits before %s instead)\n" % (args.hours, args.before))
    print(out.rstrip() or "no commits before that time")
    print("\nA deploy is not the same as a merge: confirm which commit was actually RUNNING at the failure time "
          "(build id, image tag, startup log line) before blaming a commit.")


def cmd_pickaxe(args: argparse.Namespace) -> None:
    ensure_repo(args.root)
    opts = ["log", "--date=iso-strict", "--pretty=format:" + FMT, "-S", args.text]
    if args.files:
        opts += ["--"] + [f.strip() for f in args.files.split(",") if f.strip()]
    out = git(args.root, *opts)
    print(out.rstrip() or "no commit added or removed %r" % args.text)


def cmd_bisect_plan(args: argparse.Namespace) -> None:
    ensure_repo(args.root)
    count = git(args.root, "rev-list", "--count", "%s..%s" % (args.good, args.bad)).strip()
    n = int(count or 0)
    steps = max(1, n.bit_length())
    print("commits between good and bad: %d  (about %d bisect steps)" % (n, steps))
    print("""
git bisect CHECKS OUT other commits. Never run it in a checkout that a live
process is serving from. Use a separate clone or worktree:

    git -C {root} worktree add ../trace-bisect {bad}
    cd ../trace-bisect
    git bisect start {bad} {good}
    git bisect run sh -c '{test}'
    git bisect log > bisect.log        # keep as evidence (class=git, grade FACT)
    git bisect reset
    cd - && git -C {root} worktree remove ../trace-bisect

The test must exit 0 for good, 1-124 for bad, 125 for "cannot test this
commit". A flaky test makes bisect lie: run it several times per commit if the
failure is intermittent (e.g. `for i in 1 2 3 4 5; do {test} || exit 1; done`).
""".format(root=args.root, good=args.good, bad=args.bad, test=args.test))


def main() -> None:
    ap = argparse.ArgumentParser(description="Git history leads for TRACE (read-only)")
    ap.add_argument("--root", default=".")
    sub = ap.add_subparsers(dest="cmd")
    p = sub.add_parser("recent"); p.add_argument("--files", required=True); p.add_argument("--since", default="14 days ago")
    p.add_argument("--before"); p.set_defaults(fn=cmd_recent)
    p = sub.add_parser("blame"); p.add_argument("--file", required=True); p.add_argument("--lines", required=True); p.set_defaults(fn=cmd_blame)
    p = sub.add_parser("window"); p.add_argument("--before", required=True); p.add_argument("--hours", type=int, default=72); p.set_defaults(fn=cmd_window)
    p = sub.add_parser("pickaxe"); p.add_argument("--text", required=True); p.add_argument("--files"); p.set_defaults(fn=cmd_pickaxe)
    p = sub.add_parser("bisect-plan"); p.add_argument("--good", required=True); p.add_argument("--bad", required=True)
    p.add_argument("--test", required=True); p.set_defaults(fn=cmd_bisect_plan)
    args = ap.parse_args()
    if not getattr(args, "fn", None):
        ap.print_help(); sys.exit(1)
    args.fn(args)


if __name__ == "__main__":
    main()
