#!/usr/bin/env python3
"""TRACE static call-graph tool.

Builds a call graph WITHOUT executing anything, so it is safe against a live
backend. Python is analysed precisely with the ast module; JavaScript,
TypeScript, Go and Java get a regex-based heuristic pass.

Usage:
    call_graph.py index   --root . [--out callgraph.json]
    call_graph.py func    NAME   [--graph callgraph.json | --root .]
    call_graph.py callers NAME   [--depth 3]
    call_graph.py callees NAME   [--depth 3]
    call_graph.py paths   FROM TO [--max-depth 8]
    call_graph.py enclosing FILE LINE
    call_graph.py hotspots       (broad excepts, swallowed errors, timeouts, task spawns)

IMPORTANT LIMIT. A static graph shows which calls are POSSIBLE. It cannot
show which calls HAPPENED. Calls are resolved by name, so results are an
over-approximation (same-named methods on different classes are merged) and
dynamic dispatch, decorators, callbacks and reflection can hide real edges.
Treat every edge as INFERENCE-grade evidence until a log, trace or probe
confirms it at runtime.
"""
from __future__ import annotations

import argparse
import ast
import json
import os
import re
import sys
from typing import Any, Dict, List, Optional, Set

SKIP_DIRS = {".git", "node_modules", "venv", ".venv", "env", "__pycache__", "dist", "build", ".tox",
             ".mypy_cache", ".pytest_cache", "site-packages", "target", "vendor", ".next", "debugging"}
HEURISTIC_EXT = {".js": "js", ".jsx": "js", ".mjs": "js", ".cjs": "js", ".ts": "ts", ".tsx": "ts",
                 ".go": "go", ".java": "java", ".kt": "java"}

CONCURRENCY_NAMES = {
    "create_task", "ensure_future", "gather", "wait", "wait_for", "shield", "timeout", "timeout_at",
    "run_in_executor", "to_thread", "TaskGroup", "as_completed", "cancel", "Lock", "Semaphore", "Event",
    "Condition", "Queue", "Thread", "ThreadPoolExecutor", "ProcessPoolExecutor", "submit", "apply_async",
    "delay", "sleep", "run_coroutine_threadsafe", "call_soon_threadsafe", "start_soon", "move_on_after",
    "fail_after", "CancelScope",
}
BROAD_EXC = {"Exception", "BaseException"}
CANCEL_EXC = {"CancelledError", "TimeoutError", "KeyboardInterrupt", "GeneratorExit", "SystemExit"}


def call_name(node: ast.AST) -> Optional[str]:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        base = call_name(node.value)
        return (base + "." if base else "") + node.attr
    if isinstance(node, ast.Call):
        return call_name(node.func)
    return None


def exc_names(node: Optional[ast.AST]) -> List[str]:
    if node is None:
        return ["<bare>"]
    if isinstance(node, ast.Tuple):
        out: List[str] = []
        for elt in node.elts:
            out.extend(exc_names(elt))
        return out
    name = call_name(node)
    return [name.split(".")[-1] if name else "<expr>"]


class FunctionVisitor(ast.NodeVisitor):
    def __init__(self, module: str, path: str):
        self.module = module
        self.path = path
        self.stack: List[str] = []
        self.functions: Dict[str, Dict[str, Any]] = {}
        self.current: List[Dict[str, Any]] = []

    def _enter(self, node: ast.AST, is_async: bool) -> None:
        qual = ".".join(self.stack + [node.name])
        info = {
            "id": "%s:%s" % (self.module, qual), "name": node.name, "qualname": qual, "module": self.module,
            "file": self.path, "line": min([node.lineno] + [d.lineno for d in node.decorator_list]),
            "def_line": node.lineno, "end_line": getattr(node, "end_lineno", node.lineno),
            "async": is_async, "language": "python", "resolution": "ast",
            "decorators": [call_name(d) or "<expr>" for d in node.decorator_list],
            "calls": [], "handlers": [], "concurrency": [], "raises": [],
        }
        self.functions[info["id"]] = info
        self.current.append(info)
        self.stack.append(node.name)
        self.generic_visit(node)
        self.stack.pop()
        self.current.pop()

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._enter(node, False)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._enter(node, True)

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        self.stack.append(node.name)
        self.generic_visit(node)
        self.stack.pop()

    def visit_Call(self, node: ast.Call) -> None:
        if self.current:
            name = call_name(node.func)
            if name:
                cur = self.current[-1]
                short = name.split(".")[-1]
                cur["calls"].append({"name": name, "short": short, "line": node.lineno})
                if short in CONCURRENCY_NAMES:
                    detail = {"primitive": name, "line": node.lineno}
                    for kw in node.keywords:
                        if kw.arg in ("timeout", "delay", "return_exceptions"):
                            try:
                                detail[kw.arg] = ast.literal_eval(kw.value)
                            except Exception:
                                detail[kw.arg] = "<expr>"
                    if short == "wait_for" and len(node.args) >= 2:
                        try:
                            detail["timeout"] = ast.literal_eval(node.args[1])
                        except Exception:
                            detail["timeout"] = "<expr>"
                    cur["concurrency"].append(detail)
        self.generic_visit(node)

    def visit_Await(self, node: ast.Await) -> None:
        if self.current:
            name = call_name(node.value)
            self.current[-1].setdefault("awaits", []).append({"name": name or "<expr>", "line": node.lineno})
        self.generic_visit(node)

    def visit_Raise(self, node: ast.Raise) -> None:
        if self.current:
            self.current[-1]["raises"].append({
                "exception": (call_name(node.exc) or "<re-raise>") if node.exc else "<re-raise>",
                "line": node.lineno, "from": call_name(node.cause) if node.cause else None})
        self.generic_visit(node)

    def visit_Try(self, node: ast.Try) -> None:
        if self.current:
            for h in node.handlers:
                names = exc_names(h.type)
                body = h.body
                reraises = any(isinstance(n, ast.Raise) for stmt in body for n in ast.walk(stmt))
                only_pass = all(isinstance(s, (ast.Pass, ast.Continue)) or
                                (isinstance(s, ast.Expr) and isinstance(getattr(s, "value", None), ast.Constant))
                                for s in body)
                logs = any(isinstance(n, ast.Call) and (call_name(n.func) or "").split(".")[-1] in
                           ("exception", "error", "warning", "warn", "critical", "info", "debug", "print", "log")
                           for stmt in body for n in ast.walk(stmt))
                flags = []
                if "<bare>" in names or set(names) & BROAD_EXC:
                    flags.append("broad")
                if "<bare>" in names or "BaseException" in names:
                    flags.append("catches-cancellation")
                if set(names) & CANCEL_EXC:
                    flags.append("handles-cancel-or-timeout")
                if not reraises:
                    flags.append("swallows" if only_pass or not logs else "handles-without-reraise")
                if not logs and not reraises:
                    flags.append("silent")
                handled = set()
                for other in node.handlers:
                    handled.update(exc_names(other.type))
                if (self.current[-1]["async"] and "Exception" in names and not node.finalbody
                        and not (handled & {"BaseException", "CancelledError", "<bare>"})
                        and any(isinstance(n, (ast.Await, ast.Call)) for stmt in body for n in ast.walk(stmt)
                                if not (isinstance(n, ast.Call) and (call_name(n.func) or "").split(".")[-1] in
                                        ("exception", "error", "warning", "warn", "critical", "info", "debug", "print", "log")))):
                    flags.append("cleanup-skipped-on-cancel (CancelledError is a BaseException since Python 3.8, "
                                 "so this handler does not run when the task is cancelled; no finally block)")
                self.current[-1]["handlers"].append({
                    "line": h.lineno, "exceptions": names, "reraises": reraises, "logs": logs, "flags": flags,
                    "try_line": node.lineno, "has_finally": bool(node.finalbody)})
        self.generic_visit(node)

    visit_TryStar = visit_Try  # Python 3.11+ except*


def index_python(path: str, rel: str) -> Dict[str, Dict[str, Any]]:
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            tree = ast.parse(fh.read(), filename=rel)
    except SyntaxError as exc:
        print("warning: skipped %s (syntax error line %s)" % (rel, exc.lineno), file=sys.stderr)
        return {}
    module = rel[:-3].replace(os.sep, ".")
    v = FunctionVisitor(module, rel)
    v.visit(tree)
    return v.functions


RE_DEF = {
    "js": re.compile(r"^\s*(?:export\s+)?(?:default\s+)?(?:(?P<async>async)\s+)?(?:function\s*\*?\s*(?P<n1>[A-Za-z_$][\w$]*)\s*\("
                     r"|(?:const|let|var)\s+(?P<n2>[A-Za-z_$][\w$]*)\s*=\s*(?P<async2>async\s*)?(?:\([^)]*\)|[A-Za-z_$][\w$]*)\s*(?::\s*[^=]+)?=>"
                     r"|(?:public\s+|private\s+|protected\s+|static\s+|readonly\s+)*(?P<async3>async\s+)?(?P<n3>[A-Za-z_$][\w$]*)\s*\([^)]*\)\s*(?::\s*[^{]+)?\{\s*$)"),
    "go": re.compile(r"^func\s+(?:\([^)]*\)\s*)?(?P<n1>[A-Za-z_]\w*)\s*\("),
    "java": re.compile(r"^\s*(?:(?:public|private|protected|static|final|abstract|synchronized|override|suspend|open|internal)\s+)*"
                       r"(?:fun\s+(?P<n2>[A-Za-z_]\w*)\s*\(|[\w<>\[\],.? ]+\s+(?P<n1>[A-Za-z_]\w*)\s*\([^;]*\)\s*(?:throws [\w., ]+)?\s*\{\s*$)"),
}
RE_CALL = re.compile(r"(?<![\w$.])((?:[A-Za-z_$][\w$]*\.)*[A-Za-z_$][\w$]*)\s*\(")
KEYWORDS = {"if", "for", "while", "switch", "catch", "return", "function", "func", "new", "typeof", "await",
            "else", "try", "do", "throw", "super", "this", "import", "require", "defer", "go", "select",
            "synchronized", "when", "constructor", "console.log"}


def index_heuristic(path: str, rel: str, lang: str) -> Dict[str, Dict[str, Any]]:
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            lines = fh.read().splitlines()
    except OSError:
        return {}
    rx = RE_DEF["js" if lang == "ts" else lang]
    module = os.path.splitext(rel)[0].replace(os.sep, ".")
    defs: List[Dict[str, Any]] = []
    for i, line in enumerate(lines, 1):
        m = rx.match(line)
        if not m:
            continue
        gd = m.groupdict()
        name = gd.get("n1") or gd.get("n2") or gd.get("n3")
        if not name or name in KEYWORDS:
            continue
        defs.append({"name": name, "line": i,
                     "async": bool(gd.get("async") or gd.get("async2") or gd.get("async3"))})
    functions: Dict[str, Dict[str, Any]] = {}
    for idx, d in enumerate(defs):
        end = defs[idx + 1]["line"] - 1 if idx + 1 < len(defs) else len(lines)
        calls, handlers, conc = [], [], []
        for ln in range(d["line"], end + 1):
            text = lines[ln - 1]
            body = text if ln != d["line"] else text[text.find("(") + 1:] if "(" in text else ""
            for cm in RE_CALL.finditer(body):
                full = cm.group(1)
                short = full.split(".")[-1]
                if short in KEYWORDS or full in KEYWORDS:
                    continue
                calls.append({"name": full, "short": short, "line": ln})
                if short in ("setTimeout", "setInterval", "Promise.all", "all", "race", "allSettled", "WithTimeout",
                             "WithCancel", "WithDeadline", "AbortController", "abort", "Go", "submit", "execute"):
                    conc.append({"primitive": full, "line": ln})
            if re.search(r"\bcatch\b|\brecover\(\)", text):
                empty = bool(re.search(r"catch\s*(\([^)]*\))?\s*\{\s*\}", text))
                handlers.append({"line": ln, "exceptions": ["<catch>"], "reraises": None, "logs": None,
                                 "flags": ["swallows", "silent"] if empty else [], "try_line": ln, "has_finally": None})
            if lang == "go" and re.search(r"^\s*go\s+\w", text):
                conc.append({"primitive": "go statement", "line": ln})
        fid = "%s:%s" % (module, d["name"])
        if fid in functions:
            fid = "%s@%d" % (fid, d["line"])
        functions[fid] = {"id": fid, "name": d["name"], "qualname": d["name"], "module": module, "file": rel,
                          "line": d["line"], "def_line": d["line"], "end_line": end, "async": d["async"],
                          "language": lang, "resolution": "regex-heuristic (boundaries approximate)",
                          "decorators": [], "calls": calls, "handlers": handlers, "concurrency": conc, "raises": []}
    return functions


def build_index(root: str) -> Dict[str, Any]:
    functions: Dict[str, Dict[str, Any]] = {}
    files = 0
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = sorted(d for d in dirnames if d not in SKIP_DIRS and not d.startswith("."))
        for fn in sorted(filenames):
            path = os.path.join(dirpath, fn)
            rel = os.path.relpath(path, root)
            ext = os.path.splitext(fn)[1]
            if ext == ".py":
                functions.update(index_python(path, rel)); files += 1
            elif ext in HEURISTIC_EXT:
                functions.update(index_heuristic(path, rel, HEURISTIC_EXT[ext])); files += 1
    by_short: Dict[str, List[str]] = {}
    for fid, f in functions.items():
        by_short.setdefault(f["name"], []).append(fid)
    edges: List[Dict[str, Any]] = []
    for fid, f in functions.items():
        seen: Set[str] = set()
        for c in f["calls"]:
            for target in by_short.get(c["short"], []):
                key = target + "@" + str(c["line"])
                if key in seen:
                    continue
                seen.add(key)
                edges.append({"from": fid, "to": target, "line": c["line"], "via": c["name"],
                              "ambiguous": len(by_short[c["short"]]) > 1})
    return {"root": os.path.abspath(root), "files_indexed": files, "function_count": len(functions),
            "edge_count": len(edges), "functions": functions, "edges": edges,
            "caveat": "Static, name-resolved, over-approximate. Possible calls, not observed calls."}


def get_graph(args: argparse.Namespace) -> Dict[str, Any]:
    if getattr(args, "graph", None) and os.path.exists(args.graph):
        with open(args.graph, "r", encoding="utf-8") as fh:
            return json.load(fh)
    return build_index(args.root)


def resolve(graph: Dict[str, Any], name: str) -> List[str]:
    fns = graph["functions"]
    if name in fns:
        return [name]
    hits = [fid for fid, f in fns.items() if f["name"] == name or f["qualname"] == name
            or fid.endswith(":" + name) or fid.endswith("." + name)]
    return sorted(hits)


def neighbours(graph: Dict[str, Any], fid: str, direction: str) -> List[Dict[str, Any]]:
    a, b = ("from", "to") if direction == "callees" else ("to", "from")
    return [e for e in graph["edges"] if e[a] == fid]


def walk(graph: Dict[str, Any], start: str, direction: str, depth: int) -> List[str]:
    out: List[str] = []
    other = "to" if direction == "callees" else "from"

    def rec(fid: str, level: int, trail: Set[str]) -> None:
        if level > depth:
            return
        seen_here: Set[str] = set()
        for e in sorted(neighbours(graph, fid, direction), key=lambda x: x["line"]):
            nxt = e[other]
            if nxt in seen_here:
                continue
            seen_here.add(nxt)
            f = graph["functions"][nxt]
            line = e["line"]
            site = ("called at %s:%d" % (graph["functions"][fid]["file"], line)) if direction == "callees" \
                else ("calls it at %s:%d" % (f["file"], line))
            out.append("%s%s %s%s  [%s:%d]  %s%s" % (
                "  " * level, "->" if direction == "callees" else "<-", "async " if f["async"] else "", nxt,
                f["file"], f["def_line"], site, "  (ambiguous name)" if e["ambiguous"] else ""))
            if nxt in trail:
                out.append("%s   (cycle)" % ("  " * level))
                continue
            rec(nxt, level + 1, trail | {nxt})

    rec(start, 1, {start})
    return out


def cmd_index(args: argparse.Namespace) -> None:
    graph = build_index(args.root)
    if args.out:
        with open(args.out, "w", encoding="utf-8") as fh:
            json.dump(graph, fh, indent=1)
        print("indexed %d files, %d functions, %d edges -> %s" % (
            graph["files_indexed"], graph["function_count"], graph["edge_count"], args.out))
    else:
        print(json.dumps(graph, indent=1))


def cmd_func(args: argparse.Namespace) -> None:
    graph = get_graph(args)
    ids = resolve(graph, args.name)
    if not ids:
        print("no function named %r in the index" % args.name); sys.exit(1)
    for fid in ids:
        f = graph["functions"][fid]
        view = dict(f)
        view["callers"] = sorted({e["from"] for e in neighbours(graph, fid, "callers")})
        view["callees"] = sorted({e["to"] for e in neighbours(graph, fid, "callees")})
        view["unresolved_calls"] = sorted({c["name"] for c in f["calls"]
                                           if not any(e["line"] == c["line"] and e["via"] == c["name"]
                                                      for e in neighbours(graph, fid, "callees"))})
        print(json.dumps(view, indent=2))


def cmd_walk(args: argparse.Namespace) -> None:
    graph = get_graph(args)
    ids = resolve(graph, args.name)
    if not ids:
        print("no function named %r in the index" % args.name); sys.exit(1)
    for fid in ids:
        f = graph["functions"][fid]
        print("%s%s  [%s:%d-%d]" % ("async " if f["async"] else "", fid, f["file"], f["def_line"], f["end_line"]))
        lines = walk(graph, fid, args.cmd, args.depth)
        print("\n".join(lines) if lines else "  (none found statically; dynamic dispatch, a framework, or a scheduler may still invoke it)")
    print("\n# " + graph["caveat"])


def cmd_paths(args: argparse.Namespace) -> None:
    graph = get_graph(args)
    src, dst = resolve(graph, args.src), set(resolve(graph, args.dst))
    if not src or not dst:
        print("could not resolve %r or %r" % (args.src, args.dst)); sys.exit(1)
    adj: Dict[str, Set[str]] = {}
    for e in graph["edges"]:
        adj.setdefault(e["from"], set()).add(e["to"])
    found: List[List[str]] = []

    def dfs(node: str, trail: List[str]) -> None:
        if len(found) >= args.limit or len(trail) > args.max_depth:
            return
        if node in dst and len(trail) > 1:
            found.append(list(trail)); return
        for nxt in sorted(adj.get(node, ())):
            if nxt not in trail:
                dfs(nxt, trail + [nxt])

    for s in src:
        dfs(s, [s])
    if not found:
        print("no static path from %s to %s within depth %d" % (args.src, args.dst, args.max_depth))
        print("(absence of a static path is not proof: callbacks, queues, schedulers and dynamic dispatch are invisible here)")
        return
    for p in sorted(found, key=len):
        print("  " + "  ->  ".join(p))
    print("\n%d possible path(s). %s" % (len(found), graph["caveat"]))


def cmd_enclosing(args: argparse.Namespace) -> None:
    graph = get_graph(args)
    target = os.path.normpath(args.file)
    best = None
    for f in graph["functions"].values():
        fpath = os.path.normpath(f["file"])
        if (fpath == target or target.endswith(os.sep + fpath) or fpath.endswith(os.sep + target)) \
                and f["line"] <= args.line <= f["end_line"]:
            if best is None or (f["end_line"] - f["line"]) < (best["end_line"] - best["line"]):
                best = f
    if not best:
        print("line %d of %s is not inside any indexed function (module level, or file not indexed)" % (args.line, args.file))
        sys.exit(1)
    print(json.dumps({"id": best["id"], "file": best["file"], "def_line": best["def_line"],
                      "end_line": best["end_line"], "async": best["async"]}, indent=2))


def cmd_hotspots(args: argparse.Namespace) -> None:
    graph = get_graph(args)
    rows = []
    for fid, f in sorted(graph["functions"].items()):
        for h in f["handlers"]:
            if h["flags"]:
                rows.append("%s:%d  %s  except %s  -> %s" % (f["file"], h["line"], fid, ",".join(h["exceptions"]), ", ".join(h["flags"])))
        for c in f["concurrency"]:
            extra = "".join("  %s=%s" % (k, v) for k, v in c.items() if k not in ("primitive", "line"))
            rows.append("%s:%d  %s  uses %s%s" % (f["file"], c["line"], fid, c["primitive"], extra))
    print("\n".join(rows) if rows else "no hotspots detected")
    print("\n# Hotspots are leads for investigators, not findings. Read the code before recording anything.")


def main() -> None:
    ap = argparse.ArgumentParser(description="Static call graph (TRACE)")
    sub = ap.add_subparsers(dest="cmd")

    def common(p: argparse.ArgumentParser) -> None:
        p.add_argument("--root", default="."); p.add_argument("--graph", help="reuse an index written by `index --out`")

    p = sub.add_parser("index"); p.add_argument("--root", default="."); p.add_argument("--out"); p.set_defaults(fn=cmd_index)
    p = sub.add_parser("func"); p.add_argument("name"); common(p); p.set_defaults(fn=cmd_func)
    for name in ("callers", "callees"):
        p = sub.add_parser(name); p.add_argument("name"); p.add_argument("--depth", type=int, default=3); common(p); p.set_defaults(fn=cmd_walk)
    p = sub.add_parser("paths"); p.add_argument("src"); p.add_argument("dst"); p.add_argument("--max-depth", type=int, default=8)
    p.add_argument("--limit", type=int, default=25); common(p); p.set_defaults(fn=cmd_paths)
    p = sub.add_parser("enclosing"); p.add_argument("file"); p.add_argument("line", type=int); common(p); p.set_defaults(fn=cmd_enclosing)
    p = sub.add_parser("hotspots"); common(p); p.set_defaults(fn=cmd_hotspots)
    args = ap.parse_args()
    if not getattr(args, "fn", None):
        ap.print_help(); sys.exit(1)
    args.fn(args)


if __name__ == "__main__":
    main()
