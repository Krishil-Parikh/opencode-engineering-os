#!/usr/bin/env python3
"""TRACE log parser: turn raw logs into an ordered, filterable event timeline.

Understands, per line and without configuration:
  * JSON-lines logs (timestamp/time/ts/@timestamp, level/severity, message/msg)
  * ISO-8601 timestamps        2026-11-10T09:47:05.123Z / +05:30
  * "date time,millis"         2026-11-10 09:47:05,123
  * time-only                  09:47:05 / 09:47:05.123
  * syslog                     Nov 10 09:47:05
  * epoch seconds / millis at line start
Lines without a timestamp are attached to the previous event (multi-line
stack traces stay with the event that produced them).

It also extracts correlation identifiers (request_id, trace_id, task, thread,
any key=value pair you name with --id-key, UUIDs), flags exception lines,
finds silent gaps, and recognises TRACE-PROBE markers.

Usage:
    log_parser.py app.log worker.log --around "09:47:05" --window 120
    log_parser.py app.log --corr req-7f3a --format text
    log_parser.py app.log --level ERROR --out timeline.json
    cat app.log | log_parser.py - --from 09:40:00 --to 09:50:00

Output is JSON by default: {"events": [...], "summary": {...}}.
The parser reports what the logs say. It never invents events: a missing
line means "not logged", which is not the same as "did not happen".
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import re
import statistics
import sys
from typing import Any, Dict, List, Optional, Tuple

MONTHS = {m: i for i, m in enumerate(
    ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], 1)}

RE_ISO = re.compile(
    r"(?P<date>\d{4}-\d{2}-\d{2})[T ](?P<time>\d{2}:\d{2}:\d{2})(?:[.,](?P<frac>\d{1,9}))?"
    r"(?P<tz>Z|[+-]\d{2}:?\d{2})?")
RE_SYSLOG = re.compile(r"^(?P<mon>[A-Z][a-z]{2})\s+(?P<day>\d{1,2})\s+(?P<time>\d{2}:\d{2}:\d{2})")
RE_TIME = re.compile(r"(?<![\d:])(?P<time>\d{2}:\d{2}:\d{2})(?:[.,](?P<frac>\d{1,9}))?(?![\d:])")
RE_EPOCH = re.compile(r"^\[?(?P<epoch>1\d{9}(?:\d{3})?)(?:\.\d+)?\]?\s")
RE_LEVEL = re.compile(r"\b(TRACE|DEBUG|INFO|NOTICE|WARN(?:ING)?|ERROR|ERR|CRITICAL|FATAL|PANIC)\b", re.I)
RE_EXC = re.compile(
    r"(Traceback \(most recent call last\)|\b[A-Z][A-Za-z0-9_.]*(?:Error|Exception|Timeout|Cancelled|Panic)\b"
    r"|\bpanic:|\bCaused by:|\bUnhandled(?:PromiseRejection)?\b|\bSIG(?:KILL|TERM|SEGV|ABRT)\b|\bOOM\b|\bfatal error\b)")
RE_KV = re.compile(r"\b([A-Za-z_][A-Za-z0-9_.\-]*)[=:]\s*\"?([A-Za-z0-9_\-:.]{3,64})\"?")
RE_UUID = re.compile(r"\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b", re.I)
RE_PROBE = re.compile(r"\[TRACE-PROBE (?P<stage>S[123]) (?P<label>[^\]]+)\]")

DEFAULT_ID_KEYS = [
    "request_id", "req_id", "requestid", "x_request_id", "correlation_id", "corr_id", "cid",
    "trace_id", "traceid", "span_id", "spanid", "parent_span_id", "task", "task_id", "task_name",
    "job_id", "job", "worker", "thread", "tid", "pid", "session_id", "order_id", "txn_id",
    "message_id", "batch_id",
]
JSON_TS_KEYS = ["timestamp", "time", "ts", "@timestamp", "asctime", "datetime", "t"]
JSON_LEVEL_KEYS = ["level", "severity", "levelname", "lvl", "log.level"]
JSON_MSG_KEYS = ["message", "msg", "event", "text", "log"]


def _seconds_of_day(t: str, frac: Optional[str]) -> float:
    h, m, s = (int(x) for x in t.split(":"))
    val = h * 3600 + m * 60 + s
    if frac:
        val += float("0." + frac)
    return val


def parse_timestamp(text: str) -> Tuple[Optional[float], Optional[str], bool, int]:
    """Return (sort_key, normalised string, has_date, end_offset)."""
    m = RE_ISO.search(text[:80])
    if m:
        frac = m.group("frac")
        base = dt.datetime.strptime(m.group("date") + " " + m.group("time"), "%Y-%m-%d %H:%M:%S")
        tz = m.group("tz")
        offset = dt.timedelta(0)
        if tz and tz != "Z":
            sign = 1 if tz[0] == "+" else -1
            digits = tz[1:].replace(":", "")
            offset = sign * dt.timedelta(hours=int(digits[:2]), minutes=int(digits[2:]))
        epoch = (base - offset - dt.datetime(1970, 1, 1)).total_seconds()
        if frac:
            epoch += float("0." + frac)
        norm = m.group("date") + "T" + m.group("time") + ("." + frac if frac else "") + (tz or "")
        return epoch, norm, True, m.end()
    m = RE_EPOCH.match(text)
    if m:
        raw = m.group("epoch")
        epoch = int(raw) / (1000.0 if len(raw) == 13 else 1.0)
        norm = dt.datetime.fromtimestamp(epoch, dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S") + "Z"
        return epoch, norm, True, m.end()
    m = RE_SYSLOG.match(text)
    if m and m.group("mon") in MONTHS:
        year = dt.datetime.now().year
        base = dt.datetime(year, MONTHS[m.group("mon")], int(m.group("day")))
        epoch = (base - dt.datetime(1970, 1, 1)).total_seconds() + _seconds_of_day(m.group("time"), None)
        return epoch, "%s %s %s" % (m.group("mon"), m.group("day"), m.group("time")), True, m.end()
    m = RE_TIME.search(text[:40])
    if m:
        return (_seconds_of_day(m.group("time"), m.group("frac")),
                m.group("time") + ("." + m.group("frac") if m.group("frac") else ""), False, m.end())
    return None, None, False, 0


def parse_user_time(text: str) -> Tuple[float, bool]:
    key, _norm, has_date, _ = parse_timestamp(text.strip() + " ")
    if key is None:
        raise SystemExit("error: cannot parse time %r (use HH:MM:SS or an ISO timestamp)" % text)
    return key, has_date


def normalise_level(raw: Optional[str]) -> Optional[str]:
    if not raw:
        return None
    lvl = str(raw).upper()
    return {"WARN": "WARNING", "ERR": "ERROR", "FATAL": "CRITICAL", "PANIC": "CRITICAL"}.get(lvl, lvl)


def extract_ids(text: str, keys: List[str]) -> Dict[str, str]:
    ids: Dict[str, str] = {}
    wanted = set(k.lower() for k in keys)
    for key, value in RE_KV.findall(text):
        k = key.lower().replace("-", "_")
        if k in wanted and k not in ids:
            ids[k] = value
    m = RE_UUID.search(text)
    if m and m.group(0) not in ids.values():
        ids.setdefault("uuid", m.group(0))
    return ids


def parse_json_line(line: str, keys: List[str]) -> Optional[Dict[str, Any]]:
    s = line.strip()
    if not (s.startswith("{") and s.endswith("}")):
        return None
    try:
        obj = json.loads(s)
    except ValueError:
        return None
    if not isinstance(obj, dict):
        return None
    ts_raw = next((str(obj[k]) for k in JSON_TS_KEYS if k in obj), None)
    key = norm = None
    has_date = False
    if ts_raw is not None:
        key, norm, has_date, _ = parse_timestamp(ts_raw + " ")
    level = normalise_level(next((obj[k] for k in JSON_LEVEL_KEYS if k in obj), None))
    msg = next((str(obj[k]) for k in JSON_MSG_KEYS if k in obj), s)
    wanted = set(k.lower() for k in keys)
    ids = {}
    for k, v in obj.items():
        kk = k.lower().replace("-", "_")
        if kk in wanted and isinstance(v, (str, int)):
            ids[kk] = str(v)
    extra = ""
    for k in ("exc_info", "exception", "stack", "stack_trace", "error"):
        if k in obj and obj[k]:
            extra = str(obj[k])
            break
    return {"t": key, "ts": norm, "has_date": has_date, "level": level, "message": msg,
            "ids": ids, "extra": extra, "json": True}


def parse_files(paths: List[str], id_keys: List[str]) -> Tuple[List[Dict[str, Any]], List[str]]:
    events: List[Dict[str, Any]] = []
    warnings: List[str] = []
    for path in paths:
        if path == "-":
            lines = sys.stdin.read().splitlines()
            name = "<stdin>"
        else:
            try:
                with open(path, "r", encoding="utf-8", errors="replace") as fh:
                    lines = fh.read().splitlines()
            except OSError as exc:
                raise SystemExit("error: cannot read %s: %s" % (path, exc))
            name = path
        current: Optional[Dict[str, Any]] = None
        orphan = 0
        for lineno, line in enumerate(lines, 1):
            if not line.strip():
                continue
            parsed = parse_json_line(line, id_keys)
            if parsed is None:
                key, norm, has_date, end = parse_timestamp(line)
                # A timestamp deep inside an indented/continuation line is not a new event.
                starts_event = key is not None and not line[:1].isspace()
                if starts_event:
                    lvl = RE_LEVEL.search(line)
                    msg = line[end:].strip(" \t-|]:[")
                    if lvl:
                        msg = re.sub(r"^\[?%s\]?[\s:|\-]*" % re.escape(lvl.group(1)), "", msg, count=1)
                    parsed = {"t": key, "ts": norm, "has_date": has_date,
                              "level": normalise_level(lvl.group(1)) if lvl else None,
                              "message": msg, "ids": extract_ids(line, id_keys),
                              "extra": "", "json": False}
            if parsed is None:
                if current is None:
                    orphan += 1
                    current = {"t": None, "ts": None, "has_date": False, "level": None,
                               "message": line.strip(), "ids": extract_ids(line, id_keys),
                               "file": name, "line": lineno, "continuation": [], "raw": line}
                    events.append(current)
                else:
                    current["continuation"].append(line)
                continue
            current = {"t": parsed["t"], "ts": parsed["ts"], "has_date": parsed["has_date"],
                       "level": parsed["level"], "message": parsed["message"], "ids": parsed["ids"],
                       "file": name, "line": lineno, "raw": line,
                       "continuation": parsed["extra"].splitlines() if parsed["extra"] else []}
            events.append(current)
        if orphan:
            warnings.append("%s: %d line(s) before the first timestamp were kept without a time" % (name, orphan))
    for ev in events:
        blob = ev["raw"] + "\n" + "\n".join(ev["continuation"])
        ev["exception"] = bool(RE_EXC.search(blob))
        m = RE_PROBE.search(blob)
        if m:
            ev["probe"] = {"stage": m.group("stage"), "label": m.group("label")}
        if ev["continuation"]:
            for key, value in extract_ids("\n".join(ev["continuation"]), id_keys).items():
                ev["ids"].setdefault(key, value)
    dated = set(ev["has_date"] for ev in events if ev["t"] is not None)
    if len(dated) > 1:
        warnings.append("inputs mix dated and time-only timestamps; ordering across them is unreliable. "
                        "Parse them separately or filter with --from/--to in one style.")
    # Stable sort: untimed events stay next to their predecessor.
    last = 0.0
    for i, ev in enumerate(events):
        if ev["t"] is None:
            ev["_k"] = (last, i)
        else:
            last = ev["t"]
            ev["_k"] = (ev["t"], i)
    if len(paths) > 1:
        events.sort(key=lambda e: e["_k"])
    return events, warnings


def apply_filters(events: List[Dict[str, Any]], args: argparse.Namespace) -> List[Dict[str, Any]]:
    out = events
    lo = hi = None
    if args.around:
        centre, _ = parse_user_time(args.around)
        lo, hi = centre - args.window, centre + args.window
    if args.from_:
        lo = parse_user_time(args.from_)[0]
    if args.to:
        hi = parse_user_time(args.to)[0]
    if lo is not None or hi is not None:
        def in_range(ev: Dict[str, Any]) -> bool:
            t = ev["_k"][0]
            if not ev["has_date"] and t is not None and lo is not None and lo > 86400:
                return True  # time-only log vs dated filter: cannot decide, keep
            return (lo is None or t >= lo) and (hi is None or t <= hi)
        out = [e for e in out if in_range(e)]
    if args.corr:
        needle = args.corr
        out = [e for e in out if needle in e["raw"] or needle in "\n".join(e["continuation"])
               or needle in e["ids"].values()]
    if args.level:
        order = ["TRACE", "DEBUG", "INFO", "NOTICE", "WARNING", "ERROR", "CRITICAL"]
        floor = order.index(normalise_level(args.level)) if normalise_level(args.level) in order else 0
        out = [e for e in out if e["level"] in order[floor:] or e["exception"]]
    if args.grep:
        rx = re.compile(args.grep, re.I)
        out = [e for e in out if rx.search(e["raw"]) or any(rx.search(c) for c in e["continuation"])]
    if args.exceptions_only:
        out = [e for e in out if e["exception"]]
    return out


def summarise(events: List[Dict[str, Any]], gap: Optional[float]) -> Dict[str, Any]:
    timed = [e for e in events if e["t"] is not None]
    levels: Dict[str, int] = {}
    ids: Dict[str, Dict[str, int]] = {}
    for e in events:
        levels[e["level"] or "UNKNOWN"] = levels.get(e["level"] or "UNKNOWN", 0) + 1
        for k, v in e["ids"].items():
            ids.setdefault(k, {})
            ids[k][v] = ids[k].get(v, 0) + 1
    deltas = [b["t"] - a["t"] for a, b in zip(timed, timed[1:]) if b["t"] >= a["t"]]
    threshold = gap
    if threshold is None:
        med = statistics.median(deltas) if deltas else 0.0
        threshold = max(5.0, med * 10)
    gaps = []
    for a, b in zip(timed, timed[1:]):
        d = b["t"] - a["t"]
        if d >= threshold:
            gaps.append({"after_event": a["n"], "before_event": b["n"], "seconds": round(d, 3),
                         "from": a["ts"], "to": b["ts"],
                         "note": "nothing logged in this interval; this is absence of logging, not proof of inactivity"})
    backwards = sum(1 for a, b in zip(timed, timed[1:]) if b["t"] < a["t"])
    exceptions = [{"n": e["n"], "ts": e["ts"], "file": e["file"], "line": e["line"],
                   "text": (e["message"] or e["raw"])[:240]} for e in events if e["exception"]]
    probes = [e for e in events if e.get("probe")]
    last_probe = {}
    for e in probes:
        last_probe[e["probe"]["stage"]] = {"label": e["probe"]["label"], "n": e["n"], "ts": e["ts"]}
    first_error = next((x for x in exceptions), None)
    return {
        "count": len(events),
        "first": timed[0]["ts"] if timed else None,
        "last": timed[-1]["ts"] if timed else None,
        "levels": levels,
        "exceptions": exceptions,
        "first_exception": first_error,
        "gap_threshold_seconds": round(threshold, 3),
        "gaps": gaps,
        "out_of_order_pairs": backwards,
        "ids": {k: dict(sorted(v.items(), key=lambda kv: -kv[1])[:20]) for k, v in ids.items()},
        "last_probe_per_stage": last_probe,
    }


def to_text(events: List[Dict[str, Any]], summary: Dict[str, Any], max_cont: int) -> str:
    lines = []
    gap_after = {g["after_event"]: g for g in summary["gaps"]}
    for e in events:
        mark = "!" if e["exception"] else " "
        ids = " ".join("%s=%s" % kv for kv in sorted(e["ids"].items()))
        lines.append("%s #%-5d %-26s %-8s %s%s   (%s:%d)" % (
            mark, e["n"], e["ts"] or "-", e["level"] or "-", (e["message"] or "")[:200],
            ("  {" + ids + "}") if ids else "", e["file"], e["line"]))
        for c in e["continuation"][:max_cont]:
            lines.append("          | " + c)
        if len(e["continuation"]) > max_cont:
            lines.append("          | ... %d more line(s)" % (len(e["continuation"]) - max_cont))
        if e["n"] in gap_after:
            lines.append("  ~~~ %.1fs with nothing logged ~~~" % gap_after[e["n"]]["seconds"])
    lines.append("")
    lines.append("events=%d  first=%s  last=%s  levels=%s" % (
        summary["count"], summary["first"], summary["last"], summary["levels"]))
    if summary["first_exception"]:
        fe = summary["first_exception"]
        lines.append("first exception: #%d at %s  %s" % (fe["n"], fe["ts"], fe["text"]))
    for stage, p in sorted(summary["last_probe_per_stage"].items()):
        lines.append("last %s probe reached: %s (event #%d)" % (stage, p["label"], p["n"]))
    return "\n".join(lines)


def main() -> None:
    ap = argparse.ArgumentParser(description="Parse logs into a timeline (TRACE)")
    ap.add_argument("files", nargs="+", help="log files, or - for stdin")
    ap.add_argument("--from", dest="from_", help="keep events at/after this time")
    ap.add_argument("--to", help="keep events at/before this time")
    ap.add_argument("--around", help="centre time for a window")
    ap.add_argument("--window", type=float, default=60.0, help="seconds either side of --around (default 60)")
    ap.add_argument("--corr", help="keep events mentioning this correlation/request/task id")
    ap.add_argument("--level", help="minimum level (exceptions always kept)")
    ap.add_argument("--grep", help="regex filter (case-insensitive)")
    ap.add_argument("--exceptions-only", action="store_true")
    ap.add_argument("--id-key", action="append", default=[], help="extra key name to treat as a correlation id")
    ap.add_argument("--gap", type=float, help="report silent gaps of at least this many seconds")
    ap.add_argument("--format", choices=["json", "text"], default="json")
    ap.add_argument("--max-continuation", type=int, default=40, help="continuation lines shown in text mode")
    ap.add_argument("--out", help="write output to this file instead of stdout")
    args = ap.parse_args()

    id_keys = DEFAULT_ID_KEYS + [k.lower().replace("-", "_") for k in args.id_key]
    events, warnings = parse_files(args.files, id_keys)
    for n, e in enumerate(events, 1):
        e["n"] = n
    kept = apply_filters(events, args)
    summary = summarise(kept, args.gap)
    summary["total_events_before_filter"] = len(events)
    summary["warnings"] = warnings
    for e in kept:
        e.pop("_k", None)
    if args.format == "text":
        output = to_text(kept, summary, args.max_continuation)
    else:
        output = json.dumps({"events": kept, "summary": summary}, indent=2, ensure_ascii=False)
    if args.out:
        with open(args.out, "w", encoding="utf-8") as fh:
            fh.write(output + "\n")
        print("wrote %s (%d events)" % (args.out, len(kept)))
    else:
        print(output)
    for w in warnings:
        print("warning: " + w, file=sys.stderr)


if __name__ == "__main__":
    main()
