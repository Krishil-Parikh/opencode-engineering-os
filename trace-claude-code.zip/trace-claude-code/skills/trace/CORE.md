# TRACE — Tournament-based Root-cause Analysis and Code Examination

> Every error has an execution history. Every hypothesis needs evidence. Every conclusion must survive verification.

An autonomous, adversarial debugging and root-cause analysis system, packaged as an agent skill. It is **not** an agent debate system: it is an evidence-driven investigation system that happens to use agent debates.

This directory is the portable core. The three platform packages (`claude-code/`, `opencode/`, `github-copilot/`) each contain a copy of it alongside a platform-specific entry point.

## What it does

| Capability | Where |
|---|---|
| Hierarchical fault localization: file, then function, then statement | `core/hierarchical_localization.md`, `scripts/probe.py` |
| Retrospective investigation of a failure that cannot be re-run (Mode A) | `core/investigation_engine.md`, `core/execution_reconstruction.md` |
| Targeted instrumentation when the evidence is not enough (Mode B) | `core/instrumentation_playbook.md` |
| Three-layer analysis: failure location, trigger, root cause | `core/execution_reconstruction.md` |
| Evidence ledger with FACT / INFERENCE / ASSUMPTION grading | `core/evidence_protocol.md`, `scripts/evidence_collector.py` |
| Six specialised investigator lenses | `agents/` |
| Adversarial tournament with evidence-capped scoring | `core/tournament_protocol.md`, `core/hypothesis_scoring.md`, `scripts/score.py` |
| Independent verification, with the right to declare insufficient evidence | `core/root_cause_verification.md` |
| Persistent knowledge base where losing hypotheses' findings survive | `core/knowledge_base.md`, `scripts/kb.py` |
| An actionable eight-section report | `reports/investigation_template.md`, `scripts/report_generator.py` |

## Layout

```
core/        the protocols. investigation_engine.md is the spine; read it first
agents/      one standalone brief per role. _submission.md is shared by the six lenses
scripts/     working Python 3.8+, standard library only, no dependencies
schemas/     JSON Schema for evidence, hypotheses, findings and the tournament
reports/     the report template and the fix-section guidance
examples/    a runnable incident and a complete scripted investigation of it
```

## Scripts

All take `--help`. Run them from the repository root so evidence paths stay stable.

| Script | Purpose |
|---|---|
| `workspace.py` | Create and inspect the `debugging/` workspace and investigations |
| `log_parser.py` | Logs to a correlated, filterable timeline with gap and id analysis |
| `stacktrace_parser.py` | Python, Node, Java/Kotlin and Go traces to frames, with Layer 1 identified |
| `call_graph.py` | Static call graph, callers, callees, paths, enclosing function, hotspots |
| `probe.py` | The three localization stages: insert, analyse, remove, verify |
| `evidence_collector.py` | The only writer of the evidence ledger; enforces the grade rules |
| `score.py` | Criterion scoring with ledger caps, duels, merges, the verdict |
| `kb.py` | Import, search, brief, promote, render the knowledge base |
| `git_suspects.py` | Read-only git leads: recent, window, blame, pickaxe, bisect plan |
| `report_generator.py` | `final_report.md` from the ledgers |

## Try it

```
cd examples/sample_incident
python3 run_incident.py          # reproduces the failure, writes logs/app.log
bash walkthrough.sh              # the full ten-step investigation, scripted
cat debugging/investigations/BUG-001/final_report.md
```

The walkthrough is the best documentation of the order of operations: it runs all ten steps, registers three rival hypotheses, eliminates two (one by a refuted prediction, one on evidence score), verifies the survivor with a counterfactual experiment, and produces a CONFIRMED report plus three knowledge-base entries.

## The ten steps

1. **Receive** — exception, message, timestamp, service, constraints
2. **Collect** — logs, traces, stack traces, source, git
3. **Map** — functions, dependencies, possible paths
4. **Hypothesize** — independent explanations
5. **Investigate** — specialised agents, one lens each
6. **Compete** — evidence-based adversarial duels
7. **Verify** — independent check of the strongest hypothesis
8. **Preserve** — every meaningful secondary finding
9. **Report** — actionable root-cause analysis
10. **Learn** — verified patterns to the knowledge base

Each step has an exit gate in `core/investigation_engine.md`. Do not pass a gate you cannot meet; carry the gap forward instead, where it will cap the final confidence.

## The design decisions that matter

**Evidence-driven, not debate-driven.** A debate selects the most convincing explanation. An investigation selects the explanation best supported by reality. Scores are capped by what the ledger contains, so persuasion cannot buy a verdict.

**Start with 6 to 8 agents, not 60.** Expand only when a specific open question needs a lens nobody has used. The skill cannot guarantee any number of simultaneous agents in any case: spawning, concurrency limits and tool permissions belong to the host platform.

**Losers' findings are retained.** The database hypothesis that lost may have found a real leak. It goes to the knowledge base with an honest status.

**Insufficient evidence is a first-class verdict.** Without it, the format itself pressures an agent into inventing a root cause because a winner has to be produced.

**An unverified finding never silently becomes a fact.** Status travels with every knowledge-base entry, re-observation never upgrades it, and only an explicit verified promotion reaches `confirmed`.

## Honest limits

- Source analysis reconstructs *possible* call paths. It cannot recover runtime history that was never logged or traced. The ledger's grades keep that visible in every sentence.
- A static call graph over-approximates and is blind to dynamic dispatch, callbacks and framework wiring.
- Automatic probe insertion is Python-only; other languages get snippets to place by hand, and the analysis and removal tooling works for all of them.
- The scoring weights and thresholds are engineering defaults in `debugging/trace_config.json`, not validated constants.
- Probes edit source files. They belong in a reproduction environment or a scratch copy, never a live checkout.
