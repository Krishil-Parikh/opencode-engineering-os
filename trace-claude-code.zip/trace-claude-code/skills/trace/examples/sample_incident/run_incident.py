"""Reproduce the sample incident and write logs/app.log.

    python3 run_incident.py

Three requests run. req-a1 and req-c3 succeed. For req-b2 the payment gateway
is slow, and the request ends in CancelledError inside the payment client.
"""
import asyncio
import logging
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from app import api, db, payment  # noqa: E402


async def main() -> None:
    payment.GATEWAY_LATENCY_S["ord-1002"] = 5.0   # the gateway is slow for this one order
    await api.api_handler({"id": "ord-1001", "customer_id": "7"}, "req-a1")
    await api.api_handler({"id": "ord-1002", "customer_id": "8"}, "req-b2")
    await api.api_handler({"id": "ord-1003", "customer_id": "9"}, "req-c3")
    logging.getLogger("db").info("pool status in_use=%d size=%d", db.get_pool().in_use, 2)


if __name__ == "__main__":
    os.makedirs(os.path.join(HERE, "logs"), exist_ok=True)
    handlers = [logging.FileHandler(os.path.join(HERE, "logs", "app.log"), mode="w")]
    if "--quiet" not in sys.argv:
        handlers.append(logging.StreamHandler())
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s", handlers=handlers)
    asyncio.run(main())
