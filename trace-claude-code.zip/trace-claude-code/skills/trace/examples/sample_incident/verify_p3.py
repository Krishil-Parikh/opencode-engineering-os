"""Verification experiment for H-02 prediction P3. Runs in-process, changes nothing on disk."""
import asyncio
import logging
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from app import api, config, payment  # noqa: E402


async def main() -> None:
    config.REQUEST_TIMEOUT_S = 3.0               # the only change: budget above the 2.4s retry worst case
    payment.GATEWAY_LATENCY_S["ord-1002"] = 5.0  # same slow gateway as the incident
    try:
        await api.api_handler({"id": "ord-1002", "customer_id": "8"}, "req-b2")
    except BaseException as exc:                 # report exactly what surfaces
        print("RESULT %s: %s" % (type(exc).__name__, exc))
    else:
        print("RESULT no exception")


logging.basicConfig(level=logging.WARNING, format="%(levelname)s %(name)s %(message)s", stream=sys.stdout)
asyncio.run(main())
