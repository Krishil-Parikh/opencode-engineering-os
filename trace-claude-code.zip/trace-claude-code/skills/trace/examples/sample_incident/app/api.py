"""API layer: one handler per request, with a request budget."""
import asyncio
import logging

from . import config, orders

log = logging.getLogger("api")


async def api_handler(order: dict, request_id: str) -> dict:
    log.info("request received request_id=%s path=/orders", request_id)
    task = asyncio.ensure_future(orders.process_order(order, request_id))
    done, _pending = await asyncio.wait({task}, timeout=config.REQUEST_TIMEOUT_S)
    if not done:
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            log.error("request failed request_id=%s status=500", request_id, exc_info=True)
            return {"status": 500}
    log.info("request completed request_id=%s status=200", request_id)
    return {"status": 200, "body": task.result()}
