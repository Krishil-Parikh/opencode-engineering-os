"""Tiny fake connection pool."""
import asyncio
import logging

from . import config

log = logging.getLogger("db")


class Pool:
    def __init__(self, size: int) -> None:
        self._sem = asyncio.Semaphore(size)
        self.in_use = 0

    async def acquire(self) -> None:
        await self._sem.acquire()
        self.in_use += 1
        log.debug("pool acquire in_use=%d", self.in_use)

    def release(self) -> None:
        self.in_use -= 1
        self._sem.release()
        log.debug("pool release in_use=%d", self.in_use)


pool = None


def get_pool() -> Pool:
    global pool
    if pool is None:
        pool = Pool(config.DB_POOL_SIZE)
    return pool


async def fetch_customer(customer_id: str) -> dict:
    p = get_pool()
    await p.acquire()
    await asyncio.sleep(0.05)
    p.release()
    return {"id": customer_id, "email": "c%s@example.test" % customer_id}


async def reserve_inventory(order: dict) -> str:
    p = get_pool()
    await p.acquire()
    await asyncio.sleep(0.05)
    # NOTE: the connection is only released on the success path of release_inventory().
    return "resv-%s" % order["id"]


async def release_inventory(reservation: str) -> None:
    await asyncio.sleep(0.01)
    get_pool().release()
