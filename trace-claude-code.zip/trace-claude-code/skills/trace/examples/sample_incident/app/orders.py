"""Order workflow."""
import logging

from . import db, payment

log = logging.getLogger("orders")


async def send_confirmation(customer: dict, request_id: str) -> None:
    try:
        if "@" not in customer["email"]:
            raise ValueError("bad email")
        log.info("send_confirmation completed request_id=%s", request_id)
    except Exception:
        pass


async def process_order(order: dict, request_id: str) -> dict:
    log.info("process_order started request_id=%s order_id=%s", request_id, order["id"])
    customer = await db.fetch_customer(order["customer_id"])
    log.info("fetch_customer completed request_id=%s", request_id)
    reservation = await db.reserve_inventory(order)
    log.info("check_inventory completed request_id=%s reservation=%s", request_id, reservation)
    try:
        receipt = await payment.process_payment(order, request_id)
    except Exception:
        log.exception("payment failed, releasing inventory request_id=%s", request_id)
        await db.release_inventory(reservation)
        raise
    await db.release_inventory(reservation)
    await send_confirmation(customer, request_id)
    log.info("process_order completed request_id=%s", request_id)
    return receipt
