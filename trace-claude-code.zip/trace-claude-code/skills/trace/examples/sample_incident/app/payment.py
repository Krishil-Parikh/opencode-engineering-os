"""Payment client with retries."""
import asyncio
import logging

from . import config

log = logging.getLogger("payment")

GATEWAY_LATENCY_S = {"default": 0.1}


async def external_payment_api(order: dict) -> dict:
    latency = GATEWAY_LATENCY_S.get(order["id"], GATEWAY_LATENCY_S["default"])
    await asyncio.sleep(latency)
    return {"status": "captured", "order": order["id"]}


async def process_payment(order: dict, request_id: str) -> dict:
    log.info("process_payment started request_id=%s order_id=%s", request_id, order["id"])
    last_error = None
    for attempt in range(1, config.PAYMENT_MAX_ATTEMPTS + 1):
        try:
            result = await asyncio.wait_for(external_payment_api(order), timeout=config.PAYMENT_ATTEMPT_TIMEOUT_S)
            log.info("process_payment completed request_id=%s attempt=%d", request_id, attempt)
            return result
        except asyncio.TimeoutError as exc:
            last_error = exc
            log.warning("payment attempt timed out request_id=%s attempt=%d timeout=%.1fs",
                        request_id, attempt, config.PAYMENT_ATTEMPT_TIMEOUT_S)
            await asyncio.sleep(config.PAYMENT_BACKOFF_S)
    raise RuntimeError("payment failed after %d attempts" % config.PAYMENT_MAX_ATTEMPTS) from last_error
