"""Settings for the sample order service."""

REQUEST_TIMEOUT_S = 1.0          # budget the API layer gives one request
PAYMENT_ATTEMPT_TIMEOUT_S = 0.6  # per-attempt timeout inside the payment client
PAYMENT_MAX_ATTEMPTS = 3
PAYMENT_BACKOFF_S = 0.2
DB_POOL_SIZE = 2
