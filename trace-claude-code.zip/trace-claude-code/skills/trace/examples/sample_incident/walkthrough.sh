#!/usr/bin/env bash
# TRACE worked example: a complete investigation of the sample incident,
# driven only by the bundled scripts. Run it from this directory:
#
#     bash walkthrough.sh
#
# It rebuilds ./debugging from scratch. Read it top to bottom as a reference
# for the order of operations and the exact commands; the comments say which
# of the ten steps each block belongs to and which agent would normally do it.
set -euo pipefail
cd "$(dirname "$0")"
T="${TRACE_SCRIPTS:-$(cd ../../scripts && pwd)}"
rm -rf debugging
SCRATCH="$(mktemp -d)"
trap 'rm -rf "$SCRATCH"' EXIT

# ---------------------------------------------------------------- 1. RECEIVE
python3 "$T/workspace.py" init --root debugging >/dev/null
INV=$(python3 "$T/workspace.py" new --root debugging \
        --title "CancelledError in payment processing returns 500" \
        --error "asyncio.exceptions.CancelledError" \
        --when "2026-11-10 15:53:51,529" --service orders-api --mode A)
echo "investigation: $INV"
python3 "$T/workspace.py" set --inv "$INV" constraints.may_restart=no constraints.may_instrument=scratch-copy-only >/dev/null

# ---------------------------------------------------------------- 2. COLLECT
# log-analyst: timeline for the failing request only, then the wider window.
python3 "$T/log_parser.py" logs/app.log --corr req-b2 --out "$INV/timeline.json" >/dev/null
# stacktrace-analyst: Layer 1 location.
python3 "$T/stacktrace_parser.py" logs/app.log --root . --format text | tail -3
# knowledge base: anything already known about these files? (empty on a first run)
python3 "$T/kb.py" brief --files app/payment.py,app/orders.py --root debugging

add() { python3 "$T/evidence_collector.py" add --inv "$INV" "$@"; }
add --class log --grade FACT --by log-analyst --file logs/app.log --lines 10-14 --timestamp "15:53:50.528-15:53:50.629" \
    --summary "req-b2 was received at 15:53:50.528 and progressed normally to 'process_payment started' at 15:53:50.629" >/dev/null
add --class log --grade FACT --by log-analyst --file logs/app.log --lines 15 --timestamp "15:53:51.230" \
    --summary "Payment attempt 1 for req-b2 timed out after the 0.6s per-attempt timeout" >/dev/null
add --class log --grade FACT --by log-analyst --file logs/app.log --lines 16 --timestamp "15:53:51.529" \
    --summary "req-b2 failed with status 500 at 15:53:51.529, 1.001s after it was received" >/dev/null
add --class stacktrace --grade FACT --by stacktrace-analyst --file logs/app.log --lines 17-34 \
    --summary "CancelledError surfaced at app/payment.py:14 under wait_for at app/payment.py:23; the outermost frame is api_handler at app/api.py:17 awaiting the task" >/dev/null
# ---------------------------------------------------------------- 3. MAP
python3 "$T/call_graph.py" paths api_handler external_payment_api --root . | head -2
add --class source --grade FACT --by codebase-mapper --file app/api.py --lines 12-20 \
    --summary "api_handler waits REQUEST_TIMEOUT_S for the order task, then calls task.cancel() and logs the resulting CancelledError as a 500" >/dev/null
add --class config --grade FACT --by codebase-mapper --file app/config.py --lines 3-6 \
    --summary "Request budget is 1.0s; payment client allows 3 attempts of 0.6s with 0.2s backoff" >/dev/null
add --class source --grade INFERENCE --by cancellation-analyst --derived-from E-006 \
    --reasoning "3 attempts x 0.6s + 3 backoffs x 0.2s = 2.4s worst case, which exceeds the 1.0s request budget" \
    --summary "The payment client's worst-case duration (2.4s) cannot fit inside the request budget (1.0s)" >/dev/null
add --class source --grade FACT --by exception-propagation-analyst --file app/payment.py --lines 21-31 \
    --summary "The retry loop catches only asyncio.TimeoutError; a CancelledError raised at the await propagates out unhandled" >/dev/null
add --class absence --grade FACT --by log-analyst --command "grep -c 'process_payment completed request_id=req-b2' logs/app.log" \
    --excerpt "$(grep -c 'process_payment completed request_id=req-b2' logs/app.log || true)" \
    --search-scope "logs/app.log, whole file (covers 15:53:50.316 to 15:53:51.742), exact string match" \
    --summary "No 'process_payment completed' event exists for req-b2" >/dev/null
add --class log --grade FACT --by data-state-analyst --file logs/app.log --lines 11-13 \
    --summary "For req-b2 both database steps completed about 50ms apart; nothing waited on the pool" >/dev/null
add --class source --grade FACT --by data-state-analyst --file app/orders.py --lines 24-30 \
    --summary "release_inventory runs only in 'except Exception' and on the success path; there is no finally" >/dev/null
add --class log --grade FACT --by data-state-analyst --file logs/app.log --lines 44 \
    --summary "After all three requests finished the pool reports in_use=1" >/dev/null
add --class log --grade FACT --by dependency-analyst --file logs/app.log --lines 39-40 \
    --summary "A request 2ms after the failure (req-c3) completed its payment in 0.1s on the first attempt" >/dev/null
# ---------------------------------------------------------------- 4/5. HYPOTHESIZE + INVESTIGATE
for h in H-01 H-02 H-03; do python3 "$T/evidence_collector.py" add-hypothesis --inv "$INV" --json inputs/$h.json; done

# ---------------------------------------------------------------- 6. COMPETE
J=adversarial-reviewer
# Cheap eliminations first: H-03 made a prediction the logs already refute.
python3 "$T/evidence_collector.py" set-prediction --inv "$INV" --id H-03 --prediction P1 --status refuted --evidence E-010 --by "$J"
python3 "$T/evidence_collector.py" set-prediction --inv "$INV" --id H-02 --prediction P1 --status confirmed --evidence E-001,E-003 --by "$J"
python3 "$T/score.py" duel --inv "$INV" --a H-03 --b H-01 --judge "$J" \
    --scores-a log=1,source=2,path=1,alternatives=0,verification=0 \
    --scores-b log=3,source=1,path=2,alternatives=2,verification=2 \
    --rationale "H-03 predicted slow database steps for req-b2; E-010 shows both completed about 50ms apart and E-004 shows the task suspended in the payment client, not in pool.acquire. Its leak observation (E-012) is real and is retained as a finding."
python3 "$T/score.py" duel --inv "$INV" --a H-01 --b H-02 --judge "$J" \
    --scores-a log=3,source=1,path=2,alternatives=2,verification=2 \
    --scores-b log=4,source=4,path=4,alternatives=3,verification=3 \
    --rationale "Both agree on the trigger (slow gateway, E-002). Only H-02 explains why the request died with CancelledError after one logged attempt: E-004 puts api_handler at the top of the trace, E-005 shows it cancels the task at its budget, E-003 shows the failure exactly 1.0s after receipt, and E-006/E-007 show the budgets cannot fit. H-01 names no code location and leaves E-004 unanswered."

# ---------------------------------------------------------------- 7. VERIFY
# verifier: prediction P2 via Stage 3 probes, on a SCRATCH COPY, never the live checkout.
cp -r app run_incident.py "$SCRATCH/"
( cd "$SCRATCH" && python3 "$T/probe.py" stage3 --file app/payment.py --function process_payment --vars attempt --manifest probes.json >/dev/null \
  && python3 run_incident.py 2> probe.err || true
  python3 "$T/probe.py" analyze probe.err --manifest probes.json > analysis.txt
  python3 "$T/probe.py" remove --manifest probes.json )
add --class runtime --grade FACT --by verifier \
    --command "probe.py stage3 --file app/payment.py --function process_payment --vars attempt; run_incident.py; probe.py analyze" \
    --excerpt "$(grep -A1 '^last probe reached' "$SCRATCH/analysis.txt")" \
    --notes "Run on a scratch copy. Probes removed afterwards and files verified identical." \
    --summary "Stage 3 probes on process_payment: the last statement started before the failure was L23 (the wait_for) with attempt=2" >/dev/null
add --class runtime --grade FACT --by verifier --command "python3 verify_p3.py  (REQUEST_TIMEOUT_S=3.0, same slow gateway)" \
    --excerpt "$(python3 verify_p3.py | grep -E 'attempt=3|^RESULT')" \
    --summary "With the request budget raised to 3.0s the same slow order runs all 3 attempts and ends in RuntimeError, not CancelledError" >/dev/null

# verifier: record the verification results.
python3 "$T/evidence_collector.py" set-prediction --inv "$INV" --id H-02 --prediction P2 --status confirmed --evidence E-014 --by verifier
python3 "$T/evidence_collector.py" set-prediction --inv "$INV" --id H-02 --prediction P3 --status confirmed --evidence E-015 --by verifier
python3 "$T/evidence_collector.py" link --inv "$INV" --evidence E-014 --supports H-02 >/dev/null
python3 "$T/evidence_collector.py" link --inv "$INV" --evidence E-015 --supports H-02 >/dev/null
python3 "$T/score.py" score --inv "$INV" --id H-02 --judge verifier \
    --scores log=4,source=4,path=4,alternatives=3,verification=4 \
    --rationale "Re-scored after verification: P1, P2 and P3 all confirmed with FACT evidence (E-003, E-014, E-015). Path stays capped because the cancel call itself is inferred from code plus timing."
python3 "$T/evidence_collector.py" recheck --inv "$INV"
python3 "$T/score.py" verdict --inv "$INV" --verification pass --verifier verifier \
    --notes "Verifier re-derived the path from the ledger without the investigators' narrative and ran P2 and P3 itself."

# ---------------------------------------------------------------- 8. PRESERVE
for f in F-001 F-002 F-003; do python3 "$T/evidence_collector.py" add-finding --inv "$INV" --json inputs/$f.json >/dev/null; done
python3 "$T/evidence_collector.py" update-hypothesis --inv "$INV" --id H-03 --json <(echo '{"secondary_findings":["F-001"]}') --append >/dev/null

# ---------------------------------------------------------------- 9. REPORT
python3 "$T/evidence_collector.py" validate --inv "$INV"
python3 "$T/report_generator.py" --inv "$INV" --fix-file inputs/fix.md

# ---------------------------------------------------------------- 10. LEARN
python3 "$T/workspace.py" set --inv "$INV" step=10-learn >/dev/null
python3 "$T/kb.py" import --inv "$INV"
python3 "$T/kb.py" record-hypotheses --inv "$INV"
python3 "$T/workspace.py" status --inv "$INV"
echo "report: $INV/final_report.md"
