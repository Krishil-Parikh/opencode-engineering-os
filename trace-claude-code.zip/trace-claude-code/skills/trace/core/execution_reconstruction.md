# Execution reconstruction

How to rebuild what a failed execution did, from what it left behind, without running it again. This is what turns "the error is in file X" into a root-cause analysis.

## Contents

1. The three layers
2. Worked example: the `CancelledError` that was not the payment's fault
3. Procedure: building the timeline
4. Procedure: overlaying the timeline on the code
5. Reading gaps
6. Finding the trigger (Layer 2)
7. Finding the root cause (Layer 3)
8. Async, threads and processes
9. Cancellation and timeouts
10. Background jobs, schedulers and batches
11. Distributed executions
12. Complementary techniques
13. Output: the execution path in the hypothesis

---

## 1. The three layers

Every failure is described at three layers. A report that confuses them is wrong even when each sentence in it is true.

| Layer | Name | Question | Typical answer |
|---|---|---|---|
| 1 | **Failure location** | Where did the exception surface? | `services/payment.py:142` |
| 2 | **Failure trigger** | Which event or condition caused the failure to occur this time? | "The upstream request hit its timeout while the payment call was in flight" |
| 3 | **Root cause** | What underlying defect, incorrect assumption or external condition made the failure possible? | "The request budget is shorter than the payment client's retry policy, and cancellation is not handled on that path" |

How to tell them apart:

- **Layer 1 is a place.** It comes from the stack trace or from stage-3 localization. It needs no explanation to establish, and it explains nothing.
- **Layer 2 is an event in time.** It answers "why now, and not on the ten thousand executions that worked". It is specific to this incident. Remove it and this incident does not happen, but the next one still can.
- **Layer 3 is a standing property of the system.** It was true before the incident and is still true now. Remove it and this class of incident cannot happen.

Checks:

- If your "root cause" is a file and line, you have Layer 1.
- If your "root cause" is something that happened ("the gateway was slow", "the user sent an empty list", "a deploy went out"), you have Layer 2.
- If fixing your "root cause" would not prevent the same trigger from causing the same failure, you do not have Layer 3.
- External conditions can be legitimate Layer 3 answers (a provider outage with no reasonable defence), but only after asking whether the system should have tolerated it. Usually the honest Layer 3 is "we had no handling for a condition that is normal for that dependency".

The actual source can be several functions, several tasks or several services away from where the exception surfaced.

## 2. Worked example

The code:

```python
async def process_order(order):
    customer = await fetch_customer(order.customer_id)
    inventory = await check_inventory(order)
    payment = await process_payment(order)
    await send_confirmation(customer)
```

The logs:

```
09:47:01 process_order started
09:47:02 fetch_customer completed
09:47:03 check_inventory completed
09:47:04 process_payment started
09:47:05 CancelledError
```

A basic debugging agent concludes that `process_payment()` caused the error. That is not established. `CancelledError` is not raised by the code that fails. It is injected into a task by something else, and it surfaces wherever that task happens to be waiting. All of the following fit these five lines equally well:

- The payment service was taking too long and a timeout around it fired.
- The parent task was cancelled.
- The HTTP client disconnected and the server framework cancelled the handler.
- A cancellation token was propagated from an upstream request.
- The application was shutting down.

What the five lines establish (FACT): `process_order` ran its first three steps, `process_payment` started at 09:47:04, a `CancelledError` was logged at 09:47:05, and there is no `process_payment completed` line.

What they do not establish: who cancelled, why, and whether `process_payment` was doing anything wrong.

The observations that would separate the candidates:

| Candidate | It predicts | Look at |
|---|---|---|
| Timeout around the payment call | The interval from "started" to the error equals a configured timeout. The trace passes through `wait_for`/`timeout` in the payment code. The exception may be translated to `TimeoutError` | Config values, the stack trace's frames |
| Parent task cancelled by its caller's budget | The interval from *request received* to the error equals the caller's budget. The outermost frame is the caller awaiting the task. The payment code's own timeout has not elapsed | The caller's code, request-received timestamp |
| Client disconnected | An access-log or proxy line shows the connection closed (status 499 or similar) just before. Timing is unrelated to any configured value | Proxy and access logs |
| Upstream cancellation token | The upstream service logged a cancel or deadline for the same trace id | Upstream service logs, trace spans |
| Shutdown | A termination signal, "shutting down" or lifespan event appears shortly before. Other in-flight requests fail at the same instant | Process and orchestrator logs, other requests in the same second |

The sample incident shipped with this skill (`examples/sample_incident/`) is this scenario, runnable. Its answer is the second row, and the worked investigation shows each candidate being tested.

## 3. Procedure: building the timeline

1. **Fix the anchor.** The failure event: its timestamp, source file and line in the log, and every identifier on that line.
2. **Choose the correlation key** (`core/evidence_protocol.md`, section 7). Prefer trace id, then request id, then job or task id, then a business key.
3. **Extract the execution's own events:**
   ```
   python3 <skill-dir>/scripts/log_parser.py <all relevant logs> --corr <key> --out INV/timeline.json
   python3 <skill-dir>/scripts/log_parser.py <all relevant logs> --corr <key> --format text
   ```
   Pass every log that could contain the key: application, worker, proxy, database. The parser merges and orders them, keeps multi-line traces attached to their event, and reports gaps.
4. **Extract the context window**, unfiltered, around the anchor. This is where triggers from outside the execution show up: other requests failing at the same instant, deploys, shutdown messages, pool warnings, GC pauses, health-check failures.
   ```
   python3 <skill-dir>/scripts/log_parser.py <logs> --around "<anchor time>" --window 30 --format text
   ```
5. **Find the start.** Walk the correlated events back to the first one. When did this execution begin, and what started it (HTTP request, queue message, cron tick, another service)? The elapsed time from start to failure is one of the most useful numbers in the investigation. Compare it against every timeout, deadline, TTL, lease and interval you can find in configuration.
6. **Find a healthy twin.** Extract the timeline of a similar execution that succeeded near the same time. The first point where the failing timeline departs from the healthy one bounds the search.
   ```
   python3 <skill-dir>/scripts/log_parser.py <logs> --corr <healthy key> --format text
   ```
7. **Record** the anchor, the start, the last event before the failure, each departure from the healthy twin, and any out-of-execution events in the window, as ledger FACTs.

## 4. Procedure: overlaying the timeline on the code

1. **Parse the stack trace** if there is one. `stacktrace_parser.py --root .` gives the frames outermost first, marks application frames, and names the failure frame (deepest application frame) and the entry frame. Chained exceptions ("caused by", "during handling of") are separate traces linked in order: read the chain from the original cause forward.
2. **Build the static path** from the entry point to the failure frame: `call_graph.py paths <entry> <failing function>`. If there are several, keep them all for now.
3. **Pin log statements to code.** For each event in the timeline, find the statement that emitted it (search the format string). That gives an exact source location that certainly executed, at a known time.
4. **Mark each step** of the static path `observed` (a log line, span, stack frame or probe shows it ran) or `inferred` (it lies between two observed points and the code has no other route). Between two observed points with more than one possible route, mark the segment *undetermined* and keep the alternatives.
5. **List what happens at each step that the logs do not show**: awaits, I/O, lock acquisition, retries, exception handlers that might have run, callbacks registered.
6. **List what can reach into the path from outside**: the caller's timeouts, cancellation, shared state mutated by other tasks, signals, scheduler ticks, feature flags, cache expiry.

The result is the candidate path. Every hypothesis must either use it or justify departing from it with evidence.

## 5. Reading gaps

A gap is an interval in the execution's timeline with no events. `log_parser.py` reports them with their duration. A gap means only that nothing was logged. Classify each significant one:

| Kind | Signs | Meaning |
|---|---|---|
| **Waiting** | The gap sits between "X started" and "X completed", or ends in a timeout or cancel | The execution was blocked on X: I/O, a lock, a pool, a queue, a sleep, a slow dependency. The duration is evidence: compare with configured timeouts |
| **Working** | CPU or throughput metrics are high. The code between the two events is a loop or heavy computation | No logging inside the work. Use a profiler or checkpoint logs next time |
| **Stalled process** | Every execution in the process shows the same gap at the same wall-clock time | Stop-the-world: GC pause, blocked event loop, swap, CPU starvation, a synchronous call in async code, a paused container |
| **Elsewhere** | The execution handed off to another service, queue or thread whose logs you have not merged | Get those logs |
| **Unlogged path** | The code between the events has branches with no logging | Undetermined. A candidate for instrumentation |
| **Lost logs** | Other evidence shows activity (database rows changed, downstream service saw calls) | Logging pipeline dropped lines. Treat all absence evidence from this source as unreliable |

A gap whose length matches a configured value (30.0s, 60s, 5 minutes) is very rarely a coincidence. Search the configuration and the dependencies' defaults for that number.

The most informative gap is the last one: between the last event and the failure. What was the execution waiting on, and for how long?

## 6. Finding the trigger (Layer 2)

The trigger is what was different this time. Sources of difference, each with its check:

| Difference | Check |
|---|---|
| **This input** | Compare the failing record or request with ones that succeeded. Size, nulls, encoding, duplicates, ordering, a boundary value, a new enum member |
| **This moment** | What else was happening: concurrent requests on the same key, a batch job, a cache expiry, a token refresh, a leader election, a cron tick. The context window shows it |
| **This duration** | Elapsed time compared with timeouts and budgets on the path, and with the healthy twin |
| **This state** | A resource level at the time: pool in use, queue depth, memory, disk, file handles, rate-limit remaining. Metrics, or state lines in the logs |
| **This dependency behaviour** | Latency or errors from a downstream service in the same window. Its logs and status |
| **This code** | A deploy or flag change shortly before the first occurrence. `git_suspects.py window`, deploy logs |
| **This environment** | One host, one zone, one tenant, one version. Group failures by each dimension |
| **This sequence** | A preceding event on the same entity: an earlier failed attempt that left partial state, a retry, an out-of-order message |

Establishing the first occurrence matters. Search backwards for the same error signature: if it has happened before, the trigger for "the first time" and for "this time" may differ, and the root cause is older than it looks.

A trigger is established when a FACT shows the differing condition was present for the failing execution and a FACT shows it was absent for a healthy one. One without the other is an inference.

## 7. Finding the root cause (Layer 3)

From the trigger, ask what allowed it to cause a failure. The answer falls into one of these families:

| Family | Shape of the defect | Example |
|---|---|---|
| **Missing handling** | A condition that can occur is not handled on this path | No handler for cancellation, a `None` return not checked, an empty batch |
| **Wrong assumption** | The code is correct given a belief that is false | "This call always finishes within the request budget", "ids are unique", "the list is sorted", "the callback runs once" |
| **Inconsistent contracts** | Two parts each behave reasonably, and together they cannot work | A 1.0s caller budget around a client allowed 2.4s. A retry on a non-idempotent call. A cache TTL longer than the token lifetime |
| **Unsafe sharing** | State is reachable from more than one flow without coordination | Check-then-act across an await, a module-level dict mutated by workers, a connection used by two tasks |
| **Resource lifetime** | Something acquired is not always released, or is used after release | Cleanup only on the success path, a leak on cancellation, a closed session reused |
| **Error-path defect** | The failure handling itself is wrong | An `except` that swallows, a retry that amplifies, a fallback that returns stale data as fresh, cleanup that raises |
| **Configuration defect** | The code is right and its settings are not | Pool smaller than concurrency, timeout ordering inverted between layers, a flag enabled in one environment |
| **Change defect** | A recent change removed a property the system relied on | A refactor that moved a call outside a lock, a dependency upgrade with a new default |
| **External condition without defence** | A dependency misbehaved in a way that is normal for it, and nothing bounded the damage | No timeout, no circuit breaker, no backpressure |

The "why" chain: start at Layer 1 and ask why, citing evidence at each step, until you reach a standing property of the system that someone could change. Stop when the next "why" leaves the system (organisational reasons are out of scope) or when you can no longer cite evidence. Mark the last evidenced step. Everything beyond it is hypothesis.

A root cause is established only when it makes predictions that were checked (`core/root_cause_verification.md`). The strongest is counterfactual: with the proposed defect removed and the same trigger applied, the failure does not occur.

## 8. Async, threads and processes

Sequential intuition fails in concurrent code. Rules for reconstruction:

- **One timeline per flow.** Split events by task, thread, goroutine or process before reading them. Where the log format carries a thread or task name, pass it as an id key (`log_parser.py --id-key taskName`). Where it does not, correlation ids are the only reliable separator.
- **A stack trace describes one task.** It says nothing about what other tasks were doing. For those you need their own log lines, or a thread or task dump from the time.
- **Parent and child.** Establish which task created which: `create_task`, `gather`, `TaskGroup`, thread pool submission, queue hand-off. `call_graph.py hotspots` lists these primitives. A failure in a child can surface in the parent (and the reverse: cancellation flows from parent to child).
- **Suspension points are where things happen.** Between two awaits a coroutine is atomic with respect to other coroutines on the same loop. At each await, anything can run. Any state read before an await and used after it may have changed.
- **A blocked event loop looks like everything timing out at once.** One synchronous call in async code (a blocking driver, a CPU-heavy function, a `time.sleep`) stalls every task. The signature is simultaneous gaps across unrelated executions.
- **Thread pools hide stack ancestry.** A function run via an executor has a trace that starts in the pool's worker loop. The submitting call site is not in the trace. Find it by searching for where the function is submitted.
- **Exceptions in background tasks can vanish.** A task nobody awaits swallows its exception until garbage collection ("Task exception was never retrieved"), or forever. Absence of an error line for a background task proves little.
- **Processes.** Each worker process has its own memory. A module-level cache, lock or counter is per process. A "race" that requires shared memory cannot happen across processes, and a fix based on an in-process lock does not work across them.

## 9. Cancellation and timeouts

These produce more misattributed failures than anything else, because the exception names the victim.

**Identify the mechanism from the artefacts:**

| Artefact | Reading |
|---|---|
| Exception is a timeout type raised by a wrapper (`TimeoutError` from `wait_for`, `context deadline exceeded`, `SocketTimeoutException`) | A timeout owned by code on this stack fired. The top frames show which wrapper. Its duration should match the gap |
| Exception is a cancellation type (`CancelledError`, `context canceled`, `AbortError`, `OperationCanceledException`) | Something outside this frame requested cancellation. Find the owner of the cancel scope, token or context |
| Outermost frames show a caller awaiting or joining the task | That caller is the first suspect for having cancelled it. Read its code for timers and cancel calls |
| Elapsed time since the execution started equals a configured budget | The owner of that budget cancelled, whatever the inner code was doing |
| Elapsed time since the inner call started equals a configured timeout | The inner timeout fired |
| Many executions fail in the same instant | Process-wide: shutdown, loop closure, pool teardown, a dependency going away |
| A shutdown, SIGTERM, "lifespan", or "draining" line shortly before | Shutdown-driven cancellation. Check grace period against in-flight work |

**Map the timeout hierarchy.** List every time limit on the path from the outermost entry (load balancer, gateway, client) to the innermost call (socket, query), with its value and where it is set. Include retries: a call with timeout *t*, *n* attempts and backoff *b* can take up to roughly *n*·*t* + (*n*−1)·*b*, more with jittered or exponential backoff. For the system to fail in a designed way, each inner worst case must be shorter than the limit enclosing it. Every place where an inner worst case exceeds its enclosing limit is a place where the outer layer will cut the inner one off mid-flight. That table is often the root cause on one page.

**Follow the cancellation through cleanup.** When a task is cancelled:

- Which `finally` blocks and context-manager exits run? Do they await anything that could itself be cancelled or hang?
- Which cleanup is in an `except Exception` block? In Python 3.8 and later `CancelledError` derives from `BaseException`, so that block does not run on cancellation.
- Is a cancellation caught and suppressed anywhere (a bare `except`, `except BaseException`, `suppress`)? Then the task carries on after being told to stop, and the canceller may wait forever.
- What state is left half-done: a reservation without a payment, a row locked, a message consumed and not acknowledged, a connection checked out?

Half-done state after a cancellation is the commonest source of secondary findings, and often of the *next* incident.

## 10. Background jobs, schedulers and batches

The scenario TRACE was designed around: a long-running process, a scheduled job, tens of thousands of records, one failure deep in the run.

1. **Identify the unit of work that failed.** Job run id, batch id, record id. If the log line with the error does not carry them, look at the nearest preceding line from the same worker that does.
2. **Establish where in the run it was.** Record index or count, elapsed time since the job started, which phase.
3. **Ask the three batch questions.**
   - *Is it this record?* The same record fails when run alone, and its neighbours do not. Then the trigger is in the data.
   - *Is it this position?* It fails at about the same count or elapsed time whatever the record. Then something accumulates or expires: memory, a connection or token lifetime, a cursor, a lease, a lock timeout, a rate limit.
   - *Is it this moment?* It fails at the same wall-clock time regardless of progress. Then something external happens then: another job, a backup, a deploy, a rotation, a maintenance window.
4. **Check what the scheduler did.** Did a second instance of the job start while the first was running (overlap)? Did the scheduler kill it for exceeding a limit? Was it retried, and is it safe to retry from the middle?
5. **Check what was left behind.** How many records were processed before the failure, and is the stored state consistent with that? A batch that fails at record 31,204 and has committed 31,000 has 204 records in an unknown state.
6. **Do not re-run the job to find out.** Re-running changes state and does not reproduce the conditions. If reproduction is needed, extract the failing unit and run it in isolation against a copy.

## 11. Distributed executions

When the execution crosses services:

- Follow the trace id if there is one. Where spans exist, the span tree is the execution path, with timing, and it is FACT-grade for "what called what and for how long".
- Where there is no tracing, join logs on whatever id is passed between services. If nothing is passed, cross-service ordering is inference from timestamps, subject to clock skew.
- For each hop, record both sides: the caller's view (sent at, got response or error at) and the callee's view (received at, finished at). A caller-side timeout with a callee-side success is its own, very common, class of bug: the work happened and the caller believes it did not.
- Retries multiply executions. Count how many times the callee saw the request.
- Queues decouple time. The consumer's failure may be minutes or hours after the producer's action. Carry the message id.

## 12. Complementary techniques

These are complementary, not replacements for one another. Use whichever the environment already provides, and recommend the others in the instrumentation plan when their absence made the investigation hard.

| Technique | What it gives | Use it for | Limits |
|---|---|---|---|
| **OpenTelemetry** (distributed traces, spans, correlation) | The actual call tree across services with timings and parent links | The execution path, latency attribution, who called whom | Only what was instrumented and sampled. Cancellation is often not recorded unless span status and events are set |
| **eBPF** | Runtime-level observation (syscalls, network, scheduling, function entry and exit in supported runtimes) without changing application code | Looking at a live process that cannot be restarted or modified: where is it blocked, what is it calling | Needs privileges and a supported kernel. Sees system behaviour, not application intent. Forward-looking only |
| **Source maps** | Mapping from compiled, bundled or minified locations to original source | Making a production JavaScript or TypeScript stack trace readable before localizing | Needs the map for the exact deployed build |
| **Static call graphs** | Possible function relationships without executing anything | Mapping the candidate path, finding callers, finding what else touches a function | Possible calls, not actual calls. Blind to dynamic dispatch |
| **Git bisect and blame** | The change that introduced a behaviour, and the history of specific lines | Regressions with a known good version and a reliable test | Needs a reproduction. A commit near the time is a lead, not a cause |
| **Thread, task and heap dumps** | Every flow's stack at one instant, or the object graph | Hangs, deadlocks, leaks, "what is everything waiting on" | A snapshot. Must be taken while the condition holds |
| **Database and broker introspection** | Lock waits, active queries, consumer lag, dead-letter contents | Stalls and partial state | Reflects now, not the failure time, unless historical views exist |

## 13. Output: the execution path in the hypothesis

Reconstruction ends in the `execution_path` array of a hypothesis: ordered steps, outermost first, each with a location, `observed` true or false, and the evidence ids that show it.

```json
"execution_path": [
  {"step": "api_handler()", "location": "app/api.py:10", "observed": true, "evidence": ["E-001", "E-004"]},
  {"step": "process_order()", "location": "app/orders.py:18", "observed": true, "evidence": ["E-001", "E-004"]},
  {"step": "process_payment() attempt 1 times out", "location": "app/payment.py:23", "observed": true, "evidence": ["E-002"]},
  {"step": "backoff sleep 0.2s", "location": "app/payment.py:30", "observed": false, "evidence": ["E-008"]},
  {"step": "process_payment() attempt 2 awaiting external_payment_api()", "location": "app/payment.py:23", "observed": true, "evidence": ["E-004"]},
  {"step": "api_handler budget expires, task.cancel()", "location": "app/api.py:15", "observed": false, "evidence": ["E-005", "E-003"]},
  {"step": "CancelledError", "location": "app/payment.py:14", "observed": true, "evidence": ["E-004"]}
]
```

Rules:

- `observed: true` requires a runtime artefact for that step: a log line it emitted, a span, a stack frame, a probe.
- A step deduced from code and timing is `observed: false`, however certain it feels. It can still cite the source and timing evidence it rests on.
- Include steps from other flows that act on this one (the canceller, the other writer), placed where they take effect.
- Scoring caps the path criterion when steps are inferred. That is intended: it shows exactly which observation would raise confidence, and that observation becomes a prediction for the verifier or a line in the instrumentation plan.
