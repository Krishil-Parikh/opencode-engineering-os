# Hypothesis scoring

The evidence-based scoring mechanism that decides duels and the final verdict. Its purpose is to make sure that winning a debate does not mean winning the investigation: an agent can be extremely persuasive and completely wrong.

## Contents

1. Criteria and weights
2. The 0 to 4 scale, with anchors per criterion
3. Caps: what the ledger allows
4. Penalties and elimination
5. Computing the total
6. Duel outcomes
7. Verdict thresholds and confidence levels
8. The right to declare insufficient evidence
9. Worked example
10. Tuning the weights
11. Rules for judges

---

## 1. Criteria and weights

| Key | Criterion | Weight | The question it asks |
|---|---|---|---|
| `log` | Direct evidence from logs | 25% | Does runtime evidence (logs, stack traces, telemetry, command output) show this happened? |
| `source` | Source-code verification | 25% | Has the code been read and shown to behave the way the hypothesis needs? |
| `path` | Execution-path consistency | 20% | Is there one coherent path from entry to failure that fits the timeline, with nothing unexplained? |
| `alternatives` | Alternative hypotheses eliminated | 15% | Has each rival been shown less likely, with evidence? |
| `verification` | Reproducibility or independent verification | 15% | Have its predictions been tested, by reproduction or by an independent check? |

These are initial engineering weights, not scientifically validated constants. They encode a judgement: what happened at runtime and what the code says matter most, and they matter equally, because either alone misleads. Section 10 covers changing them.

## 2. The 0 to 4 scale

The judge gives each criterion an integer from 0 to 4. Use the anchors. If you are between two, take the lower.

### `log`: direct runtime evidence

| Score | Anchor |
|---|---|
| 0 | No runtime evidence. The hypothesis rests on reading code or on plausibility |
| 1 | Runtime evidence is consistent with the hypothesis but equally consistent with its rivals (for example, only the error line itself) |
| 2 | One FACT-grade runtime item that the rivals do not predict |
| 3 | Several independent FACT-grade runtime items, correlated to the failing execution, that the rivals do not predict. Or one that is decisive |
| 4 | Runtime evidence shows the mechanism itself: the triggering event and the failure, both correlated, with timing that matches. Corroborated by at least two independent items |

### `source`: source-code verification

| Score | Anchor |
|---|---|
| 0 | No code cited, or the code cited does not say what is claimed |
| 1 | The relevant code is cited, but the claimed behaviour depends on parts not read (callees, configuration, the deployed version) |
| 2 | The code on the claimed path has been read and permits the claimed behaviour |
| 3 | The code has been read end to end along the path, including handlers and configuration values, and it produces the claimed behaviour under the stated trigger. Line-level citations |
| 4 | As 3, and the code also rules out the rival mechanisms at this location, or the deployed version has been confirmed to be the code that was read |

### `path`: execution-path consistency

| Score | Anchor |
|---|---|
| 0 | No path, or the path contradicts the timeline |
| 1 | A path exists but is entirely inferred from code. Or it has a gap the hypothesis does not explain |
| 2 | Path matches the timeline at its ends (entry and failure). The middle is inferred |
| 3 | Most steps observed. Durations between steps are consistent with the claimed mechanism. Any inferred step is forced by the code (no other route) |
| 4 | Every step observed at runtime, in order, with timing that matches. Nothing in the execution's timeline is left unexplained |

### `alternatives`: rivals eliminated

| Score | Anchor |
|---|---|
| 0 | Rivals not addressed |
| 1 | Rivals argued against by reasoning alone |
| 2 | At least one rival countered with FACT-grade evidence |
| 3 | Every live rival countered with FACT-grade evidence, or shown to be a sub-case of this hypothesis |
| 4 | Every rival countered, and the obvious unproposed alternatives (the ones in `core/execution_reconstruction.md` for this failure type) considered and excluded with evidence |

### `verification`: reproducibility or independent verification

| Score | Anchor |
|---|---|
| 0 | No predictions, or none testable |
| 1 | Predictions stated. None tested |
| 2 | At least one non-trivial prediction confirmed from existing evidence |
| 3 | Predictions confirmed by an independent party (the verifier), or the failure reproduced under the claimed conditions |
| 4 | Reproduced, and the counterfactual shown: with the proposed cause removed and the same trigger applied, the failure does not occur. All predictions tested |

A prediction is non-trivial if a rival hypothesis would have predicted otherwise. "The error will be in the log" is trivial.

## 3. Caps: what the ledger allows

After the judge enters raw scores, `scripts/score.py` reads the ledger and lowers any score that the recorded evidence cannot support. The judge cannot override a cap. To lift one, add the evidence.

| Criterion | Condition found in the ledger | Cap |
|---|---|---|
| `log` | No FACT-grade item of class log, stacktrace, telemetry or runtime in `evidence_for` | 1 |
| `log` | Exactly one such item | 3 |
| `source` | No FACT-grade item of class source, git or config in `evidence_for` | 1 |
| `path` | No `execution_path` submitted | 0 |
| `path` | No step marked `observed` | 1 |
| `path` | Some steps inferred | 3 |
| `alternatives` | No `rival_rebuttals` | 0 |
| `alternatives` | No rebuttal cites a FACT-grade item | 1 |
| `verification` | No predictions | 1 |
| `verification` | No prediction with status `confirmed` | 1 |
| `verification` | Some predictions still `untested` | 3 |

Evidence that failed `recheck` (mismatch or missing file) does not count towards any of these.

Caps are deliberately blunt. They are a floor of honesty under the judge's judgement. They are not a substitute for it: a hypothesis can satisfy every cap condition and still deserve a 1.

## 4. Penalties and elimination

**Unanswered contradictions.** For each FACT-grade item in `evidence_against` that is not listed in `addressed_contradictions`, 10 points are deducted from the total, up to 30. To address a contradiction the owner must explain it with evidence and record the explanation.

**Refuted prediction.** If any prediction has status `refuted`, the hypothesis is eliminated and its total is 0. A hypothesis that predicted something reality contradicts is wrong as stated, however well it scores elsewhere. Its owner may submit an amended hypothesis under a new id with `supersedes` set. The amended one starts from scratch in the tournament and the judge should ask whether the amendment is principled or merely shaped to dodge the refutation.

Marking a prediction confirmed or refuted itself requires FACT-grade evidence (`evidence_collector.py set-prediction` enforces this).

## 5. Computing the total

```
total = Σ over criteria ( weight × capped_score / 4 )  −  penalty
```

Range 0 to 100. With default weights, each point on `log` or `source` is worth 6.25, on `path` 5, on `alternatives` or `verification` 3.75.

```
python3 <skill-dir>/scripts/score.py score --inv INV --id H-02 \
    --scores log=4,source=4,path=4,alternatives=3,verification=4 \
    --judge verifier --rationale "<evidence ids per criterion>"
```

The tool prints raw and capped scores, each cap with its reason, the penalty and the total, and stores all of it on the hypothesis.

## 6. Duel outcomes

`score.py duel` scores both sides on the same ledger and decides:

| Outcome | Condition | Effect |
|---|---|---|
| `win` | Totals differ by at least the minimum margin (default 10) | Higher total becomes `champion`. Loser becomes `eliminated`. Its findings are retained |
| `narrow` | Totals differ by less than the minimum margin | Nobody is eliminated. The judge must state the evidence that would separate them (`--needs`). The orchestrator collects it, then the duel is re-run |
| `elimination` | One side has a refuted prediction | The other advances regardless of its own total. The tournament verdict still applies thresholds to it later |
| `both_eliminated` | Both have refuted predictions | No champion. Return to step 4 with what refuted them |
| `merge` | The two turn out to assert the same Layer 3 root cause (`score.py merge`) | One hypothesis, combined evidence and predictions, re-scored |

The minimum margin exists because the scale is coarse and judges are noisy. A three-point lead is not a finding.

## 7. Verdict thresholds and confidence levels

`score.py verdict` combines the champion's post-verification total, its lead over the best other scored hypothesis, and the verifier's result.

| Confidence | Requires | Report language |
|---|---|---|
| **CONFIRMED** | Verification `pass`. Total at least 80. No untested predictions. Lead at least the minimum margin | "The root cause is ..." |
| **PROBABLE** | Verification `pass` or `partial`. Total at least 65. Lead at least the minimum margin | "The most likely root cause is ... Remaining gaps: ..." |
| **PROVISIONAL** | Total at least 50 and lead at least the minimum margin, but verification not run, or total under 65 | "Root-cause hypothesis pending confirmation of ..." |
| **INSUFFICIENT_EVIDENCE** | Best total under 50, or the top two within the minimum margin, or no hypothesis survives, or verification `fail` | "The available evidence does not establish a root cause. Leading candidates: ... What would decide it: ..." |

Thresholds live in `debugging/trace_config.json` and are engineering defaults.

The report's wording must not exceed its confidence level. A PROVISIONAL result reported to the user as "found it" is a defect in the investigation.

## 8. The right to declare insufficient evidence

The final winner is allowed to declare that the available evidence is insufficient. So is the judge, the verifier and the orchestrator. This is extremely important: without it, the format itself pressures an AI into hallucinating a root cause because a winner has to be produced.

INSUFFICIENT_EVIDENCE is a successful outcome when it is true. It must come with:

- What is established (the FACTs, the observed part of the path, Layer 1).
- The leading candidates and their scores.
- Exactly which observations would decide between them.
- The instrumentation plan that will produce those observations (`core/instrumentation_playbook.md`).
- Any mitigation that is justified regardless of which candidate is right.

An investigator may also return "no hypothesis from this lens: the evidence shows nothing in my area" and should, when that is the case. A lens with nothing to say is information.

## 9. Worked example

From the sample incident. Two hypotheses reach the final duel.

**H-01, gateway slowness is the root cause.** Judge's raw scores: log 3, source 1, path 2, alternatives 2, verification 2.

- Ledger check: two FACT runtime items support it, so `log` stays 3. No source item, and the raw score was already 1. Three path steps, all observed, raw 2 stays. One rebuttal backed by a FACT, raw 2 stays. One confirmed prediction, none untested, raw 2 stays.
- Weighted: 25×3/4 + 25×1/4 + 20×2/4 + 15×2/4 + 15×2/4 = 18.75 + 6.25 + 10 + 7.5 + 7.5 = 50.0
- Penalty: one unanswered contradicting FACT (E-004, the trace showing the cancel came from `api_handler`): −10.
- **Total 40.0**

**H-02, request budget shorter than the retry policy.** Raw: log 4, source 4, path 4, alternatives 3, verification 3.

- Ledger check: several runtime FACTs, `log` 4 stands. Source and config FACTs, `source` 4 stands. Seven path steps, two inferred (the backoff sleep and the cancel call): `path` capped at 3. Two rebuttals with FACTs, 3 stands. One prediction confirmed, two untested: `verification` capped at 3, which was the raw score.
- Weighted: 25 + 25 + 15 + 11.25 + 11.25 = 87.5. No penalty.
- **Total 87.5**

Margin 47.5: a `win`. H-01 is eliminated and retained.

After verification confirms the remaining two predictions, H-02 is re-scored with verification 4: 25 + 25 + 15 + 11.25 + 15 = **91.25**. Verification `pass`, no untested predictions, total above 80: **CONFIRMED**.

Note what the cap did. The judge gave `path` a 4. The ledger showed two steps that nobody had observed. The cap held it at 3 and named the two steps, which is a to-do list for raising confidence: log the cancel call.

Note also what H-01 got right. Its trigger is correct. It lost because it stopped at Layer 2 and could not explain the stack trace. Its statement is preserved in the knowledge base as "outscored", not "impossible".

## 10. Tuning the weights

Edit `debugging/trace_config.json`. Weights must sum to 100. Record why you changed them.

| Situation | Reasonable adjustment |
|---|---|
| Sparse or untrustworthy logging | Lower `log`, raise `source` and `verification`. Expect more PROVISIONAL verdicts: that is the honest result |
| Failures are easily reproducible (a test suite, a deterministic pipeline) | Raise `verification`. Reproduction should dominate |
| Heavily dynamic code where static reading misleads (plugins, metaprogramming, generated code) | Lower `source`, raise `log` |
| Excellent tracing | Raise `path`: observed span trees are strong evidence |

Do not tune weights during an investigation to change its outcome. Do not raise thresholds down to make a verdict fit. If a codebase keeps producing PROVISIONAL results, the fix is better instrumentation, and the report should say so.

## 11. Rules for judges

1. **Score evidence, not prose.** Read the submission's evidence ids and open the ledger items. Ignore how well the statement is written.
2. **Cite per criterion.** The rationale names the items that earned or cost each score: "log 3: E-002, E-003 correlated to req-b2, rivals do not predict the 1.0s interval".
3. **Score both sides against the same evidence.** If an item supports one and contradicts the other, both scores should reflect it.
4. **Confidence in tone is not evidence.** Neither is length, technical vocabulary, or the number of items cited. Ten items that all restate the error line are worth 1.
5. **Check the excerpts.** A summary that claims more than its excerpt shows is scored on the excerpt.
6. **Penalise unfalsifiability.** A hypothesis with no prediction a rival would dispute cannot score above 1 on verification, and you should say why.
7. **Narrow is a valid ruling.** When the evidence does not separate them, say so and name what would.
8. **Declare a conflict.** If you proposed or helped develop one of the hypotheses, you cannot judge it.
9. **Do not help.** If a submission is missing something, score it as submitted. Suggest the missing check in the rationale. Do not fill it in.
