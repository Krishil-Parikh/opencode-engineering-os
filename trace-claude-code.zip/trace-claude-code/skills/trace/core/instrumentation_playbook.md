# Instrumentation playbook (Mode B)

What to add when existing evidence is not enough, where to add it, and how to do so without restarting everything or drowning in output.

## Contents

1. When to instrument
2. Deriving instrumentation from the hypotheses
3. The six signal types
4. Snippets: Python
5. Snippets: Node.js and TypeScript
6. Snippets: Go
7. Snippets: Java and Kotlin
8. Instrumenting a process that cannot be restarted
9. Safety rules for anything that will run in production
10. The instrumentation plan document
11. After the next occurrence

---

## 1. When to instrument

Instrument when, and only when, a specific question cannot be answered from what exists:

- Two hypotheses are within the minimum margin and no existing artefact separates them.
- A step of the execution path is inferred exactly where the hypotheses disagree.
- The last gap before the failure is too wide: many statements, several awaits, no log between them.
- There is no correlation id, so nothing ties cross-component events to the failing execution.
- The failure is silent: a job stopped, nothing was logged.

Instrumentation is targeted. The goal is the smallest set of new signals that will make the next occurrence decidable. "Add debug logging everywhere" is not a plan: it costs performance, buries the signal, and usually still misses the one value that mattered.

Two forms:

- **B1, reproduce and probe.** The failure can be made to happen somewhere safe. Use `probe.py` and the stages in `core/hierarchical_localization.md`. Probes are temporary and are removed afterwards.
- **B2, instrument for the next occurrence.** The failure cannot be produced on demand. Design durable, reviewed instrumentation, ship it through the normal release path, and wait. The investigation closes as PROVISIONAL or INSUFFICIENT_EVIDENCE with the plan as its deliverable, and resumes when the failure recurs.

## 2. Deriving instrumentation from the hypotheses

Work backwards from what would settle the question.

1. List the live hypotheses and their untested predictions (`hypotheses.json`).
2. For each pair of rivals, write down the cheapest observation they disagree about. The judge's `discriminating_evidence_needed` from a narrow duel is exactly this.
3. For each inferred step in the leading execution path, write down what artefact would make it observed.
4. For each of those, choose a signal type (section 3) and the exact location: file, function, line, and the values to capture.
5. Remove anything that would not change a verdict. Each remaining signal must name the hypothesis or prediction it serves.

Example, from the sample incident before verification:

| Question | Signal | Location | Serves |
|---|---|---|---|
| Who cancels the order task? | Log at the cancel call with request id, elapsed time and budget | `app/api.py:15` | H-02 path step 6 (inferred) |
| Which attempt was in flight? | Attempt number on entry to each try | `app/payment.py:22` | H-02 P2 |
| Was the pool a factor? | Pool wait time on acquire | `app/db.py:18` | H-03 P1 |
| Does cleanup run on cancel? | Log in a `finally` around the payment call | `app/orders.py:24` | Finding F-001 |

## 3. The six signal types

**1. Function-entry and function-exit events.** One line when a function on the suspect path is entered, one when it leaves, with the outcome (returned, raised which exception, cancelled) and the duration. Exit must be recorded in a `finally`/`defer` so it fires on every route out. This turns inferred path steps into observed ones.

**2. Execution checkpoints.** A line at each significant point inside a long function: before and after each await or external call, at each branch that matters, at loop milestones (every N records, not every record). This narrows the final gap.

**3. Input and output metadata.** Sizes, counts, types, ids, key presence, hashes, status codes. Enough to tell this execution's data from a healthy one's without logging the data. Never payloads, credentials or personal data.

**4. Exception propagation.** At every place an exception is caught: its type, whether it is re-raised, translated (and into what), or swallowed. At every translation, keep the cause chained. This exposes swallowed and rewritten errors, which are otherwise invisible.

**5. Async task and thread identifiers.** The task name or id, thread name, process id, and the parent task where there is one, on every line of the suspect path. Without these, concurrent executions cannot be separated.

**6. Cancellation propagation.** A line where cancellation is requested (who, why, elapsed time, the budget that expired), a line where it is received (which task, at which await), and a line for each cleanup step that runs because of it. This is the signal that almost no system has and that cancellation bugs always need.

Around all six: a **correlation id** generated at the entry point and carried through every call, task, thread hand-off, queue message and outbound request. If the system does not have one, adding it is the first item of every plan.

## 4. Snippets: Python

A correlation id that follows the execution through async code and into log records:

```python
# tracing_ctx.py
import contextvars, logging, uuid

correlation_id = contextvars.ContextVar("correlation_id", default="-")

def new_correlation_id(incoming: str | None = None) -> str:
    cid = incoming or uuid.uuid4().hex[:16]
    correlation_id.set(cid)
    return cid

class ContextFilter(logging.Filter):
    """Adds correlation id, asyncio task name and thread name to every record."""
    def filter(self, record: logging.LogRecord) -> bool:
        import asyncio, threading
        record.correlation_id = correlation_id.get()
        try:
            task = asyncio.current_task()
            record.task_name = task.get_name() if task else "-"
        except RuntimeError:          # no running event loop in this thread
            record.task_name = "-"
        record.thread_name = threading.current_thread().name
        return True

# setup: handler.addFilter(ContextFilter())
# format: "%(asctime)s %(levelname)s %(name)s cid=%(correlation_id)s task=%(task_name)s thread=%(thread_name)s %(message)s"
```

`contextvars` values are copied into tasks created with `asyncio.create_task` and into `asyncio.to_thread`. They are **not** carried into `loop.run_in_executor` or a plain `ThreadPoolExecutor.submit`: wrap the callable with `contextvars.copy_context().run`.

Entry, exit, duration and outcome for sync and async functions, including cancellation:

```python
# trace_calls.py
import asyncio, functools, logging, time

log = logging.getLogger("trace")

def traced(fn):
    name = fn.__qualname__
    if asyncio.iscoroutinefunction(fn):
        @functools.wraps(fn)
        async def awrapper(*args, **kwargs):
            start = time.monotonic()
            log.info("enter %s", name)
            outcome = "returned"
            try:
                return await fn(*args, **kwargs)
            except asyncio.CancelledError:
                outcome = "cancelled"
                raise                      # never swallow cancellation
            except BaseException as exc:
                outcome = "raised %s" % type(exc).__name__
                raise
            finally:
                log.info("exit %s outcome=%s elapsed=%.3fs", name, outcome, time.monotonic() - start)
        return awrapper

    @functools.wraps(fn)
    def wrapper(*args, **kwargs):
        start = time.monotonic()
        log.info("enter %s", name)
        outcome = "returned"
        try:
            return fn(*args, **kwargs)
        except BaseException as exc:
            outcome = "raised %s" % type(exc).__name__
            raise
        finally:
            log.info("exit %s outcome=%s elapsed=%.3fs", name, outcome, time.monotonic() - start)
    return wrapper
```

Recording who cancels and why, at the point of cancellation:

```python
elapsed = time.monotonic() - started
log.warning("cancelling task=%s reason=request_budget_expired elapsed=%.3fs budget=%.3fs",
            task.get_name(), elapsed, REQUEST_TIMEOUT_S)
task.cancel(msg="request budget %.1fs expired" % REQUEST_TIMEOUT_S)   # msg is carried on the CancelledError (3.9+)
```

Recording that cancellation was received, and making cleanup cancellation-safe:

```python
try:
    receipt = await process_payment(order)
except asyncio.CancelledError as exc:
    log.warning("cancelled while awaiting process_payment order=%s detail=%s", order.id, exc.args)
    raise
finally:
    # runs on success, failure AND cancellation; shield if it must finish
    await asyncio.shield(release_inventory(reservation))
```

Exception translation that keeps the chain:

```python
except httpx.TimeoutException as exc:
    log.warning("payment gateway timeout attempt=%d elapsed=%.3fs", attempt, time.monotonic() - t0)
    raise PaymentUnavailable("gateway timeout") from exc       # `from exc` preserves the cause
```

A resource gauge at intervals, for failures that depend on position or uptime:

```python
log.info("pool in_use=%d size=%d waiters=%d", pool.in_use, pool.size, pool.waiters)
```

Checkpoints in a batch, bounded:

```python
if index % 1000 == 0:
    log.info("batch=%s progress=%d/%d last_id=%s elapsed=%.1fs", batch_id, index, total, record.id, time.monotonic() - t0)
```

Background tasks that must not fail silently:

```python
def _log_task_result(task: asyncio.Task) -> None:
    if task.cancelled():
        log.warning("background task %s was cancelled", task.get_name())
    elif task.exception() is not None:
        log.error("background task %s failed", task.get_name(), exc_info=task.exception())

task = asyncio.create_task(worker(), name="settlement-worker")
task.add_done_callback(_log_task_result)
```

## 5. Snippets: Node.js and TypeScript

Correlation across async boundaries:

```ts
import { AsyncLocalStorage } from "node:async_hooks";
import { randomUUID } from "node:crypto";

export const ctx = new AsyncLocalStorage<{ cid: string; start: number }>();

export function withCorrelation<T>(incoming: string | undefined, fn: () => Promise<T>): Promise<T> {
  return ctx.run({ cid: incoming ?? randomUUID().slice(0, 16), start: performance.now() }, fn);
}
export const cid = () => ctx.getStore()?.cid ?? "-";
```

Entry, exit and outcome:

```ts
export async function traced<T>(name: string, fn: () => Promise<T>): Promise<T> {
  const t0 = performance.now();
  console.error(JSON.stringify({ evt: "enter", fn: name, cid: cid() }));
  let outcome = "returned";
  try {
    return await fn();
  } catch (err) {
    const e = err as Error;
    outcome = e.name === "AbortError" ? "aborted" : `threw ${e.name}`;
    throw err;
  } finally {
    console.error(JSON.stringify({ evt: "exit", fn: name, cid: cid(), outcome, ms: Math.round(performance.now() - t0) }));
  }
}
```

Cancellation: record the reason at the abort, and read it where it lands.

```ts
const controller = new AbortController();
const timer = setTimeout(() => {
  console.error(JSON.stringify({ evt: "abort", cid: cid(), reason: "request_budget_expired", budgetMs }));
  controller.abort(new Error(`request budget ${budgetMs}ms expired`));
}, budgetMs);

try {
  await fetch(url, { signal: controller.signal });
} catch (err) {
  if (controller.signal.aborted) {
    console.error(JSON.stringify({ evt: "aborted", cid: cid(), at: "fetch payment", reason: String(controller.signal.reason) }));
  }
  throw err;
} finally {
  clearTimeout(timer);
}
```

Errors that would otherwise vanish:

```ts
process.on("unhandledRejection", (reason) => console.error(JSON.stringify({ evt: "unhandledRejection", reason: String(reason) })));
// and never: promise.catch(() => {})  without logging what was swallowed
```

Keep the cause when translating: `throw new PaymentUnavailable("gateway timeout", { cause: err });`

## 6. Snippets: Go

```go
type ctxKey struct{}

func WithCorrelation(ctx context.Context, id string) context.Context {
    return context.WithValue(ctx, ctxKey{}, id)
}
func CID(ctx context.Context) string {
    if v, ok := ctx.Value(ctxKey{}).(string); ok { return v }
    return "-"
}

// Entry/exit with outcome. Usage: defer traced(ctx, "ProcessPayment")(&err)
func traced(ctx context.Context, name string) func(*error) {
    start := time.Now()
    slog.InfoContext(ctx, "enter", "fn", name, "cid", CID(ctx))
    return func(errp *error) {
        outcome := "returned"
        if errp != nil && *errp != nil {
            switch {
            case errors.Is(*errp, context.Canceled):         outcome = "cancelled"
            case errors.Is(*errp, context.DeadlineExceeded): outcome = "deadline"
            default:                                         outcome = "error"
            }
        }
        slog.InfoContext(ctx, "exit", "fn", name, "cid", CID(ctx), "outcome", outcome,
            "elapsed_ms", time.Since(start).Milliseconds(), "ctx_cause", fmt.Sprint(context.Cause(ctx)))
    }
}
```

Record *why* a context was cancelled, so the receiver can report it (Go 1.20+):

```go
ctx, cancel := context.WithCancelCause(parent)
// ...
cancel(fmt.Errorf("request budget %s expired", budget))     // at the cancel site
// at the receiving site:
if ctx.Err() != nil { slog.Warn("cancelled", "cause", context.Cause(ctx)) }
```

Wrap, do not replace: `return fmt.Errorf("charge order %s: %w", id, err)`. Recover and report in goroutines you start: an unrecovered panic in a goroutine kills the process, and a goroutine that returns an error to nobody fails silently.

## 7. Snippets: Java and Kotlin

```java
// Correlation through SLF4J MDC. MDC is thread-local: copy it into executors.
MDC.put("cid", incomingId != null ? incomingId : UUID.randomUUID().toString().substring(0, 16));
try { chain.doFilter(req, res); } finally { MDC.clear(); }

// Carrying it across a thread pool:
Map<String, String> context = MDC.getCopyOfContextMap();
executor.submit(() -> {
    if (context != null) MDC.setContextMap(context);
    try { work(); } finally { MDC.clear(); }
});
```

```java
long t0 = System.nanoTime();
String outcome = "returned";
log.info("enter processPayment order={}", orderId);
try {
    return gateway.charge(order);
} catch (InterruptedException e) {
    outcome = "interrupted";
    Thread.currentThread().interrupt();        // restore the flag; never swallow interruption
    throw new PaymentInterrupted(e);
} catch (TimeoutException e) {
    outcome = "timeout";
    throw new PaymentUnavailable("gateway timeout", e);   // keep the cause
} catch (RuntimeException e) {
    outcome = "threw " + e.getClass().getSimpleName();
    throw e;
} finally {
    log.info("exit processPayment outcome={} elapsedMs={}", outcome, (System.nanoTime() - t0) / 1_000_000);
}
```

Kotlin coroutines: `CancellationException` must be rethrown. A `catch (e: Exception)` that does not rethrow it breaks structured cancellation. Use `withContext(NonCancellable)` for cleanup that must finish, and `MDCContext()` to carry MDC across suspension.

## 8. Instrumenting a process that cannot be restarted

When the process is still running and must not be restarted, the options are narrower. In rough order of preference:

1. **Raise log levels at runtime**, if the application supports it (an admin endpoint, a signal handler, a config watcher, JMX for the JVM, a logging config reload). This is the cheapest and safest: the statements already exist and were reviewed. Scope it to the suspect logger, and set a time to turn it back.
2. **Read what the runtime already exposes.** Thread dumps (`jstack`, `SIGQUIT` on the JVM, `SIGQUIT` or `pprof` endpoints in Go), task dumps where the application has an endpoint for them, `py-spy dump --pid` for Python stacks without modifying the process, database views of active queries and lock waits, connection-pool statistics endpoints. These are read-only snapshots and answer "what is it doing right now".
3. **Observe from outside.** Proxy and load-balancer logs, packet capture at the host, `strace`/`ltrace` on a single thread, eBPF tools for syscalls, network and off-CPU time in supported environments. These need privileges and review, and can have measurable overhead: get approval, bound the duration.
4. **Dynamic instrumentation**, where the platform provides it (JVM agents such as Byteman or BTrace, dynamic logging products, uprobes). Powerful, and the riskiest. Requires explicit sign-off from whoever owns the process.

What does not exist: a way to recover the history of an execution that has already finished and logged nothing. If the question is about the past execution and no artefact holds the answer, say so. The instrumentation serves the next occurrence.

TRACE's role here is to **propose**. The agent writes the plan, with exact commands and expected overhead. A human with authority over the process decides and runs anything that touches production.

## 9. Safety rules for anything that will run in production

1. **Reviewed and shipped normally.** B2 instrumentation is a code change. It goes through review and the normal release path. It is not hot-edited.
2. **Never changes behaviour.** No instrumentation in a position where its failure could fail the request. Wrap risky formatting. Never add awaits, locks or I/O on a hot path that did not have them.
3. **Never swallows.** A tracing wrapper re-raises everything it catches, cancellation above all.
4. **Bounded volume.** Per-request lines on a suspect path are fine. Per-record lines in a 40,000-record loop are not: use milestones, sampling, or a ring buffer dumped only on failure.
5. **No sensitive data.** Metadata only. Review each new log line for what it could print in the worst case.
6. **Guarded.** Behind a flag or a logger level so it can be turned off without a deploy.
7. **Labelled and dated.** Mark temporary instrumentation with the investigation id (`# TRACE BUG-007 temporary`) and state in the plan when it will be removed.
8. **Cheap on the happy path.** Use lazy formatting (`log.debug("x=%s", x)`, not f-strings) and level checks around anything expensive.
9. **Monotonic clocks for durations**, wall clocks for timestamps.
10. **Probes are not instrumentation.** `# TRACE-PROBE` print lines are for reproduction environments only and never ship.

## 10. The instrumentation plan document

Write `INV/instrumentation_plan.md`. The report links to it. Structure:

```markdown
# Instrumentation plan: BUG-007

## What we cannot yet decide
- H-02 vs H-04: who cancels the order task. H-02 says the API handler at its budget; H-04 says client disconnect.
- Path step 6 (cancel call) is inferred.

## Signals to add
| # | Signal type | Location | Captures | Serves | Volume | Flag |
|---|---|---|---|---|---|---|
| 1 | Cancellation propagation | app/api.py:15 | request id, elapsed, budget, reason | H-02 P4, H-04 P1 | 1 line per cancelled request | TRACE_CANCEL_LOG |
| 2 | Checkpoint | app/payment.py:22 | attempt number, remaining budget | H-02 P2 | 1 line per attempt | level DEBUG on `payment` |
| 3 | Correlation | app/api.py:10 and outbound client | cid on every line and as a header | all | none added | always on |

## Code
(the exact diffs or snippets, per signal)

## How each hypothesis will be decided on the next occurrence
- If signal 1 fires with reason=request_budget_expired at about 1.0s: H-02 confirmed, H-04 refuted.
- If the access log shows the client closed first and signal 1 does not fire: H-04.
- If neither: both refuted; return to step 4 with the new timeline.

## Cost and risk
Estimated added log volume, performance impact, data sensitivity review, rollback (flag off).

## Removal
Signals 1 and 2 are temporary: remove after the verdict, by <date or condition>. Signal 3 is permanent.

## Until then
Interim mitigation, if any, and its side effects.
```

The section "How each hypothesis will be decided" is mandatory. If you cannot write it, the instrumentation does not discriminate and should be redesigned.

## 11. After the next occurrence

1. Open the same investigation (or a new one that references it) and collect the new signals into the ledger.
2. Mark each prediction confirmed or refuted from them.
3. Re-run the duel if the rivals are still both alive, then verify and compute the verdict.
4. Remove the temporary signals. Keep the ones that would have shortened this investigation: correlation ids, cancellation reasons, outcome-on-exit. Record them in the report's fix section as permanent observability improvements.
5. Add a `recurring_pattern` entry to the knowledge base if the instrumentation gap itself is likely to recur elsewhere in the codebase.
