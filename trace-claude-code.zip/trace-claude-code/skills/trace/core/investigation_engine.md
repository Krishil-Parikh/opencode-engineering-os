# TRACE investigation engine

The mandatory ten-step sequence, with the entry gate, the work, the artefacts and the exit gate for every step. The orchestrator owns this document. Investigators own their briefs in `agents/`.

`<skill-dir>` means the directory that contains this skill's `SKILL.md`. All script paths below are relative to it. Run every command from the repository root so that evidence paths stay stable.

## Contents

1. The principle the engine enforces
2. Roles
3. Scaling: how much machinery an incident deserves
4. Mode A and Mode B
5. The ten steps
6. The state file and resuming
7. Budgets and stop conditions
8. Degraded operation (no subagents, no shell, no logs)
9. Failure modes of the engine itself

---

## 1. The principle the engine enforces

TRACE is an evidence-driven investigation system that happens to use agent debates. It is not a debate system.

A debate selects the most convincing explanation. An investigation selects the explanation best supported by reality. Every design choice below exists to keep those two from being confused:

- Nothing is concluded from a claim that has no entry in the evidence ledger.
- Search space is narrowed in stages (file, then function, then statement) by evidence, never by guessing where the bug "probably" is.
- A failure has three layers (where it surfaced, what triggered it, what made it possible) and a report that stops at the first layer is not a root-cause analysis.
- Hypotheses compete on recorded evidence, and a tool caps each score at what the ledger supports.
- The engine is allowed, and expected, to conclude "insufficient evidence". Producing a winner is not the goal. Being right is.
- What the losing lines of inquiry found is kept, with its verification status stated.

The guiding sentence: **Every error has an execution history. Every hypothesis needs evidence. Every conclusion must survive verification.**

## 2. Roles

| Role | Does | Never does |
|---|---|---|
| Orchestrator (the main agent running this skill) | Runs the ten steps, owns the ledgers, dispatches and briefs every other role, decides scale, writes the fix section and the report | Argues for a hypothesis. Scores a duel in which it has a stake. Lets an agent's summary into the ledger without a locator |
| Evidence collectors (phase 1) | Log analyst, stack-trace analyst, codebase mapper (with call graph), git-history investigator, telemetry investigator. They gather and grade evidence. They do not theorise beyond flagging leads | Propose a root cause |
| Investigators (phase 2) | Each takes one lens: execution path, exception propagation, async and concurrency, data and state, external dependencies, cancellation and timeouts. Each returns one or more hypotheses in the schema, plus secondary findings | See another investigator's hypothesis before submitting their own |
| Adversarial reviewer (phase 3) | Judges each duel. Attacks both submissions, assigns the five raw criterion scores, writes a rationale in terms of evidence ids | Rewards rhetoric. Scores a criterion without citing the evidence that earned it |
| Verifier (phase 4) | Independently re-derives the champion from the ledger alone, runs the outstanding predictions, tries to break it | Receives the investigators' narrative or the judge's rationale before forming its own view |
| Knowledge curator (steps 8 and 10) | Turns secondary findings into knowledge-base entries with honest status | Promotes anything to `confirmed` without FACT evidence and a named verifier |

Independence is structural, not a matter of asking agents to be fair. Investigators are briefed separately and do not see each other's work. The verifier is briefed from the ledger files, not from the conversation. On hosts where subagents are unavailable, the orchestrator plays the roles one at a time and writes each role's output to disk before starting the next (see section 8).

## 3. Scaling: how much machinery an incident deserves

Do not spend fifty agents on every bug. Pick the smallest tier that can answer the question, and escalate only when the evidence demands it.

| Tier | When | What runs |
|---|---|---|
| **T1: single-agent retrospective** | The stack trace and logs point at one place, the failing path is visible end to end, and one explanation accounts for everything observed | Steps 1 to 4 by the orchestrator alone. One hypothesis, its predictions checked, straight to step 7 (self-verification is not allowed: still brief a verifier, or on a no-subagent host run the verification checklist cold from the files). Steps 8 to 10 as usual |
| **T2: focused team** (default for anything non-trivial) | The failure surfaced far from any obvious cause, involves async, concurrency, cancellation, timeouts, retries, shared state or an external dependency, or two or more explanations are plausible | 2 to 3 evidence collectors in parallel, then 3 to 4 investigators chosen by the routing table below, tournament only between hypotheses that genuinely compete, verifier |
| **T3: full ARCE** | T2 ended narrow or insufficient, the incident is high severity, it recurs, or it spans services | All 5 collectors, all 6 investigators, full tournament, verifier, and a second verifier pass on a different lens if the first found gaps |
| **Expansion** | A specific open question remains that a new lens could answer | Add investigators one at a time, each with a single written question. Record in `context.json` why each was added |

Start with 6 to 8 specialised agents at most. Expand when the evidence warrants it. The skill cannot guarantee any particular number of simultaneous agents: spawning, concurrency limits and tool permissions belong to the host platform. When the host limits parallelism, run the same roles in sequence.

**Routing table: which investigators to dispatch**

| Signal in the evidence | Dispatch |
|---|---|
| `CancelledError`, `context canceled`, `AbortError`, `TaskCanceledException`, a timeout value appears anywhere on the path, shutdown messages near the failure | Cancellation and timeout analyst, async and concurrency analyst |
| Failure is intermittent, order-dependent, load-dependent, or disappears under a debugger | Async and concurrency analyst, data and state analyst |
| Wrong value, `None`/`null`/`undefined` where an object was expected, constraint violation, corrupted or partial record, failure on specific records only | Data and state analyst, execution-path analyst |
| An exception whose type or message was translated, wrapped, logged-and-swallowed, or whose stack is short or truncated | Exception-propagation analyst |
| Connection reset, DNS, TLS, 5xx from a peer, pool exhaustion, rate limit, a queue or a database in the trace | External-dependency analyst, cancellation and timeout analyst |
| The failure started at a point in time with no traffic change | Git-history investigator first, then whichever lens the diff points to |
| The same request path succeeds for other inputs at the same time | Data and state analyst, execution-path analyst |
| Nothing above, or the logs stop with no error at all | Execution-path analyst, exception-propagation analyst (swallowed errors), and plan Mode B |

The execution-path analyst is always included from T2 upward, because every other lens needs a reconstructed path to argue from.

## 4. Mode A and Mode B

The hardest constraint in real debugging: the failed execution is gone. The backend started at 9:00, a scheduled process ran at 9:15, a worker processed 40,000 records, a function failed at 9:47, and the process is still running. You cannot restart it and expect the same execution to happen again.

**Mode A: retrospective investigation.** Analyse what already happened, without executing the failed process again. Sources, in rough order of reliability for "what ran":

1. Distributed traces and spans, where they exist
2. Stack traces attached to the error
3. Application logs correlated by request, trace, task or job id
4. Worker, scheduler and database logs covering the same window
5. Existing debug statements and audit records
6. Metrics around the failure time
7. Git history: what code was running, what changed recently
8. Source code and static call graphs: what was possible

The objective is to reconstruct the execution path. Items 7 and 8 tell you what could have happened. Only items 1 to 6 tell you what did. Source-code analysis can reconstruct likely call paths, but it cannot recover runtime history that was never logged or traced. The ledger's grades (FACT, INFERENCE, ASSUMPTION) exist to keep that distinction visible in every sentence of the report.

**Mode B: instrumented investigation.** Entered when Mode A cannot discriminate between hypotheses, or cannot establish the path at all. There are two forms:

- **B1: reproduce and probe.** The failure can be reproduced somewhere safe (a test, a staging replay, a scratch copy fed with the failing input). Use hierarchical probes (`core/hierarchical_localization.md`) to narrow file, then function, then statement.
- **B2: instrument for the next occurrence.** The failure cannot be reproduced on demand. Identify exactly which additional signals would have settled the question, write them into `instrumentation_plan.md` (`core/instrumentation_playbook.md`), have them deployed, and end this investigation with a provisional or insufficient verdict that names what the instrumentation will show.

Mode B never means "restart production to see if it happens again". The decision table:

| Situation | Do |
|---|---|
| Ledger already has an observed path and one hypothesis clears the thresholds | Stay in Mode A through verification |
| Two hypotheses are within the minimum margin | Find the cheapest observation they disagree about. If logs can supply it, Mode A. If not, B1 if reproducible, else B2 |
| The path has an unobserved gap exactly where the hypotheses differ | Same as above |
| There is no error line at all, only an absence (a job that silently stopped) | B2 almost always: silent stops are an instrumentation deficit |
| Reproduction is possible but only against production data or services | Treat as not reproducible. B2 |

## 5. The ten steps

Each step has an **exit gate**. Do not start the next step until the gate holds. If a gate cannot be met, say so in `error_context.md` under Open questions and carry the gap forward explicitly: it will cap the final confidence.

### Step 1. Receive

*Identify the exception, the error message, the timestamp and the affected service.*

1. Create the workspace and the investigation:
   ```
   python3 <skill-dir>/scripts/workspace.py new --title "<short title>" --error "<exception type or message>" --when "<first observed>" --service "<service>" --mode A
   ```
   It prints the investigation directory, for example `debugging/investigations/BUG-007`. Call it `INV` below.
2. Fill in `INV/error_context.md`. Paste the error exactly as received, unedited. Record what is unknown as `unknown`.
3. Establish the constraints by asking the user if they were not stated: may the process be restarted, may instrumentation be added, can it be reproduced elsewhere, is there sensitive data in the logs, what is the time or token budget. Record them with `workspace.py set --inv INV constraints.may_restart=no ...`.
4. Ask the knowledge base what is already known:
   ```
   python3 <skill-dir>/scripts/kb.py search --text "<exception type>"
   ```
5. Choose the tier (section 3) and write the choice and its reason into `error_context.md`.

**Exit gate.** You can state in one sentence what failed, when, and in which process, and you know whether the process may be touched. If the timestamp is unknown, finding it is the first task of step 2.

**Typical mistakes.** Paraphrasing the error instead of pasting it. Assuming the first error in the paste is the first error in time. Treating the reporter's theory ("the DB is down again") as a fact: record it as `testimony`, grade ASSUMPTION.

### Step 2. Collect

*Gather relevant logs, stack traces, source files and available traces.*

Dispatch the evidence collectors the tier calls for, in parallel where the host allows. Each gets its brief from `agents/`, the investigation directory, and the list of evidence sources from `error_context.md`. Their tools:

```
python3 <skill-dir>/scripts/log_parser.py <logs...> --around "<time>" --window 120 --format text
python3 <skill-dir>/scripts/log_parser.py <logs...> --corr <request-or-trace-id> --out INV/timeline.json
python3 <skill-dir>/scripts/stacktrace_parser.py <file-with-trace> --root . --format text
python3 <skill-dir>/scripts/git_suspects.py --root . recent --files <files on the path> --before "<failure time>"
```

Every observation that matters goes into the ledger through the tool, which reads the excerpt from disk itself:

```
python3 <skill-dir>/scripts/evidence_collector.py add --inv INV --class log --grade FACT \
    --file logs/app.log --lines 412-413 --timestamp "09:47:04" --by log-analyst \
    --summary "process_payment started 1s before the CancelledError"
```

Rules for this step are in `core/evidence_protocol.md`. The two that matter most here:

- **Find the correlation key first.** A request id, trace id, task name, job id, order id. Filter by it before reading anything. A timeline of one request among forty thousand is useless unless it is that request's timeline.
- **Record coverage.** For each source note whether it covers the failure time at all. A log that was rotated at 09:30 says nothing about 09:47, and its silence is not evidence.

**Exit gate.** The ledger contains: the failure event itself, the last few events before it on the same correlation key, the full stack trace if one exists, and a note of which sources were unavailable. `INV/timeline.json` exists.

### Step 3. Map

*Identify the functions, dependencies and possible execution paths.*

The codebase mapper builds the static picture around the Layer 1 location:

```
python3 <skill-dir>/scripts/call_graph.py index --root . --out INV/callgraph.json
python3 <skill-dir>/scripts/call_graph.py enclosing <file> <line> --graph INV/callgraph.json
python3 <skill-dir>/scripts/call_graph.py callers <function> --depth 4 --graph INV/callgraph.json
python3 <skill-dir>/scripts/call_graph.py paths <entry-point> <failing-function> --graph INV/callgraph.json
python3 <skill-dir>/scripts/call_graph.py hotspots --graph INV/callgraph.json
```

Then overlay the timeline on the map (`core/execution_reconstruction.md`): for each step on the candidate path, is there a log line, span or stack frame showing it ran? Mark each step `observed` or `inferred`. Note every place where control can arrive from outside the visible path: timers, schedulers, signal handlers, cancellation, callbacks, queue consumers, other threads and tasks touching the same state, middleware, decorators.

Record source facts as `class=source` FACTs with exact line ranges. Record "this function can call that one" as INFERENCE unless a runtime artefact shows it did.

**Exit gate.** You have a written candidate path from an entry point to the failure location, with each step marked observed or inferred, and a list of external influences on that path. The three layers are filled in as far as known: Layer 1 should now be a `file:line`. Layers 2 and 3 are usually still open.

### Step 4. Hypothesize

*Generate independent explanations for the failure.*

At T1 the orchestrator writes the hypothesis. From T2 upward, hypotheses come from the investigators in step 5, and step 4 is where the orchestrator prepares the ground:

1. Write the **investigation brief**: a neutral summary of the ledger (facts only, with ids), the candidate path with its observed and inferred marks, and the open questions. No theory, no adjectives. Save it as `INV/brief.md`. Every investigator receives exactly this.
2. Choose the investigators from the routing table.
3. Check the knowledge base for the files on the path, and attach the result to the brief with statuses intact:
   ```
   python3 <skill-dir>/scripts/kb.py brief --files <comma-separated files>
   ```

A hypothesis is only admissible if it is written in the schema (`schemas/hypothesis.schema.json`) with all three layers, an execution path, at least one prediction with a concrete check, and at least one falsifier. "Something is wrong with the cache" is a topic, not a hypothesis.

**Exit gate.** `INV/brief.md` exists and contains no claim without an evidence id.

### Step 5. Investigate

*Have specialised agents inspect different possible causes.*

Dispatch the chosen investigators in parallel, each with: its brief from `agents/`, `INV/brief.md`, read access to the repository and logs, and the instruction to return hypotheses as JSON in the schema plus any secondary findings. Each investigator works alone. Do not pass one investigator's output to another at this stage.

When they return:

1. For each new piece of evidence an investigator cites, add it to the ledger yourself with `evidence_collector.py add` (the tool re-reads the file, which catches misquotes and invented line numbers). If the excerpt on disk does not say what the investigator claimed, the evidence is rejected and the investigator is told.
2. Register each hypothesis: `evidence_collector.py add-hypothesis --inv INV --json <file>`.
3. Register secondary findings: `evidence_collector.py add-finding --inv INV --json <file>`.
4. **Merge duplicates.** Two hypotheses with the same Layer 3 root cause are one hypothesis: `score.py merge --from H-03 --into H-02 ...`. Two hypotheses with the same Layer 1 and different Layer 3 are rivals, not duplicates.
5. **Check cheap predictions now.** If a prediction can be tested from logs already collected, test it and record the result with `evidence_collector.py set-prediction`. A hypothesis refuted here never needs a duel.

**Exit gate.** Every surviving hypothesis is in `hypotheses.json`, validates, and has at least one FACT in `evidence_for`. `evidence_collector.py validate --inv INV` passes.

### Step 6. Compete

*Conduct evidence-based adversarial challenges.*

Full rules in `core/tournament_protocol.md` and `core/hypothesis_scoring.md`. In outline:

1. Skip the tournament if only one hypothesis survives step 5. Go to step 7. A tournament is for genuinely competing hypotheses.
2. Otherwise run king-of-the-hill duels: A against B, the winner against C, then against D. Order the bracket so that the two hypotheses that disagree about the most checkable fact meet first.
3. For each duel, each side's owner reads the rival's submission and updates items 5 and 6 of its own (why the rival is less likely, with evidence, and what would disprove itself). The adversarial reviewer then cross-examines both and assigns raw scores.
4. Record the duel. The tool applies caps and penalties and decides the outcome:
   ```
   python3 <skill-dir>/scripts/score.py duel --inv INV --a H-01 --b H-02 \
       --scores-a log=3,source=1,path=2,alternatives=2,verification=1 \
       --scores-b log=4,source=4,path=3,alternatives=3,verification=2 \
       --judge adversarial-reviewer --rationale "<evidence ids, not style>"
   ```
5. A **narrow** outcome (margin under the minimum) eliminates nobody. The judge must name the evidence that would separate the two, and the orchestrator goes and gets it: from existing logs if possible, otherwise Mode B.
6. Losers' findings are retained. `score.py` records which findings travelled with each eliminated hypothesis.

**Exit gate.** One hypothesis holds `champion`, or the tournament has ended with a narrow pair or with everything eliminated. All three are legitimate outcomes.

### Step 7. Verify

*Independently check the strongest hypothesis.*

Full rules in `core/root_cause_verification.md`. Brief the verifier with the ledger files and the champion's id only. It must:

1. Re-derive the execution path from the evidence without reading the investigator's reasoning.
2. Run every untested prediction it can, recording each result with `set-prediction`.
3. Attempt the falsifiers.
4. Look for a simpler explanation and for evidence the champion ignores.
5. Run `evidence_collector.py recheck --inv INV` so that stale quotes are caught.
6. Return `pass`, `partial` or `fail` with reasons.

Then re-score the champion on the post-verification ledger and compute the verdict:

```
python3 <skill-dir>/scripts/score.py score --inv INV --id H-02 --scores ... --judge verifier --rationale "..."
python3 <skill-dir>/scripts/score.py verdict --inv INV --verification pass --verifier verifier --notes "..."
```

If verification fails, the champion is refuted. Take what refuted it back to step 4 as new evidence. Do not promote the runner-up without verifying it in turn.

**Exit gate.** `tournament.json` has a `final` block with one of CONFIRMED, PROBABLE, PROVISIONAL, INSUFFICIENT_EVIDENCE.

### Step 8. Preserve

*Save every meaningful secondary finding.*

Go through every investigator's output, every eliminated hypothesis, and the hotspot list from step 3. Anything that looked wrong, whether or not it relates to this bug, becomes a finding with all required fields: file and line, description, evidence, severity, confidence, whether it was verified, whether it relates to the original bug. Status must be honest:

- `confirmed`: verified with FACT evidence by someone other than its discoverer
- `suspicious`: evidence points that way, verification incomplete
- `unverified`: noticed, not checked
- `disproven`: checked and found not to be a problem

**Exit gate.** `findings.json` holds every finding and validates. Nothing is `confirmed` without `verified: true`, evidence and `verified_by`.

### Step 9. Report

*Produce an actionable root-cause analysis.*

1. Write the recommended fix into a file (for example `INV/fix.md`). Address the Layer 3 root cause first, then the Layer 2 trigger if it can be made harmless, then the observability gap that made the investigation hard. Each item names files and lines. If the verdict is PROVISIONAL or INSUFFICIENT, write mitigations and the instrumentation plan instead, and say so.
2. Generate the report:
   ```
   python3 <skill-dir>/scripts/evidence_collector.py validate --inv INV
   python3 <skill-dir>/scripts/report_generator.py --inv INV --fix-file INV/fix.md
   ```
3. Read the generated `final_report.md` once as the person who has to act on it. If a sentence in your own summary to the user is stronger than the report's confidence level, weaken the sentence.

The report has eight sections: root cause, failure location, originating trigger, execution path, evidence, other discovered issues, recommended fix, confidence. The template with guidance is `reports/investigation_template.md`.

**Exit gate.** The report exists, the validator passes, and the summary you give the user states the confidence level in its first two sentences.

### Step 10. Learn

*Add verified patterns to the persistent knowledge base.*

```
python3 <skill-dir>/scripts/kb.py import --inv INV
python3 <skill-dir>/scripts/kb.py record-hypotheses --inv INV
python3 <skill-dir>/scripts/workspace.py set --inv INV step=10-learn
```

`import` deduplicates against existing entries and never upgrades a status on re-observation alone. `record-hypotheses` stores eliminated explanations with their scope so they are not blindly re-chased, and not blindly dismissed either. If this investigation verified or disproved an older knowledge-base entry, change its status explicitly:

```
python3 <skill-dir>/scripts/kb.py promote --id KB-004 --status confirmed --evidence "BUG-007:E-012" --by verifier --note "<how it was checked>"
```

Finally, if probes were used anywhere: `python3 <skill-dir>/scripts/probe.py status --manifest <manifest>` must report zero files still probed.

**Exit gate.** `debugging/index.md` lists the investigation with its confidence, and no probe remains in any source file.

## 6. The state file and resuming

`INV/context.json` carries `step`, `status`, `mode`, `constraints` and `confidence`. Update `step` as you pass each gate (`workspace.py set --inv INV step=5-investigate`). An interrupted investigation is resumed by running `workspace.py status --inv INV`, reading `error_context.md` and `brief.md`, and continuing from the recorded step. Everything a fresh agent needs is on disk by design: the ledgers are the investigation, the conversation is not.

## 7. Budgets and stop conditions

Stop and report with the current verdict when any of these holds:

- The champion is verified and the thresholds are met.
- Two consecutive rounds of new evidence have not moved any hypothesis's total by more than a few points. More agents will not help. Go to Mode B.
- Every remaining open question needs data that does not exist yet. Write the instrumentation plan and close as PROVISIONAL or INSUFFICIENT.
- The user's budget is reached. Report what is established, what is not, and the single most valuable next observation.

Never stop because a plausible story exists. Plausibility is where investigations go wrong.

## 8. Degraded operation

**No subagents.** Play each role in sequence yourself. Before each role, re-read only that role's brief and the files it would be given. Write the role's output to disk before starting the next. For the investigators, write each hypothesis to a file before thinking about the next lens, and do not revise earlier ones in light of later ones. For the verifier, start from the ledger files with the conversation's reasoning set aside: follow the checklist in `core/root_cause_verification.md` literally. State in the report that roles were not independently executed, and cap the verdict at PROBABLE unless a prediction was confirmed by an actual run.

**No shell.** The scripts cannot run. Keep the same files by hand in the same formats. Quote evidence with `file:line` and verbatim text, compute scores from the rubric by hand and show the arithmetic, and apply the caps yourself, strictly. State in the report that the ledger was maintained manually.

**No logs, or logs that do not cover the failure.** Mode A can still establish what was possible. It cannot establish what happened. Say so, go to Mode B2, and report INSUFFICIENT_EVIDENCE with the instrumentation plan as the deliverable. That is a successful TRACE run.

**No repository access to part of the system** (a third-party service, a closed library). Treat its behaviour as testimony unless a response, status page capture or packet-level artefact is in the ledger.

## 9. Failure modes of the engine itself

Watch for these in your own conduct. Each has cost real investigations.

| Failure mode | What it looks like | Guard |
|---|---|---|
| Anchoring on Layer 1 | "The error is in `payment.py:142`, so the bug is in `payment.py`" | The three-layer discipline. Layer 1 is a location, not a cause |
| Narrative before evidence | The brief already reads like an explanation | The brief may contain only ledger facts with ids |
| Persuasion winning | The best-written hypothesis advances | Scores are capped by the ledger, and the judge must cite ids per criterion |
| Convergence by contamination | All investigators propose the same thing because they saw the same summary with a theory in it | Neutral brief, isolated investigators |
| Absence read as presence | "There is no log of X, so X did not happen" | Absence evidence requires a stated search scope and established coverage |
| Static path read as runtime path | "A calls B calls C" presented as what happened | `observed: false` on every step with no runtime artefact, and the path cap in scoring |
| Forced winner | A root cause is named because the format has a slot for one | INSUFFICIENT_EVIDENCE is a first-class verdict |
| Verification by the author | The agent that proposed the hypothesis also confirms it | The verifier is a separate role briefed from files |
| Lost findings | A leak spotted in passing never reaches anyone | Step 8 is mandatory and has its own gate |
| Fact laundering | A suspicion from an old investigation is cited as known | Knowledge-base status travels with every entry, and only `confirmed` may be cited as fact |
| Probes left behind | Print statements shipped | The manifest, the marker, and the step 10 gate |
