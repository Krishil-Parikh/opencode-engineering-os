# Root-cause verification

Phase 4. An independent verifier checks the surviving hypothesis against source code, logs, execution paths and alternative explanations, and tries to break it. Every conclusion must survive verification.

## Contents

1. Why verification is separate from the tournament
2. Independence: what the verifier gets and does not get
3. The verification checklist
4. Testing predictions
5. Reproduction and the counterfactual
6. Looking for what the tournament missed
7. Results: pass, partial, fail
8. After a failed verification
9. Verifying the fix
10. Verifying findings
11. The verifier's report

---

## 1. Why verification is separate from the tournament

The tournament finds the best of the hypotheses that were proposed. It cannot tell you whether the best one is true. All the entrants can be wrong, and the scoring compares them to each other and to the ledger, not to the world.

Verification asks a different question: taking this one hypothesis on its own, does it hold up when someone with no stake in it tries to knock it down? The method is to derive what else must be true if it is true, and go and look.

## 2. Independence

The verifier is briefed from files:

**Given**

- `INV/context.json`, `INV/error_context.md`
- `INV/evidence.json` (the full ledger)
- `INV/hypotheses.json` (all hypotheses, including eliminated ones, as structured data)
- The id of the champion
- Read access to the repository and logs, and the scripts

**Not given**

- The investigators' prose reasoning or transcripts
- The duel exchanges and the judge's rationales
- The orchestrator's opinion of the champion
- Any statement of the form "we think it is X, please confirm"

The brief is: "Hypothesis H-02 claims the following. Determine whether the evidence supports it. Try to refute it." A verifier asked to confirm will confirm.

The verifier must be a different agent from the champion's author and from the judge. On a host without subagents the orchestrator follows the checklist below from the files, in order, writing each answer down before moving on, and the verdict is capped at PROBABLE unless at least one prediction was confirmed by an actual run during verification.

## 3. The verification checklist

Work through all of it. Record each answer in `INV/verification.md`.

**A. Is the ledger sound?**

1. Run `evidence_collector.py recheck --inv INV`. Any stale FACT supporting the champion must be re-collected or dropped.
2. For each item in the champion's `evidence_for`: open it. Does the excerpt show what the summary says, no more? Is the grade right (apply the tests in `core/evidence_protocol.md`, section 2)? Regrade anything overstated and note it.
3. For each runtime item: is it tied to the failing execution by a correlation key?
4. For each source item: is the code that was read the code that was running? Check the deployed version if it can be checked. If not, record the assumption.

**B. Does the path hold?**

5. Without reading the champion's `execution_path`, reconstruct the path yourself from the ledger: timeline, stack trace, call graph. Then compare. Differences are findings.
6. For each inferred step: what other route was possible between the observed points on either side? Is there evidence excluding it?
7. Check the arithmetic of time. Every duration the mechanism requires, against the timestamps. Every timeout and budget the hypothesis invokes, against configuration.
8. Is there any event in the execution's timeline, or in the context window around the failure, that the hypothesis does not account for?

**C. Are the three layers right?**

9. Layer 1: does the stated location match the stack trace's failure frame or the stage-3 result?
10. Layer 2: is there a FACT showing the trigger condition present for the failing execution, and a FACT showing it absent for a healthy one?
11. Layer 3: is it a standing property of the system? With it fixed and the same trigger applied, would the failure be impossible? If the honest answer is "less likely", the root cause is incomplete.

**D. Do the predictions hold?**

12. Test every `untested` prediction that can be tested (section 4). Record each with `set-prediction`.
13. Derive at least one prediction the author did not list. A good source: "if this is the cause, what else should have gone wrong at the same time, or on other executions?" Test it.
14. Attempt each falsifier: actively look for the evidence the author said would disprove the hypothesis.

**E. Is something simpler true?**

15. For this failure type, list the standard alternatives (`core/failure_signatures.md`). Was each either proposed and eliminated with evidence, or can you exclude it now? An unexamined standard alternative caps the result at `partial`.
16. Re-read each eliminated hypothesis's statement. Was it eliminated for a reason that still stands on the current ledger? If evidence added later undermines the reason, say so: it should be reinstated.
17. Could the champion be a consequence of a deeper cause, or one of two causes that are both needed? (Two defects that are each harmless alone are common. If removing the champion's cause would not have prevented the incident alone, the root cause is a conjunction and must be stated as one.)

**F. Does it explain the pattern, not just the instance?**

18. First occurrence: when did this failure signature first appear? Does the hypothesis explain why then?
19. Frequency: how often does it occur, and does the hypothesis predict that rate from how often the trigger occurs?
20. Scope: which executions fail and which do not. Does the hypothesis draw the same line?

A hypothesis that explains one execution perfectly and cannot explain why the other failures happened, or why the successes succeeded, is not yet the root cause.

## 4. Testing predictions

A prediction is a statement of the form "if the hypothesis is true, then X is observable by doing Y". Test in order of cost:

| Method | Cost | Strength | Use for |
|---|---|---|---|
| Existing logs, read again with a specific question | Lowest | Strong when correlated | Timing predictions, "this event precedes that one", "other executions with the same condition also failed" |
| Configuration and code, read | Low | Establishes possibility and consistency | "The timeout is X", "there is no handler for Y" |
| Other executions as natural experiments | Low | Strong | "Every request slower than 1.0s failed, and none faster did" |
| A read-only command against the running system | Low to medium | Strong for present state | Pool statistics, active locks, queue depth, effective configuration |
| An isolated experiment (a script, a unit test, a scratch copy with one value changed) | Medium | Strong, and it can be re-run | Mechanism predictions, counterfactuals |
| Hierarchical probes on a reproduction | Medium | Decisive for location | "The cancellation arrives during attempt 2" |
| Instrumentation for the next occurrence | High, and slow | Decisive | Whatever nothing above can reach |

Rules:

- Decide what result would confirm and what would refute **before** running the check, and write both down. A check with no refuting outcome is not a test.
- Run it. Capture the exact command and the exact output.
- Add the output to the ledger as `class=runtime` (or `log`, `source`, as appropriate), grade FACT.
- Record the result: `evidence_collector.py set-prediction --inv INV --id H-02 --prediction P2 --status confirmed --evidence E-014 --by verifier`. The tool requires FACT-grade evidence for `confirmed` and `refuted`.
- If a check cannot be run, the status stays `untested` with the reason in `notes`, or becomes `untestable` if it never could be. Untested predictions cap the verification score and the confidence level.
- A confirmation that a rival would also have predicted is weak. Say so in the notes.
- Do not run anything that changes production state, restarts a service, or exposes data. Experiments happen in scratch copies and test environments.

## 5. Reproduction and the counterfactual

Reproduction is the strongest verification, and the counterfactual is the strongest form of it:

1. **Reproduce.** Under the claimed trigger, with the claimed defect present, the failure occurs. This shows the mechanism is sufficient.
2. **Counterfactual.** Under the same trigger, with the claimed defect removed (and nothing else changed), the failure does not occur. This shows the mechanism is necessary.

Both are needed. A reproduction alone can be reproducing a different bug with the same symptom.

Practical forms:

- A script that sets up the trigger and runs the one path (the sample incident's `verify_p3.py` changes a single configuration value in-process and re-runs the failing request).
- A unit or integration test that fails before the fix and passes after. This also becomes the regression test.
- A scratch copy of the affected module with the one-line change, run against the failing input.
- For timing-dependent failures: make the timing deterministic (inject the delay, mock the clock, pause at the await) so the reproduction does not depend on luck.

Keep the reproduction in the investigation directory. It is evidence, and it is the fix's acceptance test.

When reproduction is impossible, say so, say why, and rely on predictions from existing data. The confidence ceiling is then PROBABLE in most cases, and the instrumentation plan becomes part of the deliverable.

**Intermittent failures.** One failed attempt to reproduce proves nothing, and neither does one successful run after a fix. State how many runs were made and the observed rate before and after. If the failure occurred in 3 of 50 runs before and 0 of 50 after, say exactly that. The probability of seeing 0 of 50 by chance at the old rate is about 4.5%: suggestive, not conclusive. Run more.

## 6. Looking for what the tournament missed

The verifier is the last line against shared blind spots: every investigator had the same brief and, usually, the same underlying model.

- **Question the brief.** Is there a fact everyone took as given that is actually an assumption? (The time zone of the timestamps. Which host served the request. Which version was deployed. That the pasted error was the first error.)
- **Look upstream of the entry point.** Investigations start where the logs start. The cause may be before that: the client, the load balancer, the scheduler, the message producer.
- **Look at the neighbours.** What else failed, slowed or logged warnings in the same window, on unrelated executions? A process-wide cause looks like a local one from inside a single execution.
- **Look for the second defect.** A trigger meeting a defect usually also exposes a weakness in error handling. The incident's *impact* (a 500, a leak, corrupted state) often has its own root cause distinct from the failure's.
- **Ask what the fix would not fix.** If the recommended fix were applied, list the ways the same symptom could still occur.

## 7. Results

| Result | Meaning | Conditions |
|---|---|---|
| **pass** | The hypothesis survived a serious attempt to refute it | Ledger sound. Path independently re-derived and matching. All predictions tested and confirmed (or genuinely untestable, with reasons). At least one confirmation is discriminating. Falsifiers sought and not found. Standard alternatives excluded |
| **partial** | Nothing contradicts it, and something is missing | Some predictions untested, or an inferred step that matters is still unobserved, or a standard alternative is unexamined, or the deployed version is unconfirmed, or roles were not independent |
| **fail** | The hypothesis is wrong as stated | A prediction refuted. Or a contradicting FACT it cannot explain. Or the path does not hold. Or a simpler explanation fits the evidence at least as well |

Then:

```
python3 <skill-dir>/scripts/score.py score --inv INV --id <champion> --scores ... --judge verifier --rationale "..."
python3 <skill-dir>/scripts/score.py verdict --inv INV --verification pass|partial|fail --verifier <name> --notes "<one or two sentences>"
```

`verdict` combines the result with the post-verification score and the lead over the best rival (`core/hypothesis_scoring.md`, section 7).

The verifier may also return: "the hypothesis is not refuted, and the evidence is insufficient to establish it". That is `partial` with a recommendation of INSUFFICIENT or PROVISIONAL, and it is often the correct answer.

## 8. After a failed verification

A failed verification is the process working.

1. Record the refuting evidence in the ledger, linked `--contradicts` the champion. The champion's status becomes `refuted`.
2. Do **not** promote the runner-up. It lost to a hypothesis that has now been shown wrong, on scores that may have been distorted by the same error. It must be re-scored on the current ledger and verified in its own right.
3. Ask what the refutation teaches. A refuted prediction is the most informative evidence in the investigation: it says the world is different from what a well-supported story expected. Write that down as a fact in the brief.
4. Return to step 4 with the updated brief. Prefer one or two fresh investigators who see only the ledger.
5. If two cycles of hypothesise, compete and verify have failed, the missing ingredient is evidence. Go to Mode B and close as INSUFFICIENT_EVIDENCE with the instrumentation plan.

## 9. Verifying the fix

The report's recommended fix is itself a claim. Before recommending it:

- Does it address Layer 3, or only this trigger? A fix that makes this one input work, or lengthens one timeout until the failure becomes rare, has moved the problem.
- Does the counterfactual experiment correspond to the fix? Ideally the fix is the change that was tested.
- What does the fix change for the healthy path? Longer budgets mean slower failures. New locks mean new contention and possibly new deadlocks. Retries mean more load on a struggling dependency.
- Does the system now fail in a designed way when the trigger recurs? A root-cause fix for a timeout mismatch should leave a clear, handled timeout, not silence.
- Is there a regression test, and does it fail without the fix?
- What should be monitored after deployment to know it worked? State the signal and the expected change.

If the verdict is PROVISIONAL or INSUFFICIENT, the fix section contains mitigations and instrumentation, labelled as such. Recommending a confident code change on a provisional root cause is how a wrong diagnosis becomes a second incident.

## 10. Verifying findings

Secondary findings get the same discipline at a lower cost. For each finding that someone proposes to mark `confirmed`:

- It has FACT-grade evidence of the defect itself (not only of code that looks risky).
- Someone other than its discoverer checked it.
- `verified_by` is filled.

Everything else is `suspicious` (evidence points that way, unverified) or `unverified` (noticed only), each with a `suggested_check` so that a later investigation can settle it in minutes. An unverified finding must never silently become an established fact: the tools refuse `confirmed` without verification, and the knowledge base keeps the status visible wherever the finding is shown.

Where a quick check exists, the verifier should run it. In the sample incident, the connection leak found by the losing database hypothesis was confirmed by one log line (`pool status in_use=1` after all requests had finished) and one source read (cleanup only in `except Exception`, no `finally`).

## 11. The verifier's report

`INV/verification.md`:

```markdown
# Verification of H-02 (BUG-007)

Verifier: <agent>   Independent of author and judge: yes | no (explain)

## Result: pass | partial | fail

## Ledger
- recheck: 11 match, 0 stale
- Regraded: E-007 FACT -> INFERENCE (arithmetic over E-006)
- Deployed version: confirmed <how> | not confirmed (assumption)

## Path
- Independently reconstructed: matches the submission except <...>
- Inferred steps still unobserved: step 6 (cancel call)

## Layers
- L1 matches failure frame (E-004)
- L2: present for req-b2 (E-002), absent for req-c3 (E-013)
- L3: standing property (config values, E-006); counterfactual run (E-015)

## Predictions
| | Result | Evidence | Discriminating? |
|---|---|---|---|
| P1 | confirmed | E-001, E-003 | yes: H-01 does not predict a fixed 1.0s |
| P2 | confirmed | E-014 | yes |
| P3 | confirmed | E-015 | yes: counterfactual |
| V1 (added by verifier) | ... | ... | ... |

## Falsifiers sought
- <each one, what was looked for, what was found>

## Alternatives
- Client disconnect: excluded, <evidence>
- Shutdown: excluded, other requests completed normally after (E-013)
- Inner timeout: excluded, trace passes through wait_for but exception is CancelledError not TimeoutError, and 0.3s into a 0.6s attempt

## What this does not explain
- <anything left over>

## Recommended confidence and why
```

Short is fine. Every line should point at an evidence id or say plainly that there is none.
