# Evidence protocol

How TRACE separates proven facts from hypotheses, and how every agent must collect, grade, cite and exchange evidence.

## Contents

1. The rule
2. Grades: FACT, INFERENCE, ASSUMPTION
3. Evidence classes and what each can prove
4. The ledger and its only writer
5. Collecting evidence: procedure
6. Absence evidence
7. Correlation: tying evidence to the failing execution
8. Citing evidence
9. Exchanging evidence between agents
10. Contradicting evidence
11. Staleness and re-checking
12. Sensitive data
13. Common grading mistakes

---

## 1. The rule

**No claim without a ledger id. No ledger entry without a locator. No conclusion resting on anything weaker than a FACT.**

Source-code analysis can reconstruct likely call paths. It cannot recover runtime execution history that was never logged or traced. TRACE therefore tags every piece of information with how it is known, and carries that tag all the way into the final report.

## 2. Grades

| Grade | Meaning | Required | May support |
|---|---|---|---|
| **FACT** | Directly observed, and anyone can observe it again | A locator (file and line range, or the exact command that was run, or a URL) and a verbatim excerpt | Anything |
| **INFERENCE** | Derived from other ledger items by a stated reasoning step | `derived_from` ids and the `reasoning` in one or two sentences | A hypothesis, alongside FACTs. Never the sole support for a conclusion |
| **ASSUMPTION** | Believed but not checked | Nothing, but it must be labelled | Nothing. It may be listed in a hypothesis's `assumptions` so the verifier knows what to test |

Tests to apply when grading:

- *Could a sceptical colleague open something and see this for themselves in under a minute?* If yes, FACT. If they would have to follow your argument, INFERENCE.
- *Does the statement contain "because", "so", "therefore", "must have", "probably", "would"?* Then at most INFERENCE, however obvious it feels.
- *Is it about what the code does when run, based only on reading it?* INFERENCE. The FACT is what the code says ("line 23 calls `wait_for` with `timeout=config.PAYMENT_ATTEMPT_TIMEOUT_S`"). What happens at runtime is a prediction.
- *Did someone tell you?* `class=testimony`, grade ASSUMPTION until corroborated.

An INFERENCE is only as strong as the weakest item it derives from. An inference built on an assumption is an assumption.

## 3. Evidence classes and what each can prove

| Class | Typical items | Can establish | Cannot establish |
|---|---|---|---|
| `log` | Application, worker, scheduler, proxy, database log lines | That a specific line of code ran at a specific time with specific values | That something not logged did not happen. Exact ordering across hosts with unsynchronised clocks |
| `stacktrace` | Frames of an exception trace or thread dump | The call stack at the moment the exception was raised, with exact lines | How control got to the top frame's caller before that. Anything about other tasks |
| `telemetry` | Trace spans, metrics, profiler output, eBPF captures | Timing, parent and child relationships between operations, resource levels | Application-level meaning (why a span was slow) |
| `runtime` | Output of a command or probe run during the investigation | Present-day behaviour of the code or system under the stated conditions | That the original incident had the same conditions |
| `source` | Code read from the repository | What the code says, and so what is possible | What actually executed. Which version was deployed (check that separately) |
| `git` | Commits, diffs, blame | What changed, when, by whom | That the change was deployed at the failure time. That it caused anything |
| `config` | Configuration files, environment values, feature flags | The configured value in the place you read it | The value in effect in the failing process (overrides, stale processes, per-environment files) |
| `absence` | A search that found nothing | That the thing is not in the searched scope | Anything outside that scope (see section 6) |
| `knowledge_base` | A prior TRACE finding | Whatever its status says, and no more. `confirmed` entries are facts. Others are leads | - |
| `testimony` | What a person reported | That it was reported | That it is true |

Two checks that are easy to forget and often decisive:

- **Deployed version.** Before citing `source` as what ran, establish which commit was running: a build id in a startup log line, an image tag, a version endpoint. Record it. If you cannot, say that source evidence refers to the checked-out revision and add the assumption.
- **Effective configuration.** A value in a config file is not necessarily the value in the process. Prefer a startup log line that printed the effective setting, or a runtime read.

## 4. The ledger and its only writer

Evidence lives in `INV/evidence.json`. The only writer is `scripts/evidence_collector.py`. That constraint is what makes the ledger worth trusting:

- For file-backed items the tool **reads the excerpt from disk itself**. An agent supplies the file and line range. It cannot supply a paraphrase, a tidied-up version, or lines that do not exist. If an `--excerpt` is passed as well, it must match the file exactly or the item is rejected.
- Every excerpt is hashed. `recheck` re-reads each file-backed FACT and reports any that no longer match.
- The grade rules are enforced: a FACT without a locator and excerpt is rejected, an INFERENCE without `derived_from` and `reasoning` is rejected, absence evidence without a search scope is rejected.
- Links to hypotheses are validated against `hypotheses.json`, and hypotheses cannot cite evidence ids that do not exist.

Subagents usually do not write to the ledger directly. They return proposed evidence (file, line range, one-sentence summary, grade), and the orchestrator adds it. If the tool rejects an item, the claim does not enter the investigation.

Item fields (schema: `schemas/evidence.schema.json`):

| Field | Content |
|---|---|
| `id` | `E-001`, assigned by the tool |
| `class`, `grade` | As above |
| `summary` | One sentence stating what the item shows. Neutral: no hypothesis language |
| `source` | `path`, `line_start`, `line_end`, `timestamp`, `commit`, `command`, `url`, `search_scope` as applicable |
| `excerpt`, `sha256` | Verbatim text and its hash |
| `derived_from`, `reasoning` | For inferences |
| `supports`, `contradicts` | Hypothesis ids |
| `collected_by`, `collected_at`, `notes`, `recheck` | Provenance |

## 5. Collecting evidence: procedure

1. **Locate before you read.** Use the correlation key and the time window to cut the source down first (`log_parser.py --corr`, `--around`). Reading unfiltered logs produces impressions, not evidence.
2. **Take the smallest decisive excerpt.** The two lines that show the event, not the surrounding forty. Long excerpts hide the point and the tool caps them.
3. **Write the summary as an observation.** "req-b2 failed with status 500 at 15:53:51.529, 1.001s after it was received." Not "the request timed out", which is an interpretation.
4. **One observation per item.** If a line shows two independent things, add it twice with two summaries. Items are cited individually.
5. **Add the item with the tool.** Examples:

   A log line:
   ```
   python3 <skill-dir>/scripts/evidence_collector.py add --inv INV --class log --grade FACT --by log-analyst \
       --file logs/app.log --lines 15 --timestamp "15:53:51.230" \
       --summary "Payment attempt 1 for req-b2 timed out after the 0.6s per-attempt timeout"
   ```
   A code location:
   ```
   python3 <skill-dir>/scripts/evidence_collector.py add --inv INV --class source --grade FACT --by codebase-mapper \
       --file app/api.py --lines 12-20 \
       --summary "api_handler waits REQUEST_TIMEOUT_S for the order task, then calls task.cancel()"
   ```
   A command's output:
   ```
   python3 <skill-dir>/scripts/evidence_collector.py add --inv INV --class runtime --grade FACT --by verifier \
       --command "python3 verify_p3.py" --excerpt "RESULT RuntimeError: payment failed after 3 attempts" \
       --summary "With the request budget raised to 3.0s the same order ends in RuntimeError, not CancelledError"
   ```
   An inference:
   ```
   python3 <skill-dir>/scripts/evidence_collector.py add --inv INV --class source --grade INFERENCE --by cancellation-analyst \
       --derived-from E-006 --reasoning "3 x 0.6s + 3 x 0.2s = 2.4s, which exceeds the 1.0s request budget" \
       --summary "The payment client's worst-case duration cannot fit inside the request budget"
   ```
6. **Link it** to the hypotheses it supports or contradicts, at creation (`--supports H-02 --contradicts H-01`) or later (`link`).
7. **Note what you looked for and did not find.** That is evidence too, under the rules of the next section.

## 6. Absence evidence

"There is no log line showing X" is the most abused sentence in debugging. Absence is admissible only when coverage is established. An `absence` item must state its `search_scope`: what was searched, where, and over which time range. Before relying on it, confirm all of these:

1. **The source covers the time.** Not rotated, not truncated, not from a different host or pod than the one that served the request.
2. **The event would have been logged if it had happened.** The log statement exists in the deployed code, is not conditional on something that was false, and its level was enabled.
3. **The search would have matched.** Exact string versus format string, different id formats, line wrapping, multi-line records.
4. **The pipeline did not drop it.** Sampling, rate limiting, buffering at crash time, a logging sidecar that fell behind.

If any of the four is unknown, the item may still be recorded, as FACT about the search ("the string does not occur in this file") with a note listing what is unverified, and any conclusion drawn from it is an INFERENCE that names the gap.

Good: "No `process_payment completed` event for req-b2. Scope: `logs/app.log`, whole file, covers 15:53:50.316 to 15:53:51.742, exact string match. The statement at `payment.py:24` is unconditional at INFO, and INFO lines from the same logger appear before and after."

Bad: "The retry never ran, there is nothing in the logs."

## 7. Correlation: tying evidence to the failing execution

Evidence about some other request is not evidence about this failure. For each item, be able to say why it belongs to the failing execution.

| Strength | Basis |
|---|---|
| Strong | Same trace id, span parentage, request id, job id, or task name carried through the line |
| Medium | Same business key (order id, user id) within the time window, on a path where that key is unique at that moment |
| Weak | Same thread or worker within the time window, with no interleaving possible |
| Not correlation | Same second, "around the same time", same function name |

When no correlation id exists, say so in `error_context.md`, treat cross-component links as INFERENCE, and put "propagate a correlation id" at the top of the instrumentation plan. Check `log_parser.py`'s summary of ids it found: it often surfaces a usable key nobody thought to look for.

Clocks: timestamps from different hosts can disagree by more than the intervals you are reasoning about. Use ordering within one source freely. Use ordering across sources only when the gap is much larger than plausible skew, or when a causal marker (a request id that appears in both) fixes the order. Note time zones and whether timestamps are local or UTC.

## 8. Citing evidence

- In hypotheses, briefs, duel rationales and reports, cite ids: "the failure came exactly one request budget after receipt (E-003, E-006)".
- A sentence with no id is by definition an opinion. That is allowed in an investigator's reasoning. It is not allowed in `brief.md`, in a duel rationale, or as support for a verdict.
- When quoting, quote the excerpt exactly. When summarising, do not strengthen: "timed out" is not "hung", "returned 500" is not "crashed".
- Give line numbers with file paths (`app/payment.py:23`). For logs, give the file line and the timestamp.
- Keep the grade attached when it matters: "(E-007, inference)".

## 9. Exchanging evidence between agents

- **Collectors to orchestrator.** A list of proposed items, each with class, grade, locator, one-sentence summary. Plus a short list of leads ("the hotspot list shows a broad `except` at orders.py:26"), clearly marked as leads.
- **Orchestrator to investigators.** `INV/brief.md`: ledger facts with ids, the candidate path with observed and inferred marks, open questions, relevant knowledge-base entries with status. No theory.
- **Investigators to orchestrator.** Hypotheses in the schema, each claim tied to existing ids or to newly proposed items. Secondary findings in the finding schema.
- **Between duellists.** Each receives the other's full submission. Rebuttals must cite evidence. New evidence introduced in a duel goes through the ledger like any other.
- **Orchestrator to verifier.** The ledger files and the champion's id. Not the conversation, not the judge's rationale.

An agent's prose summary of what it found is never itself evidence. Only the items it points to are. When a subagent reports "I confirmed the pool is exhausted", the orchestrator's question is: which item, which file, which lines.

## 10. Contradicting evidence

Evidence against a hypothesis is recorded as carefully as evidence for it, linked with `--contradicts`. A hypothesis's owner must do one of three things with each contradicting FACT:

1. **Explain it**, with evidence, and list it under `addressed_contradictions` with the explanation in `notes`.
2. **Amend the hypothesis.** That creates a new hypothesis with a new id and `supersedes` set. The old one stays in the file as refuted or eliminated. Never edit a hypothesis in place to fit new evidence: that is how unfalsifiable explanations are made.
3. **Concede.**

Unanswered contradicting FACTs cost points automatically in scoring. A single clean contradiction of a prediction eliminates the hypothesis.

The orchestrator and verifier should actively look for contradicting evidence for the leading hypothesis. If none has been sought, none having been found means little.

## 11. Staleness and re-checking

Logs rotate, files are edited, branches move. Before the verdict, and again before the report if time has passed:

```
python3 <skill-dir>/scripts/evidence_collector.py recheck --inv INV
```

- `match`: the lines still say what was recorded.
- `moved`: the excerpt is still in the file at different line numbers (a growing log, an edit above). Acceptable. Note it.
- `mismatch` or `missing-file`: the FACT can no longer be re-observed. It is excluded from scoring automatically. Re-collect it from an archived copy or downgrade whatever depended on it.

For logs that will rotate, copy the relevant window into the investigation directory at the start (`INV/logs/`) and cite the copy.

## 12. Sensitive data

Logs and variables contain personal data and secrets. Excerpts are written to files that may be committed and shared.

- Take the narrowest excerpt that shows the point.
- Do not record tokens, passwords, keys, full card or account numbers, or personal details in excerpts or summaries. If the decisive line contains one, cite the file and line and describe the field ("authorization header present, 187 characters") instead of quoting it, using a `--command` locator with a redacted excerpt and a note saying so.
- Ask before copying production logs into the repository. Add `debugging/investigations/*/logs/` to `.gitignore` if the user wants the ledger committed but not the raw logs.

## 13. Common grading mistakes

| Statement | Looks like | Actually | Why |
|---|---|---|---|
| "`process_payment` caused the CancelledError" | FACT | INFERENCE at best | The trace shows where the task was suspended, not who cancelled it |
| "The function calls `release()` in the except block" | FACT | FACT about the source | What the code says. Whether the block ran is separate |
| "So the connection was released" | FACT | INFERENCE | Depends on the block having run, which needs runtime evidence |
| "The timeout is 30 seconds" (from a config file) | FACT | FACT about the file | Effective value in the process is unverified unless logged |
| "The deploy at 09:30 introduced this" | FACT | INFERENCE | Timing is correlation. The diff must be shown to produce the failure |
| "No retries happened" | FACT | absence, scope-dependent | Only as good as the search and the logging |
| "This always fails under load" | FACT | ASSUMPTION | Unless a run under load is in the ledger |
| "The agent verified that..." | FACT | Nothing | Until there is an item with a locator |
| "The knowledge base says there is a race in `cache.py`" | FACT | Whatever the entry's status is | `suspicious` and `unverified` entries are leads |
