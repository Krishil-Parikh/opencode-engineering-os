# Tournament protocol (Adversarial Root Cause Engine)

How competing hypotheses are challenged one on one, how duels are judged, and how the tournament is kept an instrument of the investigation instead of a contest of persuasion.

## Contents

1. Purpose and limits
2. When to run a tournament, and when not to
3. Entry requirements: the six-part submission
4. Bracket: king of the hill
5. Anatomy of a duel
6. Cross-examination: the questions that break weak hypotheses
7. Judging
8. Outcomes and what happens next
9. Losers' findings
10. Anti-persuasion rules
11. Dynamic expansion
12. Running it on each host
13. A complete duel, as it should read

---

## 1. Purpose and limits

The tournament is a mechanism for **adversarial hypothesis elimination**. Its job is to expose each explanation to an opponent with every incentive to find its weakest point, so that unsupported assumptions, missing evidence and ignored contradictions surface before a verdict instead of after a wrong fix ships.

It is not a way to produce a winner. It can end with one champion, with an unresolved pair, or with nothing standing. All three are results.

A debate can select the most convincing explanation. An investigation must select the explanation best supported by reality. Every rule here serves the second.

## 2. When to run a tournament, and when not to

Run duels only between **genuinely competing** hypotheses: ones that cannot both be the root cause, or that make at least one different prediction.

| Situation | Do |
|---|---|
| One hypothesis survives step 5 | No tournament. Go to verification |
| Two hypotheses share Layer 3 (same root cause, different wording or different Layer 1 detail) | Merge them (`score.py merge`). No duel |
| Two hypotheses are a cause and its consequence (A explains why B happened) | Not rivals. Combine into one chain, or keep the downstream one as a finding |
| One hypothesis names the trigger (Layer 2) and another names the defect (Layer 3) for the same incident | Usually complementary. Check whether the Layer 2 one claims "there is no defect": if so it is a rival to the Layer 3 one and they duel |
| A hypothesis has a prediction that existing evidence already refutes | Mark it refuted. No duel needed |
| Two or more make different checkable predictions | Tournament |

Do not spawn dozens of agents and let them debate freely. Unstructured multi-agent debate converges on whichever claim was stated first or most confidently. Structure, isolation and scoring against a ledger are what make the adversarial step worth its cost.

## 3. Entry requirements: the six-part submission

Each duellist must submit all six. They are the fields of the hypothesis schema, so a registered hypothesis already is a submission.

| # | Must submit | Schema field | Minimum bar |
|---|---|---|---|
| 1 | Its proposed root cause | `statement`, `layers` | All three layers, stated so that it could be wrong |
| 2 | Evidence from the logs | `evidence_for` (runtime-class ids) | At least one FACT correlated to the failing execution |
| 3 | Relevant source-code locations | `evidence_for` (source-class ids) | File and line ranges that were actually read |
| 4 | The exact execution path | `execution_path` | Ordered steps, each marked observed or inferred |
| 5 | Why the competing hypothesis is less likely | `rival_rebuttals` | One entry per rival it will face, citing evidence |
| 6 | What evidence would disprove its own hypothesis | `falsifiers`, `predictions` | At least one falsifier, and at least one prediction with a concrete check |

Item 6 is the one agents resist and the one that matters most. A hypothesis that cannot say what would disprove it is not competing. It is asserting. Refuse entry until item 6 is filled.

Items 5 and 6 are written twice: once blind (step 5, before seeing rivals), and again after reading the opponent's submission at the start of the duel.

## 4. Bracket: king of the hill

With hypotheses A, B, C, D:

1. A duels B. The winner advances. The loser's findings are stored.
2. The winner faces C.
3. That winner faces D.

N hypotheses need N−1 duels. This is cheaper than a round robin and, because scores are computed against a ledger and not relative to the opponent's rhetoric, the order matters much less than in a debate.

**Ordering the bracket.**

- Put the pair that disagrees about the most cheaply checkable fact first. Their duel will generate the most decisive evidence for everyone.
- Put hypotheses with the weakest evidence early. They are eliminated cheaply.
- Put the two strongest last, so the final duel has the full ledger to draw on.

**Carry-forward.** Evidence added during any duel goes into the shared ledger and is available to all later duels. After each duel, check whether the new evidence refutes a prediction of a hypothesis that has not fought yet. If so, mark it and skip that duel.

**Re-entry.** If evidence gathered late contradicts the reason an earlier hypothesis lost, that hypothesis is reinstated (`update-hypothesis --set status=active`) and faces the current champion. Elimination is a judgement on the evidence at the time, and it is reversible.

**Narrow results.** A narrow duel leaves both alive. Park the pair, collect the discriminating evidence, and re-run. If the bracket has other entrants, the higher-scoring of the pair may continue against them in the meantime, but the parked duel must be resolved before any verdict above INSUFFICIENT.

## 5. Anatomy of a duel

One duel has five phases. Roles: two advocates (the owners of the two hypotheses), one judge (the adversarial reviewer), and the orchestrator, who runs the tools and owns the ledger.

**Phase 1. Exchange.** Each advocate receives the opponent's full submission and the current ledger. Nothing else: not the opponent's private reasoning, not earlier duels' commentary.

**Phase 2. Attack and defend.** Each advocate returns:

- An updated item 5: for the opponent's hypothesis specifically, which of its steps is unsupported, which evidence it ignores or misreads, which of its predictions is false, and the evidence for each objection.
- Responses to contradicting evidence against its own hypothesis: explain with evidence (and list under `addressed_contradictions`), amend, or concede.
- Any new evidence it wants added, as locators for the orchestrator to enter.
- An updated item 6 if the opponent's attack exposed a new way it could be wrong.

One round of attack and defence is the default. A second round is allowed only if the first introduced new evidence that the other side has not had a chance to address. There is no third round: if two exchanges did not settle it, more words will not. More evidence might.

**Phase 3. Evidence intake.** The orchestrator adds all proposed evidence through `evidence_collector.py` (rejecting anything the tool rejects), updates both hypotheses (`update-hypothesis`), and runs any prediction check that is cheap enough to do on the spot. A prediction refuted here ends the duel by elimination.

**Phase 4. Cross-examination and scoring.** The judge reads both updated submissions and the ledger items they cite, puts the cross-examination questions of section 6 to each (answering them from the submissions and the ledger, or by asking the advocate where the host allows), and assigns the five raw scores to each side with a rationale that cites evidence ids per criterion.

**Phase 5. Recording.** The orchestrator records the duel:

```
python3 <skill-dir>/scripts/score.py duel --inv INV --a H-01 --b H-02 \
    --scores-a log=3,source=1,path=2,alternatives=2,verification=2 \
    --scores-b log=4,source=4,path=4,alternatives=3,verification=3 \
    --judge adversarial-reviewer \
    --rationale "<per-criterion reasons with evidence ids>" \
    [--needs "<evidence that would separate them, required if the result is narrow>"]
```

The tool applies caps and penalties (`core/hypothesis_scoring.md`), decides the outcome, updates statuses, and appends the round to `tournament.json` with raw scores, capped scores, each cap's reason, totals, margin and rationale.

## 6. Cross-examination: the questions that break weak hypotheses

The judge puts these to each hypothesis. An advocate should expect them, and a good opponent raises them first.

**On the evidence**

1. Which single piece of evidence would you least like to lose? Open it. Does the excerpt show what the summary claims?
2. Which of your supporting items would also be true if your opponent were right? (Those items support neither of you.)
3. Is each runtime item tied to the failing execution by a correlation key, or only by time?
4. Is anything you rely on absence evidence? What was the search scope, and would the event have been logged?

**On the path**

5. Which steps of your path are inferred? For each, what other route could the execution have taken between the observed points on either side?
6. Does the timing fit? State the duration your mechanism requires between two observed events, and the duration actually observed.
7. What does your hypothesis say the execution was doing during the last gap before the failure?

**On the layers**

8. Is your root cause a standing property of the system, or an event? If the trigger happened again tomorrow with your "root cause" fixed, would the failure recur?
9. Why did this execution fail and the neighbouring ones succeed? Does your hypothesis predict that difference?
10. Why did it not fail last week? What changed, or has it been failing unnoticed?

**On the rival**

11. State your opponent's hypothesis in its strongest form. What is the best evidence for it?
12. What is the one observation on which you and your opponent disagree? Has anyone looked?

**On falsifiability**

13. What would you expect to find if you were wrong? Has anyone looked for it?
14. Which of your predictions would your opponent's hypothesis also make? (Those are not tests.)
15. If your fix were applied and the failure recurred, what would you conclude?

A hypothesis that answers 12 with a concrete, checkable observation has done the investigation a service whichever way the check comes out. Go and make the observation.

## 7. Judging

The judge follows `core/hypothesis_scoring.md`, section 11. In summary:

- Score from the ledger items, not from the prose.
- Write the rationale per criterion with evidence ids.
- Apply the same reading of each evidence item to both sides.
- Do not complete a submission on an advocate's behalf.
- Rule `narrow` when the evidence does not separate them, and name what would.
- Recommend `merge` when the two assert the same Layer 3.
- Say "both are weak" when both are weak. The verdict thresholds will handle it. Do not inflate the better of two poor hypotheses.

The judge must not have authored or developed either hypothesis. At T2 and above the judge is a separately briefed agent. On a host without subagents, the orchestrator judges, applies the rubric anchors literally, and notes in the round's rationale that the judge was not independent.

## 8. Outcomes and what happens next

| Outcome | Next |
|---|---|
| `win` | Winner is `champion`, faces the next entrant, or goes to verification if none remain |
| `elimination` | As `win`. The eliminated hypothesis's refuting evidence goes into the next entrant's briefing |
| `narrow` | Collect the evidence named in `--needs`. From existing logs if possible, otherwise Mode B. Re-run the duel on the updated ledger |
| `both_eliminated` | Return to step 4. The evidence that refuted both is the starting point for new hypotheses. Consider a lens that has not been used |
| `merge` | Re-score the merged hypothesis. It takes the place of both in the bracket |

After the final duel the champion goes to independent verification (`core/root_cause_verification.md`). A tournament win is a nomination. Verification decides.

**When the tournament ends without a champion**, do not manufacture one. Run `score.py verdict`, which will return INSUFFICIENT_EVIDENCE, and deliver what section 8 of `core/hypothesis_scoring.md` requires: what is established, the candidates, what would decide it, and the instrumentation plan.

## 9. Losers' findings

Losers' findings are retained, not discarded.

An investigator who chased a database-pool theory and lost may have found a real connection leak on the way. That leak did not cause this incident. It will cause another. The tournament must not throw it away with the hypothesis.

- Each hypothesis lists its `secondary_findings` (ids in `findings.json`).
- When a hypothesis is eliminated, `score.py` copies those ids into the round's `retained_findings`.
- The eliminated hypothesis itself stays in `hypotheses.json` with its status, scores and the reason it lost.
- In step 8 every finding gets its honest status, and in step 10 they go to the knowledge base, along with the eliminated hypotheses themselves (`kb.py record-hypotheses`), scoped to this incident.

Distinguish three things about a losing hypothesis, because they have different futures:

| Part | Fate |
|---|---|
| Its claim to be this incident's root cause | Rejected, with the reason recorded. Scoped: "outscored in BUG-007", not "impossible" |
| Real defects it found along the way | Findings, with status confirmed, suspicious or unverified |
| Things it claimed that were checked and found false | Findings with status `disproven`, so nobody re-chases them |

## 10. Anti-persuasion rules

Persuasiveness and correctness are different properties, and language models are very good at the first. Guards:

1. **The ledger caps the score.** No amount of argument lifts `log` above 1 without a FACT-grade runtime item. The judge cannot override this.
2. **Refutation is absolute.** One refuted prediction eliminates, whatever the total would have been.
3. **Unanswered contradictions cost points mechanically.**
4. **Evidence must be opened.** The judge reads excerpts, not summaries. The tool wrote the excerpts from disk, so they are what the file says.
5. **Advocates are isolated until the duel.** A hypothesis formed after reading a rival's is contaminated by it. Blind first, exchange second.
6. **The judge is not an advocate.** Different agent, or a declared lack of independence.
7. **Rationales cite ids.** A rationale such as "H-02 is more coherent and better argued" is rejected by the orchestrator. The tool refuses rationales that are too short to contain reasons, and the orchestrator must refuse those that contain no ids.
8. **No voting.** Three agents agreeing is not three pieces of evidence, especially when they share a model and a prompt. Agreement among investigators is recorded as a merge, and adds nothing to the score.
9. **No appeals to authority or prior.** "This is usually a race condition" is a reason to send the concurrency analyst. It is not evidence.
10. **Length is not strength.** Submissions have no minimum length. The judge should distrust the longer one slightly.
11. **The winner still has to survive a stranger.** The verifier starts from the files, not from the debate.

## 11. Dynamic expansion

Start small. Expand when, and only when, the evidence asks for it.

| Signal | Expansion |
|---|---|
| A duel ends narrow and the discriminating fact lies in an area no investigator covered | Dispatch that lens with the single question |
| Both hypotheses in a duel are weak and share an unexamined assumption | Dispatch an investigator whose brief is to attack that assumption |
| Cross-examination surfaces an alternative nobody proposed (question 4 of the `alternatives` anchors) | Have an investigator develop it into a full submission, then duel |
| The champion's path has an inferred step in another service or component | Dispatch a collector for that component's logs |
| Verification fails | Re-open step 4 with one or two fresh investigators who have not seen the failed hypothesis's narrative, only the ledger |

Each added agent gets one written question, the brief, and the ledger. Record the reason for each addition in `error_context.md`. If you find yourself adding agents without a specific question for each, stop: the bottleneck is evidence, not analysis, and the answer is Mode B.

## 12. Running it on each host

The protocol is host-independent. The mechanics differ.

- **Hosts with parallel subagents.** Advocates for a duel can be run in parallel in phase 2 (each sees the other's phase-1 submission, not the other's phase-2 response). The judge runs after both return. Duels themselves are sequential because each depends on the previous winner.
- **Hosts with sequential subagents only.** Same order, one at a time.
- **Hosts without subagents.** The orchestrator plays advocate A, writes A's phase-2 output to `INV/duels/round-N-A.md`, then plays advocate B from B's submission and the ledger and writes `round-N-B.md`, then judges from the two files and the ledger using the anchors literally. State in the rationale that roles were not independent.

In every case, keep each duel's working files under `INV/duels/` so the tournament can be audited: `round-1-H-01.md`, `round-1-H-02.md`, `round-1-judge.md`.

The skill cannot guarantee a particular number of simultaneously running agents. That is set by the host. The protocol does not need it.

## 13. A complete duel, as it should read

From the sample incident, round 2. Abbreviated to the parts that matter.

**H-01 (dependency analyst), phase 2.**

> *Against H-02.* H-02's step 6, "api_handler budget expires, task.cancel()", is inferred: no log line shows the cancel. The 1.0s interval (E-003) could be coincidence. H-02 must show the cancel came from `api_handler` and not from the gateway connection dropping.
> *Defending.* E-004 is listed against me. The trace ends in `CancelledError` and not a gateway timeout, which I concede my hypothesis does not explain. I maintain the gateway latency is the cause of the incident.
> *Falsifier, updated.* If the request fails before my client has exhausted its own retries, something other than the gateway ended it.

**H-02 (cancellation analyst), phase 2.**

> *Against H-01.* H-01 explains attempt 1 timing out (E-002). It does not explain why the request ended after one logged attempt, when `payment.py:21-31` (E-008) retries three times and then raises `RuntimeError`. H-01's own updated falsifier is met: the request failed 0.3s into attempt 2. E-004's outermost frame is `api_handler` at `api.py:17`, awaiting the task it had just cancelled (E-005).
> *Defending the inferred step.* Conceded that the cancel call is not logged. Prediction P3 tests it without that log: raise the request budget above 2.4s and the same order must end in `RuntimeError`, not `CancelledError`.
> *New evidence requested.* None. P2 and P3 are for the verifier.

**Judge.**

> log: H-01 3 (E-002, E-013 are runtime FACTs, but both are also predicted by H-02). H-02 4 (E-001 to E-004: start, attempt-1 timeout, failure at +1.001s, trace with `api_handler` outermost; rivals do not predict the 1.0s interval).
> source: H-01 1 (no code location; "no defect in this service" is asserted, not shown). H-02 4 (E-005, E-006, E-008 read end to end with line ranges, including config values).
> path: H-01 2 (ends match, mechanism between them is absent). H-02 4 raw (ordered, timing fits; note two steps are inferred, the tool will cap).
> alternatives: H-01 2 (counters H-03 with E-010; does not counter H-02). H-02 3 (counters both rivals with FACTs).
> verification: H-01 2 (P1 confirmed but H-02 predicts it too). H-02 3 (P1 confirmed and discriminating; P2, P3 untested).
> H-01 concedes it cannot explain E-004 and leaves it unanswered.

**Recorded result.** H-01 40.0 (weighted 50.0, penalty 10 for E-004). H-02 87.5 (`path` capped at 3: two of seven steps inferred). Margin 47.5: `win`. H-01 eliminated, retained. H-02 to verification, with P2 and P3 as the verifier's first tasks.

What made this duel useful was not the result. It was that H-01's attack identified the inferred step, and H-02 answered with a prediction that tests it. That prediction, once run, is what moved the verdict from PROVISIONAL to CONFIRMED.
