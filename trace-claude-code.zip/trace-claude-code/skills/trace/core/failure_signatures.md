# Failure signatures

A field guide for investigators and verifiers: for each family of failure, how it shows up in the evidence, the mechanisms that produce that picture, and the observation that tells them apart. Use it to generate hypotheses (step 4), to make sure the standard alternatives were considered (verification, check 15), and to write predictions that actually discriminate.

Nothing here is evidence. A matching signature is a reason to look, and the look is what goes in the ledger.

## Contents

1. Cancellation
2. Timeouts
3. Async and event-loop failures
4. Races and shared state
5. Deadlocks, hangs and stalls
6. Resource exhaustion and leaks
7. Data and state corruption
8. Exception-handling defects
9. External dependencies
10. Databases
11. Queues, schedulers and background jobs
12. Configuration and environment
13. Deployment and change
14. Memory, process and platform
15. Silent failures
16. Quick index: from symptom to section

---

## 1. Cancellation

**Symptoms.** `CancelledError`, `context canceled`, `AbortError`, `OperationCanceledException`, `TaskCanceledException`, `InterruptedException`. A request that ends with no error from the code that was running. Work half-done.

**The trap.** The exception names the victim. The stack shows where the task was waiting. The cause is whoever asked for the cancellation.

| Mechanism | Evidence pattern | Discriminating check |
|---|---|---|
| Caller's budget expired and it cancelled the task | Failure at a fixed interval after the *execution started*. Caller awaiting the task in the outermost frames. Inner timeouts not yet elapsed | Elapsed from start equals a configured budget. Raising that budget changes the outcome |
| Client disconnected, framework cancelled the handler | Proxy or access log shows the connection closed first (499, `client closed`, reset). Interval matches no configured value. Often correlates with slow responses, mobile clients, client-side timeouts | Access or proxy log for the same request id. The client's own timeout setting |
| Upstream deadline propagated | The inbound request carried a deadline or cancel signal. Upstream service logged a timeout or cancel for the same trace id slightly earlier | Upstream logs and spans. Deadline header or context deadline on entry |
| Sibling task failed in a structured group | `TaskGroup`, `gather` without `return_exceptions`, `errgroup`, `Promise.all`: one child raised, the rest were cancelled. The real error is in a different task's trace, often logged just before | Find the first exception in the group. `ExceptionGroup` contents. The sibling's log lines |
| Shutdown | SIGTERM, "shutting down", lifespan or drain messages. Many in-flight executions cancelled at the same instant. Grace period shorter than in-flight work | Process, orchestrator and deploy logs around the time. Other executions in the same second |
| Explicit cancel by application logic | A code path calls cancel: superseded request, deduplication, user action, watchdog, leader change | Search for cancel call sites reachable from the path. Log at those sites |
| Cancel scope or timeout context exited | `asyncio.timeout`, `anyio` cancel scope, `context.WithTimeout` whose `cancel` ran via `defer` while work continued in a goroutine | The scope's duration against the gap. Work started in a child that outlives the scope |

**Follow-on defects to look for** (usually secondary findings, sometimes the real impact):

- Cleanup in `except Exception` (Python 3.8+: does not run on cancellation). No `finally`.
- Cancellation swallowed by a bare `except`, `except BaseException`, `catch (e: Exception)` in Kotlin coroutines, or `InterruptedException` caught without restoring the flag. The task keeps running after being cancelled.
- Cleanup that awaits and is itself cancelled, leaving it half-done. Needs shielding.
- Cancellation reported to the user or the logs as a generic 500 or as nothing.
- Half-completed multi-step operations: reserved and not charged, charged and not recorded, message consumed and not acknowledged.

## 2. Timeouts

**Symptoms.** `TimeoutError`, `deadline exceeded`, `Read timed out`, `ETIMEDOUT`, 504, a gap of a round number of seconds before the failure.

| Mechanism | Evidence pattern | Discriminating check |
|---|---|---|
| Dependency genuinely slow | The dependency's own logs or metrics show high latency in that window. Other callers affected | Dependency-side timing for the same request |
| Timeout hierarchy inverted | An outer limit is shorter than the inner worst case (attempts × per-attempt timeout + backoff). The outer layer cuts the inner one off mid-retry | The table of every limit on the path with values. Section 9 of `core/execution_reconstruction.md` |
| Timeout too short for legitimate work | Fails for large inputs, cold caches, first request after start. Latency distribution has a tail beyond the limit | Duration against input size. p99 against the configured value |
| Queueing before the work starts | Time is spent waiting for a pool slot, a lock, a worker, a rate limiter. The operation itself is fast | Wait-time metrics or logs. Pool in-use at the time. Timing of "acquired" versus "started" |
| Blocked event loop or starved thread pool | Many unrelated operations time out together. CPU pegged on one core, or all workers busy | Simultaneous gaps across executions. Loop-lag metric. Thread dump |
| Default timeout nobody chose | The value matches a library default (often 5, 10, 30, 60, 120 seconds, or none at all) | Library documentation and effective client configuration |
| No timeout at all | The failure is a hang ended by something else: a caller's limit, a health check, an operator | No timeout on the call site. See section 5 |
| Retry amplification | Each layer retries. Three layers of three attempts is twenty-seven calls. Load rises as the dependency slows | Count calls at the callee for one logical request |
| Connect versus read confusion | A single "timeout" setting applies to connection establishment only, or to each read, not to the whole call | Client documentation. Total elapsed versus configured value |
| Clock issues | Deadlines computed from wall-clock time across a clock adjustment, or across hosts with skew | Monotonic versus wall clock in the code. NTP events |

**Always establish:** which timer fired (who owns it), its configured value, where the value comes from, what the timed operation was doing when it fired, and whether the work continued after the caller gave up.

## 3. Async and event-loop failures

| Mechanism | Evidence pattern | Discriminating check |
|---|---|---|
| Blocking call in async code | Sync HTTP client, sync DB driver, file I/O, `time.sleep`, heavy CPU, a lock held across slow work, DNS resolution. Every task stalls for the duration | Simultaneous gaps on unrelated executions. Loop debug mode slow-callback warnings. `call_graph.py` for sync calls inside `async def` |
| Missing await | A coroutine was called and never awaited: "coroutine was never awaited" warning, the work silently did not happen, or a coroutine object was used as a value | Runtime warnings in logs. Search for un-awaited calls to async functions |
| Fire-and-forget task lost | `create_task` result not kept: exception never retrieved, or the task was garbage-collected mid-flight | "Task exception was never retrieved". Tasks without stored references or done-callbacks |
| State changed across an await | Value read before an await, used after it, modified in between by another task | Section 4 |
| Wrong loop or wrong thread | Object created on one loop used on another ("attached to a different loop"), or loop APIs called from a non-loop thread | The error text. Where the object was created versus used |
| Unbounded concurrency | `gather` over thousands of items opens thousands of connections: pool exhaustion, rate limits, memory | Concurrency at the time. Absence of a semaphore |
| Exception in one of many | `gather(..., return_exceptions=True)` and the results are never inspected. Or `return_exceptions=False` and siblings keep running detached | How results are handled. Section 1, sibling row |
| Callback or handler raising | An exception in a done-callback, signal handler or event handler goes to the loop's exception handler, which only logs | "Exception in callback". Default handler output |
| Reentrancy | A handler awaits, and a second event runs the same handler before the first finishes | Two interleaved timelines for the same entity |
| Promise chain broken (JS) | Missing `return` in a `.then`, missing `await` in `try`, so the `catch` never sees the rejection | `unhandledRejection`. Read the chain |
| Goroutine leak (Go) | A goroutine blocked forever on a channel nobody will write to or read from. Count grows with uptime | Goroutine dump grouped by stack |

## 4. Races and shared state

**Symptoms.** Intermittent. Load-dependent. Disappears with logging or a debugger attached. "Impossible" states. Duplicate or lost updates. Works in tests.

| Mechanism | Evidence pattern | Discriminating check |
|---|---|---|
| Check-then-act | `if key not in cache: cache[key] = compute()` with a suspension or thread switch between. Two flows both pass the check | Two timelines on the same key overlapping between check and act. Duplicate side effects |
| Read-modify-write | Counter, balance, list append, JSON blob update without atomicity. Lost updates | Final value lower than the number of operations. Concurrent writers in the window |
| Lost update at the database | Two transactions read the same row, both write. Last write wins. No version check or row lock | Two requests on the same entity within the transaction duration. Isolation level |
| Publication before initialisation | An object visible to other flows before it is fully set up. Lazy singletons initialised twice | Double initialisation logs. Use before the "ready" line |
| Shared mutable default or module state | A module-level dict, a mutable default argument, a class attribute used as instance state, a client or cursor shared between tasks | Where the state is defined. Whether flows on different executions touch the same object |
| Ordering assumed and not guaranteed | Messages, callbacks or events handled in an order the code assumes. Out-of-order delivery after a retry or rebalance | Sequence numbers or timestamps at the consumer |
| Time-of-check to time-of-use on external state | File exists then is opened. Row exists then is updated. Token valid then is used | An intervening change by another actor in the window |
| Double execution | The same job, message or request processed twice: retry after a timeout whose first attempt actually succeeded, at-least-once delivery, overlapping cron runs, double submit | Two executions with the same business key. Idempotency key absent |
| Iteration during mutation | "dictionary changed size during iteration", `ConcurrentModificationException`, skipped elements | The error text. Who mutates while who iterates |
| Visibility (threads) | A flag written by one thread never seen by another: missing `volatile`, atomics or locks | Language memory model. Reproduces only optimised |

**To establish a race** you need: the shared state identified, two flows that touch it, evidence both were active in the window for this incident, and the interleaving that produces the observed outcome. Then a reproduction with the interleaving forced (a pause at the suspension point) and its absence with the fix. "It is probably a race" is not a hypothesis: name the state and the interleaving.

**Probe effect.** Adding logging changes timing. A race that vanishes under observation is still a race. Record the vanishing as evidence, and force the interleaving deterministically instead of hoping to catch it.

## 5. Deadlocks, hangs and stalls

**Symptoms.** No error. Requests pile up. A job that never finishes. Health checks fail. The logs simply stop.

| Mechanism | Evidence pattern | Discriminating check |
|---|---|---|
| Lock-order deadlock | Two flows each hold one lock and wait for the other. Permanent. CPU idle | Thread or task dump showing the cycle. Database deadlock log |
| Self-deadlock | A non-reentrant lock acquired twice on the same flow. Awaiting your own result. Sync-over-async on a single-threaded context | One flow waiting on something only it can release |
| Pool starvation deadlock | Every worker holds a pool slot and waits for a second slot. Or all workers are waiting for tasks that need a worker to run | Pool in-use equals size, all holders blocked on acquire |
| Waiting on a future nobody completes | An exception path skipped the `set_result`. A callback was never registered. A channel has no sender | The completing code path, and whether it ran |
| Missing timeout on I/O | A peer stopped responding, the connection is half-open, no timeout or keepalive. Waits until the OS gives up, which can be hours | Stack blocked in a read. No timeout on the call site |
| Livelock or retry storm | Activity without progress. Logs repeat. CPU busy | Repeating pattern in the logs. Counters increasing, results not |
| Backpressure with no consumer | A bounded queue is full and the producer blocks. The consumer died or is slower | Queue depth. Consumer liveness |
| Stop-the-world | GC pause, swap, CPU throttling, a paused container, a debugger attached, a long synchronous section | All flows gap together, then resume. Platform metrics |
| Infinite loop | One flow at 100% CPU, same stack each sample | Repeated stack samples |

**The decisive artefact is a dump taken while it is stuck**: thread dump, task dump, goroutine dump, `py-spy dump`, database lock views. If the process was already restarted, that evidence is gone. The instrumentation plan should make sure a dump is captured before any restart next time (a watchdog that dumps on stall, a runbook step).

## 6. Resource exhaustion and leaks

**Symptoms.** Works after restart, degrades with uptime. "Too many open files", "connection pool exhausted", "cannot allocate memory", "too many connections", slow then failing. Fails at a similar uptime or request count each time.

| Mechanism | Evidence pattern | Discriminating check |
|---|---|---|
| Leak on an error path | Resource acquired, released only on success. Each failure leaks one | Acquire and release sites. Is release in `finally`/`defer`/a context manager? Gauge rises by one per failure |
| Leak on cancellation | Released in an `except Exception` or after an await that got cancelled | Section 1. Gauge rises by one per cancelled request |
| Leak by reference | Objects kept alive by a growing cache, list, listener registry, closure or global map | Heap snapshot diff. Unbounded cache. Listeners added and never removed |
| Pool too small for concurrency | Not a leak: in-use returns to zero when idle, but peak demand exceeds size | Gauge returns to baseline. Wait time under load |
| Holding a resource across slow work | A connection or lock held during an external call | What happens between acquire and release |
| Exhaustion of the peer | The database's connection limit, the provider's rate limit, the broker's channel limit, shared by several services | Peer-side limits and usage |
| Descriptor exhaustion | Sockets or files opened per request and left to the garbage collector | Open descriptor count over time. `ResourceWarning`s |
| Disk, inodes, temp files | Writes fail, logs stop (which then hides everything else) | Disk and inode usage at the time |
| Thread or task explosion | A thread or task per request with nothing bounding it | Count over time |
| Ephemeral port exhaustion | High rate of short outbound connections without reuse | Connection reuse settings. Ports in `TIME_WAIT` |

**To establish a leak:** a gauge of the resource over time (or before and after N operations), the acquire site, the path on which release is skipped, and a demonstration that exercising that path moves the gauge. After the incident, a state line such as `pool in_use=1` with nothing in flight is direct evidence.

## 7. Data and state corruption

**Symptoms.** Wrong values. `None`, `null`, `undefined`, `NaN`. `KeyError`, `IndexError`, `TypeError`, constraint violations. Fails for specific records. "This can't happen".

| Mechanism | Evidence pattern | Discriminating check |
|---|---|---|
| Unvalidated input | A field missing, empty, wrong type, unexpectedly large, a new enum value, different unit or time zone, unusual encoding | Diff the failing input against a passing one. Schema versus actual |
| Stale cache | The value was right when cached. Invalidation missed a path, or the TTL outlives the truth | Cache write time versus source change time. Bypass the cache and compare |
| Partial write | A multi-step update interrupted: by an exception, a cancellation, a crash, a timeout. No transaction, or a transaction not covering everything | State that satisfies some steps and not others. An earlier failed execution on the same entity |
| Earlier failure left bad state | The current failure is the *second* incident. The first one, possibly days ago, wrote the bad record | History of the entity. Search for earlier errors on the same key |
| Schema or contract drift | Producer and consumer disagree after a deploy of one. A migration half-applied. Old messages in a queue after a format change | Versions on both sides. When the first bad record appears versus deploy times |
| Aliasing and unintended mutation | A shared list or dict mutated by a callee. A default argument. A cached object modified by a caller | Object identity across call sites |
| Numeric issues | Float rounding in money. Integer overflow. Division by zero. Precision lost in JSON or a database column type | The exact values |
| Time issues | Naive versus aware datetimes, DST transitions, month ends, leap days, clock skew, epoch seconds versus milliseconds | The failing timestamp. Does it fail only at certain times or dates? |
| Encoding and locale | Mojibake, normalisation differences, case folding, decimal commas | Bytes of the failing value |
| Serialisation round trip | A type that does not survive JSON, pickle or an ORM: sets, dates, decimals, large ints, `NaN` | Value before and after the round trip |
| Off-by-one and boundary | First or last element, empty collection, exactly-at-limit page size | Whether failing inputs sit on a boundary |
| Replica lag | Read-your-writes violated: a write to the primary followed by a read from a lagging replica | Routing of the read. Lag at the time |

**Method.** Trace the bad value backwards: where was it last known good, where first known bad (bisection across the pipeline, `core/hierarchical_localization.md` section 7). The defect is between those two points, and often not on the failing execution's path at all.

## 8. Exception-handling defects

The original failure is often ordinary. The handling turns it into an incident, or hides it.

| Mechanism | Evidence pattern | Discriminating check |
|---|---|---|
| Swallowed exception | `except: pass`, empty `catch`, `.catch(() => {})`, ignored error returns in Go. No error anywhere, and wrong behaviour downstream | `call_graph.py hotspots` flags `swallows` and `silent`. Read every handler on the path |
| Logged and continued | The error was logged at a level nobody reads and execution carried on with a default or partial result | Lower-level lines just before. What value the code continued with |
| Translation that loses the cause | A specific exception re-raised as a generic one without chaining. The log shows only the generic one | `raise X from e` or `cause` missing. The original type visible only with instrumentation |
| Wrong exception caught | Handler too broad (catches programming errors as "expected"), too narrow (misses the real type), or catching a base class that includes cancellation or interruption | Exception hierarchy against what the handler names |
| Handler raises | Cleanup or logging in the handler fails and replaces the original exception | "During handling of the above exception, another exception occurred". The first trace in the chain is the original |
| `finally` masks | A `return` or exception in `finally` discards the in-flight exception | Control flow in `finally` blocks |
| Error as value ignored | Return codes, `Result` types, `(value, err)` not checked. `None` returned on failure and used | The caller's handling of the failure value |
| Retry on the non-retryable | Retrying validation errors, auth failures, non-idempotent operations | What the retry predicate matches |
| Fallback that lies | On failure, return cached or default data as if fresh. Downstream decisions made on it | Whether the consumer can tell a fallback from a real answer |
| Error boundary too high | One bad record aborts a batch of 40,000. One failed sub-call fails a whole page | Where the `try` sits relative to the loop |
| Unhandled in background context | Exceptions in threads, tasks, callbacks, timers, signal handlers go to a default handler | Section 3 and 15 |
| Exit code or status wrong | A failed job exits 0. A failed request returns 200 with an error body | What the supervisor or client actually saw |

Reading a chained trace: the **first** exception is where things first went wrong. Later ones describe what happened while dealing with it. Reports that quote only the last exception in a chain are usually describing the wrong failure.

## 9. External dependencies

| Mechanism | Evidence pattern | Discriminating check |
|---|---|---|
| Outage or degradation | Errors or latency for all callers in a window. Provider status page. Recovers without any change on our side | Dependency-side evidence. Other consumers |
| Rate limiting or quota | 429, 503 with retry-after, throttling messages. Starts at a traffic threshold or a time boundary (minute, day, month) | Response codes and headers. Usage against quota |
| Contract change | New required field, changed enum, changed error format, stricter validation, deprecated endpoint removed | Diff responses before and after. Provider changelog. First occurrence time |
| Credentials | Expired token, rotated secret, revoked key, clock skew breaking signatures. 401 or 403. Starts at an exact instant | Token lifetime and refresh logic. Rotation times |
| TLS and certificates | Expired or changed certificate, missing intermediate, protocol or cipher mismatch, SNI | Handshake error text. Certificate dates |
| DNS | Resolution failures or stale cached addresses after a failover. Fails on some hosts | Resolver logs. Resolved address versus current |
| Connection reuse | Stale pooled connection closed by the peer or a load balancer's idle timeout. First request after idle fails with reset or EOF, retry succeeds | Idle time before failure against the peer's idle timeout. Keepalive settings |
| Network path | Resets, packet loss, MTU, a firewall or security-group change, NAT port exhaustion | Fails on specific routes or hosts. Network-level capture |
| Partial failure | The call succeeded at the dependency and the response was lost. The caller retried a non-idempotent operation | Dependency-side record of the first call |
| Slow, not down | Latency rises without errors. Timeouts and queues upstream do the damage | Sections 2 and 6 |
| Dependency version | A client library upgrade changed defaults: timeouts, retries, TLS, serialisation | Lock-file diff. Library changelog |
| Regional or tenant-specific | Only some regions, accounts or shards | Group failures by those dimensions |

**The standing question for any dependency hypothesis:** a dependency misbehaving is a trigger (Layer 2). What did our system do about it, and was that the designed behaviour? "The gateway was slow" is rarely a complete root cause. Compare the sample incident: the gateway being slow was true, and the root cause was the service's own inconsistent timeouts.

Evidence about a dependency you cannot inspect is testimony unless you hold an artefact: the response body and headers, a status-page capture with time, a packet capture, the provider's request id.

## 10. Databases

| Mechanism | Evidence pattern | Discriminating check |
|---|---|---|
| Lock wait or deadlock | "Lock wait timeout", "deadlock detected", statements stuck behind a long transaction, DDL waiting on an open transaction | Lock and activity views. The database's deadlock log names both statements |
| Long or idle transaction | A transaction left open (by an exception path, a forgotten commit, an await inside it) holds locks and bloats | Idle-in-transaction sessions. Where the transaction begins and every way out of it |
| Connection pool | Section 6. Also: connections broken by a failover and still in the pool, server-side idle timeouts | Pool settings. Pre-ping or validation |
| Slow query | Plan change after statistics or data growth. Missing index. N+1 queries. Full scan on a filter | Query log with durations. Plan now versus before. Query count per request |
| Isolation anomalies | Lost update, write skew, non-repeatable read, phantom, at the configured isolation level | Section 4. The isolation level in force |
| Constraint violations | Unique, foreign-key, not-null, check. Often the symptom of a race (double insert) or of bad upstream data | Which constraint. Two inserts in the window |
| Migration | Schema changed under running code. A long migration locking a table. Code deployed before or after the migration it depends on | Migration and deploy timeline |
| Replica lag and failover | Stale reads. Writes to a demoted primary. Connections not re-established | Topology events at the time |
| ORM behaviour | Lazy loading after the session closed, implicit flushes, stale identity map, autocommit assumptions | The ORM's emitted SQL for the request |
| Limits | Max connections, statement timeout, temp space, row or packet size | Server error codes |

## 11. Queues, schedulers and background jobs

| Mechanism | Evidence pattern | Discriminating check |
|---|---|---|
| Poison message | One message fails every time, is redelivered, blocks or churns the consumer | Same message id across many attempts. Delivery count |
| At-least-once without idempotency | Duplicate side effects after a redelivery, rebalance or visibility-timeout expiry | Two handlings of one message id |
| Visibility or lease timeout shorter than processing | The message reappears while still being processed. Two workers on it | Processing duration against the timeout |
| Acknowledged before done, or never acknowledged | Lost work after a crash, or endless redelivery | Where the ack sits relative to the work and its failure paths |
| Ordering | Section 4 |  |
| Overlapping scheduled runs | A cron job takes longer than its interval. No lock. Two instances interleave | Start and end lines for consecutive runs |
| Missed or duplicated schedule | Scheduler down across a tick, DST shifts, multiple scheduler instances | Scheduler logs. Expected versus actual run times |
| Job killed | Time limit, memory limit, node eviction, deployment during the run. Ends with no error from the job | Supervisor, orchestrator or kernel logs (OOM kill). Exit code or signal |
| Position-dependent failure | Fails around the same count or elapsed time each run: token or connection lifetime, cursor timeout, memory growth, rate quota | Section 10 of `core/execution_reconstruction.md` |
| Unbounded batch | Memory or transaction size grows with input. Worked until the data grew | Input size over time against the failure onset |
| Retry storm | Failed jobs retried immediately and in bulk | Retry policy. Job arrival rate after a failure |
| Consumer lag | Nothing failed, everything is late | Lag metrics. Consumer throughput against production rate |
| Dead worker, live heartbeat | The worker loop died and a separate heartbeat thread keeps reporting healthy | Last work-progress line versus last heartbeat |

## 12. Configuration and environment

| Mechanism | Evidence pattern | Discriminating check |
|---|---|---|
| Value differs between environments | Works in staging. Fails in one region, one tenant, one host | Diff effective configuration (as printed at startup), not the files |
| Override precedence | Environment variable, flag, file and default disagree, and the winner is not the one assumed | The loader's precedence. The effective value logged |
| Stale process | Configuration changed and the process was not restarted or did not reload. Some instances have the new value | Process start time against change time, per instance |
| Type and unit | "30" seconds read as milliseconds. String "false" truthy. Timeout 0 meaning infinite, or immediate | How the value is parsed and consumed |
| Missing in one place | A secret, variable or mount absent on a new host, a new worker type, a cron environment | The failing process's actual environment |
| Feature flag | Enabled for a cohort. Changed at a time that matches the first failure | Flag audit log |
| Dependency version skew | Different lock-file resolution, base image, system library or runtime between hosts | Versions per instance |
| Locale, time zone, file system | Case-sensitive paths, default encoding, TZ, line endings, temp directory | The environment of the failing host against a healthy one |
| Capacity settings inconsistent | Worker count × pool size exceeds the database limit. Timeouts inverted between layers | The numbers side by side |

## 13. Deployment and change

**Signature.** A clear first occurrence with no traffic change.

| Mechanism | Evidence pattern | Discriminating check |
|---|---|---|
| Code regression | First failure shortly after a deploy. Only on instances running the new version | Version per failing instance. `git_suspects.py window`. Bisect if reproducible |
| Mixed versions during rollout | Old and new instances disagree on a format, a schema, a cache key | Failures only during the rollout window, involving one of each |
| Migration ordering | Code needs a column that is not there yet, or the reverse | Deploy and migration timeline |
| Dependency upgrade | Lock-file change in the deploy. Behavioural default changed | Diff of resolved versions |
| Infrastructure change | Load balancer, proxy, network policy, node type, kernel, runtime image | Infrastructure change log for the window |
| Data change | A bulk import, backfill or a new customer with unusual data | First failing record. Section 7 |
| Latent bug newly exposed | The defect is old. A change elsewhere made the trigger reachable or more frequent | `git blame` shows the defective lines are old. Find what changed the trigger's frequency |
| Cold start | Empty caches, lazy initialisation, connection warm-up after restart | Failures cluster in the first minutes after start |
| Revert did not fix it | State written by the bad version persists | Section 7, earlier failure left bad state |

A commit near the failure time is a lead. It becomes a cause when its diff is read and shown to produce the failure, and the version running at the failure time is confirmed. Deployed is not the same as merged.

## 14. Memory, process and platform

| Mechanism | Evidence pattern | Discriminating check |
|---|---|---|
| OOM kill | Process vanishes, no application error, exit code 137 or SIGKILL. Kernel or orchestrator log names it | `dmesg`, container status, memory graph climbing to the limit |
| Memory leak | Growth with uptime, GC time rising, then OOM or thrash | Section 6, leak by reference |
| Crash in native code | Segfault, abort, core dump. No language-level trace | Core dump, native stack, library versions |
| CPU throttling or starvation | Latency without load, timeouts across the board, container CPU limit hit | Throttling metrics. Noisy neighbour |
| Eviction, preemption, node failure | Termination with a grace period, or none | Orchestrator events |
| Health check kill | The process was working and slow. A probe failed and it was restarted mid-work | Probe configuration against observed latency. Restart count |
| File-descriptor, process, thread limits | `EMFILE`, `EAGAIN`, "can't start new thread" | `ulimit` and current counts |
| Stack overflow | Deep or unbounded recursion on unusual input | Trace of repeated frames. Input depth |
| Clock | Time jumps, skew between hosts, monotonic versus wall | Section 2 |

A process that dies without logging leaves its evidence outside itself: supervisor, orchestrator, kernel, the previous container's status. Collect those before concluding "no error".

## 15. Silent failures

The hardest class: nothing was logged, something did not happen.

| Mechanism | Evidence pattern | Discriminating check |
|---|---|---|
| Exception swallowed | Section 8 | Read every handler between the last log line and where the next should have been |
| Early return | A guard condition returned before the work, with no log | Each `return`, `continue`, `break` in the bracket |
| Background task died | Section 3. The loop that should be doing the work is gone | Is the worker's periodic line still appearing? |
| Never triggered | The scheduler, webhook, subscription or consumer never delivered the event | Evidence of the trigger arriving at all |
| Work done somewhere unexpected | Wrong tenant, wrong environment, wrong queue, dry-run mode on | Where the side effects actually are |
| Filtered out | A query, feature flag or permission check excluded the item | Evaluate the filter for the affected item |
| Process killed | Section 14 | External logs |
| Logging itself failed | Disk full, handler error, log level changed, pipeline dropping | Do *any* lines from that process appear after the time? |
| Success reported for failure | Exit 0, HTTP 200, "completed" logged before the work was confirmed | Compare the claim against the side effects |

Silent failures are almost always Mode B2: the deliverable is the instrumentation that would have made the failure loud, plus a check for the same silence elsewhere.

## 16. Quick index: from symptom to section

| You see | Start at |
|---|---|
| A cancellation-type exception | 1, then 2 |
| A timeout-type exception, or a round-number gap | 2, then 9, 6 |
| Many unrelated things fail in the same instant | 3 (blocked loop), 5 (stop-the-world), 14, 1 (shutdown) |
| Intermittent, load-dependent, vanishes when observed | 4, then 3 |
| No error, no progress | 5, then 15, 11 |
| Degrades with uptime, fine after restart | 6, then 14 |
| Wrong value or type error on specific records | 7, then 8 |
| The logged error is generic or the trace is short | 8 |
| Connection reset, 5xx, 429, TLS, DNS | 9 |
| Lock, deadlock, constraint, slow query | 10 |
| A job or consumer misbehaved | 11, then section 10 of `core/execution_reconstruction.md` |
| Works in one environment and not another | 12 |
| Started at a specific time | 13, then 9 (credentials, certificates), 12 (flags) |
| The process disappeared | 14 |
| Something simply did not happen | 15 |
