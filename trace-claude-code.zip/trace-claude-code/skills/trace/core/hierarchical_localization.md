# Hierarchical fault localization

The debugging philosophy TRACE is built around, and the procedure for applying it both with probes (when the failure can be re-run) and without them (when it cannot).

## Contents

1. The idea
2. Why it beats reading the code
3. The three stages
4. Running the stages with `probe.py`
5. Probe labels: making every probe distinguishable
6. Retrospective localization: existing logs as probes
7. Bisection: when there are too many candidates
8. Concurrency: when "the last probe" lies
9. Other languages
10. Hygiene and safety
11. From location to cause

---

## 1. The idea

Progressively narrow the search space, and at each level let evidence choose where to look next.

- **Stage 1: locate the responsible file.** Insert numbered print statements across files. The error occurs after entering file 56, so investigate file 56.
- **Stage 2: locate the responsible function.** Inside that file, add distinguishable print statements at function entries and before function calls. `hello`, then `helloO`, then `helloOO`: the last distinct marker printed identifies the failing execution path.
- **Stage 3: locate the root statement.** Repeat inside the responsible function until the precise statement or condition is isolated.

Each stage answers one question with one observation. Nothing is guessed. The output of each stage is the input of the next.

## 2. Why it beats reading the code

An agent asked to understand two hundred files and say where a bug came from will produce a fluent answer. Fluency is not evidence. The search space is too large for reading to be reliable, and the agent has no way to know which of several plausible locations is the real one.

Hierarchical localization replaces "understand everything, then guess" with "establish an increasingly precise chain of evidence". Three properties make it work:

- **Each step is cheap and decisive.** A probe either printed or it did not.
- **Errors do not compound.** If stage 1 points at the wrong file, stage 2 shows no failure inside it, and you know to back up one level. A wrong guess in a read-and-reason approach is carried silently to the end.
- **The cost is logarithmic.** Two hundred files, twenty functions in the suspect file, fifteen statements in the suspect function: three runs, not three thousand hypotheses.

The same narrowing applies when nothing can be re-run. The probes are then whatever the system already emitted: log lines, spans, stack frames, audit rows. Section 6 covers that.

## 3. The three stages

| | Question | Probe granularity | Result | Next |
|---|---|---|---|---|
| Stage 1 | Which file was executing when it failed? | One label per file, printed at entry to every function in the file | "Failure follows entry into F056" | Stage 2 on F056 |
| Stage 2 | Which function, and which call inside it? | One ENTER label per function, one CALL label before each statement that makes a call | "Reached `process_payment` CALL->`wait_for` L23 and nothing after" | Stage 3 on that function, or stage 2 on the callee's file if the callee is the suspect |
| Stage 3 | Which statement, with what values? | One label before every statement, optionally with selected variables | "Statement at L23 started with `attempt=2`; next probe never fired" | Layer 1 is now exact. Move to trigger and root cause |

Scope each stage as tightly as the evidence already allows. If a stack trace names the file, skip stage 1. If it names the function, skip stage 2. Stage 1 across an entire monorepo is rarely needed: restrict it to the packages on the candidate path from the call graph.

## 4. Running the stages with `probe.py`

All commands run from the repository root, against a reproduction environment or scratch copy (section 10).

**Stage 1**

```
python3 <skill-dir>/scripts/probe.py stage1 --root src --manifest INV/probes.json [--include "orders/*.py"] [--ctx]
<run the failing scenario, capturing stderr together with the normal log output>  2> run1.err
python3 <skill-dir>/scripts/probe.py analyze run1.err --manifest INV/probes.json
python3 <skill-dir>/scripts/probe.py remove --manifest INV/probes.json
```

`stage1` numbers the files (F001, F002, ...) and inserts, as the first statement of every function, a line such as:

```python
print("[TRACE-PROBE S1 F056 services/payment.py]", file=__import__("sys").stderr, flush=True)  # TRACE-PROBE
```

`analyze` prints the collapsed sequence of probes and names the last one reached before the first error-looking line. The numbering is saved in the manifest so that F056 can be resolved back to a path.

**Stage 2**

```
python3 <skill-dir>/scripts/probe.py stage2 --file src/services/payment.py --manifest INV/probes.json [--ctx]
<run>  2> run2.err
python3 <skill-dir>/scripts/probe.py analyze run2.err --manifest INV/probes.json
python3 <skill-dir>/scripts/probe.py remove --manifest INV/probes.json
```

Each function gets `F056.fn02 process_payment ENTER`, and each statement containing a call gets `F056.fn02 process_payment CALL->wait_for+external_payment_api L23`.

**Stage 3**

```
python3 <skill-dir>/scripts/probe.py stage3 --file src/services/payment.py --function process_payment \
        --vars attempt,last_error --manifest INV/probes.json
<run>  2> run3.err
python3 <skill-dir>/scripts/probe.py analyze run3.err --manifest INV/probes.json
python3 <skill-dir>/scripts/probe.py remove --manifest INV/probes.json
python3 <skill-dir>/scripts/probe.py status --manifest INV/probes.json     # must report 0 files still probed
```

Every statement in the function, including those inside loops, branches, `try` bodies and handlers, gets `process_payment L23 stmt#05 Assign`, followed by the requested variables. Variables are read with `locals().get(name, "<unbound>")`, so a variable not yet assigned prints `<unbound>` instead of raising.

**Recording the result.** The analysis output is evidence. Add it with `class=runtime`, grade FACT, the exact commands as the locator and the "last probe reached" lines as the excerpt:

```
python3 <skill-dir>/scripts/evidence_collector.py add --inv INV --class runtime --grade FACT --by verifier \
    --command "probe.py stage3 --file src/services/payment.py --function process_payment --vars attempt; <run>; probe.py analyze" \
    --excerpt "<the 'last probe reached' lines>" \
    --summary "Stage 3: last statement started before the failure was L23 with attempt=2"
```

**What the tool does to keep this safe.** Every inserted line ends with `# TRACE-PROBE`. Insertion is refused if the resulting file would not parse. A manifest stores each file's hash before probing, and `remove` verifies the file is byte-identical to the original afterwards, reporting any mismatch. A file that already contains probes is refused a second stage until `remove` has run, so stages cannot stack. Statements that share a line with something else (`if x: return`, `a = 1; b = 2`) are reported as not probed instead of being rewritten.

## 5. Probe labels: making every probe distinguishable

The original technique's `hello`, `helloO`, `helloOO` exists for one reason: when the output shows a marker, you must know exactly which line printed it. Two probes with the same text destroy the stage. TRACE's convention:

| Stage | Label | Example |
|---|---|---|
| S1 | `F<file number> <relative path>` | `[TRACE-PROBE S1 F056 services/payment.py]` |
| S2 entry | `F<nnn>.fn<nn> <qualified function> ENTER` | `[TRACE-PROBE S2 F056.fn02 process_payment ENTER]` |
| S2 call | `F<nnn>.fn<nn> <function> CALL-><callees> L<line>` | `[TRACE-PROBE S2 F056.fn02 process_payment CALL->wait_for L23]` |
| S3 | `<function> L<line> stmt#<nn> <statement type>` | `[TRACE-PROBE S3 process_payment L23 stmt#05 Assign]` |

When placing probes by hand (other languages, or a spot the tool skipped), follow the same convention and keep the `TRACE-PROBE` marker comment at the end of the line so `probe.py analyze` and `probe.py remove` both recognise it.

Add context only when it discriminates. `--ctx` appends the thread name. `--vars` in stage 3 prints named locals. In async code, print the task name by hand where needed (see section 8). Do not print whole objects, request bodies, credentials or personal data.

## 6. Retrospective localization: existing logs as probes

When the failed execution cannot be repeated, run the same three stages using what the system already wrote. This is the Mode A form of the technique, and it is where most investigations start.

**Stage 1 without probes: which component.**

1. Filter every available log to the failing correlation key (`log_parser.py --corr <id>`).
2. List which loggers, services, modules or files emitted lines for that key, in time order. Most logging formats carry the logger name, module or source file.
3. The last component that logged before the failure, and the first that should have logged and did not, bracket the failing component.
4. Cross-check with the stack trace if there is one: `stacktrace_parser.py` gives the application frames in order.

**Stage 2 without probes: which function.**

1. In the suspect component, list every log statement in the source (search for the logging calls). Each one is a fixed probe with a known location.
2. Mark which of them fired for this key and which did not. The failure lies between the last one that fired and the first one that should have fired next.
3. Use the call graph to list the functions that lie between those two points (`call_graph.py callees`, `paths`). That is the candidate set.

**Stage 3 without probes: which statement.**

1. Between the last fired log statement and the next expected one, read every statement. For each, ask whether it can raise, block, be cancelled, return early, or behave differently for this input.
2. Use the stack trace's line number if there is one: it is a stage-3 probe that the runtime inserted for you.
3. Use message parameters. A log line that printed `attempt=1 timeout=0.6s` is a stage-3 variable dump.

**What changes compared with real probes.**

- The probes are sparse and were placed by someone with other purposes. The bracket you get may contain fifty lines of code and three awaits. Say so. Record the bracket as a FACT ("between payment.py:19 and payment.py:24") and anything narrower as INFERENCE.
- A log statement that did not fire is absence evidence. It counts only if the log level in force would have emitted it, the log covers that time, and the line is not conditional. Check all three before relying on it.
- When the bracket is too wide to discriminate between hypotheses, that width is precisely the instrumentation gap to close: it tells you where the next occurrence needs function-entry and checkpoint events (`core/instrumentation_playbook.md`).

## 7. Bisection: when there are too many candidates

The stages are a three-level search. The same idea works at any level by halving.

- **Across statements.** In a long function, put probes at the quarter points first. One run tells you which quarter. Faster than fifty probes when output is expensive to capture.
- **Across a pipeline.** For a wrong value that travels through ten transformations, print it after step 5. Correct there means the corruption is in steps 6 to 10.
- **Across records.** A batch of 40,000 records fails. Run the first half. Halve again. Sixteen runs find the record. Then ask what distinguishes it.
- **Across commits.** `git bisect` halves history. See `git_suspects.py bisect-plan`: always in a separate worktree, never in a checkout a live process is serving from.
- **Across configuration.** Two environments, one works. Halve the configuration differences.
- **Across time.** A failure that appears only after hours of uptime: log the suspect resource (pool in-use count, queue depth, memory, open handles) at intervals and find when it departs from baseline.

Each bisection step is a prediction with a check. Record the decisive ones as evidence.

## 8. Concurrency: when "the last probe" lies

In single-threaded synchronous code, the last probe printed is the last thing that ran before the failure. In async and multi-threaded code it is only the last thing that ran anywhere.

- **Interleaving.** Probes from several tasks or threads are mixed in the output. Use `--ctx` (thread name), and for asyncio print the task name by hand in stage 3. `probe.py analyze` prints the last probe per thread when more than one thread appears.
- **Cancellation and timeouts.** A cancelled task's exception surfaces at whichever `await` it happened to be suspended on. The statement the stage-3 probe points to is where the task was waiting, not what went wrong. The cause is whoever called cancel. Stage 3 gives you Layer 1 exactly and tells you nothing about Layer 2. See `core/execution_reconstruction.md`.
- **Probe effect.** Printing takes time and can change the interleaving. A race that disappears when probed is still a race: record that observation as evidence in its own right, and switch to lighter instrumentation (counters, an in-memory ring buffer dumped at failure) or to reasoning from the code with the concurrency analyst.
- **Buffered output.** Probes write to stderr with flush for this reason. If the process is killed with SIGKILL or the container is torn down, even flushed output can be lost in transit. Check that the output file's last line is complete.
- **Multiple processes.** Worker pools run the same code in several processes. Add the process id to labels by hand, or capture each worker's stderr separately.

## 9. Other languages

`probe.py stage1/2/3` inserts automatically for Python. For other languages place the probe lines by hand, with the same labels and the trailing marker. `probe.py snippet --lang <lang>` prints the line to use:

| Language | Probe line |
|---|---|
| JavaScript / TypeScript | `console.error("[TRACE-PROBE S2 <label>]"); // TRACE-PROBE` |
| Go | `fmt.Fprintln(os.Stderr, "[TRACE-PROBE S2 <label>]") // TRACE-PROBE` |
| Java / Kotlin | `System.err.println("[TRACE-PROBE S2 <label>]"); // TRACE-PROBE` |
| Ruby | `$stderr.puts "[TRACE-PROBE S2 <label>]" # TRACE-PROBE` |
| Rust | `eprintln!("[TRACE-PROBE S2 <label>]"); // TRACE-PROBE` |
| C# | `Console.Error.WriteLine("[TRACE-PROBE S2 <label>]"); // TRACE-PROBE` |
| PHP | `fwrite(STDERR, "[TRACE-PROBE S2 <label>]\n"); // TRACE-PROBE` |

`probe.py analyze` reads the output regardless of language. `probe.py remove --root <dir>` deletes every line that ends with the marker comment in `.py .js .jsx .ts .tsx .mjs .cjs .go .java .kt .rb .rs .cs .php` files. Because hand-placed probes are not in the manifest, confirm the cleanup with `git diff` afterwards. In Go, an added `fmt`/`os` import must be removed by hand if nothing else uses it.

Compiled and bundled code: probe the source and rebuild. If a stack trace points into minified or transpiled output, map it back with the source map before choosing where to probe. If you cannot rebuild, you cannot probe: use retrospective localization and Mode B2.

## 10. Hygiene and safety

1. **Never probe a live production checkout.** Probing edits source files. Use a reproduction environment, a branch, or a scratch copy. If the only place the bug occurs is production, you are in Mode B2: propose reviewed, deployable instrumentation instead.
2. **One stage at a time.** Insert, run, analyse, remove. Then the next stage.
3. **Commit nothing with probes in it.** Before reporting: `probe.py status` must show zero probed files, and `git status`/`git diff` must show no probe lines.
4. **If `remove` reports a mismatch**, the file was edited while probed. Inspect with `git diff`. Do not continue until the difference is understood.
5. **Probes go to stderr.** They must not contaminate stdout that another program parses.
6. **No secrets or personal data** in `--vars`. Print lengths, types, ids or hashes instead.
7. **Hot paths.** A stage-3 probe inside a loop that runs a million times produces a million lines. Bisect the loop index, or add the probe by hand under a condition.
8. **Tests are a fine harness.** The cheapest reproduction is often an existing test with the failing input. Probe, run that one test, analyse.

## 11. From location to cause

Localization ends with a statement. That is Layer 1. It is the start of the root-cause analysis, not the end.

At the isolated statement, ask in order:

1. **What exactly failed here?** Exception type, value, the state of each operand. Stage 3 with `--vars` answers this.
2. **Was this statement wrong, or was it handed something wrong?** If the inputs were already bad, the defect is upstream: run the stages again on whatever produced them.
3. **Was it interrupted from outside?** Cancellation, timeout, signal, shutdown. If so, the cause is in whoever interrupted it. Find the caller that owns the timer or the cancel.
4. **Why this time and not the other ten thousand times?** That difference is the trigger, Layer 2.
5. **What allowed the trigger to cause a failure?** That is the root cause, Layer 3: the missing check, the wrong assumption, the inconsistent configuration, the unhandled case.

Then write the hypothesis in the schema and let it compete.
