# TRACE report template

`scripts/report_generator.py` produces `final_report.md` from the ledgers, so in normal operation you do not write this file by hand. This document is here for three reasons: to show what the generator produces and why, to give you the structure when the scripts are unavailable, and to tell you how to write the one section the generator cannot write for you (section 7, the fix).

The deliverable must be much more useful than "the error is in file X".

## Rules for the whole report

1. **The wording never exceeds the confidence.** A PROVISIONAL verdict says "pending confirmation of X". Only CONFIRMED says "the root cause is".
2. **Every claim carries its evidence ids**, and inference-grade support is marked as such.
3. **The three layers stay separate.** Sections 1, 2 and 3 are Layer 3, Layer 1 and Layer 2 respectively, and they are not interchangeable.
4. **Inferred path steps are labelled.** A path with unobserved steps is normal and honest; a path pretending to be fully observed is a defect.
5. **Unverified findings are labelled on every line they appear.**
6. **No agent count, no process narrative.** The reader wants the cause, the evidence and the fix. How many agents ran is not in the report.
7. **One screen of value at the top.** The header table and section 1 should let a reader decide what to do.

## The structure

### Header

A table: error, first observed, service, mode (A retrospective or B instrumented), confidence. The confidence belongs in the header because it changes how every other line should be read.

### 1. Root cause

**Layer 3.** The standing property of the system that made this failure possible, in one or two sentences, followed by the hypothesis statement in full, then the hypothesis id, its author, its lens, its score and its margin over the runner-up.

If the verdict is INSUFFICIENT_EVIDENCE, this section says **"Not determined"**, lists the reasons, and gives a table of the leading candidates with their scores and proposed root causes. It does not pick one anyway. That is the whole point of having the verdict.

### 2. Failure location

**Layer 1.** Where the exception surfaced: a `file:line`, with the function. One line. It needs no explanation and it explains nothing.

### 3. Originating trigger

**Layer 2.** The event or condition that made this execution fail when others succeeded. If the champion is only a leading candidate, say so inline.

### 4. Execution path

The ordered path, outermost first, as an indented tree. Every step marked `[observed]` or `[inferred]`, with its evidence ids. Below the tree, a sentence naming which steps are inferred and therefore come from reading the code rather than from runtime evidence, or a sentence saying every step is backed by runtime evidence.

### 5. Evidence

Four tables and two lists:

- **Supporting**: id, grade, class, what it shows, where. The "where" is a file and line range, or the exact command, so the reader can re-check it.
- **Contradicting or complicating**: id, grade, what it shows, and whether it was addressed. An unaddressed contradiction appears in bold as **no**.
- **Predictions tested**: id, the prediction, the check, the result, the evidence.
- **Assumptions not checked**, as a list. Declared assumptions are a feature, not an embarrassment.
- **What would prove this wrong**, as a list: the falsifiers. A reader who disagrees with the report should be told exactly where to attack it.
- **Alternatives considered**: every other hypothesis, its lens, its status, its score, and why it lost or what about it is unresolved. Then a collapsed tournament record with each round's totals, caps and rationale.

Ledger totals and any stale evidence excluded from scoring go at the end of the section.

### 6. Other discovered issues

Every finding: id, title, location, severity, **status**, verified yes or no, and whether it relates to this bug. Followed by the sentence that only `Confirmed` findings are established and the rest are leads recorded in the knowledge base.

This section is why the losing investigators' work was worth paying for. Do not trim it because it is not about this incident.

### 7. Recommended fix

The section the generator takes from `--fix-file`, because it needs judgement. Write it as numbered items, in this order:

1. **The Layer 3 fix.** Address the standing property. Name files and lines.
2. **The Layer 2 mitigation**, if the trigger can be made harmless or less frequent, and if that is worth doing in its own right.
3. **The failure-mode fix.** If the system failed in an undesigned way (a cancellation surfacing as a generic 500, a cleanup path that did not run), make it fail in a designed way even when the trigger recurs.
4. **The observability fix.** Whatever made this investigation slow: a missing correlation id, an unlogged cancel, a swallowed exception, a missing outcome-on-exit. This is the item that makes the *next* investigation cheap, and it is the one most often left out.
5. **Any data repair**, if bad state was written: how to identify the affected records and how many there are.

For each item, state what it changes for the healthy path. Longer budgets mean slower failures. New locks mean new contention. More retries mean more load on a struggling dependency. A fix with no stated cost has not been thought through.

End with: the regression test that fails without the fix, and the signal to watch after deployment with its expected change.

If the verdict is PROVISIONAL or INSUFFICIENT, this section contains mitigations and the instrumentation plan, **labelled as such**, and the generator adds a line saying the root cause is not established. Recommending a confident code change on a provisional diagnosis is how a wrong analysis becomes a second incident.

### 8. Confidence

The level, the sentence that defines it, the reasons from the verdict, the verification result and verifier, and then the outstanding checks: for each untested prediction, the command that would run it. A reader who wants more certainty should be able to see exactly what to do and in what order.

## Writing the fix file

`INV/fix.md` is plain markdown, numbered items, that the generator inserts verbatim. Example shape:

```markdown
1. **Make the budgets consistent.** Give the payment client one overall deadline derived from the
   request budget, so its retries always finish, or fail in its own handled way, before the caller
   gives up. Either raise `REQUEST_TIMEOUT_S` above the client's worst case (2.4s) or cut the retry
   policy to fit inside 1.0s. `app/config.py:3-6`. Cost: a longer budget means slower failures under
   gateway degradation; a shorter retry policy means fewer recoveries from transient errors.
2. **Fail in a designed way.** When the request budget expires, `api_handler` should return 504 and
   log it as a timeout rather than surfacing `CancelledError` as a generic 500. `app/api.py:14-20`.
3. **Make cleanup cancellation-safe.** Move `release_inventory` into a `finally` (shielded if it must
   complete) so the reservation and its connection are returned on cancellation too.
   `app/orders.py:24-30`. This fixes finding F-001.
4. **Carry correlation into the cancel path.** Log `request_id`, elapsed time and remaining budget at
   the moment `task.cancel()` is called, so the next occurrence needs no stack-trace archaeology.

Regression test: `tests/test_orders.py::test_slow_gateway_yields_handled_timeout`, which fails today
with `CancelledError`. After deployment, watch the rate of 504s versus 500s on `/orders`.
```

## Writing by hand

Keep the eight sections and their order. Keep the evidence tables with their grades and locators. Keep the status column in section 6. Keep the confidence in the header and in section 8. Those are the parts that make the report checkable by someone who was not there, which is the only property that matters once you have left.

The report ends with the guiding line, which is not decoration: it is the standard the report must have met.

> Every error has an execution history. Every hypothesis needs evidence. Every conclusion must survive verification.
