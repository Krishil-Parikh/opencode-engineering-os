# TRACE for Claude Code

Tournament-based Root-cause Analysis and Code Examination: an autonomous, adversarial debugging and
root-cause analysis skill.

> Every error has an execution history. Every hypothesis needs evidence. Every conclusion must survive
> verification.

## Install

**Project** (shared with the team through the repository):

```bash
mkdir -p .claude/skills .claude/agents
cp -r skills/trace   .claude/skills/
cp    agents/*.md    .claude/agents/
```

**Personal** (every project on this machine):

```bash
mkdir -p ~/.claude/skills ~/.claude/agents
cp -r skills/trace   ~/.claude/skills/
cp    agents/*.md    ~/.claude/agents/
```

Restart Claude Code, or start a new session, so the skill and the 14 subagents are discovered.

## Use it

```
/trace asyncio.exceptions.CancelledError in services/payment.py, logs/app.log, started 09:47 today
```

Or just describe the failure — the skill's description is written to trigger on "root cause", "why did
this fail", "investigate this incident", "RCA", "postmortem", "it only fails in production" and
"intermittent". Verify it is discoverable with `/skills`, and check a subagent with `/agents`.

## How it fits together on Claude Code

| Piece | Where it goes | What it is |
|---|---|---|
| `skills/trace/SKILL.md` | `.claude/skills/trace/` | The orchestrator's operating manual. Loaded on demand, invocable as `/trace` |
| `skills/trace/core/`, `agents/`, `scripts/`, `schemas/`, `reports/`, `examples/` | beside `SKILL.md` | Progressive disclosure: read only when a step calls for them. Reference them with `${CLAUDE_SKILL_DIR}/...` |
| `agents/trace-*.md` | `.claude/agents/` | 14 subagents, launched with the Task tool as `subagent_type` |

The main agent is the orchestrator: it keeps the evidence ledger and is the only role that talks to you.
Subagents run in their own context, which is what keeps the roles independent — an investigator never
sees another investigator's hypothesis, and the verifier is briefed from the ledger files rather than
from the debate.

Phase-1 collectors and phase-2 investigators are dispatched in a single turn so they run in parallel.
Duels are sequential, because each depends on the previous winner. If the Task tool is unavailable, the
skill falls back to playing each role in sequence and says so in the report.

## The 14 subagents

| Agent | Phase | Lens |
|---|---|---|
| `trace-log-analyst` | 1 Collect | Correlated timeline, gaps, log coverage |
| `trace-stacktrace-analyst` | 1 Collect | Frames, Layer 1, exception chains |
| `trace-codebase-mapper` | 1 Map | Static call graph, possible paths, hotspots |
| `trace-git-investigator` | 1 Collect | Regression or latent defect, read-only git |
| `trace-telemetry-investigator` | 1 Collect | Spans, metrics, live-process instruments |
| `trace-execution-path-analyst` | 2 Investigate | What actually ran, observed versus inferred |
| `trace-exception-propagation-analyst` | 2 Investigate | Caught, translated, swallowed, replaced |
| `trace-concurrency-analyst` | 2 Investigate | Interleaving, races, blocked loops, stalls |
| `trace-cancellation-analyst` | 2 Investigate | Who ended it, timeout hierarchy, cleanup |
| `trace-data-state-analyst` | 2 Investigate | Values, stored state, resources and leaks |
| `trace-dependency-analyst` | 2 Investigate | The peer's behaviour and our handling of it |
| `trace-adversarial-reviewer` | 3 Compete | Duel judge, scoring against the ledger |
| `trace-verifier` | 4 Verify | Tries to refute the champion |
| `trace-knowledge-curator` | 8, 10 | Findings, statuses, the persistent knowledge base |

## What you get

```
skills/trace/
├── SKILL.md                     the operating manual: the ten steps, the rules, the commands
├── CORE.md                      what the portable core contains, and its honest limits
├── core/                        ten protocol documents (read the one you need, not all of them)
│   ├── investigation_engine.md      the spine: roles, tiers, every step's exit gate
│   ├── hierarchical_localization.md file, then function, then statement — with and without probes
│   ├── evidence_protocol.md         FACT / INFERENCE / ASSUMPTION, absence, correlation, staleness
│   ├── execution_reconstruction.md  the three layers, timelines, gaps, async, cancellation, batches
│   ├── instrumentation_playbook.md  Mode B: what to add, where, snippets, production safety
│   ├── hypothesis_scoring.md        criterion anchors, ledger caps, thresholds, judging rules
│   ├── tournament_protocol.md       entry requirements, brackets, duels, cross-examination
│   ├── root_cause_verification.md   the verification checklist and the counterfactual
│   ├── knowledge_base.md            workspace layout, finding fields, status transitions
│   └── failure_signatures.md        15 failure families, their mechanisms, discriminating checks
├── agents/                      one standalone brief per role (+ _submission.md for the six lenses)
├── scripts/                     10 working Python 3.8+ tools, standard library only
├── schemas/                     JSON Schema for evidence, hypotheses, findings, tournament
├── reports/investigation_template.md
└── examples/sample_incident/    a runnable incident and a complete scripted investigation
```

## Try it before you trust it

```bash
cd skills/trace/examples/sample_incident
python3 run_incident.py          # reproduces the failure, writes logs/app.log
bash walkthrough.sh              # the full ten-step investigation, scripted
cat debugging/investigations/BUG-001/final_report.md
```

The walkthrough runs all ten steps against the sample incident: it registers three rival hypotheses,
eliminates one by a refuted prediction and one on evidence score, verifies the survivor with a
counterfactual experiment, and produces a CONFIRMED report plus three knowledge-base entries. It is the
best documentation of the order of operations.

## The ten steps

1. **Receive** — exception, message, timestamp, service, constraints
2. **Collect** — logs, traces, stack traces, source, git
3. **Map** — functions, dependencies, possible execution paths
4. **Hypothesize** — independent explanations
5. **Investigate** — specialised agents, one lens each, working alone
6. **Compete** — evidence-based adversarial duels
7. **Verify** — independent check of the strongest hypothesis
8. **Preserve** — every meaningful secondary finding
9. **Report** — actionable root-cause analysis
10. **Learn** — verified patterns to the persistent knowledge base

## The design decisions that matter

**Evidence-driven, not debate-driven.** A debate selects the most convincing explanation; an
investigation selects the explanation best supported by reality. `score.py` caps every criterion score
at what the evidence ledger contains, so persuasion cannot buy a verdict. One refuted prediction
eliminates a hypothesis outright, whatever its total would have been.

**Three layers, kept separate.** Where the failure surfaced, what triggered it this time, and what
standing property made it possible. A report that stops at the first is not a root-cause analysis.

**Start with 6 to 8 agents, not 60.** Expand only when a specific open question needs a lens nobody has
used. No skill can guarantee a number of simultaneous agents in any case: spawning, concurrency limits
and tool permissions belong to the host platform.

**Insufficient evidence is a first-class verdict.** Without it, the format itself pressures an agent
into inventing a root cause because a winner has to be produced.

**Losers' findings are retained.** The database theory that lost may have found a real connection leak.
It goes to the knowledge base with an honest status, and re-observation never upgrades that status.

## Honest limits

- Source analysis reconstructs *possible* call paths. It cannot recover runtime history that was never
  logged or traced. The ledger's grades keep that visible in every sentence.
- A static call graph over-approximates and is blind to dynamic dispatch, callbacks and framework wiring.
- Automatic probe insertion is Python-only. Other languages get snippets to place by hand; the analysis
  and removal tooling works for all of them.
- The scoring weights and thresholds are engineering defaults in `debugging/trace_config.json`, not
  validated constants.
- Probes edit source files. They belong in a reproduction environment or a scratch copy, never a live
  checkout. `probe.py status` must report zero probed files before you report.
- The scripts need Python 3.8 or later and nothing else. No network access, no third-party packages.

## Workspace it creates

```
debugging/
├── investigations/BUG-001/   context, error_context, brief, timeline, evidence, hypotheses,
│                             tournament, findings, duels/, verification, fix, final_report
├── knowledge_base/           findings.json + rendered markdown by category and status
├── trace_config.json         scoring weights and thresholds for this codebase
└── index.md                  every investigation with its confidence, and knowledge-base counts
```

Commit `debugging/` for shared debugging memory, but check excerpts for secrets and personal data
first, and consider `.gitignore`-ing `investigations/*/logs/`.
