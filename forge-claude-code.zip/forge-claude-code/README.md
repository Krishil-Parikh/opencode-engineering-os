# FORGE for Claude Code

Framework for Optimized and Reliable Generation Engineering: a competitive, measurement-driven coding
skill.

> Never accept the first working implementation. Generate alternatives, challenge them, measure them,
> simplify them and verify the winner.

## Install

**Project** (shared with the team through the repository):

```bash
mkdir -p .claude/skills .claude/agents
cp -r skills/forge  .claude/skills/
cp    agents/*.md   .claude/agents/
```

**Personal** (every project on this machine):

```bash
mkdir -p ~/.claude/skills ~/.claude/agents
cp -r skills/forge  ~/.claude/skills/
cp    agents/*.md   ~/.claude/agents/
```

Restart Claude Code, or start a new session, so the skill and the 11 subagents are discovered.

## Use it

```
/forge implement top-N selection over 100k records; speed matters, we are cautious about new deps
```

Or just describe the work — the description is written to trigger on "which implementation should we
ship", "make this faster", "is this the simplest way", "optimise this", "benchmark these approaches",
and on the four behavioural guidelines. Verify discovery with `/skills`, and check a subagent with
`/agents`.

## How it fits together on Claude Code

| Piece | Where it goes | What it is |
|---|---|---|
| `skills/forge/SKILL.md` | `.claude/skills/forge/` | The orchestrator's operating manual. Loaded on demand, invocable as `/forge` |
| `skills/forge/core/`, `agents/`, `scripts/`, `schemas/`, `reports/`, `examples/` | beside `SKILL.md` | Progressive disclosure: read when a phase calls for them. Reference with `${CLAUDE_SKILL_DIR}/...` |
| `agents/forge-*.md` | `.claude/agents/` | 11 subagents, launched with the Task tool as `subagent_type` |

The main agent is the orchestrator: it owns the frozen spec and every record, and it is the only role
that talks to you. Subagents run in their own context, which is what keeps the implementers independent
— none of them sees another's candidate, or even knows which strategies the others hold.

Implementers and reviewers are dispatched in a single turn so they run in parallel. The benchmark
engineer runs **alone**, because a benchmark competing with other work is a benchmark you cannot trust.

## The 11 subagents

| Agent | Phase | Role |
|---|---|---|
| `forge-requirement-analyst` | 1 | The contract, measurable criteria, the baseline question |
| `forge-test-designer` | 2 | The suite and the drivers, written from the spec |
| `forge-minimal-implementer` | 3 | The least code that satisfies every clause |
| `forge-performance-implementer` | 3 | Best expected behaviour, with a testable prediction |
| `forge-maintainability-implementer` | 3 | The version the next person would want to inherit |
| `forge-alternative-architect` | 3 | A genuinely different architecture |
| `forge-benchmark-engineer` | 6 | Calibration, measurement, scaling, honest ties |
| `forge-adversarial-reviewer` | 5 | Attacks candidates it did not write, with a basis |
| `forge-security-reviewer` | 5 | The security gate, with named evidence |
| `forge-simplification-agent` | 7 | Removes things; the harness decides whether it worked |
| `forge-knowledge-curator` | 9 | Measured facts with scope, patterns, rejected approaches |

## What you get

```
skills/forge/
├── SKILL.md                      the operating manual: the nine phases, the rules, the commands
├── CORE.md                       what the portable core contains, and its honest limits
├── core/                         twelve protocol documents (read the one you need)
│   ├── forge_engine.md               the spine: roles, tiers, every phase's exit gate
│   ├── requirements_protocol.md      the contract, measurable criteria, the baseline question
│   ├── candidate_generation.md       the five strategies, independence, avoiding monoculture
│   ├── correctness_and_tests.md      suite design, the drivers, differential testing, mutation sanity
│   ├── evaluation_gates.md           constraint-first evaluation, gate kinds, retirement
│   ├── measurement_protocol.md       calibration, statistics, scaling, memory, how benchmarks lie
│   ├── pareto_selection.md           dominance with ties, the five verdicts, naming a trade-off
│   ├── adversarial_review.md         the attack catalogue, challenge kinds, resolution
│   ├── simplification_pass.md        the eight questions, verification, what not to remove
│   ├── antipatterns.md               the overengineering catalogue, with detectors
│   ├── engineering_guidelines.md     the four behavioural principles, properly attributed
│   ├── knowledge_base.md             workspace layout, entry kinds, scope and expiry
│   └── integration_with_trace.md     using FORGE alongside the TRACE debugging skill
├── agents/                       thirteen standalone briefs (+ _candidate_submission.md)
├── scripts/                      eleven working Python 3.8+ tools, standard library only
├── schemas/                      JSON Schema for spec, candidates, measurements, challenges, decisions
├── reports/report_template.md    what the report contains, and what belongs in the notes
└── examples/top_n/               a runnable competition with five candidates and two real bugs
```

## Try it before you trust it

```bash
cd skills/forge/examples/top_n
bash walkthrough.sh              # about a minute; needs pytest, and numpy for one candidate
cat forge/tasks/TASK-001/final_report.md
```

Five candidates compete on "return the top 100 of 100,000 records by score". What happens:

- Two candidates misread the same contract clause, and `harness.py differential --shrink` localises it
  to a **three-record input** showing exactly which candidates returned what.
- A third passes the entire 37-test suite while violating a clause at the sizes that matter, because the
  test for that clause used five records and the candidate switches to a process pool above twenty
  thousand. A reviewer reading the **design** finds it; the fix is a new gate, which means unfreezing
  the spec and re-running everything.
- The measurement contradicts the obvious reading of the code: the NumPy candidate has to build arrays
  from dicts first, which looks fatal, and it is several times faster at n=100,000.
- The verdict is `TIE_NEEDS_PRIORITIES`, because the fastest candidate costs a dependency and nobody
  said whether that matters. FORGE states the trade-off with the figures and hands it back.
- The accepted simplification makes the leading candidate **two lines longer**.

## The nine phases

1. **Requirements** — the contract, measurable criteria, the baseline question; freeze and hash
2. **Test design** — the suite from the spec, before any candidate exists
3. **Candidates** — independent implementations under distinct mandates
4. **Gates** — correctness first; differential testing; fix or retire
5. **Review** — attack what the tests did not, with a basis for every claim
6. **Measurement** — calibrate, then measure; medians, spreads, scaling
7. **Simplification** — remove things, then prove nothing broke
8. **Selection** — eligibility, then the Pareto front, then a verdict
9. **Report and learn** — the deliverable, and the facts worth keeping

Each phase has an exit gate in `core/forge_engine.md`.

## The design decisions that matter

**No single score.** Collapsing correctness, speed, memory, complexity and dependency cost into one
weighted number means the answer comes from the weights, and the weights were invented. FORGE ranks on
a Pareto front; when more than one candidate survives it names the trade-off and asks.

**Correctness is a filter, not a criterion.** A candidate failing one mandatory gate is out, whatever
its numbers. Speed is not a defence against being wrong.

**A difference below the noise is not a difference.** `bench.py calibrate` measures the same candidate
twice to find what the host's noise actually is, and anything below that is reported as a tie.

**Fewer lines are not better.** Size is reported, never ranked on by default.

**The baseline competes.** If the standard library already does this, it is candidate C-01 and
everything else must beat it on a measurement. Sometimes the right outcome is to write no new code.

**Three of the five verdicts are not a winner.** `TIE_NEEDS_PRIORITIES`, `NO_CANDIDATE_PASSES` and
`INSUFFICIENT_MEASUREMENT` are first-class results.

## Where the ideas come from

| Source | Borrowed | What it actually is |
|---|---|---|
| Community "Karpathy guidelines" skill | Think before coding, simplicity first, surgical changes, goal-driven execution | A **community-authored** skill (originally Forrest Chang, later Multica AI) built from Karpathy's public criticisms of LLM code. **Not an official Karpathy release.** It shapes behaviour; it generates and benchmarks nothing. FORGE treats it as the floor |
| Karpathy's `autoresearch` | Experiment, measure, keep or discard | An agent edits `train.py`, trains under a fixed 5-minute budget, and the change is kept or reverted by **validation bits per byte**. One objective; general software has several, which is why FORGE uses a Pareto front |
| AgentCoder | Separate coding, testing and execution | Never let the coding agent be the only judge of its own code |
| SWE-Debate | Adversarial multi-agent reasoning | Dependency-graph traces, specialised perspectives, three debate rounds, then an MCTS patch agent. Agents challenge assumptions rather than voting |
| RankAgent | Generate and systematically rank alternatives | Ranking by generated tests rather than by asking a model which looks best |

## Honest limits

- The scripts measure time, memory, scaling, complexity and dependency count. **Maintainability and
  readability are not measured**; they are argued in review and used to separate candidates the
  measurements cannot.
- Static analysis is precise for Python (AST) and heuristic for other languages, which it states.
- `tracemalloc` cannot see C-extension allocations, so memory is compared with resident-set growth.
- A measured growth exponent describes the sizes tested; it is not a proof of asymptotic class.
- Measurements are comparable within one host and one session. The tooling records the host and refuses
  to compare across changed code or spec hashes.
- The benchmark drivers shipped here are Python. For another language, write the equivalent drivers; the
  JSON contract on stdin and stdout is all `bench.py` requires.
- The defaults in `forge_config.json` are engineering defaults, not validated constants.
- The scripts need Python 3.8 or later and nothing else. The example additionally uses pytest, and
  numpy for one of its five candidates.

## Workspace it creates

```
forge/
├── tasks/TASK-001/     spec (frozen, hashed), requirements, candidates/, tests/, gates,
│                       measurements, complexity, differential, reviews, simplification,
│                       decisions, notes, final_report
├── knowledge_base/     measured facts, patterns, rejected approaches (JSON + rendered markdown)
├── forge_config.json   benchmark and selection defaults for this codebase
└── index.md            every task with its verdict, and knowledge-base counts
```

Commit `forge/` for shared engineering memory. Check scopes and evidence strings for anything sensitive
first, and decide whether every candidate's code should be committed or only the selected one.

## Pairs with TRACE

FORGE makes sure the software being written is as simple and effective as possible. TRACE investigates
why software failed. They share an evidence discipline, a workspace convention and the right to refuse
an answer. Either works alone: see `core/integration_with_trace.md`.
